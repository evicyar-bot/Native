package app.megastudiya.nativeapp

import android.content.Context
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

data class Post(val id: String, val author: String, val text: String, val ts: Long, val mine: Boolean = false, val aid: String = "", val pub: Boolean = true)

// Локальное хранилище: копия лежит в закрытой папке приложения, сети нет.
object Store {
    val posts = mutableStateListOf<Post>()
    var name by mutableStateOf("")
        private set
    var draft by mutableStateOf("")
        private set
    var follows: Set<String> = emptySet()
        private set
    var meId: String = ""
        private set
    private var imported = listOf<Post>()
    private val mine = ArrayList<Post>()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ms", Context.MODE_PRIVATE)

    fun setName(ctx: Context, v: String) {
        name = v.take(40)
        prefs(ctx).edit().putString("name", name).apply()
    }

    fun setDraft(ctx: Context, v: String) {
        draft = v
        prefs(ctx).edit().putString("draft", v).apply()
    }

    // pub = false: «только мне», пост остаётся личным и не уходит в публичное поле.
    fun publish(ctx: Context, pub: Boolean = true) {
        val t = draft.trim()
        if (t.isEmpty()) return
        val ts = System.currentTimeMillis()
        mine.add(Post("m$ts", name.ifBlank { "Я" }, t, ts, true, "", pub))
        saveMine(ctx)
        setDraft(ctx, "")
        rebuild()
    }

    fun delete(ctx: Context, id: String) {
        if (mine.removeAll { it.id == id }) { saveMine(ctx); rebuild() }
    }

    // Отозвать из публичного поля (pub = false) или сделать публичным (pub = true).
    fun setPub(ctx: Context, id: String, pub: Boolean) {
        val i = mine.indexOfFirst { it.id == id }
        if (i < 0) return
        mine[i] = mine[i].copy(pub = pub)
        saveMine(ctx); rebuild()
    }

    // Запись «всё или ничего»: пишем во временный файл, сбрасываем на диск, затем подменяем.
    // Прошлая целая версия остаётся в .bak. Обрыв питания или убийство процесса не портят файл.
    private fun writeAtomic(f: File, text: String) {
        try {
            val tmp = File(f.parentFile, f.name + ".tmp")
            FileOutputStream(tmp).use { it.write(text.toByteArray(Charsets.UTF_8)); it.fd.sync() }
            val bak = File(f.parentFile, f.name + ".bak")
            try {
                if (f.exists()) Files.move(f.toPath(), bak.toPath(), StandardCopyOption.REPLACE_EXISTING)
            } catch (_: Throwable) {
            }
            try {
                Files.move(tmp.toPath(), f.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
            } catch (_: Throwable) {
                if (!tmp.renameTo(f)) f.writeText(text)
            }
        } catch (_: Throwable) {
        }
    }

    // Читаем основной файл; если он битый или пропал, берём прошлую копию.
    private fun <T> readSafe(f: File, parse: (String) -> T): T? {
        for (c in listOf(f, File(f.parentFile, f.name + ".bak"))) {
            try {
                if (c.exists()) return parse(c.readText())
            } catch (_: Throwable) {
            }
        }
        return null
    }

    private fun saveMine(ctx: Context) {
        val a = JSONArray()
        mine.forEach { a.put(JSONObject().put("id", it.id).put("author", it.author).put("text", it.text).put("ts", it.ts).put("pub", it.pub)) }
        writeAtomic(File(ctx.filesDir, "my.json"), a.toString())
    }

    private fun rebuild() {
        val all = ArrayList<Post>(imported.size + mine.size)
        all.addAll(imported)
        all.addAll(mine)
        all.sortByDescending { it.ts }
        val seen = HashSet<String>()
        all.retainAll { seen.add((if (it.mine) "m" else "i") + it.id) } // одинаковый id показываем один раз
        posts.clear()
        posts.addAll(all)
    }

    fun load(ctx: Context) {
        name = prefs(ctx).getString("name", "") ?: ""
        draft = prefs(ctx).getString("draft", "") ?: ""
        readSafe(File(ctx.filesDir, "my.json")) { raw ->
            val a = JSONArray(raw)
            val out = ArrayList<Post>(a.length())
            for (i in 0 until a.length()) {
                val p = a.optJSONObject(i) ?: continue
                try {
                    out.add(Post(p.getString("id"), p.getString("author"), p.getString("text"), p.getLong("ts"), true, "", p.optBoolean("pub", true)))
                } catch (_: Throwable) {
                }
            }
            out
        }?.let { mine.clear(); mine.addAll(it.distinctBy { p -> p.id }) } // load() может вызываться повторно: не плодим копии
        rebuild()
        readSafe(File(ctx.filesDir, "copy.json")) { JSONObject(it) }?.let {
            try {
                apply(it)
            } catch (_: Throwable) {
            }
        }
    }

    // Файл «Копия» из старого приложения: либо зашифрованный (enc=1), либо обычный.
    // Бросает исключение при неверном пароле или чужом файле.
    fun parse(raw: String, pw: String): JSONObject {
        val o = JSONObject(raw)
        if (!o.has("enc")) return o
        val salt = Base64.decode(o.getString("salt"), Base64.DEFAULT)
        val iv = Base64.decode(o.getString("iv"), Base64.DEFAULT)
        val ct = Base64.decode(o.getString("data"), Base64.DEFAULT)
        val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pw.toCharArray(), salt, 250000, 256)).encoded
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return JSONObject(String(c.doFinal(ct), Charsets.UTF_8))
    }

    fun commit(ctx: Context, o: JSONObject) {
        writeAtomic(File(ctx.filesDir, "copy.json"), o.toString())
        apply(o)
    }

    private fun apply(o: JSONObject) {
        val authors = o.optJSONObject("authors") ?: JSONObject()
        val arr = o.optJSONArray("posts") ?: return
        meId = o.optJSONObject("me")?.optString("id") ?: ""
        val fo = o.optJSONObject("follows") ?: JSONObject()
        follows = fo.keys().asSequence().filter { fo.optBoolean(it, false) }.toSet()
        val hidden = o.optJSONObject("hidden") ?: JSONObject()
        val blocked = o.optJSONObject("blocked") ?: JSONObject()
        val list = ArrayList<Post>(arr.length())
        for (i in 0 until arr.length()) {
            val p = arr.optJSONObject(i) ?: continue
            val a = p.optString("author")
            val id = p.optString("id", i.toString())
            if (p.optBoolean("del", false) || hidden.optBoolean(id, false) || blocked.optBoolean(a, false)) continue
            list.add(Post(id, authors.optString(a, a), p.optString("text"), p.optLong("ts"), false, a))
        }
        imported = list
        rebuild()
    }
}
