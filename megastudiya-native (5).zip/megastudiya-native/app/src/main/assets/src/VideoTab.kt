package app.megastudiya.nativeapp

import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.net.Uri
import android.os.SystemClock
import android.widget.VideoView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// Вкладка «Видео»: базовая вертикальная лента на MediaHub (каталог, сигналы, порядок ForYouEngine) и MediaRepository (файлы).
// Один материал = одна страница на весь экран. Свайп вверх — следующий. Ничего не скачивает и не принимает: только показывает каталог.

private val VtAcc = Color(0xFF6EA8FF)
private const val VT_BATCH = 6

@Composable
fun VideoScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { MediaHub.load(ctx) }

    // Приложение ушло на задний план: воспроизведение и учёт времени просмотра останавливаются.
    var bg by remember { mutableStateOf(false) }
    val owner = ctx as? LifecycleOwner
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) bg = true else if (e == Lifecycle.Event.ON_RESUME) bg = false
        }
        owner?.lifecycle?.addObserver(ob)
        onDispose { owner?.lifecycle?.removeObserver(ob) }
    }

    val order = remember { mutableStateListOf<String>() }
    var exhausted by remember { mutableStateOf(false) }
    val visibleCount = MediaHub.cards.count { MediaHub.isVisible(it) }
    val pages = order.mapNotNull { id -> MediaHub.card(id)?.takeIf { MediaHub.isVisible(it) } }

    fun refill() {
        val more = MediaHub.plan(order.toList(), VT_BATCH)
        if (more.isEmpty()) exhausted = true else order.addAll(more)
    }

    LaunchedEffect(MediaHub.loaded, visibleCount) {
        if (MediaHub.loaded && (order.isEmpty() || exhausted)) { exhausted = false; refill() }
    }

    val pager = rememberPagerState { pages.size + if (exhausted) 1 else 0 }

    LaunchedEffect(pager.settledPage, pages.size) {
        if (pages.isNotEmpty() && !exhausted && pager.settledPage >= pages.size - 2) refill()
    }

    // Просмотр засчитывается, когда страницу покинули (или приложение ушло в фон, или вкладку закрыли).
    val cur = pager.settledPage
    val curCard = pages.getOrNull(cur)
    DisposableEffect(cur, curCard?.id, bg) {
        val c = curCard
        val on = !bg
        val t0 = SystemClock.elapsedRealtime()
        onDispose {
            if (c != null && on) MediaHub.signalView(c.id, SystemClock.elapsedRealtime() - t0, c.durationMs, 0)
        }
    }

    if (!MediaHub.loaded) return
    if (pages.isEmpty() && !exhausted) {
        Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Здесь пока пусто", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Видео, фото и ссылки появятся в этой ленте, когда попадут в каталог.",
                    color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
        return
    }

    VerticalPager(pager, Modifier.fillMaxSize(), key = { it }) { i ->
        val c = pages.getOrNull(i)
        if (c == null) {
            EndPage {
                MediaHub.restartSession()
                order.clear(); exhausted = false; refill()
                scope.launch { pager.scrollToPage(0) }
            }
        } else {
            VideoPage(c, active = pager.currentPage == i, bg = bg)
        }
    }
}

@Composable
private fun EndPage(onRestart: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Это всё на сейчас", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(
                "Показанное ненадолго скрыто, чтобы не повторяться.",
                color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 6.dp)
            )
            Text(
                "Смотреть сначала", color = VtAcc, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 18.dp).clip(RoundedCornerShape(999.dp))
                    .background(Color(0x336EA8FF)).clickable { onRestart() }.padding(horizontal = 20.dp, vertical = 12.dp)
            )
        }
    }
}

@Composable
private fun VideoPage(c: VideoCard, active: Boolean, bg: Boolean) {
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize()) {
        when (c.kind) {
            Mk.LOCAL -> VideoPlayer(c, active, bg)
            Mk.IMAGE -> {
                val bmp = rememberBitmap(remember(c.file) { MediaRepository.fileOf(ctx, c.file) }, 1600)
                if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            }
            else -> LinkPage(c)
        }

        // подпись снизу слева
        Column(
            Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(start = 16.dp, end = 84.dp, bottom = 100.dp)
        ) {
            if (c.kind != Mk.LINK && c.title.isNotEmpty()) {
                Text(c.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            val who = listOf(c.author, Mk.sourceLabel(c.source)).filter { it.isNotEmpty() }.joinToString(" · ")
            Text(who, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
            if (c.tags.isNotEmpty()) {
                Text(
                    c.tags.take(3).joinToString(" ") { "#$it" }, color = VtAcc, fontSize = 13.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp)
                )
            }
        }

        // действия справа
        Column(
            Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 14.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val liked = c.id in MediaHub.likedIds
            val saved = c.id in MediaHub.savedIds
            RoundAction(onClick = { MediaHub.toggleLike(c.id) }) {
                Text(if (liked) "♥" else "♡", color = if (liked) VtAcc else Color.White, fontSize = 22.sp)
            }
            RoundAction(onClick = { MediaHub.toggleSave(c.id) }) {
                DockIcon(2, if (saved) VtAcc else Color.White, 24.dp)
            }
        }
    }
}

@Composable
private fun RoundAction(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(48.dp).clip(CircleShape).background(Color(0x66000000)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun LinkPage(c: VideoCard) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(start = 24.dp, end = 24.dp, top = 70.dp, bottom = 200.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            Mk.sourceLabel(c.source), color = VtAcc, fontSize = 13.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(RoundedCornerShape(999.dp)).background(Color(0x336EA8FF)).padding(horizontal = 12.dp, vertical = 5.dp)
        )
        Text(
            c.title.ifEmpty { c.url }, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
            maxLines = 4, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 14.dp)
        )
        if (c.desc.isNotEmpty() && c.desc != c.title) {
            Text(
                c.desc, color = Color.White.copy(alpha = 0.7f), fontSize = 15.sp,
                maxLines = 6, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 10.dp)
            )
        }
        Text(
            "Открыть оригинал", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 20.dp).clip(RoundedCornerShape(999.dp)).background(Color(0x33FFFFFF))
                .clickable {
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(c.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        MediaHub.signalOpen(c.id)
                    } catch (_: Throwable) {
                    }
                }.padding(horizontal = 20.dp, vertical = 12.dp)
        )
    }
}

@Composable
private fun VideoPlayer(c: VideoCard, active: Boolean, bg: Boolean) {
    val ctx = LocalContext.current
    val path = remember(c.file) { MediaRepository.fileOf(ctx, c.file).absolutePath }
    val thumbFile = remember(c.id, c.thumb) { MediaRepository.thumbFile(ctx, c) }
    // превью можно удалять (очистка кэша): если его нет, оно пересоздаётся
    LaunchedEffect(c.id, thumbFile == null) { if (thumbFile == null) MediaHub.ensureThumb(ctx, c.id) }
    val thumb = rememberBitmap(thumbFile, 1080)

    var started by remember { mutableStateOf(false) }
    var prepared by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    LaunchedEffect(active) { if (!active) { started = false; prepared = false } }

    Box(Modifier.fillMaxSize()) {
        if (!started && thumb != null) Image(thumb, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        if (active && !failed) {
            val playing = !paused && !bg
            AndroidView(
                factory = { x ->
                    VideoView(x).apply {
                        setOnPreparedListener { mp ->
                            mp.isLooping = true
                            mp.setOnInfoListener { _, what, _ ->
                                if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) started = true
                                false
                            }
                            prepared = true
                        }
                        setOnErrorListener { _, _, _ -> failed = true; true }
                        setVideoPath(path)
                    }
                },
                modifier = Modifier.fillMaxSize(),
                update = { v ->
                    if (prepared) {
                        if (playing) { if (!v.isPlaying) v.start() } else if (v.isPlaying) v.pause()
                    }
                }
            )
            // касание ставит на паузу и снимает с неё
            Box(
                Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { paused = !paused }
            )
        }
        if (failed) {
            Text(
                "Не удаётся воспроизвести", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp,
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}

@Composable
private fun rememberBitmap(file: File?, maxSide: Int): ImageBitmap? {
    val bmp by produceState<ImageBitmap?>(null, file?.path) {
        value = if (file == null) null else withContext(Dispatchers.IO) { decodeSampled(file, maxSide) }
    }
    return bmp
}

private fun decodeSampled(f: File, maxSide: Int): ImageBitmap? = try {
    val o = BitmapFactory.Options().also { it.inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.absolutePath, o)
    var s = 1
    while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= maxSide) s *= 2
    val o2 = BitmapFactory.Options().also { it.inSampleSize = s }
    BitmapFactory.decodeFile(f.absolutePath, o2)?.asImageBitmap()
} catch (_: Throwable) {
    null
}
