package app.megastudiya.nativeapp

import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.net.Uri
import android.os.SystemClock
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.VideoView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// Вкладка «Видео»: базовая вертикальная лента на MediaHub (каталог, сигналы, порядок ForYouEngine) и MediaRepository (файлы).
// Один материал = одна страница на весь экран. Свайп вверх — следующий. Ничего не скачивает и не принимает: только показывает каталог.

private val VtAcc = Color(0xFF6EA8FF)
private const val VT_BATCH = 6
private const val EMBED_TIMEOUT_MS = 15000L

@Composable
fun VideoScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { MediaHub.load(ctx) }

    // Приложение ушло на задний план: воспроизведение и учёт времени просмотра останавливаются.
    var bg by remember { mutableStateOf(false) }
    val owner = ctx as? LifecycleOwner
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) bg = true else if (e == Lifecycle.Event.ON_RESUME) bg = false
        }
        owner?.lifecycle?.addObserver(ob)
        onDispose { owner?.lifecycle?.removeObserver(ob) }
    }

    val order = remember { mutableStateListOf<String>() }
    var exhausted by remember { mutableStateOf(false) }
    val visibleCount = MediaHub.cards.count { MediaHub.isVisible(it) }
    val connectorRev = ConnectorSetup.rev
    val autoDiscoveryConfigured = remember(connectorRev) { ConnectorSetup.hasTikTokDiscoveryToken(ctx) }
    val pages = order.mapNotNull { id -> MediaHub.card(id)?.takeIf { MediaHub.isVisible(it) } }

    fun refill() {
        val more = MediaHub.plan(order.toList(), VT_BATCH)
        if (more.isEmpty()) exhausted = true else order.addAll(more)
    }

    LaunchedEffect(MediaHub.loaded, visibleCount, autoDiscoveryConfigured) {
        if (MediaHub.loaded && (order.isEmpty() || exhausted)) { exhausted = false; refill() }
        if (MediaHub.loaded && autoDiscoveryConfigured && visibleCount < 8 && !MediaHub.discoveryBusy) MediaHub.discoverTikTok(ctx)
    }

    val pager = rememberPagerState { pages.size + if (exhausted) 1 else 0 }

    LaunchedEffect(pager.settledPage, pages.size, exhausted) {
        if (pages.isNotEmpty() && !exhausted && pager.settledPage >= pages.size - 2) refill()
        if (pages.isNotEmpty() && exhausted && autoDiscoveryConfigured && pager.settledPage >= pages.size - 1 && !MediaHub.discoveryBusy) {
            MediaHub.discoverTikTok(ctx, done = { msg ->
                if (MediaHub.cards.count { MediaHub.isVisible(it) } > pages.size) {
                    order.clear(); exhausted = false; refill(); scope.launch { pager.scrollToPage(0) }
                }
            })
        }
    }

    // Просмотр засчитывается, когда страницу покинули (или приложение ушло в фон, или вкладку закрыли).
    val cur = pager.settledPage
    val curCard = pages.getOrNull(cur)
    DisposableEffect(cur, curCard?.id, bg) {
        val c = curCard
        val on = !bg
        val t0 = SystemClock.elapsedRealtime()
        onDispose {
            if (c != null && on) MediaHub.signalView(c.id, SystemClock.elapsedRealtime() - t0, c.durationMs, 0)
        }
    }

    if (!MediaHub.loaded) return
    // Каталог пуст (нет ни одной карточки) — показываем причину и способы наполнить ленту, а не «Это всё на сейчас».
    if (pages.isEmpty() && (!exhausted || visibleCount == 0)) {
        EmptyFeed(autoDiscoveryConfigured)
        return
    }

    VerticalPager(pager, Modifier.fillMaxSize(), key = { it }) { i ->
        val c = pages.getOrNull(i)
        if (c == null) {
            EndPage {
                MediaHub.restartSession()
                order.clear(); exhausted = false; refill()
                scope.launch { pager.scrollToPage(0) }
            }
        } else {
            VideoPage(c, active = pager.currentPage == i, bg = bg)
        }
    }
}

@Composable
private fun EmptyFeed(autoOn: Boolean) {
    val ctx = LocalContext.current
    var note by remember { mutableStateOf("") }
    val reason = when {
        !autoOn -> "Автопоиск выключен: не задан токен Apify («Я» → «Источники видео»). Без него видео сами не появятся."
        MediaHub.discoveryBusy -> "Ищем публичные TikTok-видео…"
        MediaHub.discoveryMessage.isNotEmpty() -> "Автопоиск: " + MediaHub.discoveryMessage
        else -> "Автопоиск ещё не вернул видео."
    }
    Column(
        Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Здесь пока пусто", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(reason, color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
        Text(
            "Добавить видео сейчас: скопируйте ссылку на ролик TikTok, YouTube или пост Telegram и нажмите кнопку.",
            color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 14.dp)
        )
        Text(
            "Вставить ссылку из буфера", color = VtAcc, fontSize = 16.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 14.dp).clip(RoundedCornerShape(999.dp)).background(Color(0x336EA8FF))
                .clickable {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    val t = try { cm?.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty().trim() } catch (_: Throwable) { "" }
                    // из «Поделиться» TikTok часто копируется текст со ссылкой внутри: берём все ссылки из буфера
                    val urls = Regex("""https?://[^\s<>"']+""", RegexOption.IGNORE_CASE).findAll(t).map { it.value.trimEnd('.', ',', ')') }.distinct().take(10).toList()
                    if (urls.isEmpty()) note = "В буфере нет ссылки: скопируйте ссылку на видео и нажмите снова"
                    else {
                        note = "Добавляю…"
                        MediaHub.ingestBatch(ctx, emptyList(), null, "link", urls, "", false) { sum -> note = sum.text() }
                    }
                }.padding(horizontal = 20.dp, vertical = 12.dp)
        )
        if (autoOn) {
            Text(
                "Повторить автопоиск", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 10.dp).clip(RoundedCornerShape(999.dp)).background(Color(0x33FFFFFF))
                    .clickable { if (!MediaHub.discoveryBusy) MediaHub.discoverTikTok(ctx, force = true) }
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            )
        }
        if (note.isNotEmpty()) Text(note, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 14.dp))
    }
}

@Composable
private fun EndPage(onRestart: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Это всё на сейчас", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(
                "Показанное ненадолго скрыто, чтобы не повторяться.",
                color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 6.dp)
            )
            Text(
                "Смотреть сначала", color = VtAcc, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 18.dp).clip(RoundedCornerShape(999.dp))
                    .background(Color(0x336EA8FF)).clickable { onRestart() }.padding(horizontal = 20.dp, vertical = 12.dp)
            )
        }
    }
}

@Composable
private fun VideoPage(c: VideoCard, active: Boolean, bg: Boolean) {
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize()) {
        when (c.kind) {
            Mk.LOCAL -> VideoPlayer(c, active, bg)
            Mk.IMAGE -> {
                val bmp = rememberBitmap(remember(c.file) { MediaRepository.fileOf(ctx, c.file) }, 1600)
                if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            }
            else -> {
                val yt = ytEmbedId(c)
                val tg = tgEmbedRef(c)
                when {
                    c.canEmbed && c.streamUrl.isNotBlank() -> TikTokStream(c, active, bg)
                    c.canEmbed -> TikTokEmbed(c, active, bg)
                    yt.isNotEmpty() -> PlayerEmbed(c, active, bg, yt, null)
                    tg != null -> PlayerEmbed(c, active, bg, "", tg)
                    else -> LinkPage(c)
                }
            }
        }

        // подпись снизу слева
        Column(
            Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(start = 16.dp, end = 84.dp, bottom = 100.dp)
        ) {
            if (c.kind != Mk.LINK && c.title.isNotEmpty()) {
                Text(c.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            val who = listOf(c.author, Mk.sourceLabel(c.source)).filter { it.isNotEmpty() }.joinToString(" · ")
            Text(who, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
            if (c.tags.isNotEmpty()) {
                Text(
                    c.tags.take(3).joinToString(" ") { "#$it" }, color = VtAcc, fontSize = 13.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp)
                )
            }
        }

        // действия справа
        Column(
            Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 14.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val liked = c.id in MediaHub.likedIds
            val saved = c.id in MediaHub.savedIds
            RoundAction(onClick = { MediaHub.toggleLike(c.id) }) {
                Text(if (liked) "♥" else "♡", color = if (liked) VtAcc else Color.White, fontSize = 22.sp)
            }
            RoundAction(onClick = { MediaHub.toggleSave(c.id) }) {
                DockIcon(2, if (saved) VtAcc else Color.White, 24.dp)
            }
        }
    }
}

@Composable
private fun RoundAction(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(48.dp).clip(CircleShape).background(Color(0x66000000)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun LinkPage(c: VideoCard, note: String? = null, showOpen: Boolean = true) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(start = 24.dp, end = 24.dp, top = 70.dp, bottom = 200.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            Mk.sourceLabel(c.source), color = VtAcc, fontSize = 13.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(RoundedCornerShape(999.dp)).background(Color(0x336EA8FF)).padding(horizontal = 12.dp, vertical = 5.dp)
        )
        Text(
            c.title.ifEmpty { c.url }, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
            maxLines = 4, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 14.dp)
        )
        if (c.desc.isNotEmpty() && c.desc != c.title) {
            Text(
                c.desc, color = Color.White.copy(alpha = 0.7f), fontSize = 15.sp,
                maxLines = 6, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 10.dp)
            )
        }
        if (note != null) {
            Text(note, color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, modifier = Modifier.padding(top = 14.dp))
        }
        if (showOpen) {
            Text(
                "Открыть оригинал", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 20.dp).clip(RoundedCornerShape(999.dp)).background(Color(0x33FFFFFF))
                    .clickable {
                        try {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(c.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            MediaHub.signalOpen(c.id)
                        } catch (_: Throwable) {
                        }
                    }.padding(horizontal = 20.dp, vertical = 12.dp)
            )
        }
    }
}

// Временный CDN URL из поискового API: пробуем native VideoView, при истёкшем URL — официальный embed.
@Composable
private fun TikTokStream(c: VideoCard, active: Boolean, bg: Boolean) {
    var failed by remember(c.id, c.streamUrl) { mutableStateOf(false) }
    var prepared by remember(c.id, c.streamUrl) { mutableStateOf(false) }
    LaunchedEffect(active) { if (!active) { failed = false; prepared = false } }
    if (!active || failed) {
        TikTokEmbed(c, active, bg)
        return
    }
    AndroidView(
        factory = { ctx -> VideoView(ctx).apply {
            setOnPreparedListener { mp -> mp.isLooping = true; prepared = true }
            setOnErrorListener { _, _, _ -> failed = true; true }
            setVideoURI(Uri.parse(c.streamUrl))
        } },
        modifier = Modifier.fillMaxSize(),
        update = { v -> if (prepared) { if (bg) v.pause() else if (!v.isPlaying) v.start() } },
        onRelease = { v -> v.stopPlayback() }
    )
}

// Официальный TikTok Embed Player (https://www.tiktok.com/player/v1/<id>): iframe внутри WebView, ролик не скачивается.
// Обёртка страницы слушает сообщения плеера (postMessage) и передаёт их приложению через console.log.
private fun embedHtml(vid: String): String =
    "<!DOCTYPE html><html><head><meta charset=\"utf-8\">" +
        "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
        "<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}" +
        "#l{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#777;font:15px sans-serif}" +
        "#p{position:absolute;inset:0;width:100%;height:100%;border:0}</style></head><body>" +
        "<div id=\"l\">Загрузка…</div>" +
        "<iframe id=\"p\" src=\"https://www.tiktok.com/player/v1/$vid?autoplay=1&loop=1&controls=0&rel=0\" " +
        "allow=\"autoplay; fullscreen; encrypted-media\" title=\"TikTok\"></iframe>" +
        "<script>" +
        "window.addEventListener('message',function(e){" +
        "if(e.origin!=='https://www.tiktok.com')return;var d=e.data;" +
        "if(typeof d==='string'){try{d=JSON.parse(d)}catch(x){return}}" +
        "if(d&&d['x-tiktok-player']){console.log('MSTK|'+d.type+'|'+(d.value===undefined?'':JSON.stringify(d.value)))}});" +
        "function cmd(t){document.getElementById('p').contentWindow.postMessage({type:t,'x-tiktok-player':true},'*')}" +
        "</script></body></html>"

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun TikTokEmbed(c: VideoCard, active: Boolean, bg: Boolean) {
    val vid = c.embedVideoId
    var ready by remember(c.id) { mutableStateOf(false) }
    var failed by remember(c.id) { mutableStateOf(false) }
    var userPaused by remember(c.id) { mutableStateOf(false) }
    val web = remember { arrayOfNulls<WebView>(1) }

    LaunchedEffect(active) { if (!active) { ready = false; failed = false; userPaused = false } }
    // встраивание отключено или плеер не ответил: страница не зависает, а предлагает открыть оригинал
    LaunchedEffect(active, c.id) {
        if (active) { delay(EMBED_TIMEOUT_MS); if (!ready) failed = true }
    }
    // команды плееру: пауза по касанию и при уходе приложения в фон
    val wantPlay = !userPaused && !bg
    LaunchedEffect(wantPlay, ready) {
        if (ready) web[0]?.evaluateJavascript("cmd('" + (if (wantPlay) "play" else "pause") + "')", null)
    }

    Box(Modifier.fillMaxSize()) {
        if (!active) {
            LinkPage(c, showOpen = false)
        } else if (failed) {
            LinkPage(c, note = "Этот ролик не удалось показать внутри приложения: автор или TikTok не разрешают встраивание, ролик удалён или нет соединения.")
        } else {
            AndroidView(
                factory = { x ->
                    WebView(x).apply {
                        setBackgroundColor(android.graphics.Color.BLACK)
                        isVerticalScrollBarEnabled = false
                        overScrollMode = android.view.View.OVER_SCROLL_NEVER
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.allowFileAccess = false
                        settings.allowContentAccess = false
                        settings.setSupportZoom(false)
                        // уйти со страницы-обёртки нельзя: переходы верхнего уровня блокируются
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = request.isForMainFrame
                        }
                        webChromeClient = object : WebChromeClient() {
                            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                                val parts = m.message().split('|', limit = 3)
                                if (parts.size == 3 && parts[0] == "MSTK") {
                                    val type = parts[1]
                                    val value = parts[2]
                                    when {
                                        type == "onPlayerReady" -> ready = true
                                        type.contains("error", ignoreCase = true) ->
                                            // 3002: браузер не дал автозапуск — это не ошибка встраивания, ждём касания
                                            if (value.contains("3002")) { ready = true; userPaused = true } else failed = true
                                    }
                                }
                                return true
                            }
                        }
                        web[0] = this
                        loadDataWithBaseURL(YouTubeConfig.embedOrigin.trimEnd('/') + "/", embedHtml(vid), "text/html", "utf-8", null)
                    }
                },
                modifier = Modifier.fillMaxSize(),
                update = { v -> if (bg) v.onPause() else v.onResume() },
                onRelease = { v ->
                    web[0] = null
                    (v.parent as? android.view.ViewGroup)?.removeView(v)
                    v.stopLoading()
                    v.destroy()
                }
            )
            // касание ставит на паузу и снимает с неё; вертикальные свайпы уходят в ленту
            Box(
                Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { userPaused = !userPaused }
            )
        }
    }
}

// Встроенные плееры YouTube (IFrame Player API) и Telegram (виджет поста). Ролики и посты не скачиваются.
// Идентификатор берётся из метаданных карточки, у старых карточек — из ключа «yt:<id>» / из канонической ссылки t.me/<канал>/<номер>.
private val YtIdRe = Regex("^[A-Za-z0-9_-]{6,15}$")
private val TgUrlRe = Regex("^https://t\\.me/([A-Za-z0-9_]{4,32})/(\\d+)$")

private fun ytEmbedId(c: VideoCard): String {
    if (c.source != "youtube") return ""
    val id = c.embedId.ifEmpty { if (c.dedupKey.startsWith("yt:")) c.dedupKey.removePrefix("yt:") else "" }
    return if (YtIdRe.matches(id)) id else ""
}

private fun tgEmbedRef(c: VideoCard): Pair<String, Long>? {
    if (c.source != "telegram") return null
    val m = TgUrlRe.matchEntire(c.url) ?: return null
    val post = m.groupValues[2].toLongOrNull() ?: return null
    return if (post > 0) m.groupValues[1] to post else null
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun PlayerEmbed(c: VideoCard, active: Boolean, bg: Boolean, ytId: String, tg: Pair<String, Long>?) {
    val isYt = ytId.isNotEmpty()
    var ready by remember(c.id) { mutableStateOf(false) }
    var failed by remember(c.id) { mutableStateOf(false) }
    var failNote by remember(c.id) { mutableStateOf("") }
    var userPaused by remember(c.id) { mutableStateOf(false) }
    var interactive by remember(c.id) { mutableStateOf(false) }   // Telegram: пост открыт для касаний
    val web = remember { arrayOfNulls<WebView>(1) }

    LaunchedEffect(active) { if (!active) { ready = false; failed = false; userPaused = false; interactive = false } }
    LaunchedEffect(active, c.id) {
        if (active) { delay(EMBED_TIMEOUT_MS); if (!ready) failed = true }
    }
    // команды плееру YouTube: пауза по касанию и при уходе приложения в фон (у виджета Telegram своих команд нет)
    val wantPlay = !userPaused && !bg
    LaunchedEffect(wantPlay, ready) {
        if (isYt && ready) web[0]?.evaluateJavascript("cmd('" + (if (wantPlay) "play" else "pause") + "')", null)
    }

    Box(Modifier.fillMaxSize()) {
        if (!active) {
            LinkPage(c, showOpen = false)
        } else if (failed) {
            LinkPage(
                c, note = failNote.ifEmpty {
                    if (isYt) "Этот ролик не удалось показать внутри приложения: автор запретил встраивание, ролик удалён или нет соединения."
                    else "Этот пост не удалось показать внутри приложения: канал не публичный, пост удалён или нет соединения."
                }
            )
        } else {
            AndroidView(
                factory = { x ->
                    WebView(x).apply {
                        setBackgroundColor(android.graphics.Color.BLACK)
                        isVerticalScrollBarEnabled = false
                        overScrollMode = android.view.View.OVER_SCROLL_NEVER
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.allowFileAccess = false
                        settings.allowContentAccess = false
                        settings.setSupportZoom(false)
                        // уйти со страницы-обёртки нельзя: переходы верхнего уровня блокируются
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = request.isForMainFrame
                            override fun onPageFinished(view: WebView, url: String?) { if (!isYt) ready = true }
                            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                                if (request.isForMainFrame) failed = true
                            }
                        }
                        webChromeClient = object : WebChromeClient() {
                            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                                val e = YouTubeEmbed.parse(m.message()) ?: return true
                                when {
                                    e.type == "onReady" -> ready = true
                                    YouTubeEmbed.isEmbedBlocked(e) -> { failNote = "Автор запретил встраивание этого ролика."; failed = true }
                                    YouTubeEmbed.isGone(e) -> { failNote = "Ролик удалён или закрыт автором."; failed = true }
                                    YouTubeEmbed.isConfigError(e) -> { failNote = "Плеер YouTube не принял адрес приложения (ошибка 153)."; failed = true }
                                    e.type == "onError" -> failed = true
                                }
                                return true
                            }
                        }
                        web[0] = this
                        val html = if (isYt) YouTubeEmbed.html(ytId) else TelegramEmbed.html(tg!!.first, tg.second)
                        val base = if (isYt) YouTubeConfig.embedOrigin.trimEnd('/') + "/" else "https://t.me/"
                        if (html.isEmpty()) failed = true else loadDataWithBaseURL(base, html, "text/html", "utf-8", null)
                    }
                },
                modifier = Modifier.fillMaxSize(),
                update = { v -> if (bg) v.onPause() else v.onResume() },
                onRelease = { v ->
                    web[0] = null
                    (v.parent as? android.view.ViewGroup)?.removeView(v)
                    v.stopLoading()
                    v.destroy()
                }
            )
            // Конфликт жестов решается слоями над WebView: WebView забирает касание целиком, поэтому свайп по нему ленте не доходит.
            // YouTube: слой на весь экран. Касание — пауза, вертикальные свайпы проходят в ленту (WebView их не видит).
            // Telegram: пока пост «закрыт», слой на весь экран, свайпы работают как везде; касание «открывает» пост для управления
            //   (воспроизведение видео в виджете). В открытом режиме верхняя и нижняя четверти остаются слоем для свайпов,
            //   середина отдана виджету. Страница сбрасывается в «закрытый» режим при уходе с неё.
            if (isYt) {
                Box(
                    Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { userPaused = !userPaused }
                )
            } else if (!interactive) {
                Box(
                    Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { interactive = true }
                )
                Text(
                    "Коснитесь, чтобы управлять постом", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 64.dp)
                        .clip(RoundedCornerShape(999.dp)).background(Color(0x66000000)).padding(horizontal = 12.dp, vertical = 6.dp)
                )
            } else {
                Column(Modifier.fillMaxSize()) {
                    Box(Modifier.fillMaxWidth().weight(1f).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { })
                    Box(Modifier.fillMaxWidth().weight(2f))
                    Box(Modifier.fillMaxWidth().weight(1f).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { })
                }
            }
        }
    }
}

@Composable
private fun VideoPlayer(c: VideoCard, active: Boolean, bg: Boolean) {
    val ctx = LocalContext.current
    val path = remember(c.file) { MediaRepository.fileOf(ctx, c.file).absolutePath }
    val thumbFile = remember(c.id, c.thumb) { MediaRepository.thumbFile(ctx, c) }
    // превью можно удалять (очистка кэша): если его нет, оно пересоздаётся
    LaunchedEffect(c.id, thumbFile == null) { if (thumbFile == null) MediaHub.ensureThumb(ctx, c.id) }
    val thumb = rememberBitmap(thumbFile, 1080)

    var started by remember { mutableStateOf(false) }
    var prepared by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    LaunchedEffect(active) { if (!active) { started = false; prepared = false } }

    Box(Modifier.fillMaxSize()) {
        if (!started && thumb != null) Image(thumb, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        if (active && !failed) {
            val playing = !paused && !bg
            AndroidView(
                factory = { x ->
                    VideoView(x).apply {
                        setOnPreparedListener { mp ->
                            mp.isLooping = true
                            mp.setOnInfoListener { _, what, _ ->
                                if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) started = true
                                false
                            }
                            prepared = true
                        }
                        setOnErrorListener { _, _, _ -> failed = true; true }
                        setVideoPath(path)
                    }
                },
                modifier = Modifier.fillMaxSize(),
                update = { v ->
                    if (prepared) {
                        if (playing) { if (!v.isPlaying) v.start() } else if (v.isPlaying) v.pause()
                    }
                }
            )
            // касание ставит на паузу и снимает с неё
            Box(
                Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { paused = !paused }
            )
        }
        if (failed) {
            Text(
                "Не удаётся воспроизвести", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp,
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}

@Composable
private fun rememberBitmap(file: File?, maxSide: Int): ImageBitmap? {
    val bmp by produceState<ImageBitmap?>(null, file?.path) {
        value = if (file == null) null else withContext(Dispatchers.IO) { decodeSampled(file, maxSide) }
    }
    return bmp
}

private fun decodeSampled(f: File, maxSide: Int): ImageBitmap? = try {
    val o = BitmapFactory.Options().also { it.inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.absolutePath, o)
    var s = 1
    while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= maxSide) s *= 2
    val o2 = BitmapFactory.Options().also { it.inSampleSize = s }
    BitmapFactory.decodeFile(f.absolutePath, o2)?.asImageBitmap()
} catch (_: Throwable) {
    null
}
