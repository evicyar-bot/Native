# TikTok auto-fill feed (implementation notes)

The Video tab now has an optional public-video discovery provider. It uses the Apify Actor `scrapysocial/tiktok-scraper` and its `search-videos` endpoint. It does not require TikTok login. It is a third-party scraper, not TikTok's official API; public search availability and playback can change, and use must comply with applicable platform terms and privacy law.

## Configure
1. Create/use an Apify account and obtain an API token from Apify Console → Settings → Integrations.
2. In Megastudiya → Sources for Video → Automatic TikTok feed, paste the token and Save. The app encrypts the token using the same device-keystore secret storage used for other connector credentials.
3. Tap **Check search** to make a small initial request. The search is limited to two topic queries, five items per query per run. Results are de-duplicated by TikTok video ID and saved to the existing MediaHub catalog.
4. Open the Video tab. If fewer than eight catalog items exist, discovery is triggered automatically; additional batches are requested as the session runs out of recommendations.

## Playback
Each result is a TikTok public video card. If the Actor returns a temporary direct CDN playback URL, the app tries native Android playback first. If it fails or the signed URL expires, the app falls back to TikTok's official embedded player. Direct URLs are temporary and are not a permanent media archive.

## Provider API
The implementation calls Apify's synchronous run-and-read-dataset endpoint over HTTPS using Bearer authentication. The Actor input uses `endpoint=search-videos`, a keyword, `count`/`maxItems` limits. It parses the Actor's documented result fields (`id`, `description`, `author.username`, `video.cover`, `video.playUrl`, and hashtags), while tolerating a few alternate field names.

A build and on-device playback test are still required before treating this as production-ready. This workspace currently has no Android SDK, Gradle executable, or Gradle wrapper, so an APK could not be compiled here.
