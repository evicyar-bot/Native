package app.megastudiya.nativeapp

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Public TikTok search through a configured Apify Actor. Returns public links and metadata only. */
object TikTokDiscovery {
    private const val ACTOR = "scrapysocial~tiktok-scraper"
    private const val API = "https://api.apify.com/v2/acts/$ACTOR/run-sync-get-dataset-items"
    val defaultQueries = listOf("funny videos", "street food", "travel", "animals", "technology", "fashion", "music", "interesting facts")
    data class Item(val videoId: String, val url: String, val title: String, val author: String, val thumb: String, val streamUrl: String, val tags: List<String>)
    data class Result(val items: List<Item>, val message: String)

    fun discover(token: String, queries: List<String> = defaultQueries, maxPerQuery: Int = 8): Result {
        if (token.isBlank()) return Result(emptyList(), "Для автопоиска нужен Apify API token в настройках источников")
        val found = LinkedHashMap<String, Item>()
        val qlist = queries.filter { it.isNotBlank() }.distinct().take(2)
        if (qlist.isEmpty()) return Result(emptyList(), "Нет поисковых тем")
        for (q in qlist) {
            val input = JSONObject().put("endpoint", "search-videos").put("keyword", q).put("count", maxPerQuery).put("maxItems", maxPerQuery)
            val conn = (URL(API + "?timeout=60&limit=" + maxPerQuery).openConnection() as HttpURLConnection)
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 70000
                conn.doOutput = true
                conn.setRequestProperty("Authorization", "Bearer $token")
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("Accept", "application/json")
                conn.outputStream.use { it.write(input.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val body = (if (code in 200..299) conn.inputStream else conn.errorStream)?.use { it.readBytes().toString(Charsets.UTF_8) }.orEmpty()
                if (code !in 200..299) return Result(found.values.toList(), "Apify HTTP $code: ${body.take(220)}")
                val arr = JSONArray(body)
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val id = first(o, "id", "videoId", "awemeId")
                    val authorObj = o.optJSONObject("author") ?: o.optJSONObject("authorMeta")
                    val author = authorObj?.let { first(it, "username", "uniqueId", "name", "nickname") }.orEmpty()
                    val rawUrl = first(o, "webVideoUrl", "videoUrl", "url", "shareUrl")
                    val url = rawUrl.ifEmpty { if (id.isNotBlank() && author.isNotBlank()) "https://www.tiktok.com/@$author/video/$id" else "" }
                    if (id.isBlank() || url.isBlank() || !url.contains("tiktok.com")) continue
                    val canonical = LinkNorm.parse(url)?.canonical ?: url
                    val title = first(o, "description", "text", "title", "desc", "caption").take(300)
                    val meta = o.optJSONObject("video") ?: o.optJSONObject("videoMeta")
                    val thumb = first(o, "coverUrl", "thumbnail", "thumbnailUrl", "cover").ifEmpty { meta?.let { first(it, "cover", "coverUrl", "originCover") }.orEmpty() }
                    val stream = meta?.let { first(it, "playUrl", "downloadUrl") }.orEmpty()
                    val hashtagList = o.optJSONArray("hashtags")
                    val tags = if (hashtagList != null) (0 until hashtagList.length()).map { hashtagList.optString(it).removePrefix("#") }.filter { it.isNotBlank() } else MhTags.of(title)
                    found.putIfAbsent("tiktok:$id", Item(id, canonical, title, author, thumb, stream, tags))
                }
            } finally { conn.disconnect() }
        }
        return Result(found.values.toList(), if (found.isEmpty()) "Поисковик не вернул публичные ролики" else "Найдено ${found.size} роликов")
    }

    private fun first(o: JSONObject, vararg keys: String): String {
        for (k in keys) {
            val v = o.opt(k)
            if (v is String && v.isNotBlank()) return v
            if (v is Number) return v.toString()
        }
        return ""
    }
}
