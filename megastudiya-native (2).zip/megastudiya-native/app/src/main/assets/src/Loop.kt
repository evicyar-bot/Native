package app.megastudiya.nativeapp

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

// LOOP RUNNER: замкнутый цикл самостоятельной работы. Испытания выдаёт только владелец («цикл ещё»).
//   проект-исследование (Purpose) → стратегия (Agency) → чтение (Core.loopRead) → проверка ОБЪЁМА → дневник.
// Границы (решение владельца 14.11.2026):
//  • R0/R1: само; чтение только из разрешённых источников (сейчас только ru.wikipedia.org).
//  • R2 (запись в Workspace) здесь НЕ реализована и остаётся ручной.
//  • R3, R4, ядро, защитные механизмы, лимиты безопасности и права цикл менять не может.
//  • У задачи: потолок шагов, чтений и активного времени; контрольная точка до каждого действия; журнал; рубильник.
//  • Mentor в цикле не вызывается, расход токенов задачи равен нулю.
// Четыре исхода, не смешиваются:
//  1) ВРЕМЕННАЯ ОШИБКА СЕТИ (нет сети, платная сеть, дневной лимит): пауза 5/15/30 мин (лимит: 60), чтение и шаг НЕ тратятся,
//     задача ждёт и возобновляется сама; через сутки без сети прерывается без записи итога.
//  2) НЕУДАЧА ЧТЕНИЯ (источник ответил ошибкой, пустой поиск, слишком короткий текст): одна повторная попытка через 5 мин,
//     затем остановка БЕЗ записи неудачи в Agency; стратегия остаётся одобренной, решает владелец.
//  3) НЕДОСТАТОЧНЫЙ ОБЪЁМ (текст прочитан, но мало): тоже без записи неудачи; дневник и журнал; решает владелец.
//  4) ИССЛЕДОВАНИЕ ЗАВЕРШЕНО (объём подтверждён): дневник; достижение цели автоматически НЕ проверяется,
//     итог по цели остаётся за владельцем («итог N: успех/неудача»).
// Любой из исходов 2–4 тратит одно испытание. Следующее разрешает владелец («цикл ещё»): одна задача, остальные проекты не одобряются.
// Состояние: loop_state.json. Контрольная точка пишется во временный файл, перечитывается и проверяется, предыдущий
// рабочий файл сохраняется как .bak и не удаляется до успешной замены. При старте берётся самая свежая годная копия.
// По умолчанию цикл ВЫКЛЮЧЕН: включает только владелец.
object Loop {
    private const val FMT = 1
    private const val MAX_STEPS = 6
    private const val MAX_READS = 2
    private const val MAX_MS = 15 * 60_000L          // активное время задачи; паузы ожидания в него не входят
    private const val WAIT_MS = 3 * 60_000L          // сколько ждать ответ чтения, прежде чем считать его потерянным
    private const val READ_RETRY_MS = 5 * 60_000L    // пауза перед единственной повторной попыткой после неудачи чтения
    private const val LIMIT_WAIT_MS = 60 * 60_000L   // пауза при дневном лимите трафика или памяти
    private const val MAX_WAIT_MS = 24 * 3_600_000L  // сколько всего можно ждать сеть
    private const val MAX_ATTEMPTS = 3
    private const val TEST_TASKS = 1
    private const val MIN_WORDS = 120
    private const val MIN_ABSORBED = 100
    private const val MAX_RISK = 0.2f
    private const val IDLE_LOG_MS = 6 * 3_600_000L
    private val BACKOFF = longArrayOf(5 * 60_000L, 15 * 60_000L, 30 * 60_000L)
    private val ALLOWED_SOURCES = listOf("ru.wikipedia.org")

    private class Task(val id: String, val num: Int, val projectId: String, val topic: String, val expected: String, var started: Long) {
        var step = "execute"
        var steps = 0
        var reads = 0
        var stepTs = 0L
        var waiting = false
        var readId = ""
        var words = 0
        var absorbed = 0
        var code = ""
        var query = ""
        var resumeAt = 0L
        var waitSince = 0L
        var netWaits = 0
    }

    private class Entry(val ts: Long, val text: String)

    private var file: File? = null
    private var on = false
    private var completed = 0      // испытаний доведено до конца (исходы 2, 3, 4)
    private var volumePassed = 0   // из них: объём подтверждён
    private var lowVolume = 0      // из них: объём недостаточный
    private var readFailed = 0     // из них: чтение не удалось
    private var extra = 0          // сколько дополнительных испытаний разрешил владелец
    private var attempts = 0
    private var seq = 0L
    private var saveOk = true
    private var task: Task? = null
    private var idleAt = 0L
    private var lastIdle = ""
    private val journal = ArrayList<Entry>()
    private val ran = HashSet<Int>()      // стратегии, по которым объём подтверждён
    private val held = HashSet<Int>()     // стратегии, остановленные без итога (мало текста или чтение не удалось): решает владелец
    private val skipped = HashSet<Int>()

    private fun budget() = TEST_TASKS + extra

    // ===== Память: контрольная точка =====
    private fun parse(f: File): JSONObject? = try {
        if (f.exists()) JSONObject(f.readText(Charsets.UTF_8)) else null
    } catch (_: Throwable) {
        null
    }

    @Synchronized
    fun init(ctx: Context) {
        if (file != null) return
        val dir = ctx.applicationContext.filesDir
        val f = File(dir, "loop_state.json")
        file = f
        val files = listOf(f, File(dir, "loop_state.json.tmp"), File(dir, "loop_state.json.bak"))
        val cands = files.mapNotNull { x -> parse(x)?.let { o -> Pair(x, o) } }
        val best = cands.maxByOrNull { it.second.optLong("seq", 0L) }
        if (best == null) {
            if (files.any { it.exists() }) runCatching { f.copyTo(File(dir, "loop_state.json.bad"), overwrite = true) }
            return
        }
        try {
            val o = best.second
            on = o.optBoolean("on", false)
            completed = o.optInt("completed", o.optInt("done", 0))
            volumePassed = o.optInt("volumePassed", 0)
            lowVolume = o.optInt("lowVolume", 0)
            readFailed = o.optInt("readFailed", 0)
            extra = o.optInt("extra", 0)
            attempts = o.optInt("attempts", 0)
            seq = o.optLong("seq", 0L)
            o.optJSONArray("ran")?.let { a -> for (i in 0 until a.length()) ran.add(a.optInt(i)) }
            o.optJSONArray("held")?.let { a -> for (i in 0 until a.length()) held.add(a.optInt(i)) }
            val ja = o.optJSONArray("journal")
            if (ja != null) for (i in 0 until ja.length()) {
                val e = ja.optJSONObject(i) ?: continue
                journal.add(Entry(e.optLong("ts"), e.optString("text")))
            }
            val t = o.optJSONObject("task")
            if (t != null) {
                val x = Task(t.optString("id"), t.optInt("num"), t.optString("projectId"), t.optString("topic"), t.optString("expected"), t.optLong("started"))
                x.step = t.optString("step", "execute")
                x.steps = t.optInt("steps")
                x.reads = t.optInt("reads")
                x.stepTs = t.optLong("stepTs")
                x.waiting = t.optBoolean("waiting")
                x.readId = t.optString("readId")
                x.words = t.optInt("words")
                x.absorbed = t.optInt("absorbed")
                x.code = t.optString("code")
                x.query = t.optString("query")
                x.resumeAt = t.optLong("resumeAt")
                x.waitSince = t.optLong("waitSince")
                x.netWaits = t.optInt("netWaits")
                task = x
            }
            if (best.first != f) log("Состояние восстановлено из " + (if (best.first.name.endsWith(".bak")) "резервной копии" else "непереименованной контрольной точки") + ".")
        } catch (_: Throwable) {
            // состояние нечитаемо: цикл остаётся выключенным, копия сохраняется
            runCatching { best.first.copyTo(File(dir, "loop_state.json.bad"), overwrite = true) }
            on = false; completed = 0; volumePassed = 0; lowVolume = 0; readFailed = 0; extra = 0; attempts = 0
            task = null; journal.clear(); ran.clear(); held.clear()
        }
    }

    private fun build(): JSONObject {
        val o = JSONObject().put("fmt", FMT).put("seq", seq).put("on", on).put("completed", completed)
            .put("volumePassed", volumePassed).put("lowVolume", lowVolume).put("readFailed", readFailed)
            .put("extra", extra).put("attempts", attempts)
        o.put("ran", JSONArray().also { a -> for (n in ran) a.put(n) })
        o.put("held", JSONArray().also { a -> for (n in held) a.put(n) })
        o.put("journal", JSONArray().also { ja -> for (e in journal) ja.put(JSONObject().put("ts", e.ts).put("text", e.text)) })
        val t = task
        if (t != null) o.put("task", JSONObject().put("id", t.id).put("num", t.num).put("projectId", t.projectId).put("topic", t.topic)
            .put("expected", t.expected).put("started", t.started).put("step", t.step).put("steps", t.steps).put("reads", t.reads)
            .put("stepTs", t.stepTs).put("waiting", t.waiting).put("readId", t.readId).put("words", t.words).put("absorbed", t.absorbed)
            .put("code", t.code).put("query", t.query).put("resumeAt", t.resumeAt).put("waitSince", t.waitSince).put("netWaits", t.netWaits))
        return o
    }

    // Возвращает true только если новая контрольная точка записана, перечитана и проверена.
    // Рабочий файл не удаляется: сначала он копируется в .bak, затем атомарно заменяется (rename поверх файла).
    private fun save(): Boolean {
        val f = file ?: return false
        val tmp = File(f.parentFile, f.name + ".tmp")
        val bak = File(f.parentFile, f.name + ".bak")
        var stage = 0
        return try {
            seq++
            tmp.writeText(build().toString(), Charsets.UTF_8)
            val back = JSONObject(tmp.readText(Charsets.UTF_8))
            if (back.optLong("seq") != seq || back.optInt("fmt") != FMT) throw IllegalStateException("verify")
            stage = 1
            if (parse(f) != null) f.copyTo(bak, overwrite = true)
            if (!tmp.renameTo(f)) throw IllegalStateException("rename")
            saveOk = true
            true
        } catch (_: Throwable) {
            if (stage == 0) runCatching { tmp.delete() } // непроверенный временный файл не оставляем
            saveOk = false
            false
        }
    }

    private fun log(text: String) {
        journal.add(Entry(System.currentTimeMillis(), text))
        while (journal.size > 200) journal.removeAt(0)
    }

    private fun hhmm(ts: Long): String = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ts))

    private fun why(code: String, q: String): String = when (code) {
        "nonet" -> "нет доступа в сеть"
        "metered" -> "платная сеть, мобильный интернет читать не разрешён"
        "limit" -> "дневной лимит трафика или памяти"
        "wait" -> "ядро ещё не готово"
        "http" -> "источник ответил ошибкой"
        "badreply" -> "ответ источника не удалось разобрать"
        "empty" -> "поиск ничего не нашёл по «$q»"
        "short" -> "найденный по «$q» текст слишком короткий"
        else -> "неизвестная причина ($code)"
    }

    // ===== Рубильник, разрешение следующего испытания, отчёты =====
    @Synchronized
    fun setOn(v: Boolean): String {
        if (v && completed >= budget()) return "Все разрешённые испытания доведены до конца. Чтобы разрешить следующее, напиши «цикл ещё»."
        on = v
        if (v) attempts = 0
        log(if (v) "Цикл включён владельцем." else "Цикл остановлен владельцем.")
        save()
        return if (v) "Цикл включён. Остановить: «цикл стоп»."
        else "Цикл остановлен. Контрольная точка сохранена."
    }

    // Явное решение владельца. История не сбрасывается. Одобряется только та стратегия, которую цикл возьмёт в работу.
    @Synchronized
    fun grantMore(): String {
        if (completed < budget()) {
            on = true
            log("Владелец напомнил: разрешённое испытание ещё не доведено до конца, цикл включён.")
            save()
            return "Разрешённое испытание ещё не завершено, цикл включён. Новое разрешение будет доступно после его завершения."
        }
        extra++
        on = true
        attempts = 0
        log("Владелец разрешил следующее испытание (разрешено всего ${budget()}). Одобряется только стратегия, которую цикл возьмёт в работу; остальные проекты ждут.")
        save()
        return "Разрешила следующее испытание: одна задача. Остальные проекты не одобряются и не трогаются. Остановить: «цикл стоп»."
    }

    @Synchronized
    fun statusText(): String {
        val t = task
        val now = System.currentTimeMillis()
        return "Цикл: " + (if (on) "включён" else "выключен") + " · испытаний доведено до конца $completed из ${budget()}: объём подтверждён $volumePassed, объём недостаточный $lowVolume, чтение не удалось $readFailed. Достижение цели автоматически не проверяется." +
            (if (t != null) "\nЗадача №${t.num} «${t.topic}»: шаг «${t.step}», шагов ${t.steps} из $MAX_STEPS, чтений ${t.reads} из $MAX_READS" +
                (if (t.resumeAt > now) ", пауза до ${hhmm(t.resumeAt)}" else "")
            else "\nЗадачи сейчас нет" + (if (lastIdle.isNotEmpty()) ": $lastIdle" else "")) +
            (if (!saveOk) "\nВнимание: последнюю контрольную точку сохранить не удалось." else "") +
            "\nЖурнал: «журнал цикла». Остановить: «цикл стоп». Следующее испытание: «цикл ещё»."
    }

    @Synchronized
    fun journalText(): String {
        if (journal.isEmpty()) return "Журнал цикла пуст."
        val fmt = java.text.SimpleDateFormat("dd.MM HH:mm", java.util.Locale.getDefault())
        return journal.takeLast(15).joinToString("\n") { fmt.format(java.util.Date(it.ts)) + " · " + it.text }
    }

    // ===== Один маленький шаг за вызов; вызывает ядро (поток ядра) =====
    @Synchronized
    fun tick() {
        if (!on || file == null || !Core.enabled) return
        val now = System.currentTimeMillis()
        val t = task
        if (t == null) { start(now); return }
        if (t.resumeAt != 0L) { // пауза: временная ошибка сети или единственная повторная попытка
            if (t.waitSince != 0L && now - t.waitSince > MAX_WAIT_MS) { abort(t, "сеть не появилась за сутки"); return }
            if (now < t.resumeAt) return
            t.resumeAt = 0L
            t.started = now // активное время отсчитывается заново после паузы
            save()
        }
        if (t.steps >= MAX_STEPS || now - t.started > MAX_MS) { abort(t, "исчерпан потолок шагов или времени"); return }
        when (t.step) {
            "execute" -> execute(t, now)
            "verify" -> verifyVolume(t)
            else -> abort(t, "неизвестный шаг")
        }
    }

    private fun idle(now: Long, text: String) {
        if (now - idleAt < IDLE_LOG_MS) return
        idleAt = now
        log(text)
        save()
    }

    // Класс R1: только исследование темы по проекту Purpose, риск не выше порога. Всё остальное цикл не автоодобряет.
    private fun isR1(c: Agency.Cand, topic: String?): Boolean =
        topic != null && topic.length >= 3 && c.risk <= MAX_RISK && c.text.startsWith("Исследовать «")

    private fun start(now: Long) {
        if (completed >= budget()) {
            on = false
            log("Все разрешённые испытания доведены до конца. Цикл остановлен; следующее разрешает владелец: «цикл ещё».")
            save()
            return
        }
        if (attempts >= MAX_ATTEMPTS) {
            on = false
            log("Три попытки без результата. Цикл остановлен, нужен взгляд владельца.")
            save()
            return
        }
        var pick: Agency.Cand? = null
        var topic = ""
        val all = Agency.loopCandidates()
        var nRan = 0; var nHeld = 0; var nNoProject = 0; var nNotR1 = 0
        for (c in all) {
            if (c.num in ran) { nRan++; continue }
            if (c.num in held) { nHeld++; continue }
            val tp = Purpose.topicOf(c.projectId)
            if (tp == null) { nNoProject++; continue }
            if (isR1(c, tp)) { pick = c; topic = tp; break }
            nNotR1++
            if (skipped.add(c.num)) log("Не беру стратегию №${c.num}: это не чтение разрешённого источника (не R0/R1), решает владелец.")
        }
        val c = pick
        if (c == null) {
            lastIdle = if (all.isEmpty()) "в Agency нет стратегий от Purpose; Purpose: " + Purpose.stopReason()
            else "стратегий от Purpose ${all.size}: объём подтверждён $nRan, остановлены без итога $nHeld, проект не в статусе «предложен/в работе» $nNoProject, не R1 $nNotR1"
            idle(now, "Задач нет: $lastIdle.")
            return
        }
        lastIdle = ""
        if (c.status == "proposed") {
            if (!Agency.autoAuthorize(c.num)) { log("Не удалось автоодобрить стратегию №${c.num}."); save(); return }
            log("Автоодобрено по решению владельца (R1, чтение разрешённых источников): №${c.num} «$topic».")
        }
        task = Task(UUID.randomUUID().toString(), c.num, c.projectId, topic, c.expected, now)
        log("Задача начата: №${c.num} «$topic». Потолки: шагов $MAX_STEPS, чтений $MAX_READS, ${MAX_MS / 60_000} мин активного времени, токенов 0.")
        save()
    }

    private fun execute(t: Task, now: Long) {
        if (t.waiting && now - t.stepTs < WAIT_MS) return
        if (t.reads >= MAX_READS) { endReadFail(t, t.code.ifEmpty { "http" }, t.query.ifEmpty { t.topic }); return }
        t.steps++
        t.reads++
        t.waiting = true
        t.stepTs = now
        t.readId = UUID.randomUUID().toString() // у каждого чтения свой номер: ответ предыдущего чтения принят не будет
        log("Шаг ${t.steps}: читаю «${t.topic}» (${ALLOWED_SOURCES.joinToString()}).")
        if (!save()) { // контрольная точка до действия: нет точки, нет действия
            t.waiting = false
            abort(t, "контрольную точку сохранить не удалось, действие не выполнял")
            return
        }
        val id = t.id
        val rid = t.readId
        Core.loopRead(t.topic) { code, words, absorbed, query -> onRead(id, rid, code, words, absorbed, query) }
    }

    @Synchronized
    private fun onRead(id: String, readId: String, code: String, words: Int, absorbed: Int, query: String) {
        val t = task
        if (t == null || t.id != id || t.readId != readId || !t.waiting || t.step != "execute") {
            log("Устаревший ответ чтения проигнорирован: результат нового чтения он не заменяет.")
            save()
            return
        }
        val now = System.currentTimeMillis()
        t.waiting = false
        t.code = code
        if (query.isNotEmpty()) t.query = query
        when (code) {
            "ok", "dup" -> {
                t.words = words
                t.absorbed = absorbed
                t.step = "verify"
                t.netWaits = 0
                t.waitSince = 0L
                log(if (code == "dup") "Текст по «${t.query}» уже был в памяти, повторно не добавлен. Слов в нём: $words."
                else "Прочитано слов: $words по запросу «${t.query}», лёгло в память: $absorbed.")
            }
            "nonet", "metered", "limit", "wait" -> { // 1) временная ошибка: ничего не потрачено, ждём и возобновляем
                t.reads = maxOf(0, t.reads - 1)
                t.steps = maxOf(0, t.steps - 1)
                if (t.waitSince == 0L) t.waitSince = now
                val d = if (code == "limit") LIMIT_WAIT_MS else BACKOFF[minOf(t.netWaits, BACKOFF.size - 1)]
                t.netWaits++
                t.resumeAt = now + d
                log("Временная ошибка: ${why(code, t.query)}. Чтение и шаг не потрачены, возобновлю после ${hhmm(t.resumeAt)}.")
            }
            else -> { // 2) неудача чтения: одна повторная попытка с паузой, затем остановка без записи неудачи
                log("Чтение не удалось: ${why(code, t.query)} (чтение ${t.reads} из $MAX_READS).")
                if (t.reads >= MAX_READS) { endReadFail(t, code, t.query); return }
                t.resumeAt = now + READ_RETRY_MS
            }
        }
        save()
    }

    // Один общий выход для исходов 2–4: тратит одно испытание, задача закрывается
    private fun finishTrial() {
        completed++
        attempts = 0
        task = null
        if (completed >= budget()) {
            on = false
            log("Испытание доведено до конца. Цикл остановлен; следующее разрешает владелец: «цикл ещё».")
        }
        save()
    }

    private fun endReadFail(t: Task, code: String, query: String) {
        readFailed++
        held.add(t.num)
        log("Исследование не состоялось: ${why(code, query)}. Это не неудача стратегии: в Agency ничего не записано, стратегия №${t.num} осталась одобренной, решаешь ты.")
        Core.diaryNote("Цикл: по теме «${t.topic}» (запрос «$query») прочитать не удалось: ${why(code, query)}. Итог по стратегии №${t.num} не записан, жду решения владельца.")
        finishTrial()
    }

    // Проверка ОБЪЁМА: сколько текста прочитано и легло в память (замер внутри потока ядра по счётчику памяти).
    // Качество исследования и достижение цели она не проверяет. Результат НЕ пишется в Agency как неудача или успех.
    private fun verifyVolume(t: Task) {
        t.steps++
        val dup = t.code == "dup" // текст уже лежит в памяти: повторно не добавлялся, объём считается по тексту
        val volOk = t.words >= MIN_WORDS && (dup || t.absorbed >= MIN_ABSORBED)
        if (volOk) {
            volumePassed++
            ran.add(t.num)
            Core.diaryNote("Цикл: по теме «${t.topic}» прочитано ${t.words} слов, в память легло ${t.absorbed}. Объём подтверждён, достижение цели не проверено: жду итога владельца (итог ${t.num}: успех или неудача).")
            log("Проверка объёма: подтверждена (слов ${t.words} из $MIN_WORDS, в память ${t.absorbed}). Проверка цели: НЕ выполнена, критерия качества пока нет. Стратегия №${t.num} остаётся одобренной до итога владельца: «итог ${t.num}: успех» или «итог ${t.num}: неудача».")
        } else {
            lowVolume++
            held.add(t.num)
            Core.diaryNote("Цикл: по теме «${t.topic}» (запрос «${t.query}») объём недостаточный: ${t.words} слов, в память легло ${t.absorbed}. Это не неудача стратегии: она остаётся одобренной, итог решаешь ты (итог ${t.num}: успех или неудача).")
            log("Объём недостаточный: слов ${t.words} из $MIN_WORDS, в память ${t.absorbed} из $MIN_ABSORBED. Agency не тронут, проект не остановлен, решаешь ты.")
        }
        finishTrial()
    }

    // Прерывание (лимит шагов или времени, не сохранилась точка, сеть сутки): итог не пишется, попытки ограничены
    private fun abort(t: Task, why: String) {
        log("Задача №${t.num} прервана: $why. Итог не записан.")
        attempts++
        task = null
        save()
    }
}
