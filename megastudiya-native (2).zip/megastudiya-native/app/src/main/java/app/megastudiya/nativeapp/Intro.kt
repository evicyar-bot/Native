package app.megastudiya.nativeapp

import android.graphics.Bitmap
import android.graphics.LinearGradient
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.first

// ЦИКЛ ЗАПУСКА (см. ANIMATIONS.md): тоннель звёзд → звёзды стягиваются в кольцо-систему → узлы загораются, сигналы,
// дуги → проявляется логотип → логотип летит в верхнюю пилюлю, кольцо расходится в небо ленты → лента.
// Один раз за запуск процесса, тап пропускает. Приложение под заставкой не рисуется, пока она не передаст эстафету.
object IntroGate {
    var shown = false
    var flying by mutableStateOf(true) // пока заставка несёт логотип к пилюле, логотип самой пилюли скрыт
}

private val IntroBg = Color(0xFF0B0D12)
private val Gold = Color(0xFFFFB84D)
private val Pale = Color(0xFFFFE2AA)
private val Neb = Color(0xFF2850BE)

private fun ss(a: Float, b: Float, x: Float): Float { val q = ((x - a) / (b - a)).coerceIn(0f, 1f); return q * q * (3f - 2f * q) }

private fun ringPt(x: Float, y: Float, cx: Float, cy: Float, sc: Float, cp: Float, sp: Float): Offset {
    val dx = (x - 54f) * sc; val dy = (y - 54f) * sc
    return Offset(cx + dx * cp - dy * sp, cy + dx * sp + dy * cp)
}

private fun tunZ(z0: Float, sp: Float, time: Float): Float = (((z0 - time * 3.2f * sp) % 1f) + 1f) % 1f // 1 далеко, 0 рядом

private fun argb(a: Int, r: Int, g: Int, b: Int) = (a shl 24) or (r shl 16) or (g shl 8) or b

// мягкое свечение звезды; spikes — дифракционные лучи у ярких звёзд
private fun glowSprite(size: Int, r: Int, g: Int, b: Int, spikes: Boolean): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val cv = android.graphics.Canvas(bmp)
    val c = size / 2f
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    p.shader = RadialGradient(
        c, c, c,
        intArrayOf(argb(255, 255, 255, 255), argb(235, (r + 255) / 2, (g + 255) / 2, (b + 255) / 2), argb(110, r, g, b), argb(28, r, g, b), argb(0, r, g, b)),
        floatArrayOf(0f, 0.14f, 0.30f, 0.60f, 1f), Shader.TileMode.CLAMP
    )
    cv.drawCircle(c, c, c, p)
    if (spikes) {
        val sp = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        for (k in 0 until 4) {
            val long = k % 2 == 0
            val len = if (long) c else c * 0.55f
            val th = if (long) size * 0.016f else size * 0.011f
            val a0 = if (long) 215 else 110
            sp.shader = LinearGradient(c - len, c, c + len, c, intArrayOf(argb(0, r, g, b), argb(a0, r, g, b), argb(0, r, g, b)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            cv.save()
            cv.rotate(k * 45f, c, c)
            cv.drawRect(c - len, c - th, c + len, c + th, sp)
            cv.restore()
        }
    }
    return bmp
}

// Млечный Путь: розово-красная диагональная полоса с тёмными пылевыми рукавами (рисуется один раз, мелким битмапом)
private fun nebulaBitmap(): Bitmap {
    val w = 180; val h = 320
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val cv = android.graphics.Canvas(bmp)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    val r = java.util.Random(21)
    val cols = arrayOf(intArrayOf(255, 110, 150), intArrayOf(230, 60, 100), intArrayOf(150, 90, 235), intArrayOf(70, 110, 230), intArrayOf(255, 170, 120))
    for (i in 0 until 120) {
        val s = r.nextFloat()
        val off = (r.nextGaussian() * 0.05).toFloat()
        val x = (0.04f + 0.92f * s + off * 0.6f) * w
        val y = (0.94f - 0.88f * s + off * 0.5f) * h
        val rad = (0.06f + 0.15f * r.nextFloat()) * w
        val c = cols[r.nextInt(cols.size)]
        val a = 22 + r.nextInt(40)
        p.shader = RadialGradient(x, y, rad, intArrayOf(argb(a, c[0], c[1], c[2]), argb(0, c[0], c[1], c[2])), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, rad, p)
    }
    for (i in 0 until 26) {
        val s = r.nextFloat()
        val off = (r.nextGaussian() * 0.035).toFloat()
        val x = (0.06f + 0.88f * s + off * 0.6f) * w
        val y = (0.92f - 0.84f * s + off * 0.5f) * h
        val rad = (0.03f + 0.06f * r.nextFloat()) * w
        p.shader = RadialGradient(x, y, rad, intArrayOf(argb(60 + r.nextInt(40), 0, 0, 4), argb(0, 0, 0, 4)), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, rad, p)
    }
    return bmp
}

private val REAL = arrayOf(intArrayOf(170, 190, 255), intArrayOf(235, 240, 255), intArrayOf(255, 238, 200), intArrayOf(255, 205, 150), intArrayOf(255, 165, 125))
private val BRAND = arrayOf(intArrayOf(255, 184, 77), intArrayOf(255, 226, 170), intArrayOf(120, 160, 255), intArrayOf(255, 158, 196))

private class Sprites {
    val real = Array(5) { glowSprite(64, REAL[it][0], REAL[it][1], REAL[it][2], false) }
    val realSp = Array(5) { glowSprite(128, REAL[it][0], REAL[it][1], REAL[it][2], true) }
    val brand = Array(4) { glowSprite(64, BRAND[it][0], BRAND[it][1], BRAND[it][2], false) }
    val hub = glowSprite(160, 255, 200, 110, true)
    val dust = glowSprite(24, 235, 240, 255, false)
    val neb = nebulaBitmap()
}

private class SpriteDrawer {
    val add = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG).also { it.xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD) }
    val plain = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
    val dst = RectF()
    // спрайт растягивается вдоль движения: у летящей звезды получается светящийся хвост без дорогих штрихов
    fun draw(cv: android.graphics.Canvas, bmp: Bitmap, x: Float, y: Float, len: Float, th: Float, deg: Float, alpha: Float) {
        val a = (alpha * 255f).toInt()
        if (a <= 2) return
        add.alpha = if (a > 255) 255 else a
        cv.save()
        cv.translate(x, y)
        if (deg != 0f) cv.rotate(deg)
        dst.set(-len / 2f, -th / 2f, len / 2f, th / 2f)
        cv.drawBitmap(bmp, null, dst, add)
        cv.restore()
    }
}

@Composable
fun StarIntro(onReveal: () -> Unit, onDone: () -> Unit) {
    val t = remember { Animatable(0f) }
    var skip by remember { mutableStateOf(false) }
    var boxH by remember { mutableStateOf(0) }
    val dens = LocalDensity.current
    val topInset = WindowInsets.statusBars.getTop(dens)
    val n = RingData.dots.size / 5
    // на звезду: угол, задержка схода, стартовая глубина, скорость, величина
    val rnd = remember { val r = java.util.Random(5); FloatArray(n * 5) { r.nextFloat() } }
    val ca = remember { FloatArray(n) { Math.cos(rnd[it * 5] * 6.2832).toFloat() } }
    val sa = remember { FloatArray(n) { Math.sin(rnd[it * 5] * 6.2832).toFloat() } }
    // цвет по температуре звезды: голубая, белая, жёлтая, оранжевая, красная
    val tc = remember { val r = java.util.Random(9); IntArray(n) { val q = r.nextFloat(); when { q < 0.12f -> 0; q < 0.42f -> 1; q < 0.70f -> 2; q < 0.90f -> 3; else -> 4 } } }
    val dust = remember { val r = java.util.Random(13); FloatArray(130 * 4) { r.nextFloat() } }
    val spr = remember { Sprites() }
    val drawer = remember { SpriteDrawer() }
    val pathNet = remember { Path() }
    val pathChord = remember { Path() }
    val pathArc = remember { Path() }

    LaunchedEffect(Unit) {
        IntroGate.flying = true
        t.animateTo(1f, tween(3400, easing = LinearEasing))
        IntroGate.flying = false
        onDone()
    }
    LaunchedEffect(Unit) {
        snapshotFlow { t.value >= 0.80f }.first { it }
        onReveal()
    }
    LaunchedEffect(skip) {
        if (skip) {
            onReveal()
            t.animateTo(1f, tween(260, easing = LinearEasing))
            IntroGate.flying = false
            onDone()
        }
    }
    Box(
        Modifier.fillMaxSize()
            .onSizeChanged { boxH = it.height }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent()
                        e.changes.forEach { it.consume() }
                        if (e.changes.any { !it.pressed && it.previousPressed }) skip = true
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxSize().graphicsLayer { alpha = 1f - ss(0.86f, 1f, t.value) }.background(IntroBg))
        Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = 1f - ss(0.86f, 1f, t.value) }) {
            val tt = t.value
            val cv = drawContext.canvas.nativeCanvas
            val w = size.width; val h = size.height
            val cx = w / 2f; val cy = h / 2f
            val base = minOf(w, h * 0.62f)
            val sc = 0.36f * base / 28f
            val maxR = Math.hypot(cx.toDouble(), cy.toDouble()).toFloat() * 1.1f
            val phi = 0.38f * ss(0.20f, 1f, tt)
            val cp = Math.cos(phi.toDouble()).toFloat(); val sp = Math.sin(phi.toDouble()).toFloat()
            val nb = ss(0.50f, 0.80f, tt)
            val nl = ss(0.72f, 0.92f, tt)
            val ex = ss(0.84f, 1f, tt)
            val scE = sc * (1f + 0.45f * ex) // в конце кольцо расходится в небо
            val c = Offset(cx, cy)

            // 1) Млечный Путь: летим сквозь него, потом он схлопывается в кольцо
            val nebA = (1f - ss(0.30f, 0.72f, tt)) * 0.9f
            if (nebA > 0.01f) {
                val z = 1f + 0.35f * ss(0f, 0.7f, tt)
                drawer.dst.set(cx - w * z / 2f, cy - h * z / 2f, cx + w * z / 2f, cy + h * z / 2f)
                drawer.plain.alpha = (nebA * 255f).toInt()
                cv.drawBitmap(spr.neb, null, drawer.dst, drawer.plain)
            }
            // 2) далёкая звёздная пыль для глубины
            val dustA = (1f - 0.6f * ss(0.4f, 0.8f, tt)) * (1f - ex)
            for (k in 0 until 130) {
                val px = cx + (dust[k * 4] * w - cx) * (1f + 0.25f * tt)
                val py = cy + (dust[k * 4 + 1] * h - cy) * (1f + 0.25f * tt)
                val s = (2f + dust[k * 4 + 2] * 5f) * density
                val tw = 0.6f + 0.4f * Math.sin((tt * 18f + dust[k * 4 + 3] * 6.28f).toDouble()).toFloat()
                drawer.draw(cv, spr.dust, px, py, s, s, 0f, 0.55f * tw * dustA)
            }
            // 3) туманность кольца и орбиты
            if (nb > 0f) {
                for ((wd, al) in listOf(16f to 0.05f, 11f to 0.07f, 7f to 0.09f, 4f to 0.10f))
                    drawCircle(Neb.copy(alpha = al * nb), radius = 28f * sc, center = c, style = Stroke(width = wd * sc))
                for ((rr, al) in listOf(33.2f to 0.28f, 29.5f to 0.22f, 22.5f to 0.20f, 8.5f to 0.22f))
                    drawCircle(Gold.copy(alpha = al * nb), radius = rr * sc, center = c, style = Stroke(width = (0.22f * sc).coerceAtLeast(1f)))
            }
            // 4) связи между соседними точками и хорды: по одному пути на слой
            if (nl > 0f) {
                val ne = RingData.net
                pathNet.reset()
                var i = 0
                while (i < ne.size) {
                    val a = ringPt(ne[i], ne[i + 1], cx, cy, scE, cp, sp); val b = ringPt(ne[i + 2], ne[i + 3], cx, cy, scE, cp, sp)
                    pathNet.moveTo(a.x, a.y); pathNet.lineTo(b.x, b.y)
                    i += 4
                }
                drawPath(pathNet, Gold.copy(alpha = 0.38f * nl), style = Stroke(width = (0.16f * sc).coerceAtLeast(1f)))
                val ch = RingData.chords
                pathChord.reset()
                i = 0
                while (i < ch.size) {
                    val a = ringPt(ch[i], ch[i + 1], cx, cy, scE, cp, sp); val m = ringPt(ch[i + 2], ch[i + 3], cx, cy, scE, cp, sp); val b = ringPt(ch[i + 4], ch[i + 5], cx, cy, scE, cp, sp)
                    pathChord.moveTo(a.x, a.y); pathChord.lineTo(m.x, m.y); pathChord.lineTo(b.x, b.y)
                    i += 6
                }
                drawPath(pathChord, Gold.copy(alpha = 0.28f * nl), style = Stroke(width = (0.14f * sc).coerceAtLeast(1f)))
            }
            // 5) звёзды: тоннель → точки кольца. Цвет меняется от температуры звезды к цвету бренда
            val d = RingData.dots
            for (i in 0 until n) {
                val rd = d[i * 5 + 2]; val ci = d[i * 5 + 3].toInt(); val fa = d[i * 5 + 4]
                val tgt = ringPt(d[i * 5], d[i * 5 + 1], cx, cy, scE, cp, sp)
                val dl = rnd[i * 5 + 1]
                val u = ss(0.26f + 0.14f * dl, 0.58f + 0.14f * dl, tt)
                val z0 = rnd[i * 5 + 2]; val spd = 0.7f + 0.6f * rnd[i * 5 + 3]; val mag = rnd[i * 5 + 4]
                val z = tunZ(z0, spd, tt); val zp = tunZ(z0, spd, tt - 0.016f)
                val r1 = (1f - z) * (1f - z) * maxR; val r0 = (1f - zp) * (1f - zp) * maxR
                val x1 = cx + ca[i] * r1; val y1 = cy + sa[i] * r1
                val x0 = cx + ca[i] * r0; val y0 = cy + sa[i] * r0
                val px1 = x1 + (tgt.x - x1) * u; val py1 = y1 + (tgt.y - y1) * u
                val px0 = x0 + (tgt.x - x0) * u; val py0 = y0 + (tgt.y - y0) * u
                val near = 1f - z
                val tunA = (1.15f * near + 0.12f).coerceIn(0f, 1f)
                val sT = (3f + near * near * 16f) * (0.55f + 0.9f * mag) * density
                val sR = (rd * sc * 9f).coerceAtLeast(5f)
                val size = sT + (sR - sT) * u
                val dx = px1 - px0; val dy = py1 - py0
                val trail = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
                val len = size + trail * 1.4f
                val deg = if (trail > 0.5f) Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble())).toFloat() else 0f
                val mx = (px1 + px0) / 2f; val my = (py1 + py0) / 2f
                if (u < 0.5f) {
                    val sprite = if (mag > 0.88f && near > 0.25f) spr.realSp[tc[i]] else spr.real[tc[i]]
                    drawer.draw(cv, sprite, mx, my, len, size, deg, tunA * (1f - u * 0.9f))
                } else {
                    val bi = when { ci == 2 -> 2; ci == 1 -> 1; i % 5 == 0 -> 3; else -> 0 }
                    val tw = if (u > 0.98f) 0.82f + 0.18f * Math.sin((tt * 26f + i).toDouble()).toFloat() else 1f
                    drawer.draw(cv, spr.brand[bi], mx, my, len, size, deg, (tunA + (fa - tunA) * u) * tw)
                }
            }
            // 6) дуги между узлами рисуются по кругу
            val pa = ss(0.58f, 0.84f, tt)
            if (pa > 0f) {
                val ar = RingData.arcs
                pathArc.reset()
                var i = 0
                while (i < ar.size) {
                    val s0 = ringPt(ar[i], ar[i + 1], cx, cy, scE, cp, sp)
                    pathArc.moveTo(s0.x, s0.y)
                    for (j in 1..12) {
                        if ((j - 1) / 12f >= pa) break
                        val q = minOf(j / 12f, pa); val m = 1f - q
                        val qx = m * m * ar[i] + 2f * m * q * ar[i + 2] + q * q * ar[i + 4]
                        val qy = m * m * ar[i + 1] + 2f * m * q * ar[i + 3] + q * q * ar[i + 5]
                        val cur = ringPt(qx, qy, cx, cy, scE, cp, sp)
                        pathArc.lineTo(cur.x, cur.y)
                    }
                    i += 6
                }
                drawPath(pathArc, Pale.copy(alpha = 0.75f), style = Stroke(width = (0.3f * sc).coerceAtLeast(1.2f), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            // 7) узлы загораются по очереди, от каждого уходит волна сигнала
            val hb = RingData.hubs
            for (k in 0 until hb.size / 2) {
                val lit = ss(0.60f + 0.015f * k, 0.68f + 0.015f * k, tt)
                if (lit <= 0f) continue
                val hp = ringPt(hb[k * 2], hb[k * 2 + 1], cx, cy, scE, cp, sp)
                val hs = 14f * sc * (0.5f + 0.5f * lit)
                drawer.draw(cv, spr.hub, hp.x, hp.y, hs, hs, 0f, lit)
                if (k % 3 == 0) drawCircle(Gold.copy(alpha = 0.7f * lit), radius = 5.6f * sc, center = hp, style = Stroke(width = (0.3f * sc).coerceAtLeast(1f)))
                val pp = ((tt - 0.64f - 0.015f * k) * 2.4f).coerceIn(0f, 1f)
                if (pp > 0f && pp < 1f) drawCircle(Gold.copy(alpha = 0.5f * (1f - pp)), radius = sc * (2f + 9f * pp), center = hp, style = Stroke(width = (0.25f * sc).coerceAtLeast(1f)))
            }
        }
        // логотип проявляется в центре кольца, затем летит в верхнюю пилюлю
        Image(
            painterResource(R.drawable.ms_logo),
            contentDescription = null,
            modifier = Modifier.size(150.dp, 38.dp).graphicsLayer {
                val a = ss(0.70f, 0.88f, t.value)
                val e = ss(0.84f, 1f, t.value)
                val targetY = topInset + 33.5f * dens.density
                translationY = e * (targetY - boxH / 2f)
                val s = (1f - e * (1f - 106f / 150f)) * (0.9f + 0.1f * a)
                scaleX = s; scaleY = s
                alpha = a
            }
        )
    }
}
