# Модельный порт Loop.kt n0.85 (n0.84 + самостоятельная серия, статус владельца, восстановление после остановки процесса)
# + порт дедупа Core.loopRead. Это модель на Python, НЕ Kotlin: проверяет логику переходов, а не компиляцию.
import json, hashlib, re, copy
MAX_STEPS=6; MAX_READS=2; MAX_MS=15*60_000; WAIT_MS=3*60_000; READ_RETRY_MS=5*60_000; LIMIT_WAIT_MS=60*60_000
TICK_GAP_MS=2*60_000; MAX_WAIT_MS=24*3_600_000; MAX_ATTEMPTS=3; TEST_TASKS=1; MIN_WORDS=120; MIN_ABSORBED=100; BACKOFF=[5*60_000,15*60_000,30*60_000]
MIN=60_000
AUTO_MAX=10; AUTO_MAX_ACTIVE=60*MIN; AUTO_MAX_SPAN=48*3_600_000; AUTO_PAUSE=60_000; AUTO_IDLE=6*3_600_000; AUTO_MAX_MISS=2
class Clock: t=1_000_000_000
class AgencyStub:
    def __init__(s): s.strats={}; s.observed=[]; s.diary=[]
    def add(s,num,status="proposed"): s.strats[num]={"status":status,"src":f"p{num}","risk":0.1,"text":f"Исследовать «t{num}»: x","exp":""}
    def loopCandidates(s):
        l=[(n,v) for n,v in s.strats.items() if v["src"] and v["status"] in("proposed","authorized")]
        return sorted(l,key=lambda x:0 if x[1]["status"]=="authorized" else 1)
    def autoAuthorize(s,n):
        if s.strats[n]["status"]!="proposed": return False
        s.strats[n]["status"]="authorized"; return True
    def observe(s,*a): s.observed.append(a)
class CoreStub:
    """Порт loopRead: очередь сценарных ответов сети + дедуп по отпечатку текста + замер lm_n."""
    def __init__(s): s.script=[]; s.meta={}; s.lm_n=0; s.callbacks=[]; s.absorb_calls=0
    def loopRead(s,topic,cb):
        # асинхронно: cb вызывается позже (как io.execute); здесь складываем и вызываем явно
        s.callbacks.append((topic,cb))
    def deliver(s,i=0):
        topic,cb=s.callbacks.pop(i); kind=s.script.pop(0)
        if isinstance(kind,str):
            cb(kind,0,0,"q"); return
        text=kind["text"]; words=len(re.findall(r"[^\W\d_]{2,}",text))
        h="lp:"+hashlib.sha1(" ".join(text.lower().split()).encode()).hexdigest()[:20]
        s.meta["rd:"+topic]=Clock.t
        if h in s.meta: cb("dup",words,0,"q"); return
        before=s.lm_n; s.lm_n+=min(words,400); s.absorb_calls+=1; s.meta[h]=Clock.t
        cb("ok",words,s.lm_n-before,"q")
class Loop:
    def __init__(s,agency,core,store):
        s.agency=agency; s.core=core; s.store=store   # store: dict с ключами f, tmp, bak
        s.on=False; s.completed=0; s.volumePassed=0; s.lowVolume=0; s.readFailed=0; s.extra=0; s.attempts=0; s.seq=0
        s.task=None; s.journal=[]; s.ran=set(); s.held=set(); s.saveOk=True; s.fail_save=False
        s.auto=False; s.autoQuota=0; s.autoBase=0; s.autoStart=0; s.autoActive=0; s.autoMiss=0; s.nextAt=0; s.noTaskSince=0
        s.stopCode=""; s.ownerNote=""; s.results=[]; s.lastIdle=""; s.core_enabled=True
        s.load()
    def budget(s): return TEST_TASKS+s.extra
    def log(s,t): s.journal.append((Clock.t,t))
    def build(s):
        o={"fmt":1,"seq":s.seq,"on":s.on,"completed":s.completed,"volumePassed":s.volumePassed,"lowVolume":s.lowVolume,"readFailed":s.readFailed,"extra":s.extra,"attempts":s.attempts,"auto":s.auto,"autoQuota":s.autoQuota,"autoBase":s.autoBase,"autoStart":s.autoStart,"autoActive":s.autoActive,"autoMiss":s.autoMiss,"nextAt":s.nextAt,"noTaskSince":s.noTaskSince,"stopCode":s.stopCode,"ownerNote":s.ownerNote,"results":s.results,"ran":sorted(s.ran),"held":sorted(s.held),"journal":s.journal}
        if s.task: o["task"]=dict(s.task)
        return o
    def save(s):
        if s.fail_save: s.saveOk=False; return False
        s.seq+=1; s.store["tmp"]=json.dumps(s.build()); back=json.loads(s.store["tmp"])
        assert back["seq"]==s.seq
        if "f" in s.store and s.store["f"] is not None: s.store["bak"]=s.store["f"]
        s.store["f"]=s.store.pop("tmp"); s.saveOk=True; return True
    def load(s):
        c=[]
        for k in("f","tmp","bak"):
            v=s.store.get(k)
            if v:
                try: c.append(json.loads(v))
                except Exception: pass
        if not c: return
        o=max(c,key=lambda x:x.get("seq",0))
        s.on=o.get("on",False); s.completed=o.get("completed",o.get("done",0)); s.volumePassed=o.get("volumePassed",0)
        s.lowVolume=o.get("lowVolume",0); s.readFailed=o.get("readFailed",0); s.extra=o.get("extra",0); s.attempts=o.get("attempts",0)
        s.auto=o.get("auto",False); s.autoQuota=o.get("autoQuota",0); s.autoBase=o.get("autoBase",0); s.autoStart=o.get("autoStart",0); s.autoActive=o.get("autoActive",0)
        s.autoMiss=o.get("autoMiss",0); s.nextAt=o.get("nextAt",0); s.noTaskSince=o.get("noTaskSince",0); s.stopCode=o.get("stopCode",""); s.ownerNote=o.get("ownerNote",""); s.results=list(o.get("results",[]))
        s.seq=o.get("seq",0); s.ran=set(o.get("ran",[])); s.held=set(o.get("held",[])); s.journal=[tuple(x) if isinstance(x,list) else x for x in o.get("journal",[])]
        t=o.get("task"); s.task=dict(t) if t else None
        if s.task:
            for k,v in dict(activeMs=0,lastTick=0,step="execute",steps=0,reads=0,stepTs=0,waiting=False,readId="",words=0,absorbed=0,code="",query="",resumeAt=0,waitSince=0,netWaits=0).items(): s.task.setdefault(k,v)
            if s.task["waiting"]:   # процесс остановился посреди чтения: ответ не придёт, чтение не засчитывается
                s.task["waiting"]=False; s.task["reads"]=max(0,s.task["reads"]-1); s.task["steps"]=max(0,s.task["steps"]-1)
                s.log("process killed during read: not counted")
    def setOn(s,v):
        if v and s.completed>=s.budget(): return "refused"
        s.on=v
        if v: s.attempts=0; s.ownerNote=""; s.stopCode=""
        if (not v) and s.auto: s.auto=False; s.stopCode="owner"; s.ownerNote=""; s.nextAt=0
        s.save(); return "ok"
    def grantMore(s):
        if s.completed<s.budget(): s.on=True; s.save(); return "already"
        s.extra+=1; s.on=True; s.attempts=0; s.log("grant"); s.save(); return "granted"
    def setAuto(s,n):
        if s.auto and s.on: return "already"
        q=max(1,min(AUTO_MAX,n)); now=Clock.t
        s.auto=True; s.on=True; s.autoQuota=q; s.autoBase=s.completed; s.autoStart=now; s.autoActive=0; s.autoMiss=0
        s.nextAt=0; s.noTaskSince=0; s.stopCode=""; s.ownerNote=""; s.attempts=0
        s.extra=max(s.extra,s.completed+q-TEST_TASKS); s.log("auto on"); s.save(); return "ok"
    def endAuto(s,code,note):
        s.auto=False; s.on=False; s.stopCode=code; s.ownerNote=note; s.nextAt=0; s.log("auto off: "+code); s.save()
    def autoGate(s,now):
        if now-s.autoStart>AUTO_MAX_SPAN: s.endAuto("span","span"); return True
        if s.autoActive>AUTO_MAX_ACTIVE: s.endAuto("time","time"); return True
        if s.task is None and s.completed>=s.autoBase+s.autoQuota: s.endAuto("quota","quota"); return True
        return False
    def backgroundWork(s):
        if not s.on: return False
        t=s.task; now=Clock.t
        if t is not None: return t["resumeAt"]==0 or t["resumeAt"]-now<=20_000
        return s.auto and s.lastIdle=="" and s.completed<s.autoBase+s.autoQuota
    def ownerStatus(s):
        t=s.task; now=Clock.t
        if s.on and not s.core_enabled: return "paused"
        if s.on and t is not None:
            if t["resumeAt"]>now and t["waitSince"]!=0: return "wait_net"
            return "work"
        if s.on: return "work"
        if s.ownerNote: return "done" if s.stopCode=="quota" else "paused" if s.stopCode in("time","span") else "need_owner"
        if s.stopCode=="owner": return "paused"
        return "off"
    def addResult(s,x):
        s.results.append(x); s.results=s.results[-30:]
    def tick(s):
        if not s.on: return
        now=Clock.t
        if s.auto and s.autoGate(now): return
        if s.task is None:
            if now<s.nextAt: return
            s.start(now)
            if s.task is None: return
        t=s.task
        if t["resumeAt"]!=0:
            if t["waitSince"]!=0 and now-t["waitSince"]>MAX_WAIT_MS: s.abort("net 24h"); return
            if now<t["resumeAt"]: return
            t["resumeAt"]=0; t["lastTick"]=now; s.save()
        counted=False
        if t["lastTick"]!=0:
            gap=now-t["lastTick"]
            if 1<=gap<=TICK_GAP_MS:
                t["activeMs"]+=gap; counted=True
                if s.auto: s.autoActive+=gap
        t["lastTick"]=now
        if counted: s.save()
        so=t["steps"]>=MAX_STEPS; to=t["activeMs"]>MAX_MS
        if so or to:
            s.abort("исчерпаны лимит шагов ({} из {}) и лимит активного времени ({} минут)".format(t["steps"],MAX_STEPS,MAX_MS//60000) if so and to
                    else "исчерпан лимит шагов ({} из {})".format(t["steps"],MAX_STEPS) if so
                    else "исчерпан лимит активного времени ({} минут)".format(MAX_MS//60000)); return
        if t["step"]=="execute": s.execute(now)
        elif t["step"]=="verify": s.verify()
        else: s.abort("unknown")
    def start(s,now):
        if s.completed>=s.budget(): s.on=False; s.log("budget exhausted"); s.save(); return
        if s.attempts>=MAX_ATTEMPTS:
            if s.auto: s.endAuto("attempts","attempts")
            else: s.on=False; s.log("3 attempts"); s.save()
            return
        pick=None
        for n,v in s.agency.loopCandidates():
            if n in s.ran or n in s.held: continue
            pick=(n,v); break
        if not pick:
            s.lastIdle="no candidates"
            if s.auto:
                if s.noTaskSince==0: s.noTaskSince=now; s.save()
                elif now-s.noTaskSince>AUTO_IDLE: s.endAuto("noTasks","noTasks"); return
            return
        s.lastIdle=""; s.noTaskSince=0
        n,v=pick
        if v["status"]=="proposed":
            if not s.agency.autoAuthorize(n): s.attempts+=1; s.log("autoauth failed"); s.save(); return
        s.task=dict(id=f"task{n}-{now}",num=n,topic=f"t{n}",started=now,activeMs=0,lastTick=now,step="execute",steps=0,reads=0,stepTs=0,waiting=False,readId="",words=0,absorbed=0,code="",query="",resumeAt=0,waitSince=0,netWaits=0)
        s.save()
    def execute(s,now):
        t=s.task
        if t["waiting"] and now-t["stepTs"]<WAIT_MS: return
        if t["reads"]>=MAX_READS: s.endReadFail(t["code"] or "http"); return
        t["steps"]+=1; t["reads"]+=1; t["waiting"]=True; t["stepTs"]=now; t["readId"]=f"r{t['reads']}-{now}"
        if not s.save(): t["waiting"]=False; s.abort("save failed",True); return
        tid,rid=t["id"],t["readId"]
        s.core.loopRead(t["topic"],lambda code,w,a,q: s.onRead(tid,rid,code,w,a,q))
    def onRead(s,tid,rid,code,words,absorbed,q):
        t=s.task
        if t is None or t["id"]!=tid or t["readId"]!=rid or not t["waiting"] or t["step"]!="execute":
            s.log("stale ignored"); s.save(); return
        now=Clock.t; t["waiting"]=False; t["code"]=code
        if q: t["query"]=q
        if code in("ok","dup"):
            t["words"]=words; t["absorbed"]=absorbed; t["step"]="verify"; t["netWaits"]=0; t["waitSince"]=0
        elif code in("nonet","metered","limit","wait"):
            t["reads"]=max(0,t["reads"]-1); t["steps"]=max(0,t["steps"]-1)
            if t["waitSince"]==0: t["waitSince"]=now
            d=LIMIT_WAIT_MS if code=="limit" else BACKOFF[min(t["netWaits"],len(BACKOFF)-1)]
            t["netWaits"]+=1; t["resumeAt"]=now+d
        else:
            if t["reads"]>=MAX_READS: s.endReadFail(code); return
            t["resumeAt"]=now+READ_RETRY_MS
        s.save()
    def finishTrial(s,good):
        s.completed+=1; s.attempts=0; s.task=None
        if s.auto:
            s.autoMiss=0 if good else s.autoMiss+1; s.nextAt=Clock.t+AUTO_PAUSE
            if s.autoMiss>=AUTO_MAX_MISS: s.endAuto("errors","errors"); return
            if s.completed>=s.autoBase+s.autoQuota: s.endAuto("quota","quota"); return
        if s.completed>=s.budget(): s.on=False; s.log("trial done")
        s.save()
    def endReadFail(s,code):
        t=s.task; s.readFailed+=1; s.held.add(t["num"]); s.agency.diary.append(("readfail",t["num"])); s.addResult(("readfail",t["num"])); s.finishTrial(False)
    def verify(s):
        t=s.task; t["steps"]+=1; dup=t["code"]=="dup"
        ok=t["words"]>=MIN_WORDS and (dup or t["absorbed"]>=MIN_ABSORBED)
        if ok: s.volumePassed+=1; s.ran.add(t["num"]); s.agency.diary.append(("volume_ok",t["num"])); s.addResult(("volume_ok",t["num"]))
        else: s.lowVolume+=1; s.held.add(t["num"]); s.agency.diary.append(("low",t["num"])); s.addResult(("low",t["num"]))
        s.finishTrial(ok)
    def abort(s,why,fatal=False):
        s.log("abort "+why); s.attempts+=1; s.task=None; s.save()
        if fatal and s.auto: s.endAuto("save","save")
def text(n): return " ".join(f"слово{i%50}" for i in range(n))
def new(strats=(1,2,3)):
    a=AgencyStub(); [a.add(n) for n in strats]; c=CoreStub(); st={}; return a,c,st,Loop(a,c,st)
def restart(a,c,st): return Loop(a,c,st)   # новый «процесс»: состояние только из файлов
results=[]
def check(name,cond): results.append((name,bool(cond))); print(("PASS " if cond else "FAIL ")+name)

# S-A: временные ошибки сети: чтение и шаг не тратятся, пауза нарастает, возобновление само, перезапуск посреди паузы
a,c,st,L=new(); L.on=True; L.save(); L.tick()
c.script=["nonet","metered",{"text":text(300)}]
L.tick(); c.deliver(); t=L.task
check("A1 nonet: reads/steps не потрачены",t["reads"]==0 and t["steps"]==0 and t["resumeAt"]==Clock.t+5*MIN)
L.tick(); check("A2 во время паузы повторного запроса нет",len(c.callbacks)==0)
L=restart(a,c,st); L.on=True; Clock.t+=5*MIN+1; L.tick(); check("A3 после перезапуска и паузы возобновляется",len(c.callbacks)==1)
c.deliver(); check("A4 metered: пауза 15 мин, чтение не потрачено",L.task["reads"]==0 and L.task["resumeAt"]==Clock.t+15*MIN)
Clock.t+=15*MIN+1; L.tick(); c.deliver(); L.tick()
check("A5 после сети: объём подтверждён, испытание закрыто",L.volumePassed==1 and L.completed==1 and 1 in L.ran and not L.on)
check("A6 в Agency ничего не записано как итог",a.observed==[] and a.strats[1]["status"]=="authorized")

# S-B: неудача чтения: одна повторная попытка через 5 мин, затем остановка без записи неудачи
a,c,st,L=new(); L.on=True; L.save(); L.tick(); c.script=["http","empty"]
L.tick(); c.deliver(); check("B1 после 1-й неудачи читаем снова только через 5 мин",L.task["reads"]==1 and L.task["resumeAt"]==Clock.t+5*MIN)
L.tick(); check("B2 без паузы запроса нет",len(c.callbacks)==0)
Clock.t+=5*MIN+1; L.tick(); c.deliver()
check("B3 после 2-й неудачи задача закрыта без записи неудачи",L.task is None and L.readFailed==1 and 1 in L.held and a.observed==[] and a.strats[1]["status"]=="authorized" and not L.on)

# S-C: недостаточный объём (27 слов)
a,c,st,L=new(); L.on=True; L.save(); L.tick(); c.script=[{"text":text(27)}]; L.tick(); c.deliver(); L.tick()
check("C1 27 слов: объём недостаточный, не неудача стратегии",L.lowVolume==1 and 1 in L.held and a.observed==[] and a.strats[1]["status"]=="authorized" and ("low",1) in a.diary)
check("C2 27 слов остались в памяти (не стёрты)",c.lm_n==27)

# S-D: завершено
a,c,st,L=new(); L.on=True; L.save(); L.tick(); c.script=[{"text":text(400)}]; L.tick(); c.deliver(); L.tick()
check("D1 400 слов: исследование завершено, цель не оценивается автоматически",L.volumePassed==1 and ("volume_ok",1) in a.diary and a.observed==[])

# S-E: дедуп
a,c,st,L=new(); T={"text":text(300)}
c.loopRead("t1",lambda *x:None); c.script=[T]; c.deliver(); lm1=c.lm_n
res=[]; c.loopRead("t1",lambda code,w,ab,q:res.append((code,ab))); c.script=[T]; c.deliver()
check("E1 тот же текст второй раз: dup, absorbed=0, память не выросла",res==[("dup",0)] and c.lm_n==lm1 and c.absorb_calls==1)
res=[]; c.loopRead("t1",lambda code,w,ab,q:res.append(code)); c.script=[{"text":text(300)+" ещё"}]; c.deliver()
check("E2 другой текст усваивается",res==["ok"])
a,c,st,L=new(); L.on=True; L.save(); c.meta["lp:"+hashlib.sha1(" ".join(text(300).lower().split()).encode()).hexdigest()[:20]]=1
L.tick(); c.script=[{"text":text(300)}]; L.tick(); c.deliver(); L.tick()
check("E3 dup + 300 слов в тексте: объём подтверждён без повторного добавления",L.volumePassed==1 and c.absorb_calls==0)

# S-F: устаревший ответ внутри процесса (ожидание истекло, повторное чтение запущено, потом приходит ответ первого)
a,c,st,L=new(); L.on=True; L.save(); L.tick(); c.script=["http","http"]
check("F0 чтение запущено",L.task["waiting"] and len(c.callbacks)==1)
tid0,rid0=L.task["id"],L.task["readId"]
Clock.t+=WAIT_MS+1; L.tick(); r1=L.task["reads"]; rid1=L.task["readId"]
L.onRead(tid0,rid0,"ok",300,300,"q")   # запоздавший ответ ПЕРВОГО чтения приходит уже после повторной попытки
check("F1 устаревший ответ не подменяет новое чтение",L.task["step"]=="execute" and r1==2 and rid1!=rid0 and L.task["waiting"] and any("stale" in str(j) for j in L.journal))
L.onRead(tid0,rid1,"ok",300,300,"q")
check("F2 ответ актуального чтения принимается",L.task["step"]=="verify" and L.task["words"]==300)
# S-F2 (n0.85): процесс остановлен посреди чтения. Ответ уже не придёт, чтение не засчитывается, шаг не дублируется сверх лимита
a,c,st,L=new(); L.on=True; L.save(); L.tick()
check("F3 чтение в полёте записано в контрольную точку",L.task["waiting"] and L.task["reads"]==1 and L.task["steps"]==1)
L2=restart(a,c,st); L2.on=True
check("F4 после перезапуска прерванное чтение не засчитано (reads=0, steps=0, ожидания нет)",L2.task["waiting"]==False and L2.task["reads"]==0 and L2.task["steps"]==0)
nb=len(c.callbacks); Clock.t+=30_000; L2.tick()
check("F5 после перезапуска чтение запускается заново ровно один раз",len(c.callbacks)==nb+1 and L2.task["reads"]==1 and L2.task["steps"]==1)
check("F6 после перезапуска не создана вторая задача, Agency не тронут",L2.task["num"]==1 and a.observed==[] and a.strats[1]["status"]=="authorized")

# S-G: «цикл ещё»: история не сбрасывается, одобряется только одна следующая стратегия
a,c,st,L=new((1,2,3,4,5)); L.on=True; L.save(); L.tick(); c.script=[{"text":text(27)}]; L.tick(); c.deliver(); L.tick()
check("G0 лимит выбран, цикл выключен, включить нельзя",not L.on and L.setOn(True)=="refused")
hist=(L.completed,set(L.held),set(L.ran),len(L.journal))
check("G1 «цикл ещё» выдаёт ровно одно испытание",L.grantMore()=="granted" and L.budget()==2 and L.on)
L.tick()
st_=[a.strats[n]["status"] for n in sorted(a.strats)]
check("G2 одобрена одна следующая (№2), остальные proposed, №1 не берётся повторно",st_==["authorized","authorized","proposed","proposed","proposed"] and L.task["num"]==2)
check("G3 история не сброшена",L.completed==hist[0] and L.held>=hist[1] and len(L.journal)>=hist[3] and 1 in L.held)
check("G4 повторное «цикл ещё» при незавершённом не плодит разрешения",L.grantMore()=="already" and L.budget()==2)

# S-H: файл старого формата (n0.82): completed=1, ran={1}, без held/extra
a,c,st,_=new(); st.clear()
st["f"]=json.dumps({"fmt":1,"seq":9,"on":False,"completed":1,"volumePassed":0,"attempts":0,"ran":[],"journal":[[1,"x"]]})
a.strats[1]["status"]="failed"
L=Loop(a,c,st); check("H1 старый файл читается, цикл остаётся выключенным",L.completed==1 and L.budget()==1 and not L.on and L.held==set())
check("H2 «цикл ещё» работает после миграции, берёт №2",L.grantMore()=="granted" and (L.tick() or True) and L.task["num"]==2)

# S-I: сеть пропала на сутки: прерывание без итога
a,c,st,L=new(); L.on=True; L.save(); L.tick(); c.script=["nonet"]; L.tick(); c.deliver()
Clock.t+=MAX_WAIT_MS+MIN; L.tick()
check("I1 сутки без сети: задача прервана без итога, attempts=1",L.task is None and L.attempts==1 and a.observed==[])
# S-J: активное время отсчитывается заново после паузы
a,c,st,L=new(); L.on=True; L.save(); L.tick(); c.script=["nonet",{"text":text(300)}]; L.tick(); c.deliver()
Clock.t+=MAX_MS*2; L.tick()   # пауза дольше MAX_MS, но задача не должна быть прервана по «времени»
check("J1 длинная пауза не убивает задачу по лимиту времени",L.task is not None and L.task["steps"]==1 and len(c.callbacks)==1)
# S-K: не сохранилась контрольная точка: действия нет
a,c,st,L=new(); L.on=True; L.save(); L.fail_save=True; L.tick()
check("K1 нет контрольной точки: чтение не запускалось",len(c.callbacks)==0 and L.task is None)

def tk(L):
    """Тик при чтении, которое ещё «в полёте» (ответа пока нет, но ожидание не истекло)."""
    if L.task and L.task["waiting"]: L.task["stepTs"]=Clock.t
    L.tick()
# ===== n0.84: учёт активного времени и первый тик =====
def fresh():
    Clock.t=2_000_000_000
    a,c,st,L=new(); L.on=True; L.save(); return a,c,st,L
# N1/N2: задача создаётся и чтение стартует в том же тике; второй тик шаг не повторяет
a,c,st,L=fresh(); L.tick()
check("N1 создание задачи и немедленное начало чтения в одном тике",L.task is not None and L.task["steps"]==1 and L.task["reads"]==1 and len(c.callbacks)==1)
tid=L.task["id"]; Clock.t+=60_000; tk(L); Clock.t+=60_000; tk(L)
check("N2 повторных тиков шаг не дублируется, задача не создаётся заново",len(c.callbacks)==1 and L.task["id"]==tid and L.task["steps"]==1 and L.task["reads"]==1)
# N3: простой между тиками не расходует время (10 интервалов по 30 минут)
a,c,st,L=fresh(); L.tick(); t0=L.task["activeMs"]
for _ in range(10): Clock.t+=30*MIN; tk(L)
check("N3 простой (10 интервалов по 30 мин) не расходует активное время",L.task is not None and L.task["activeMs"]==t0==0)
# N4: накопление между рабочими тиками
a,c,st,L=fresh(); L.tick()
for _ in range(5): Clock.t+=60_000; tk(L)
check("N4 пять рабочих тиков по минуте = 5 минут активного времени",L.task is not None and L.task["activeMs"]==5*60_000)
Clock.t+=2*MIN; tk(L); check("N4b интервал ровно 2 минуты засчитывается",L.task["activeMs"]==7*60_000)
Clock.t+=2*MIN+1; tk(L); check("N4c интервал больше 2 минут не засчитывается (простой)",L.task["activeMs"]==7*60_000)
# N5: сохранение и восстановление после перезапуска
a,c,st,L=fresh(); L.tick()
for _ in range(4): Clock.t+=60_000; tk(L)
saved=json.loads(st["f"])["task"]
check("N5a накопленное время записано в loop_state.json",saved["activeMs"]==4*60_000 and saved["lastTick"]==Clock.t)
L2=restart(a,c,st); L2.on=True
check("N5b после перезапуска время восстановлено",L2.task["activeMs"]==4*60_000 and L2.task["lastTick"]==Clock.t)
Clock.t+=90_000; tk(L2); check("N5c после перезапуска интервал 90 с засчитан",L2.task["activeMs"]==4*60_000+90_000)
Clock.t+=40*MIN; tk(L2); check("N5d долгий простой до перезапуска не расходует лимит",L2.task["activeMs"]==4*60_000+90_000)
# N6/N7/N8: лимиты отдельно и вместе
a,c,st,L=fresh(); L.tick(); L.task["activeMs"]=MAX_MS-30_000; Clock.t+=60_000; L.tick()
check("N6 сработал только лимит времени",L.task is None and any("исчерпан лимит активного времени (15 минут)" in j[1] for j in L.journal) and not any("лимит шагов" in j[1] for j in L.journal))
a,c,st,L=fresh(); L.tick(); L.task["steps"]=MAX_STEPS; L.task["waiting"]=False; Clock.t+=60_000; L.tick()
check("N7 сработал только лимит шагов",L.task is None and any("исчерпан лимит шагов (6 из 6)" in j[1] for j in L.journal) and not any("активного времени" in j[1] for j in L.journal))
a,c,st,L=fresh(); L.tick(); L.task["steps"]=MAX_STEPS; L.task["activeMs"]=MAX_MS-1_000; Clock.t+=60_000; L.tick()
check("N8 сработали оба лимита: указано оба",L.task is None and any("исчерпаны лимит шагов (6 из 6) и лимит активного времени (15 минут)" in j[1] for j in L.journal))
# N9: завершённый шаг не выполняется повторно
a,c,st,L=fresh(); c.script=[{"text":text(300)}]; L.tick(); c.deliver()
for _ in range(4): Clock.t+=60_000; L.tick()
check("N9 после завершения испытания шаги не повторяются, новая задача не создаётся",L.completed==1 and L.task is None and c.absorb_calls==1 and len(c.callbacks)==0 and not L.on)
# N10: старый формат состояния без activeMs/lastTick и давний started: не прерывается по настенному времени
a,c,st,_=new(); old={"fmt":1,"seq":5,"on":True,"completed":0,"attempts":0,"ran":[],"journal":[],"task":{"id":"old","num":1,"topic":"t1","started":1,"step":"execute","steps":0,"reads":0,"stepTs":0,"waiting":False,"readId":"","words":0,"absorbed":0,"code":"","query":"","resumeAt":0,"waitSince":0,"netWaits":0}}
st["f"]=json.dumps(old); a.strats[1]["status"]="authorized"; Clock.t=2_000_000_000
L=Loop(a,c,st); L.on=True
check("N10a старое состояние загружено, поля времени = безопасные значения по умолчанию",L.task["activeMs"]==0 and L.task["lastTick"]==0)
L.tick(); check("N10b старая задача не прервана по настенному времени и начала чтение",L.task is not None and len(c.callbacks)==1)
# N11: пауза сети не расходует активное время
a,c,st,L=fresh(); c.script=["nonet",{"text":text(300)}]; L.tick(); c.deliver()
act=L.task["activeMs"]; Clock.t+=4*MIN; L.tick(); Clock.t+=2*MIN; L.tick()
check("N11 пауза не расходует активное время; чтение после неё стартует",L.task["activeMs"]==act and len(c.callbacks)==1)

# N12: сценарий реального журнала (№3 «панора»): задача создана, 25 минут тиков нет, затем приложение открыто
a,c,st,L=fresh(); L.tick(); Clock.t+=25*MIN; L.tick()
check("N12 после 25 минут без тиков задача жива и не прервана по времени",L.task is not None and L.task["activeMs"]==0 and not any("прервана" in j[1] or "abort" in j[1] for j in L.journal))


# ===== n0.85: самостоятельная серия =====
def run_trial(L,a,c,txt=None,gap=70_000):
    """Одно испытание: тик (старт+чтение), ответ сети, тик (проверка объёма), затем пауза серии."""
    c.script=[{"text":txt or text(400+len(c.meta))}]
    L.tick(); c.deliver(); Clock.t+=30_000; L.tick(); Clock.t+=gap; return L
def mk(n=8):
    Clock.t=3_000_000_000; a,c,st,L=new(tuple(range(1,n+1))); return a,c,st,L

# AU1: один раз включили, дальше без «цикл ещё» проходит несколько испытаний подряд
a,c,st,L=mk(); L.setAuto(3)
for _ in range(3): run_trial(L,a,c,text(300+_*7))
check("AU1 серия из 3: три испытания без «цикл ещё»",L.completed==3 and L.volumePassed==3 and L.ran=={1,2,3})
check("AU2 после лимита серия остановлена, причина quota, рубильник сработал",not L.on and not L.auto and L.stopCode=="quota" and L.ownerStatus()=="done")
check("AU3 следующая стратегия не одобрена заранее (только 3 из 8 authorized)",sum(1 for v in a.strats.values() if v["status"]=="authorized")==3)
check("AU4 Agency: итог не записан ни по одной (цель не объявляется достигнутой)",a.observed==[])
check("AU5 исходы записаны (3 записи, объём подтверждён)",[r[0] for r in L.results]==["volume_ok"]*3)
L.tick(); check("AU6 после остановки тик ничего не делает",L.completed==3 and L.task is None)

# AU7: нет повторного выполнения: те же номера не берутся снова
a,c,st,L=mk(5); L.setAuto(5)
for _ in range(5): run_trial(L,a,c,text(300+_*7))
check("AU7 5 испытаний = 5 разных стратегий, повторов нет",sorted(L.ran)==[1,2,3,4,5] and L.completed==5)
check("AU7b стратегий для повторного прогона не осталось: новая серия простаивает, а не повторяет",(L.setAuto(2) or True) and (L.tick() or True) and L.task is None and L.lastIdle!="")

# AU8: пауза между испытаниями
a,c,st,L=mk(); L.setAuto(5); c.script=[{"text":text(300)}]; L.tick(); c.deliver(); Clock.t+=30_000; L.tick()
n=len(c.callbacks); Clock.t+=10_000; L.tick()
check("AU8 в течение паузы 60 с новая задача не начинается",L.task is None and len(c.callbacks)==n)
Clock.t+=AUTO_PAUSE; L.tick(); check("AU8b после паузы начата следующая задача",L.task is not None and L.task["num"]==2)

# AU9: две неудачи подряд (мало текста) = остановка, нужен владелец
a,c,st,L=mk(); L.setAuto(5)
run_trial(L,a,c,text(20)); check("AU9 одна неудача объёма: серия идёт",L.auto and L.on and L.autoMiss==1)
run_trial(L,a,c,text(25)+" а"); 
check("AU9b две подряд: серия остановлена, нужен владелец",not L.on and L.stopCode=="errors" and L.ownerStatus()=="need_owner")
check("AU9c в Agency ничего не записано, обе стратегии остались одобренными",a.observed==[] and a.strats[1]["status"]=="authorized" and a.strats[2]["status"]=="authorized")
# AU10: успешное испытание сбрасывает счётчик
a,c,st,L=mk(); L.setAuto(5); run_trial(L,a,c,text(20)); run_trial(L,a,c,text(300)); run_trial(L,a,c,text(21)+" б")
check("AU10 неудача, успех, неудача: серия не остановлена (счётчик подряд сброшен)",L.on and L.auto and L.autoMiss==1 and L.completed==3)

# AU11: лимит активного времени серии
a,c,st,L=mk(); L.setAuto(10); L.tick(); L.autoActive=AUTO_MAX_ACTIVE+1; Clock.t+=30_000; L.tick()
check("AU11 лимит активного времени серии: остановка, причина time, задача сохранена",not L.on and L.stopCode=="time" and L.task is not None and L.ownerStatus()=="paused")
# AU12: лимит срока серии 48 часов
a,c,st,L=mk(); L.setAuto(10); Clock.t+=AUTO_MAX_SPAN+1; L.tick()
check("AU12 срок серии 48 ч: остановка, причина span",not L.on and L.stopCode=="span")
# AU13: квота ограничена 10
a,c,st,L=mk(); L.setAuto(99); check("AU13 квота не больше 10",L.autoQuota==10)

# AU14: нет подходящих тем: серия ждёт, затем останавливается с просьбой к владельцу
a,c,st,L=mk(0); L.setAuto(3); L.tick(); check("AU14 тем нет: серия ждёт, не останавливается сразу",L.on and L.noTaskSince!=0 and L.task is None)
Clock.t+=AUTO_IDLE+1; L.tick(); check("AU14b через 6 часов без тем: остановка noTasks, нужен владелец",not L.on and L.stopCode=="noTasks" and L.ownerStatus()=="need_owner")
# AU15: тема появилась до срока: работа продолжается
a,c,st,L=mk(0); L.setAuto(3); L.tick(); Clock.t+=3_600_000; a.add(1); c.script=[{"text":text(300)}]; L.tick()
check("AU15 тема появилась: серия её берёт, ожидание сброшено",L.task is not None and L.task["num"]==1 and L.noTaskSince==0)

# AU16: рубильник «цикл стоп» гасит серию; задача и история сохраняются; повторный запуск продолжает ту же задачу
a,c,st,L=mk(); L.setAuto(5); c.script=[{"text":text(300)}]; L.tick(); tid=L.task["id"]; L.setOn(False)
check("AU16 рубильник: серия и цикл выключены, задача сохранена, статус paused",not L.on and not L.auto and L.task["id"]==tid and L.ownerStatus()=="paused")
L.tick(); check("AU16b после стопа тик ничего не делает",len(c.callbacks)==1)
L.setAuto(5); check("AU16c новая серия продолжает ту же задачу, а не создаёт другую",L.task["id"]==tid)

# AU17: сохранение и восстановление серии между запусками
a,c,st,L=mk(); L.setAuto(4); run_trial(L,a,c,text(300)); L2=restart(a,c,st)
check("AU17 серия восстановлена: квота, база, счётчики, результаты",L2.auto and L2.on and L2.autoQuota==4 and L2.autoBase==0 and L2.completed==1 and L2.ran=={1} and len(L2.results)==1)
c.script=[{"text":text(310)}]; Clock.t+=AUTO_PAUSE+1; L2.tick(); c.deliver(); Clock.t+=30_000; L2.tick()
check("AU17b после перезапуска серия идёт дальше, №1 не повторяется",L2.completed==2 and L2.ran=={1,2})

# AU18: сеть пропала посреди серии: ожидание, статус wait_net, затем продолжение
a,c,st,L=mk(); L.setAuto(3); c.script=["nonet",{"text":text(300)}]; L.tick(); c.deliver()
check("AU18 нет сети: статус wait_net, чтение и шаг не потрачены, серия не остановлена",L.ownerStatus()=="wait_net" and L.task["reads"]==0 and L.on and L.auto)
check("AU18b во время ожидания сети серия не расходует активное время",L.autoActive==0)
Clock.t+=5*MIN+1; L.tick(); c.deliver(); Clock.t+=30_000; L.tick()
check("AU18c сеть вернулась: испытание завершено, серия идёт",L.completed==1 and L.ran=={1} and L.on)

# AU19: простой между фоновыми запусками не расходует лимит серии
a,c,st,L=mk(); L.setAuto(3); L.tick()
for _ in range(6): Clock.t+=30*MIN; tk(L)
check("AU19 шесть фоновых запусков по 30 минут: активное время серии не растёт",L.autoActive==0 and L.on)

# AU20: нет контрольной точки: серия останавливается (небезопасно продолжать)
a,c,st,L=mk(); L.setAuto(3); L.fail_save=True; L.tick()
check("AU20 не сохраняется состояние: чтение не запущено, серия остановлена, нужен владелец",len(c.callbacks)==0 and not L.on and L.stopCode=="save" and L.ownerStatus()=="need_owner")

# AU21: три прерывания подряд (лимит шагов) останавливают серию
a,c,st,L=mk(); L.setAuto(5)
for _ in range(3):
    L.tick(); L.task["steps"]=MAX_STEPS; Clock.t+=1000; L.tick()
Clock.t+=1000; L.tick()
check("AU21 три прерывания подряд: серия остановлена, причина attempts, итог не записан",not L.on and L.stopCode=="attempts" and a.observed==[])

# AU22: совместимость: файл n0.84 (без полей серии) читается, серия выключена
a,c,st,_=new(); st.clear()
st["f"]=json.dumps({"fmt":1,"seq":5,"on":False,"completed":2,"volumePassed":2,"extra":1,"attempts":0,"ran":[1,2],"held":[],"journal":[],"task":{"id":"x","num":3,"projectId":"p3","topic":"t3","expected":"","started":1,"step":"execute","steps":1,"reads":1,"activeMs":120000,"lastTick":5}})
L=Loop(a,c,st)
check("AU22 файл n0.84 читается: серия выключена, completed/ran/task сохранены",not L.auto and L.completed==2 and L.ran=={1,2} and L.task["activeMs"]==120000 and L.stopCode=="" and L.results==[])
# AU23: старый ручной режим не изменился
a,c,st,L=mk(3); L.on=True; L.save(); run_trial(L,a,c,text(300))
check("AU23 ручной режим: одно испытание и стоп без «цикл ещё» (n0.84 сохранено)",L.completed==1 and not L.on and L.task is None and not L.auto)
# AU24: фон: backgroundWork
a,c,st,L=mk(); L.setAuto(3); check("AU24 фон: без задачи и при наличии тем нужен шаг",L.backgroundWork())
c.script=[{"text":text(300)}]; L.tick(); check("AU24b фон: чтение в полёте, шаг нужен",L.backgroundWork())
c.deliver(); L.task["resumeAt"]=Clock.t+10*MIN; L.task["waitSince"]=Clock.t
check("AU24c фон: долгая пауза сети, задание не держим",not L.backgroundWork())
a,c,st,L=mk(0); L.setAuto(3); L.tick(); check("AU24d фон: тем нет, задание не держим",not L.backgroundWork())
# AU25: ядро выключено
a,c,st,L=mk(); L.setAuto(3); L.core_enabled=False; check("AU25 ядро выключено: статус «приостановлена», а не «работает»",L.ownerStatus()=="paused")
# AU26: права: автопилот берёт только R1 (в модели все кандидаты R1; не R1 в Kotlin отсекает isR1, код не менялся) и не трогает Agency
a,c,st,L=mk(); L.setAuto(3)
for _ in range(3): run_trial(L,a,c,text(300+_*7))
check("AU26 за серию Agency получил только одобрения №1–3 и ни одного итога/отклонения",a.observed==[] and not any(v["status"] in("failed","succeeded","rejected") for v in a.strats.values()))

print(); print("ИТОГО:",sum(1 for _,ok in results if ok),"из",len(results)); import sys; sys.exit(0 if all(ok for _,ok in results) else 1)
