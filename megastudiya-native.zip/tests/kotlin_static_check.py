# Статическая проверка Kotlin-файлов БЕЗ компилятора: баланс скобок вне строк и комментариев (с учётом шаблонов ${...}),
# закрытые строки, и поиск ошибочных токенов лексером Pygments. Это НЕ компиляция: типы, имена и вызовы не проверяются.
import sys, os
def balance(src):
    st=[]; i=0; n=len(src); line=1; pairs={')':'(',']':'[','}':'{'}
    mode=[('code',None)]   # стек режимов: code / tstr(шаблон в строке)
    def err(m): return f"строка {line}: {m}"
    while i<n:
        c=src[i]
        if c=='\n': line+=1
        if src.startswith('//',i):
            while i<n and src[i]!='\n': i+=1
            continue
        if src.startswith('/*',i):
            d=1; i+=2
            while i<n and d:
                if src.startswith('/*',i): d+=1; i+=2
                elif src.startswith('*/',i): d-=1; i+=2
                else:
                    if src[i]=='\n': line+=1
                    i+=1
            if d: return err('незакрытый комментарий')
            continue
        if src.startswith('"""',i):
            i+=3
            while i<n and not src.startswith('"""',i):
                if src[i]=='\n': line+=1
                i+=1
            i+=3; continue
        if c=='"':
            i+=1
            while i<n:
                ch=src[i]
                if ch=='\\': i+=2; continue
                if ch=='\n': return err('строка не закрыта до конца строки')
                if ch=='"': i+=1; break
                if ch=='$' and i+1<n and src[i+1]=='{':
                    # шаблон: ищем парную }
                    d=1; i+=2
                    while i<n and d:
                        if src[i]=='{': d+=1
                        elif src[i]=='}': d-=1
                        elif src[i]=='"':   # вложенная строка в шаблоне
                            i+=1
                            while i<n and src[i]!='"':
                                if src[i]=='\\': i+=1
                                i+=1
                        i+=1
                    continue
                i+=1
            continue
        if c=="'":
            j=i+1
            if src[j]=='\\': j+=2
            else: j+=1
            while j<n and src[j]!="'" and j-i<8: j+=1
            i=j+1; continue
        if c in '([{': st.append((c,line))
        elif c in ')]}':
            if not st or st[-1][0]!=pairs[c]: return err(f"лишняя «{c}»")
            st.pop()
        i+=1
    if st: return f"не закрыта «{st[-1][0]}» из строки {st[-1][1]}"
    return None
def pyg(src):
    from pygments.lexers import KotlinLexer
    from pygments.token import Error
    bad=[(l,v) for t,v in KotlinLexer().get_tokens(src) for l in [0] if t in Error]
    return bad
if __name__=="__main__":
    root=sys.argv[1]; bad=0
    for f in sorted(os.listdir(root)):
        if not f.endswith('.kt'): continue
        s=open(os.path.join(root,f),encoding='utf-8').read()
        r=balance(s); e=pyg(s)
        if r or e: bad+=1; print("FAIL",f,r or "",e[:3])
        else: print("ok  ",f)
    print("ИТОГО проблем:",bad); sys.exit(1 if bad else 0)
