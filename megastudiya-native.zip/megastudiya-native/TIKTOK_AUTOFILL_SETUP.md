# TikTok automatic feed — setup and verification

The Video tab can search public TikTok videos through the third-party Apify Actor `scrapysocial/tiktok-scraper`. This is not TikTok's official API and does not require a TikTok login. The Actor and TikTok may change or block scraping at any time.

## Required to populate the feed
1. Create/sign in to an Apify account and copy an API token from Apify Console → Settings / API & Integrations.
2. In Megastudiya → Я → Источники видео → Automatic TikTok feed, paste the token and Save.
3. Use **Check search** to run a small search and read its result message. The app also attempts automatic discovery when the Video tab is opened and the catalog is low.

Without an Apify token, automatic discovery cannot run. The clipboard-link import is still available in the empty feed screen.

## What the app requests
- `endpoint=search-videos`
- up to three keyword queries in one batch run, five items per query
- results are de-duplicated by TikTok video ID and saved to the MediaHub catalog
- repeated searches are rate-limited for four minutes unless Force/Check is used; batch mode combines queries into one Actor run

Actor input/output can change; inspect the returned message in-app if a request fails. A successful search can still return no videos for a keyword. The request uses the Actor documented batch input and parses the documented `id`, `author.username`, `description`, `video.cover`, and `video.playUrl` fields.

## Playback caveat
Search results are metadata/link cards. A direct CDN video URL is not guaranteed to be present or stable in search results. The app therefore uses TikTok's official embedded player for cards without a usable direct stream. Embedding can be blocked, a video can be removed/private, and autoplay may require a tap. This package has **not** been APK-built or playback-tested on a physical Android device.

## Cost and privacy
The actor advertises pay-per-result pricing (listed from $1.40 per 1,000 results, with plan-dependent pricing), so a small search is inexpensive but not necessarily free. The API token is stored encrypted by the app's device-keystore-backed secret storage. Searches send keywords and the token to Apify; they are not sent to TikTok's official API.

## Diagnostics
- HTTP 401/403: token rejected or actor permission issue.
- HTTP 402: billing/credits issue.
- HTTP 404: actor identifier or endpoint changed.
- Timeout/network error: retry when connection is available.
- “Search returned no public videos”: the provider returned an empty result or the current parser did not recognize its response; treat this as unverified rather than success.
