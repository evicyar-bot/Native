import pickle, math
RAMP=[(255,232,176),(255,190,90),(205,200,215),(140,170,255)]
D=pickle.load(open('logo.pkl','rb'))
def hx(c): c=RAMP[c] if isinstance(c,int) else c; return '#%02X%02X%02X'%c
f=lambda v:('%.2f'%v).rstrip('0').rstrip('.')
o=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108" width="1080" height="1080">',
 '<title>Megastudiya — кольцо-сеть. Ядро — само кольцо.</title>',
 '<defs><radialGradient id="v" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#142458" stop-opacity=".55"/><stop offset=".6" stop-color="#142458" stop-opacity=".18"/><stop offset="1" stop-color="#142458" stop-opacity="0"/></radialGradient></defs>',
 '<rect width="108" height="108" fill="#0B0D12"/><circle cx="54" cy="54" r="46" fill="url(#v)"/>']
prims=list(D['prims'])
for s in D['sats']:
    ci=0 if s['b']>0.6 else 2 if s['b']<0.3 else 1
    prims.append(('fill',(s['x'],s['y'],s['r']*3),ci,s['a']*0.18,'glow'))
    prims.append(('fill',(s['x'],s['y'],s['r']),ci,s['a'],'core'))
for kind,ar,c,a,tier in prims:
    h=hx(c); a=min(1,a)
    if kind=='fill': x,y,r=ar; o.append('<circle cx="%s" cy="%s" r="%s" fill="%s" fill-opacity="%s"/>'%(f(x),f(y),f(r),h,f(a)))
    elif kind=='ring': x,y,r,w=ar; o.append('<circle cx="%s" cy="%s" r="%s" fill="none" stroke="%s" stroke-opacity="%s" stroke-width="%s"/>'%(f(x),f(y),f(r),h,f(a),f(w)))
    elif kind=='line': x1,y1,x2,y2,w=ar; o.append('<line x1="%s" y1="%s" x2="%s" y2="%s" stroke="%s" stroke-opacity="%s" stroke-width="%s" stroke-linecap="round"/>'%(f(x1),f(y1),f(x2),f(y2),h,f(a),f(w)))
    elif kind=='star':
        x,y,s=ar; pts=[]
        for i in range(8):
            ang=i*math.pi/4-math.pi/2; rr=s*1.9 if i%2==0 else s*0.38
            pts.append('%s,%s'%(f(x+rr*math.cos(ang)),f(y+rr*math.sin(ang))))
        o.append('<polygon points="%s" fill="%s" fill-opacity="%s"/>'%(' '.join(pts),h,f(a)))
o.append('</svg>')
open('/mnt/user-data/outputs/megastudiya-logo.svg','w',encoding='utf-8').write('\n'.join(o))
import os; print(os.path.getsize('/mnt/user-data/outputs/megastudiya-logo.svg'))
