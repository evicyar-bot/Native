def ramp_idx(b):
    u=1-b
    return 0 if u<0.25 else 1 if u<0.5 else 2 if u<0.75 else 3
