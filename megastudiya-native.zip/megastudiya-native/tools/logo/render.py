import pickle, math, sys
from PIL import Image, ImageDraw, ImageFilter
import sys
D=pickle.load(open(sys.argv[1] if len(sys.argv)>1 else 'logo.pkl','rb'))
BG=(11,13,18)
RAMP=[(255,232,176),(255,190,90),(205,200,215),(140,170,255)]
def col(c): return RAMP[c] if isinstance(c,int) else c
def render(S, with_sats=True, mono=False, sat_max_r=99, bg=True):
    N=108*S
    if bg:
        img=Image.new('RGBA',(N,N),BG+(255,))
        # мягкий тёмно-синий ореол
        ov=Image.new('RGBA',(N,N),(0,0,0,0)); d=ImageDraw.Draw(ov)
        for r,a in [(46,10),(38,14),(30,18)]:
            d.ellipse([(54-r)*S,(54-r)*S,(54+r)*S,(54+r)*S],fill=(20,36,90,a))
        ov=ov.filter(ImageFilter.GaussianBlur(S*6)); img=Image.alpha_composite(img,ov)
    else: img=Image.new('RGBA',(N,N),(0,0,0,0))
    def over(bb,fn,c,a):
        nonlocal img
        x0,y0,x1,y1=[int(v) for v in bb]; x0=max(0,x0-2);y0=max(0,y0-2);x1=min(N,x1+2);y1=min(N,y1+2)
        if x1<=x0 or y1<=y0: return
        lay=Image.new('RGBA',(x1-x0,y1-y0),(0,0,0,0)); d=ImageDraw.Draw(lay)
        fn(d,(-x0,-y0),(*c,int(255*min(1,a))))
        reg=img.crop((x0,y0,x1,y1)); img.paste(Image.alpha_composite(reg,lay),(x0,y0))
    prims=list(D['prims'])
    if with_sats:
        for s in D['sats']:
            if math.hypot(s['x']-54,s['y']-54)>sat_max_r: continue
            ci=0 if s['b']>0.6 else 2 if s['b']<0.3 else 1
            prims.append(('fill',(s['x'],s['y'],s['r']*3),ci,s['a']*0.18,'glow'))
            prims.append(('fill',(s['x'],s['y'],s['r']),ci,s['a'],'core'))
    for kind,ar,c,a,tier in prims:
        if mono and tier=='glow': continue
        cc=(255,255,255) if mono else col(c)
        if kind=='fill':
            x,y,r=ar
            over(((x-r)*S,(y-r)*S,(x+r)*S,(y+r)*S),lambda d,o,f:d.ellipse([(x-r)*S+o[0],(y-r)*S+o[1],(x+r)*S+o[0],(y+r)*S+o[1]],fill=f),cc,a)
        elif kind=='ring':
            x,y,r,w=ar; rr=r+w/2
            over(((x-rr)*S,(y-rr)*S,(x+rr)*S,(y+rr)*S),lambda d,o,f:d.ellipse([(x-rr)*S+o[0],(y-rr)*S+o[1],(x+rr)*S+o[0],(y+rr)*S+o[1]],outline=f,width=max(1,int(w*S))),cc,a)
        elif kind=='line':
            x1,y1,x2,y2,w=ar
            over((min(x1,x2)*S-S,min(y1,y2)*S-S,max(x1,x2)*S+S,max(y1,y2)*S+S),lambda d,o,f:d.line([x1*S+o[0],y1*S+o[1],x2*S+o[0],y2*S+o[1]],fill=f,width=max(1,int(w*S))),cc,a)
        elif kind=='star':
            x,y,s=ar; pts=[]
            for i in range(8):
                ang=i*math.pi/4-math.pi/2; rr=s*1.9 if i%2==0 else s*0.38
                pts.append((x+rr*math.cos(ang),y+rr*math.sin(ang)))
            over((min(p[0] for p in pts)*S,min(p[1] for p in pts)*S,max(p[0] for p in pts)*S,max(p[1] for p in pts)*S),lambda d,o,f:d.polygon([(px*S+o[0],py*S+o[1]) for px,py in pts],fill=f),cc,a)
    return img.convert('RGB') if bg else img
if __name__=='__main__':
    big=render(10); big.save('master_'+('icon' if 'icon' in (sys.argv[1] if len(sys.argv)>1 else '') else 'full')+'.png'); print('master ok')
    # проверка на малых размерах (круглая маска как у лаунчера)
    sheet=Image.new('RGB',(1000,420),(30,30,34)); x=20
    for px in [300,160,96,64,48]:
        im=render(8,with_sats=True,sat_max_r=34).resize((px,px),Image.LANCZOS)
        m=Image.new('L',(px,px),0); ImageDraw.Draw(m).ellipse([px*0.09,px*0.09,px*0.91,px*0.91],fill=255)
        sheet.paste(im,(x,20),m); x+=px+30
    sheet.save('sizes_'+('icon' if 'icon' in (sys.argv[1] if len(sys.argv)>1 else '') else 'full')+'.png'); print('sizes ok')
