import math, random, pickle, sys
C=54.0; LIGHT=-math.pi/4; TAU=2*math.pi
def bright(th): return 0.5+0.5*math.cos(th-LIGHT)
def ramp_idx(b):
    u=1-b
    return 0 if u<0.25 else 1 if u<0.5 else 2 if u<0.75 else 3
def pol(th,r): return (C+r*math.cos(th), C+r*math.sin(th))
def ell_pt(a,b,phi,t):
    x=a*math.cos(t); y=b*math.sin(t)
    return (C+x*math.cos(phi)-y*math.sin(phi), C+x*math.sin(phi)+y*math.cos(phi))
def frac(th): return ((th+math.pi/2)%TAU)/TAU
def build(ICON, seed=8):
    rnd=random.Random(seed)
    K=20 if ICON else 30; SEG=36
    a,b=(32.5,24.0) if ICON else (31.5,24.5)
    lw=0.36 if ICON else 0.13
    prims=[]; segs=[]; nodes=[]; hubs=[]; sats=[]
    # свечение полосы
    for m in range(48):
        th=m*TAU/48-math.pi/2; bb=bright(th); x,y=pol(th,28.0); ci=ramp_idx(bb); w=0.35+0.65*bb
        for rr,al in ([(9.0,0.018),(6.0,0.028),(3.4,0.04)] if ICON else [(8.5,0.012),(5.5,0.018),(3.2,0.026)]):
            prims.append(('fill',(x,y,rr),ci,al*w,'glow'))
    # нити: повёрнутые эллипсы дают плетёный ободок
    for k in range(K):
        phi=math.pi*k/K
        pts=[ell_pt(a,b,phi,TAU*s/SEG) for s in range(SEG+1)]
        for s in range(SEG):
            p,q=pts[s],pts[s+1]
            th=math.atan2((p[1]+q[1])/2-C,(p[0]+q[0])/2-C); bb=bright(th); ci=ramp_idx(bb)
            al=(0.30+0.55*bb) if ICON else (0.16+0.52*bb)
            prims.append(('line',(*p,*q,lw),ci,al,'core'))
            segs.append((*p,*q,frac(th),ci))
    # бусины по внешнему краю: кончики эллипсов
    tips=[]
    for k in range(K):
        phi=math.pi*k/K
        for t in (0,math.pi):
            x,y=ell_pt(a,b,phi,t); th=math.atan2(y-C,x-C); tips.append((th,x,y))
    for th,x,y in tips:
        bb=bright(th); r=(0.32+0.55*bb**1.5)*(1.9 if ICON else 1.0); al=0.6+0.4*bb; ci=ramp_idx(bb)
        prims.append(('fill',(x,y,r*2.6),ci,0.12*al,'glow'))
        prims.append(('fill',(x,y,r),ci,al,'core'))
        nodes.append((x,y,r,ci,al))
    # узлы на нитях в середине полосы (только полная версия)
    if not ICON:
        for _ in range(22):
            k=rnd.randrange(K); phi=math.pi*k/K; t=rnd.uniform(0,TAU)
            x,y=ell_pt(a,b,phi,t)
            if not (26.2<math.hypot(x-C,y-C)<29.2): continue
            th=math.atan2(y-C,x-C); bb=bright(th); ci=ramp_idx(bb); r=rnd.uniform(0.35,0.8)*(0.6+0.5*bb); al=0.7
            prims.append(('fill',(x,y,r*2.4),ci,0.12,'glow')); prims.append(('fill',(x,y,r),ci,al,'core'))
            nodes.append((x,y,r,ci,al))
    # пять неровных хабов вместо ровных «мест»: один яркий у света и несколько тихих
    want=[(-45,1.0),(22,0.55),(112,0.62),(203,0.5),(262,0.55)]
    for deg,s_ in want:
        th0=math.radians(deg)
        th,x,y=min(tips,key=lambda t_:abs(((t_[0]-th0+math.pi)%TAU)-math.pi))
        ci=ramp_idx(bright(th))
        prims.append(('fill',(x,y,4.2*s_),ci,0.11,'glow')); prims.append(('fill',(x,y,2.4*s_),ci,0.22,'glow'))
        prims.append(('fill',(x,y,0.9*s_+0.4),0,1.0,'core'))
        if s_==1.0:
            prims.append(('star',(x,y,2.4),0,0.95,'core'))
            prims.append(('line',(x-11,y,x+11,y,0.14),0,0.55,'core')); prims.append(('line',(x,y-11,x,y+11,0.14),0,0.55,'core'))
        hubs.append((x,y,frac(th),s_))
    # спутники только снаружи; центр остаётся чистым
    if not ICON:
        hth=[math.radians(d) for d,_ in want]
        for _ in range(300):
            th=rnd.choice(hth)+rnd.gauss(0,0.25) if rnd.random()<0.5 else rnd.uniform(0,TAU)
            r=min(39,32.2+abs(rnd.gauss(0,2.8)))
            x,y=pol(th,r); bb=bright(th)
            sats.append(dict(x=x,y=y,r=rnd.uniform(0.10,0.22),a=rnd.uniform(0.3,0.85),b=bb))
    return dict(prims=prims,segs=segs,nodes=nodes,hubs=hubs,sats=sats)
F=build(False); I=build(True)
pickle.dump(F,open('logo.pkl','wb')); pickle.dump(I,open('logo_icon.pkl','wb'))
print(len(F['prims']),len(F['segs']),len(I['prims']))
