import pickle, math, os
from collections import OrderedDict
RAMP=[(255,232,176),(255,190,90),(205,200,215),(140,170,255)]
def col(c): return RAMP[c] if isinstance(c,int) else c
def f(v): return ('%.2f'%v).rstrip('0').rstrip('.')
ICON=pickle.load(open('logo_icon.pkl','rb')); FULL=pickle.load(open('logo.pkl','rb'))
base='/home/claude/proj/megastudiya-native/app/src/main/'
def build(D,mono):
    groups=OrderedDict()
    def add(key,seg): groups.setdefault(key,[]).append(seg)
    for kind,ar,c,a,tier in D['prims']:
        if mono:
            if tier=='glow' or a<0.3: continue
            cc=(255,255,255); a=min(1.0,a*1.1+0.1)
        else: cc=col(c)
        ab=min(1.0,round(a*16)/16)
        hexc='#%02X%02X%02X%02X'%(int(round(ab*255)),*cc)
        if kind=='fill':
            x,y,r=ar
            add(('fill',hexc,0),'M%s,%sa%s,%s 0 1,0 %s,0a%s,%s 0 1,0 %s,0z'%(f(x-r),f(y),f(r),f(r),f(2*r),f(r),f(r),f(-2*r)))
        elif kind=='line':
            x1,y1,x2,y2,w=ar
            if mono and w<0.3: w=0.3
            add(('line',hexc,w),'M%s,%sL%s,%s'%(f(x1),f(y1),f(x2),f(y2)))
        elif kind=='star':
            x,y,s=ar; pts=[]
            for i in range(8):
                ang=i*math.pi/4-math.pi/2; rr=s*1.9 if i%2==0 else s*0.38
                pts.append((x+rr*math.cos(ang),y+rr*math.sin(ang)))
            add(('fill',hexc,0),'M'+'L'.join('%s,%s'%(f(px),f(py)) for px,py in pts)+'z')
    out=['<?xml version="1.0" encoding="utf-8"?>',
         '<!-- Логотип: плетёное кольцо из нитей-орбит без ядра. Ядро — само кольцо. Сгенерировано (gen2.py), не править руками. -->',
         '<vector xmlns:android="http://schemas.android.com/apk/res/android"',
         '    android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">']
    for (kind,c,w),segs in groups.items():
        d=''.join(segs)
        if kind=='fill': out.append('    <path android:fillColor="%s" android:pathData="%s" />'%(c,d))
        else: out.append('    <path android:fillColor="#00000000" android:strokeColor="%s" android:strokeWidth="%s" android:strokeLineCap="round" android:pathData="%s" />'%(c,f(w),d))
    out.append('</vector>')
    return '\n'.join(out)+'\n'
for n,m in [('ic_launcher_foreground.xml',False),('ic_launcher_mono.xml',True)]:
    open(base+'res/drawable/'+n,'w',encoding='utf-8').write(build(ICON,m)); print(n,os.path.getsize(base+'res/drawable/'+n))
ramp2brand={0:1,1:0,2:3,3:2}
dots=[(x,y,r,ramp2brand[ci],a) for x,y,r,ci,a in FULL['nodes']]
for s_ in FULL['sats']:
    ci=1 if s_['b']>0.6 else 2 if s_['b']<0.3 else 0
    dots.append((s_['x'],s_['y'],s_['r'],ci,s_['a']))
links=sorted(FULL['segs'],key=lambda r:r[4])
hubs=FULL['hubs']
def S(rows): return ','.join('%.2f'%v for r in rows for v in r)
kt='''package app.megastudiya.nativeapp

// Геометрия логотипа (сетка 108×108, центр 54,54). Сгенерировано (tools/logo/gen2.py), не править руками.
// Ядра нет: ядро — само кольцо, плетёный ободок из нитей-орбит. Центр пустой намеренно.
// DOTS: x,y,радиус,цвет(0 золото,1 светлый,2 голубой,3 серебро),прозрачность — бусины кольца и спутники;
// HUBS: x,y,доля обхода круга (0 сверху, по часовой),размер;
// LINKS: x1,y1,x2,y2,доля обхода,класс цвета(0..3) — отрезки нитей, по возрастанию доли обхода
object RingData {
    private fun p(s: String): FloatArray { val a = s.split(','); return FloatArray(a.size) { a[it].toFloat() } }
    val dots: FloatArray by lazy { p(DOTS) }
    val hubs: FloatArray by lazy { p(HUBS) }
    val links: FloatArray by lazy { p(LINKS) }
    private const val DOTS = "%s"
    private const val HUBS = "%s"
    private const val LINKS = "%s"
}
''' % (S(dots),S(hubs),S(links))
open(base+'java/app/megastudiya/nativeapp/RingData.kt','w',encoding='utf-8').write(kt)
print('dots',len(dots),'hubs',len(hubs),'links',len(links),'kt',len(kt))
