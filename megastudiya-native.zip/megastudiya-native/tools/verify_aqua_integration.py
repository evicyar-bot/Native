#!/usr/bin/env python3
"""Static integrity checks for the AQUA Step105 host integration."""
from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
app=root/'app/src/main/java'
aqua=list((app/'aqua').rglob('*.kt'))
assert len(aqua)>=40, f'Expected the AQUA module source set, found {len(aqua)} Kotlin files'
# Kotlin package/class top-level declarations: detect obvious duplicate fq class/object names.
decls={}
for f in app.rglob('*.kt'):
    text=f.read_text(encoding='utf-8')
    pkg=re.search(r'^\s*package\s+([\w.]+)',text,re.M)
    package=pkg.group(1) if pkg else ''
    for kind,name in re.findall(r'^(?:(?:public|internal|private)\s+)?(?:(?:data|sealed|open|enum|annotation)\s+)?(class|object|interface|typealias)\s+(\w+)',text,re.M):
        fq=package+'.'+name
        if fq in decls: raise AssertionError(f'Duplicate declaration {fq}: {decls[fq]} and {f}')
        decls[fq]=f
bridge=app/'app/megastudiya/nativeapp/AquaStep105Runtime.kt'
chat=app/'app/megastudiya/nativeapp/Aqua.kt'
assert bridge.exists() and 'FileDurableBundleStore' in bridge.read_text()
assert 'AquaStep105Runtime.status(ctx)' in chat.read_text()
gradle=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 95' in gradle and 'n0.96-aqua-step105' in gradle
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
assert 'android:name=".MainActivity"' in manifest or 'MainActivity' in manifest
print(f'AQUA_SOURCE_FILES={len(aqua)}')
print(f'KOTLIN_DECLARATIONS={len(decls)}')
print('HOST_ADAPTER=PASS')
print('CHAT_STATUS_COMMAND=PASS')
print('SINGLE_APP_MANIFEST=PASS')
print('STATIC_INTEGRATION_CHECK=PASS')
