# Megastudiya Dynamic Island — technology baseline and integration plan

## Visual reference (do not regress)
- Preserve the V8 Obsidian capsule material as the visual reference: near-black `#020203`, true pill silhouette, restrained rim/highlight, no screen-wide dimming or blue overlay.
- Keep the capsule's compact geometry aligned to the physical display cutout using Android `DisplayCutout` / `WindowInsets`; do not replace this with arbitrary fixed top offsets.
- The lower Dock uses clear glass: keep the scene blur/refraction layer, remove the opaque tint/fog layer, retain only a subtle white glass edge and the existing icon/selection behavior.

## Required technology layers

1. **Cutout-aware placement** — Android `WindowInsets` + `DisplayCutout` (API 28+) with coordinate conversion through the actual root view; safe fallback when OEM firmware does not expose a cutout rectangle.
2. **A single Compose surface** — one clipped `Shape`/`graphicsLayer` owns compact and expanded layouts. The content, background, border, glow and hit target must share the same rounded outline; no separate card below the capsule.
3. **Explicit interaction state machine** — `Compact`, `Expanded`, `LaunchingSpace`, `Space`, `Refreshing`. All user actions dispatch through one event handler; no nested click handlers that compete for the same gesture.
4. **Motion system** — Compose `Animatable` / spring and tween transitions for entrance, morph (width, height, corner radius), press feedback, pull progress and exit. Each transition must have an observable visual result and be cancellable/reversible.
5. **Touch and accessibility** — one authoritative tap target, explicit semantics/content description, pressed feedback, haptic feedback, and Back handling. Space action must be a child action that cannot accidentally trigger the parent toggle.
6. **Space navigation** — a single event from the capsule to the app-level state; app-level state owns the transition into/out of `Zen`. Do not rely on a local composable boolean to perform app navigation.
7. **Pull-to-refresh** — `NestedScrollConnection` at the feed scroll boundary, progress mapped to the capsule glow, threshold + release handling, guarded refresh job, and reset on tab/Space changes. Refresh news and weather independently with visible completion/error state.
8. **Live status renderer** — a small status model for refresh/activity state, rendered inside the same capsule surface; no permanent fake status or dead button.
9. **Glass renderer** — existing `SceneRec`/`RenderNode` scene capture and Android `RenderEffect` blur; Android 13+ AGSL refraction only as a progressive enhancement. Fallback must remain visually valid on API 31/32 and when shader creation fails.
10. **Lifecycle and system bars** — status-bar visibility changes scoped to expanded state, always restored on collapse, Back, navigation, and disposal. The in-app capsule must not be represented as a system-wide HONOR Magic Capsule.

## Integration order
1. Freeze and preserve the current V8 Obsidian visual baseline; no global screen dimming.
2. Refactor input handling and app-level navigation first; prove tap -> Expanded and Space action -> Zen -> Back.
3. Implement the single-surface morph and verify geometry/clipping at compact and expanded sizes.
4. Integrate pull progress, release, refresh lifecycle and tab reset.
5. Add haptics, accessibility semantics, and polish entrance/exit animation.
6. Verify Dock independently: clear transparent surface with blur retained, existing drag/tab/add actions unchanged.

## Acceptance checks on device
- Tap capsule: it visibly expands every time; tap outside/Back: it collapses.
- Tap Space action: Zen appears; Back returns to feed; no dead or double-fired taps.
- No rectangular corners or content escaping the capsule at any animation frame.
- Pull below threshold cancels; pull above threshold refreshes news and weather once; indicator clears on success/failure.
- Switching tabs or entering Space clears unfinished pull state.
- Dock background is clear, underlying scene is blurred, and tab drag/tap/add still work.
- Status bar always restores after every exit path.

## Current status
This file records the integration plan, not a claim that every item is implemented. The V9 code change is limited to the Dock's clear-glass treatment; the Dynamic Island interaction architecture still requires the staged refactor above and on-device validation.


## Haptic design — Obsidian Capsule

The Android implementation must not claim to reproduce Apple's Taptic Engine. It uses Android's device-native vibrator primitives through the existing `Hap` engine, with the platform-selected primitive when supported and a short waveform fallback otherwise. The intended feel is a subtle, single transient paired with the spring animation:

- Compact → Expanded / Expanded → Compact: very light spring-settle pulse (`islandSnap`).
- Space launch: slightly more distinct two-part lift/click (`islandLaunch`).
- Pull threshold reached: one restrained tick, only on crossing the threshold (`islandThreshold`), never on every drag frame.
- Refresh completion: a soft confirmation pulse (`islandRefreshDone`) when wired to the final success state.

Haptics must remain brief, causally tied to visible state changes, and optional through the device's system haptic settings. Avoid repeating feedback during animation frames or continuous scroll. Apple HIG recommends short, purposeful haptics and avoiding overuse; Android recommends using device-tuned haptic primitives and view/system feedback APIs.

## V10 change log

- Added dedicated low-intensity haptic patterns for capsule tap/snap, Space launch, and pull threshold.
- Wired the capsule state toggle and Space action to those patterns.
- Added one-shot threshold feedback with a reset when the pull retreats below the threshold.
- This is an incremental haptic/interaction pass, not proof of end-to-end Dynamic Island operation. App-level state-machine refactoring, runtime verification, and device testing remain required.


## V11 integration pass

- Hoisted capsule mode ownership to `MegaApp` using `IslandMode` (`COMPACT`, `EXPANDED`, `LAUNCHING_SPACE`, `SPACE`, `REFRESHING`).
- `TopPill` now renders from app-owned state and dispatches state changes instead of owning a private expanded boolean.
- Space launch is sequenced through a short launch state before switching the app to Zen; leaving Zen resets the island to compact.
- Added accessibility descriptions to the capsule and Space action.
- Added refresh-completion haptic feedback after the refresh attempts settle.
- This pass does not claim verified runtime behavior; Gradle build and HONOR device testing remain acceptance requirements.
