# Megastudiya — Obsidian Glass Dynamic Island (V4)

## Baseline and preserved behavior

- Based on the latest project archive `megastudiya-native.zip` (version 0.94), not the earlier original-only ZIP.
- Existing feed, Space/Zen renderer, pull-to-refresh state/gesture, and Dock tab/add interactions are retained.
- The app remains an in-app Android Compose implementation. It is not represented as a system-owned HONOR Magic Capsule integration.

## Top capsule

- The collapsed capsule is now a clean, deep-obsidian glass body; the prominent logo has been removed from directly over the camera aperture so the aperture and capsule read as one dark continuous element.
- Target proportions follow the iPhone Dynamic Island silhouette and scale with the actual logical screen width: width 32% of screen width (clamped 112–132 dp), height 9.4% (clamped 34–39 dp). At 393 dp logical width this is approximately 126 × 37 dp.
- Positioning reads Android `DisplayCutout.boundingRects` and anchors the capsule's vertical center to the cutout rectangle nearest the horizontal screen center. A small near-top fallback is used only if the OEM does not expose cutout bounds.
- Entrance animation uses a short spring overshoot (“bubble” settle).
- Tap on the collapsed capsule expands a glass panel. The panel's Space Platform action enters the existing Space/Zen experience.
- Pull-to-refresh progress glow remains drawn around the capsule, not around the expanded panel.

## Shared Obsidian Glass material

- `LiquidSurface` remains the material implementation: captured scene, blur/saturation, Android 13+ AGSL lens refraction where supported, dark glass tint, subtle edge reflection.
- The shared tint and rim have been darkened and softened so there is no bright silver outline around the camera.
- The Dock continues to use the same `LiquidSurface`; its active indicator is now a low-contrast blue-tinted glass highlight rather than a bright blue outlined capsule.

## Platform and verification limits

- Android's cutout bounds are used when available; some OEM builds may not expose a punch-hole rectangle. The fallback position then requires visual verification on the target HONOR X7d.
- A normal third-party APK cannot recolor the physical camera ring or take ownership of HONOR Magic Capsule. This capsule is drawn by Megastudiya inside its own app window.
- This environment does not have Gradle/Android SDK or a Gradle wrapper in the supplied project. The archive is source-updated and statically checked, but no APK build or on-device test has been performed.
