# MediaHub gateway

Один Cloudflare Worker вместо собственного сервера. Можно перенести на любой хостинг с Node/Deno: код — обычный `fetch`-обработчик.

## Развёртывание (владелец)
1. `npm i -g wrangler && wrangler login`
2. В папке `server/gateway`: `wrangler deploy` — выдаст адрес вида `https://<имя>.<ваш-поддомен>.workers.dev` (или привяжите свой домен).
3. Секреты (значения вводятся в консоль, в файлах не хранятся):
   `wrangler secret put TIKTOK_CLIENT_KEY`, `TIKTOK_CLIENT_SECRET`, `TG_BOT_TOKEN`, `TG_ACCESS_KEY`
   (`TG_ACCESS_KEY` — случайная строка от 32 символов, например `openssl rand -base64 36`).
4. TikTok for Developers → Login Kit → Redirect URI: `https://<адрес шлюза>/tiktok/callback`.
5. В приложении: «Я» → «Источники видео» → адрес шлюза; client key TikTok; ключ доступа Telegram (= `TG_ACCESS_KEY`).

## Что защищено
- `client_secret` TikTok и токен бота живут только на шлюзе.
- Ключ доступа в приложении пропускает лишь `getMe`, `getUpdates`, `getFile`, `getChat` и скачивание файлов: писать от имени бота и менять вебхук через него нельзя. Утёк ключ — смените `TG_ACCESS_KEY` командой выше; токен бота остаётся прежним.
- Возврат TikTok идёт на `megastudiya://tiktok`; code привязан к PKCE-проверке, которая есть только в приложении.
