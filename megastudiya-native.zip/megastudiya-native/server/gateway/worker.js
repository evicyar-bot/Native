// MediaHub gateway — единственный серверный компонент. Cloudflare Worker, зависимостей нет.
// Хранит секреты, которых не должно быть в приложении:
//   TIKTOK_CLIENT_KEY, TIKTOK_CLIENT_SECRET — приложение TikTok (Login Kit)
//   TG_BOT_TOKEN                            — токен бота Telegram
//   TG_ACCESS_KEY                           — ключ доступа приложения к шлюзу (длинная случайная строка, ≥32 символа)
// Секреты задаются командой `wrangler secret put ИМЯ` и в репозиторий не попадают.
//
// Маршруты:
//   GET  /tiktok/callback  — адрес возврата TikTok (его регистрируют как Redirect URI). Перенаправляет в приложение
//                            на megastudiya://tiktok с теми же code/state/error. Другой адрес назначения невозможен.
//   POST /tiktok/token     — обмен code / refresh_token на токены: добавляет client_secret и вызывает TikTok.
//   POST /tg/<метод>       — Bot API, только getMe, getUpdates, getFile, getChat. Заголовок Authorization: Bearer TG_ACCESS_KEY.
//   GET  /tg/file/<путь>   — скачивание файла бота (тот же заголовок).
// Методы отправки сообщений, смены вебхука и управления ботом шлюз не пропускает: утечка ключа доступа не даёт управлять ботом.

const TIKTOK_TOKEN_URL = "https://open.tiktokapis.com/v2/oauth/token/";
const APP_SCHEME_URL = "megastudiya://tiktok";
const TG_METHODS = new Set(["getMe", "getUpdates", "getFile", "getChat"]);
const TG_FILE_RE = /^[A-Za-z0-9_\-]+(\/[A-Za-z0-9_\-.]+)+$/;

const json = (o, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });

// сравнение за постоянное время
function same(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

function authorized(req, env) {
  const h = req.headers.get("authorization") || "";
  const key = h.startsWith("Bearer ") ? h.slice(7) : "";
  return !!env.TG_ACCESS_KEY && env.TG_ACCESS_KEY.length >= 32 && same(key, env.TG_ACCESS_KEY);
}

async function tiktokCallback(url) {
  const out = new URL(APP_SCHEME_URL);
  for (const k of ["code", "state", "error", "error_description", "scopes"]) {
    const v = url.searchParams.get(k);
    if (v) out.searchParams.set(k, v.slice(0, 2048));
  }
  return new Response(
    `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">` +
      `<title>MediaHub</title><body style="font:16px sans-serif;background:#0b0d12;color:#fff;text-align:center;padding:48px">` +
      `<p>Возвращаемся в приложение…</p><p><a style="color:#6ea8ff" href="${out.toString().replace(/&/g, "&amp;")}">Открыть приложение</a></p>` +
      `<script>location.replace(${JSON.stringify(out.toString())})</script>`,
    { status: 200, headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store", "referrer-policy": "no-referrer" } }
  );
}

async function tiktokToken(req, env, origin) {
  if (!env.TIKTOK_CLIENT_KEY || !env.TIKTOK_CLIENT_SECRET) return json({ error: "gateway_not_configured" }, 500);
  const form = new URLSearchParams(await req.text());
  if (form.get("client_key") !== env.TIKTOK_CLIENT_KEY) return json({ error: "bad_client_key" }, 403);
  const grant = form.get("grant_type");
  const out = new URLSearchParams();
  out.set("client_key", env.TIKTOK_CLIENT_KEY);
  out.set("client_secret", env.TIKTOK_CLIENT_SECRET);
  out.set("grant_type", grant || "");
  if (grant === "authorization_code") {
    const code = form.get("code"), verifier = form.get("code_verifier");
    if (!code || !verifier) return json({ error: "missing_code_or_verifier" }, 400);
    out.set("code", code);
    out.set("code_verifier", verifier);
    out.set("redirect_uri", origin + "/tiktok/callback"); // всегда собственный адрес шлюза, чужой подставить нельзя
  } else if (grant === "refresh_token") {
    const rt = form.get("refresh_token");
    if (!rt) return json({ error: "missing_refresh_token" }, 400);
    out.set("refresh_token", rt);
  } else return json({ error: "bad_grant_type" }, 400);
  const r = await fetch(TIKTOK_TOKEN_URL, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded", "cache-control": "no-cache" },
    body: out.toString(),
  });
  return new Response(await r.text(), { status: r.status, headers: { "content-type": "application/json", "cache-control": "no-store" } });
}

async function telegram(req, env, url) {
  if (!authorized(req, env)) return json({ ok: false, error_code: 401, description: "unauthorized" }, 401);
  if (!env.TG_BOT_TOKEN) return json({ ok: false, error_code: 500, description: "gateway_not_configured" }, 500);
  const rest = url.pathname.slice("/tg/".length);
  if (rest.startsWith("file/")) {
    const path = rest.slice(5);
    if (req.method !== "GET" || path.includes("..") || !TG_FILE_RE.test(path)) return json({ ok: false, description: "bad_path" }, 400);
    const r = await fetch(`https://api.telegram.org/file/bot${env.TG_BOT_TOKEN}/${path}`);
    const h = { "content-type": r.headers.get("content-type") || "application/octet-stream", "cache-control": "no-store" };
    const len = r.headers.get("content-length");
    if (len) h["content-length"] = len;
    return new Response(r.body, { status: r.status, headers: h });
  }
  if (req.method !== "POST" || !TG_METHODS.has(rest)) return json({ ok: false, error_code: 403, description: "method_not_allowed" }, 403);
  const body = await req.text();
  if (body.length > 4096) return json({ ok: false, description: "too_large" }, 413);
  const r = await fetch(`https://api.telegram.org/bot${env.TG_BOT_TOKEN}/${rest}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body,
  });
  return new Response(await r.text(), { status: r.status, headers: { "content-type": "application/json", "cache-control": "no-store" } });
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    try {
      if (url.pathname === "/tiktok/callback" && req.method === "GET") return await tiktokCallback(url);
      if (url.pathname === "/tiktok/token" && req.method === "POST") return await tiktokToken(req, env, url.origin);
      if (url.pathname.startsWith("/tg/")) return await telegram(req, env, url);
    } catch (_) {
      return json({ error: "gateway_error" }, 502);
    }
    return json({ error: "not_found" }, 404);
  },
};
