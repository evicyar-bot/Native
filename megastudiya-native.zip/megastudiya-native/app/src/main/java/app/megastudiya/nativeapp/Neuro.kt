package app.megastudiya.nativeapp

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.math.exp
import kotlin.math.sqrt

// НЕЙРО-ОРГАН. Маленькая нейросеть, которая учится прямо на телефоне, без внешних библиотек и серверов.
// Устройство: у каждого слова есть вектор из 32 чисел «на входе» и «на выходе». Чтобы предсказать следующее слово,
// берём среднее векторов трёх предыдущих слов и сравниваем его с выходными векторами слов (скалярное произведение).
// Учится методом негативных примеров: настоящее следующее слово подтягивается, пять случайных отодвигаются.
// Результат: слова, которые встречаются в похожих местах, получают близкие векторы, то есть она «чувствует» близость
// смыслов (космос ~ орбита), а не только считает пары слов. Память: до 20 000 слов, около 5 МБ.
// Вызывается только из потока ядра, поэтому без блокировок.
object Neuro {
    private const val D = 32
    private const val MAXV = 20_000
    private const val K = 5
    private const val LR = 0.05f
    private const val MAGIC = 0x4E455552

    private var inn = FloatArray(0)
    private var out = FloatArray(0)
    private var cnt = IntArray(0)
    private val words = ArrayList<String>()
    private val idx = HashMap<String, Int>()
    private val liked = FloatArray(D) // центр того, что вам нравится, в пространстве смыслов
    private val buf = IntArray(65_536) // недавние слова, из них берутся случайные «неверные» примеры
    private var bufN = 0
    private var dirty = false
    private val rnd = java.util.Random()

    var tokens = 0L
        private set
    // точность: как часто настоящее следующее слово оценено выше случайного (50% = не лучше случайности)
    var accEma = -1f
        private set
    var acc0 = -1f
        private set

    fun size(): Int = words.size

    fun has(w: String): Boolean = idx.containsKey(w)

    fun ensure(dir: File) {
        if (inn.isNotEmpty()) return
        inn = FloatArray(MAXV * D)
        out = FloatArray(MAXV * D)
        cnt = IntArray(MAXV)
        load(File(dir, "neuro.bin"))
    }

    private fun wipe() {
        words.clear()
        idx.clear()
        if (inn.isNotEmpty()) { inn.fill(0f); out.fill(0f); cnt.fill(0) }
        liked.fill(0f)
        bufN = 0
        tokens = 0L
        accEma = -1f
        acc0 = -1f
    }

    fun reset(dir: File) {
        wipe()
        inn = FloatArray(0)
        out = FloatArray(0)
        cnt = IntArray(0)
        File(dir, "neuro.bin").delete()
        File(dir, "neuro.bin.tmp").delete()
        dirty = false
    }

    private fun id(w: String): Int {
        val e = idx[w]
        if (e != null) return e
        if (words.size >= MAXV) return -1
        val k = words.size
        words.add(w)
        idx[w] = k
        for (j in 0 until D) inn[k * D + j] = (rnd.nextFloat() - 0.5f) / D
        return k
    }

    private fun sig(x: Float): Float = 1f / (1f + exp(-x.coerceIn(-8f, 8f)))

    // Учим на тексте. wt: вес (слова владельца учатся несколько раз). Возвращает точность на этом тексте до обучения (0…1).
    fun train(tk: List<String>, wt: Int): Float {
        if (inn.isEmpty() || tk.size < 2) return -1f
        val ids = IntArray(tk.size) { id(tk[it]) }
        for (v in ids) {
            if (v < 0) continue
            cnt[v]++
            buf[bufN % buf.size] = v
            bufN++
        }
        val h = FloatArray(D)
        val gh = FloatArray(D)
        val ctx = IntArray(3)
        var accSum = 0f
        var n = 0
        repeat(wt.coerceIn(1, 3)) {
            for (i in 1 until ids.size) {
                val t = ids[i]
                if (t < 0) continue
                var nc = 0
                for (k in 1..3) {
                    if (i - k < 0) break
                    val c = ids[i - k]
                    if (c >= 0) { ctx[nc] = c; nc++ }
                }
                if (nc == 0) continue
                h.fill(0f)
                for (q in 0 until nc) {
                    val b = ctx[q] * D
                    for (j in 0 until D) h[j] += inn[b + j]
                }
                for (j in 0 until D) h[j] /= nc
                gh.fill(0f)
                var posDot = 0f
                var gotNeg = false
                for (s in 0..K) {
                    val tg: Int
                    if (s == 0) {
                        tg = t
                    } else {
                        if (bufN == 0) continue
                        tg = buf[rnd.nextInt(minOf(bufN, buf.size))]
                        if (tg == t) continue
                    }
                    val o = tg * D
                    var dot = 0f
                    for (j in 0 until D) dot += h[j] * out[o + j]
                    val p = sig(dot)
                    if (s == 0) {
                        posDot = dot
                    } else if (!gotNeg) {
                        gotNeg = true
                        accSum += if (posDot > dot) 1f else 0f
                        n++
                    }
                    val g = ((if (s == 0) 1f else 0f) - p) * LR
                    for (j in 0 until D) {
                        gh[j] += g * out[o + j]
                        out[o + j] += g * h[j]
                    }
                }
                val sc = 1f / nc
                for (q in 0 until nc) {
                    val b = ctx[q] * D
                    for (j in 0 until D) inn[b + j] += gh[j] * sc
                }
            }
        }
        tokens += tk.size.toLong() * wt
        dirty = true
        if (n == 0) return -1f
        val l = accSum / n
        accEma = if (accEma < 0f) l else 0.95f * accEma + 0.05f * l
        if (acc0 < 0f && tokens > 3000L) acc0 = accEma
        return l
    }

    private fun mean(tk: List<String>): FloatArray? {
        val m = FloatArray(D)
        var c = 0
        for (t in tk) {
            val k = idx[t] ?: continue
            for (j in 0 until D) m[j] += inn[k * D + j]
            c++
        }
        if (c == 0) return null
        for (j in 0 until D) m[j] /= c
        return m
    }

    // Ваша реакция сдвигает «центр симпатий»: понравилось — приближаем, нет — отодвигаем
    fun likeUpdate(tk: List<String>, d: Float) {
        if (inn.isEmpty()) return
        val m = mean(tk) ?: return
        val sgn = if (d > 0f) 1f else if (d < 0f) -1f else 0f
        for (j in 0 until D) liked[j] = 0.97f * liked[j] + 0.03f * sgn * m[j]
    }

    private fun cos(a: FloatArray, b: FloatArray): Float {
        var d = 0f
        var na = 0f
        var nb = 0f
        for (j in 0 until D) { d += a[j] * b[j]; na += a[j] * a[j]; nb += b[j] * b[j] }
        return if (na < 1e-9f || nb < 1e-9f) 0f else d / (sqrt(na) * sqrt(nb))
    }

    // Насколько слово близко к тому, что вам нравится (−1…1)
    fun sim(word: String): Float {
        val k = idx[word] ?: return 0f
        return cos(inn.copyOfRange(k * D, k * D + D), liked)
    }

    fun nearest(word: String, k: Int): List<String> {
        val a = idx[word] ?: return emptyList()
        val va = inn.copyOfRange(a * D, a * D + D)
        val top = ArrayList<Pair<Float, Int>>()
        for (v in words.indices) {
            if (v == a || cnt[v] < 3) continue
            val c = cos(va, inn.copyOfRange(v * D, v * D + D))
            if (top.size < k) { top.add(Pair(c, v)); top.sortBy { it.first } }
            else if (c > top[0].first) { top[0] = Pair(c, v); top.sortBy { it.first } }
        }
        return top.sortedByDescending { it.first }.map { words[it.second] }
    }

    fun randomWord(): String? {
        if (words.isEmpty()) return null
        for (i in 0 until 30) {
            val v = rnd.nextInt(words.size)
            if (cnt[v] >= 5) return words[v]
        }
        return null
    }

    // Следующее слово по смыслу: оценка по нейросети плюс подсказка bonus (например, частота пары)
    fun next(ctxWords: List<String>, exclude: Set<String>, bonus: (String) -> Float): String? {
        if (inn.isEmpty()) return null
        val h = mean(ctxWords.takeLast(3)) ?: return null
        val ti = IntArray(30) { -1 }
        val ts = FloatArray(30) { -1e9f }
        var mp = 0
        for (v in words.indices) {
            if (cnt[v] < 3 || words[v] in exclude) continue
            val o = v * D
            var dot = 0f
            for (j in 0 until D) dot += h[j] * out[o + j]
            if (dot > ts[mp]) {
                ts[mp] = dot
                ti[mp] = v
                mp = 0
                for (q in 1 until 30) if (ts[q] < ts[mp]) mp = q
            }
        }
        val cand = ArrayList<Pair<String, Float>>()
        for (q in 0 until 30) if (ti[q] >= 0) cand.add(Pair(words[ti[q]], ts[q] + bonus(words[ti[q]])))
        if (cand.isEmpty()) return null
        cand.sortByDescending { it.second }
        val pool = cand.take(8)
        val mx = pool[0].second
        val w = pool.map { exp((it.second - mx).coerceAtLeast(-8f)) }
        var r = rnd.nextFloat() * w.sum()
        for (i in pool.indices) {
            r -= w[i]
            if (r <= 0f) return pool[i].first
        }
        return pool[0].first
    }

    // Строка для отчёта: что она «понимает» про близость слов
    fun demo(): String {
        val w = randomWord() ?: return ""
        val n = nearest(w, 3)
        return if (n.isEmpty()) "" else "$w ≈ " + n.joinToString(", ")
    }

    fun stats(): String {
        if (inn.isEmpty()) return "Нейро: просыпается"
        val l = if (accEma < 0f) "—" else "%.0f%%".format(accEma * 100f)
        val l0 = if (acc0 < 0f) "" else " (в начале %.0f%%)".format(acc0 * 100f)
        return "Нейро: слов ${words.size} · прочитано $tokens · точность предсказания слова $l$l0, случайно 50%"
    }

    fun save(dir: File) {
        if (!dirty || inn.isEmpty()) return
        val tmp = File(dir, "neuro.bin.tmp")
        DataOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { o ->
            o.writeInt(MAGIC)
            o.writeInt(D)
            o.writeInt(words.size)
            for (i in words.indices) { o.writeUTF(words[i]); o.writeInt(cnt[i]) }
            val n = words.size * D
            for (i in 0 until n) o.writeFloat(inn[i])
            for (i in 0 until n) o.writeFloat(out[i])
            for (j in 0 until D) o.writeFloat(liked[j])
            o.writeLong(tokens)
            o.writeFloat(accEma)
            o.writeFloat(acc0)
        }
        tmp.renameTo(File(dir, "neuro.bin"))
        dirty = false
    }

    private fun load(f: File) {
        if (!f.exists()) return
        try {
            DataInputStream(BufferedInputStream(FileInputStream(f))).use { i ->
                if (i.readInt() != MAGIC || i.readInt() != D) return
                val v = i.readInt()
                if (v < 0 || v > MAXV) return
                for (k in 0 until v) {
                    val w = i.readUTF()
                    words.add(w)
                    idx[w] = k
                    cnt[k] = i.readInt()
                }
                val n = v * D
                for (k in 0 until n) inn[k] = i.readFloat()
                for (k in 0 until n) out[k] = i.readFloat()
                for (j in 0 until D) liked[j] = i.readFloat()
                tokens = i.readLong()
                accEma = i.readFloat()
                acc0 = i.readFloat()
            }
        } catch (_: Throwable) {
            wipe()
        }
    }
}
