package app.megastudiya.nativeapp

import android.content.Context
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.os.SystemClock
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.time.ZoneOffset
import java.time.ZonedDateTime
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sqrt
import kotlin.math.sin

// Общее состояние между интерфейсом и потоком отрисовки Земли
object EarthGate {
    @Volatile var scrolling = false
    @Volatile var scrollEnd = 0L
    @Volatile var touching = false
    @Volatile var holdUntil = 0L
    @Volatile var renderMs = 0f
    @Volatile var lite = false
    @Volatile var hasCity = false
    @Volatile var cityLat = 0.0
    @Volatile var cityLon = 0.0
    @Volatile var contemplate = false
    @Volatile var zoom = 1f
    @Volatile var scale = 0.5f // доля разрешения экрана, в которой рисуется Земля
    @Volatile var focusLat = 0.0
    @Volatile var focusLon = 0.0
    var view: GLSurfaceView? = null
}

// Земля: тот же шейдер, что в веб-версии, на нативном OpenGL ES 2.0.
// Рисуется на сниженном разрешении, примерно 15 кадров/с, и замирает на время скролла.
class EarthGLView(ctx: Context) : GLSurfaceView(ctx) {
    private var appliedScale = 0.5f

    private fun applyScale() {
        if (width > 0 && height > 0) holder.setFixedSize((width * appliedScale).toInt().coerceAtLeast(1), (height * appliedScale).toInt().coerceAtLeast(1))
    }

    private val ticker = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            if (EarthGate.scale != appliedScale) {
                appliedScale = EarthGate.scale
                applyScale()
            }
            if (EarthGate.contemplate) requestRender()
            else if (!EarthGate.scrolling && !EarthGate.touching && now > EarthGate.holdUntil && now - EarthGate.scrollEnd > 260) requestRender()
            // Частота зависит от стоимости кадра: GPU Земля занимает не больше ~20-30% времени, остальное остаётся интерфейсу.
            // В облегчённом режиме на Земле почти ничего не движется, поэтому достаточно нескольких кадров в секунду.
            val ms = EarthGate.renderMs
            val period = when {
                EarthGate.contemplate -> 33L
                EarthGate.lite -> (ms * 5f).toLong().coerceIn(120L, 400L)
                else -> maxOf(66L, (ms * 3f).toLong())
            }
            postDelayed(this, period)
        }
    }

    init {
        setEGLContextClientVersion(2)
        setRenderer(EarthRenderer(ctx))
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w > 0 && h > 0) {
            holder.setFixedSize((w * appliedScale).toInt().coerceAtLeast(1), (h * appliedScale).toInt().coerceAtLeast(1))
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(ticker)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }
}

class EarthRenderer(private val ctx: Context) : GLSurfaceView.Renderer {

    private class Prog(val id: Int) {
        val uC = GLES20.glGetUniformLocation(id, "C")
        val uR = GLES20.glGetUniformLocation(id, "rot")
        val uT = GLES20.glGetUniformLocation(id, "tm")
        val uM = GLES20.glGetUniformLocation(id, "M")
        val uL = GLES20.glGetUniformLocation(id, "L")
        val uTl = GLES20.glGetUniformLocation(id, "tl")
        val uOH = GLES20.glGetUniformLocation(id, "OH")
        val uOT = GLES20.glGetUniformLocation(id, "OT")
        val uBD = GLES20.glGetUniformLocation(id, "BD")
        val uD = GLES20.glGetUniformLocation(id, "D")
        val uN = GLES20.glGetUniformLocation(id, "N")
        val uK = GLES20.glGetUniformLocation(id, "K")
        val ap = GLES20.glGetAttribLocation(id, "p")
    }

    private var full: Prog? = null
    private var lite: Prog? = null
    private var w = 1
    private var h = 1
    private val t0 = SystemClock.elapsedRealtime()
    private var rot0 = 0.0
    private val oh = FloatArray(9)
    private val ot = FloatArray(9)
    private val bd = floatArrayOf(0f, 0f, 0f, 99f, 99f, -9f)
    private val quad: FloatBuffer = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
        position(0)
    }
    private var frames = 0
    private var slowStreak = 0
    private var inited = false
    private var lastNs = 0L
    private var curRot = 0.0
    private var curTilt = 0.38
    private var curCm = 0.0
    private var curZoom = 1.0
    private val mk = FloatArray(3)

    private fun asset(name: String): String = ctx.assets.open(name).bufferedReader().use { it.readText() }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            Log.e("Earth", GLES20.glGetShaderInfoLog(s))
            GLES20.glDeleteShader(s)
            return 0
        }
        return s
    }

    private fun build(fragName: String): Prog? {
        val v = compile(GLES20.GL_VERTEX_SHADER, asset("earth.vert"))
        val f = compile(GLES20.GL_FRAGMENT_SHADER, asset(fragName))
        if (v == 0 || f == 0) return null
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, v)
        GLES20.glAttachShader(p, f)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) {
            Log.e("Earth", GLES20.glGetProgramInfoLog(p))
            return null
        }
        return Prog(p)
    }

    private fun loadTex(unit: Int, name: String) {
        val bmp = ctx.assets.open(name).use { BitmapFactory.decodeStream(it) }
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + unit)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        bmp.recycle()
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        full = build("earth_full.frag")
        lite = build("earth_lite.frag")
        loadTex(0, "earth_d.jpg")
        loadTex(1, "earth_n.jpg")
        loadTex(2, "earth_k.jpg")
        rot0 = sunLon() + 0.709
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        if (full == null) EarthGate.lite = true
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        w = width
        h = height
        GLES20.glViewport(0, 0, width, height)
    }

    private fun hoursAndDoy(): Pair<Double, Double> {
        val z = ZonedDateTime.now(ZoneOffset.UTC)
        val hh = z.hour + z.minute / 60.0 + z.second / 3600.0
        return Pair(hh, z.dayOfYear + hh / 24.0)
    }

    private fun sunLon(): Double = -(hoursAndDoy().first - 12.0) * PI / 12.0

    private fun gv(la: Double, lo: Double, r: Double, rt: Double, sT: Double, cT: Double, o: FloatArray, i: Int) {
        val qx = cos(la) * sin(lo - rt)
        val qy = sin(la)
        val qz = cos(la) * cos(lo - rt)
        o[i] = (r * qx).toFloat()
        o[i + 1] = (r * (qy * cT + qz * sT)).toFloat()
        o[i + 2] = (r * (-qy * sT + qz * cT)).toFloat()
    }

    private fun orb(inc: Double, per: Double, p0: Double, ts: Double): DoubleArray {
        val u = ts / per * 6.2832 + p0
        return doubleArrayOf(
            asin(sin(inc) * sin(u)),
            atan2(cos(inc) * sin(u), cos(u)) - ts * 0.004,
            u
        )
    }

    override fun onDrawFrame(gl: GL10?) {
        val p = (if (EarthGate.lite) lite else full) ?: lite ?: full ?: return
        val tStart = System.nanoTime()
        val tm = (SystemClock.elapsedRealtime() - t0) / 1000.0
        val nowNs = System.nanoTime()
        val dt = if (lastNs == 0L) 0.066 else ((nowNs - lastNs) / 1e9).coerceIn(0.0, 0.5)
        lastNs = nowNs
        val cont = EarthGate.contemplate
        curCm += ((if (cont) 1.0 else 0.0) - curCm) * (1 - exp(-dt * 3.0))
        curZoom += (EarthGate.zoom - curZoom) * (1 - exp(-dt * 8.0))
        val rrN = w * 0.98
        val rr = (rrN + (w * 0.42 * curZoom - rrN) * curCm).toFloat()
        val cx = w * 0.5f
        val cyN = -rrN + h * 0.46
        val cy = (cyN + (h * 0.5 - cyN) * curCm).toFloat()
        // Город (свой или выбранный при созерцании) выводим в видимый центр: подбираем поворот и наклон
        val hasT = cont || EarthGate.hasCity
        val tLat = if (cont) EarthGate.focusLat else EarthGate.cityLat
        val tLon = if (cont) EarthGate.focusLon else EarthGate.cityLon
        val yT = h * (0.23 + (0.5 - 0.23) * curCm)
        val qy0 = ((yT - cy) / rr).coerceIn(-0.95, 0.95)
        val delta = kotlin.math.atan2(sqrt(1 - qy0 * qy0), qy0)
        val tTilt = if (hasT) (acos(sin(tLat).coerceIn(-1.0, 1.0)) - delta).coerceIn(-1.1, 1.1) else 0.38
        val tRot = if (hasT) tLon else rot0 - tm * 0.006
        if (!inited) { curRot = tRot; curTilt = tTilt; inited = true }
        val dr = atan2(sin(tRot - curRot), cos(tRot - curRot))
        curRot += dr * (1 - exp(-dt * (if (cont) 1.6 else 2.5)))
        curTilt += (tTilt - curTilt) * (1 - exp(-dt * 2.0))
        val tlc = curTilt
        val rt = curRot
        if (hasT) {
            mk[0] = (cos(tLat) * sin(tLon)).toFloat()
            mk[1] = sin(tLat).toFloat()
            mk[2] = (cos(tLat) * cos(tLon)).toFloat()
        } else {
            mk[0] = 0f; mk[1] = 0f; mk[2] = 0f
        }
        val hd = hoursAndDoy()
        val hh = hd.first
        val doy = hd.second
        val d = -0.4093 * cos(2 * PI * (doy + 10) / 365.0)
        val lo = -(hh - 12.0) * PI / 12.0
        val sx = cos(d) * sin(lo)
        val sy = sin(d)
        val sz = cos(d) * cos(lo)
        val cr = cos(rt)
        val sr = sin(rt)
        val qx = sx * cr - sz * sr
        val qz = sx * sr + sz * cr
        val sT = sin(tlc)
        val cT = cos(tlc)
        val lx = qx
        val ly = sy * cT + qz * sT
        val lz = -sy * sT + qz * cT

        // спутник и кометы
        val t = System.currentTimeMillis() / 1000.0
        val a = orb(0.9006, 150.0, 0.5, t)
        val b = orb(0.9006, 150.0, 0.5, t - 1.3)
        gv(a[0], a[1], 1.065, rt, sT, cT, oh, 0)
        gv(b[0], b[1], 1.065, rt, sT, cT, ot, 0)
        val cfg = arrayOf(doubleArrayOf(1.25, 210.0, 1.0, 0.22), doubleArrayOf(0.55, 300.0, 3.7, 0.27))
        for (i in 0..1) {
            val c = cfg[i]
            val o = orb(c[0], c[1], c[2], t)
            val r = 1.18 + 0.5 * (0.5 + 0.5 * sin(o[2] * 0.5 + c[2]))
            val j = 3 + i * 3
            gv(o[0], o[1], r, rt, sT, cT, oh, j)
            ot[j] = (oh[j] - lx * c[3]).toFloat()
            ot[j + 1] = (oh[j + 1] - ly * c[3]).toFloat()
            ot[j + 2] = (oh[j + 2] - lz * c[3]).toFloat()
        }
        // Солнце жёстко в пространстве, Луны в этой версии пока нет
        bd[0] = (lx * 4.5).toFloat()
        bd[1] = (ly * 4.5).toFloat()
        bd[2] = lz.toFloat()
        // Луна: фаза по синодическому месяцу (новолуние 6.01.2000 18:14 UTC), ходит по небу над планетой
        val ph = (((System.currentTimeMillis() / 86400000.0) - 10962.76) / 29.530588).let { it - kotlin.math.floor(it) }
        val ma = 2 * PI * ph
        bd[3] = (0.78 * sin(ma)).toFloat()
        bd[4] = (1.45 + 0.1 * cos(ma)).toFloat()
        bd[5] = 1f

        GLES20.glViewport(0, 0, w, h)
        GLES20.glClearColor(0.043f, 0.051f, 0.071f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(p.id)
        GLES20.glUniform1i(p.uD, 0)
        GLES20.glUniform1i(p.uN, 1)
        GLES20.glUniform1i(p.uK, 2)
        GLES20.glUniform3f(p.uC, cx, cy, rr)
        GLES20.glUniform1f(p.uR, rt.toFloat())
        GLES20.glUniform1f(p.uTl, tlc.toFloat())
        GLES20.glUniform1f(p.uT, tm.toFloat())
        GLES20.glUniform3f(p.uL, lx.toFloat(), ly.toFloat(), lz.toFloat())
        GLES20.glUniform3f(p.uM, mk[0], mk[1], mk[2])
        GLES20.glUniform3fv(p.uOH, 3, oh, 0)
        GLES20.glUniform3fv(p.uOT, 3, ot, 0)
        GLES20.glUniform3fv(p.uBD, 2, bd, 0)
        GLES20.glEnableVertexAttribArray(p.ap)
        GLES20.glVertexAttribPointer(p.ap, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        frames++
        if (frames % 10 == 0) {
            GLES20.glFinish()
            val ms = (System.nanoTime() - tStart) / 1_000_000f
            EarthGate.renderMs = ms
            // если Земля тяжёлая для телефона, сами переключаемся на облегчённый шейдер (без сияния и комет)
            if (frames > 40 && ms > 45f) slowStreak++ else slowStreak = 0
            if (slowStreak >= 4 && lite != null) EarthGate.lite = true
            // даже облегчённая Земля тяжела: рисуем в меньшем разрешении (стоимость растёт с числом пикселей)
            if (EarthGate.lite && ms > 40f && EarthGate.scale > 0.4f) EarthGate.scale = 0.38f
        }
    }
}
