package app.megastudiya.nativeapp

import android.content.Context
import android.graphics.RuntimeShader
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.Constraints
import kotlinx.coroutines.delay

// Погодные эффекты: переключатель и уровень качества (сам снижается, если телефон не тянет).
object WxFx {
    var on by mutableStateOf(true)
        private set
    var q by mutableIntStateOf(0) // 0 полное, 1 легче, 2 минимум

    fun init(ctx: Context) {
        on = ctx.getSharedPreferences("ms", Context.MODE_PRIVATE).getBoolean("wx", true)
    }

    fun toggle(ctx: Context) {
        on = !on
        q = 0
        ctx.getSharedPreferences("ms", Context.MODE_PRIVATE).edit().putBoolean("wx", on).apply()
    }
}

// Облака, дождь, снег, туман и гроза: один шейдер на GPU, один слой.
// Рисуется в половинном разрешении (при нагрузке в трети) и растягивается: мягкая картинка, в 4 раза меньше пикселей.
// Слой отдельный и от скролла ленты не зависит: дождь идёт и во время прокрутки.
@RequiresApi(33)
@Composable
fun WxLayer(kind: Int, lit: Color, dark: Color) {
    val shader = remember { RuntimeShader(WX_AGSL) }
    val brush = remember(shader) { ShaderBrush(shader) }
    var t by remember { mutableFloatStateOf(0f) }
    val q = WxFx.q
    val still = kind <= 3 // облака и туман только плывут: хватает 10 кадров/с
    val fps = if (still) 10 else if (q >= 2) 20 else 30
    LaunchedEffect(fps) {
        val period = 1000L / fps
        var prev = 0L
        var seen = 0
        var slow = 0
        while (true) {
            delay(period - 6)
            withFrameNanos { n ->
                t = ((n / 1_000_000L) % 3_600_000L) / 1000f
                if (prev != 0L) {
                    seen++
                    if ((n - prev) / 1_000_000L > period * 9 / 5) slow++
                    if (seen >= 45) {
                        // пятая часть кадров запоздала: телефону тяжело, облегчаем эффект
                        if (slow >= 9 && WxFx.q < 2) WxFx.q = WxFx.q + 1
                        seen = 0
                        slow = 0
                    }
                }
                prev = n
            }
        }
    }
    val ds = if (q >= 1) 3 else 2
    val cover = when (kind) { 1 -> 0.32f; 2 -> 0.62f; 4 -> 0.62f; 5 -> 0.55f; 6 -> 0.78f; else -> 0f }
    val ca = when (kind) { 1 -> 0.55f; 2 -> 0.70f; 4 -> 0.75f; 5 -> 0.65f; 6 -> 0.85f; else -> 0f }
    Canvas(
        Modifier.layout { m, c ->
            val w = c.maxWidth
            val h = c.maxHeight
            val p = m.measure(Constraints.fixed((w / ds).coerceAtLeast(1), (h / ds).coerceAtLeast(1)))
            layout(w, h) {
                p.placeWithLayer(0, 0) {
                    scaleX = ds.toFloat()
                    scaleY = ds.toFloat()
                    transformOrigin = TransformOrigin(0f, 0f)
                    compositingStrategy = CompositingStrategy.Offscreen
                }
            }
        }
    ) {
        shader.setFloatUniform("size", size.width, size.height)
        shader.setFloatUniform("t", t) // читается только здесь: перерисовывается слой, а не весь экран
        shader.setFloatUniform("kind", kind.toFloat())
        shader.setFloatUniform("q", q.toFloat())
        shader.setFloatUniform("cover", cover)
        shader.setFloatUniform("ca", ca)
        shader.setFloatUniform("lit", lit.red, lit.green, lit.blue)
        shader.setFloatUniform("dark", dark.red, dark.green, dark.blue)
        drawRect(brush)
    }
}

// kind: 1 малооблачно, 2 пасмурно, 3 туман, 4 дождь, 5 снег, 6 гроза
private const val WX_AGSL = """
uniform float2 size;
uniform float t;
uniform float kind;
uniform float q;
uniform float cover;
uniform float ca;
uniform float3 lit;
uniform float3 dark;

float hash(float2 p) {
    p = fract(p * float2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}
float vn(float2 p) {
    float2 i = floor(p);
    float2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + float2(1.0, 0.0));
    float c = hash(i + float2(0.0, 1.0));
    float d = hash(i + float2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
float fbm(float2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 4; i++) {
        v += a * vn(p);
        p = p * 2.03 + float2(17.1, 9.2);
        a *= 0.5;
    }
    return v;
}
float4 over(float4 o, float3 c, float a) {
    return float4(c * a + o.rgb * (1.0 - a), a + o.a * (1.0 - a));
}
// Капля: яркая головка и тающий хвост. Ячейки сетки, у каждой своя капля (или пусто).
float rain(float2 pn, float sx, float sy, float spd, float slant, float wpx, float ln, float dens) {
    float cw = size.y / sx;
    float ch = size.y / sy;
    float2 qq = float2(pn.x * sx + pn.y * sy * slant, pn.y * sy - mod(t * spd, 64.0));
    float2 id = floor(qq);
    float2 f = fract(qq);
    id.y = mod(id.y, 64.0);
    float r1 = hash(id);
    if (r1 > dens) return 0.0;
    float r2 = hash(id + 17.3);
    float r3 = hash(id + 5.1);
    float x = (f.x - 0.5 - (r2 - 0.5) * 0.5) * cw;
    float l = ln * (0.7 + 0.6 * r3);
    float yh = l + (1.0 - l) * r2;
    float u = (yh - f.y) / l;
    float body = (1.0 - smoothstep(0.0, wpx, abs(x))) * smoothstep(-0.04, 0.02, u) * (1.0 - smoothstep(0.9, 1.0, u)) * pow(clamp(1.0 - u, 0.0, 1.0), 1.5);
    float dy = (f.y - yh) * ch;
    float bead = 1.0 - smoothstep(0.0, wpx * 1.8, length(float2(x, dy * 0.7)));
    return clamp(body * 0.8 + bead * 0.7, 0.0, 1.0);
}
// Снежинка: мягкий круг, покачивается
float snow(float2 pn, float sc, float spd, float rad, float sway, float seed) {
    float2 qq = pn * sc;
    qq.y -= mod(t * spd, 64.0);
    float2 id = floor(qq);
    float2 f = fract(qq);
    id.y = mod(id.y, 64.0);
    float r1 = hash(id + seed);
    float r2 = hash(id + seed + 9.7);
    if (r1 < 0.4) return 0.0;
    float cx = 0.5 + (r2 - 0.5) * 0.3 + sway * sin(t * (0.5 + r1) + r2 * 6.283);
    float cy = 0.25 + 0.5 * r1;
    float d = length(f - float2(cx, cy));
    return 1.0 - smoothstep(rad * 0.35, rad, d);
}

half4 main(float2 p) {
    float2 pn = p / size.y;
    float4 o = float4(0.0);
    float fl = 0.0;
    if (kind > 5.5) {
        float ph = mod(t, 9.0) - 3.0;
        if (ph > 0.0 && ph < 0.4) fl = (1.0 - ph / 0.4) * (0.55 + 0.45 * step(0.5, fract(ph * 13.0)));
    }
    if (cover > 0.0 && pn.y < 0.7) {
        float2 cu = float2(pn.x * 2.2 + t * 0.006, pn.y * 2.6);
        float d = fbm(cu);
        float th = 0.66 - 0.40 * cover;
        float dens = smoothstep(th, th + 0.22, d);
        if (dens > 0.0) {
            float shade = 0.5;
            if (q < 1.0) {
                float d2 = fbm(cu + float2(-0.07, -0.09));
                shade = clamp(0.5 + (d - d2) * 3.5, 0.0, 1.0);
            }
            float3 col = mix(dark, lit, shade) + float3(0.35, 0.40, 0.55) * fl;
            float topm = 1.0 - smoothstep(0.30, 0.70, pn.y);
            o = over(o, col, dens * topm * ca);
        }
    }
    if (kind > 2.5 && kind < 3.5) {
        float fg = fbm(float2(pn.x * 1.3 + t * 0.01, pn.y * 1.7 + t * 0.002));
        o = over(o, float3(0.89, 0.91, 0.95), smoothstep(0.30, 0.75, fg) * 0.30);
    }
    if (kind > 3.5 && kind != 5.0) {
        float inten = kind > 5.5 ? 1.0 : 0.7;
        float slant = kind > 5.5 ? 0.16 : 0.08;
        float3 rc = mix(float3(0.78, 0.87, 1.0), lit, 0.25);
        float a = 0.0;
        if (q < 1.0) a += rain(pn, 44.0, 5.5, 2.6, slant, 0.9, 0.30, 0.55 * inten) * 0.20;
        if (q < 2.0) a += rain(pn, 26.0, 3.6, 3.4, slant, 1.2, 0.33, 0.55 * inten) * 0.32;
        a += rain(pn, 15.0, 2.4, 4.2, slant, 1.8, 0.36, 0.50 * inten) * 0.45;
        o = over(o, rc, clamp(a, 0.0, 0.85));
        o = over(o, float3(0.8, 0.85, 1.0), fl * 0.10);
    }
    if (kind > 4.5 && kind < 5.5) {
        float a = 0.0;
        if (q < 1.0) a += snow(pn, 70.0, 2.8, 0.40, 0.12, 0.0) * 0.50;
        if (q < 2.0) a += snow(pn, 40.0, 4.0, 0.42, 0.14, 3.3) * 0.75;
        a += snow(pn, 18.0, 3.0, 0.46, 0.16, 7.7) * 0.45;
        o = over(o, float3(1.0), clamp(a, 0.0, 0.9));
    }
    return half4(o);
}
"""
