package app.megastudiya.nativeapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.withFrameNanos

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setHighRefresh()
        setContent { MegaApp() }
    }

    // просим у системы максимальную частоту экрана (90/120 Гц, если есть)
    private fun setHighRefresh() {
        try {
            @Suppress("DEPRECATION")
            val d = windowManager.defaultDisplay
            val best = d.supportedModes.maxByOrNull { it.refreshRate } ?: return
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            window.attributes = lp
        } catch (_: Throwable) {
        }
    }
}

private val Bg = Color(0xFF0B0D12)
private val Pill = RoundedCornerShape(999.dp)
private val Line = Color.White.copy(alpha = 0.14f)

@Composable
fun MegaApp() {
    var tab by remember { mutableIntStateOf(0) }
    val haptic = LocalHapticFeedback.current
    Box(Modifier.fillMaxSize().background(Bg)) {
        Sky()
        Crossfade(targetState = tab, animationSpec = tween(160), label = "tab") { t ->
            when (t) {
                0 -> Feed()
                1 -> Simple("Чаты")
                2 -> Simple("Сеть")
                else -> Simple("Я")
            }
        }
        TopPill(Modifier.align(Alignment.TopCenter))
        Dock(
            sel = tab,
            onTab = {
                tab = it
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            },
            m = Modifier.align(Alignment.BottomCenter)
        )
        FpsMeter(Modifier.align(Alignment.TopEnd))
    }
}

// Небо: звёзды и свечение Земли внизу. Статичное, рисуется один раз.
@Composable
fun Sky() {
    val stars = remember {
        val r = java.util.Random(7)
        List(90) { Triple(r.nextFloat(), r.nextFloat(), 0.4f + r.nextFloat() * 1.2f) }
    }
    Canvas(Modifier.fillMaxSize()) {
        stars.forEach { (x, y, s) ->
            drawCircle(Color.White.copy(alpha = 0.35f + s * 0.25f), s, Offset(x * size.width, y * size.height))
        }
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color(0xFF2A6BD8), Color(0xFF0E2A5E), Color.Transparent),
                center = Offset(size.width / 2f, size.height * 1.08f),
                radius = size.width * 1.25f
            ),
            radius = size.width * 1.25f,
            center = Offset(size.width / 2f, size.height * 1.08f)
        )
    }
}

@Composable
fun Feed() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 110.dp, bottom = 140.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(count = 400, key = { it }) { i -> GlassCard(i) }
    }
}

@Composable
fun GlassCard(i: Int) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.13f), Color.White.copy(alpha = 0.04f))))
            .border(BorderStroke(1.dp, Line), shape)
            .clickable(interactionSource = src, indication = null) {}
            .padding(16.dp)
    ) {
        Text("Карточка $i", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(
            "Тест плавности скролла: нативный список, без WebView.",
            color = Color.White.copy(alpha = 0.6f),
            fontSize = 14.sp,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
fun Simple(name: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun TopPill(m: Modifier) {
    Box(
        m.statusBarsPadding().padding(top = 10.dp)
            .clip(Pill).background(Color(0xCC121826)).border(1.dp, Line, Pill)
            .padding(horizontal = 22.dp, vertical = 10.dp)
    ) {
        Text("МЕГАСТУДИЯ", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
    }
}

@Composable
fun Dock(sel: Int, onTab: (Int) -> Unit, m: Modifier) {
    val names = listOf("Сегодня", "Чаты", "Сеть", "Я")
    Row(
        m.navigationBarsPadding().padding(bottom = 14.dp)
            .clip(Pill).background(Color(0xCC121826)).border(1.dp, Line, Pill).padding(6.dp)
    ) {
        names.forEachIndexed { i, n ->
            val on = i == sel
            val bg by animateColorAsState(
                targetValue = if (on) Color(0x407AA8FF) else Color.Transparent,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                label = "bg"
            )
            val src = remember { MutableInteractionSource() }
            val pressed by src.collectIsPressedAsState()
            val sc by animateFloatAsState(
                targetValue = if (pressed) 0.92f else 1f,
                animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
                label = "dsc"
            )
            Box(
                Modifier
                    .graphicsLayer { scaleX = sc; scaleY = sc }
                    .clip(Pill).background(bg)
                    .clickable(interactionSource = src, indication = null) { onTab(i) }
                    .padding(horizontal = 18.dp, vertical = 11.dp)
            ) {
                Text(
                    n,
                    color = if (on) Color.White else Color.White.copy(alpha = 0.6f),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

// Счётчик кадров: средний fps и число «лагов» (кадр дольше 25 мс)
@Composable
fun FpsMeter(m: Modifier) {
    var txt by remember { mutableStateOf("…") }
    LaunchedEffect(Unit) {
        var last = 0L
        var n = 0
        var sum = 0L
        var lag = 0
        while (true) {
            val t = withFrameNanos { it }
            if (last != 0L) {
                val d = t - last
                if (d < 500_000_000L) {
                    sum += d
                    n++
                    if (d > 25_000_000L) lag++
                }
            }
            last = t
            if (n >= 60) {
                txt = "${(1e9 * n / sum).toInt()} fps · лаги $lag"
                n = 0
                sum = 0L
            }
        }
    }
    Text(txt, color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp, modifier = m.statusBarsPadding().padding(10.dp))
}
