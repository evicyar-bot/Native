package app.megastudiya.nativeapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import android.os.SystemClock
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.withFrameNanos

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Store.load(this)
        setHighRefresh()
        setContent { MegaApp() }
    }

    override fun onPause() {
        super.onPause()
        EarthGate.view?.onPause()
    }

    override fun onResume() {
        super.onResume()
        EarthGate.view?.onResume()
    }

    // просим у системы максимальную частоту экрана (90/120 Гц, если есть)
    private fun setHighRefresh() {
        try {
            @Suppress("DEPRECATION")
            val d = windowManager.defaultDisplay
            val best = d.supportedModes.maxByOrNull { it.refreshRate } ?: return
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            window.attributes = lp
        } catch (_: Throwable) {
        }
    }
}

private val Bg = Color(0xFF0B0D12)
private val Pill = RoundedCornerShape(999.dp)
private val Line = Color.White.copy(alpha = 0.14f)
private val fmt = SimpleDateFormat("d MMM, HH:mm", Locale("ru"))

@Composable
fun MegaApp() {
    var tab by remember { mutableIntStateOf(0) }
    val haptic = LocalHapticFeedback.current
    val feedState = rememberLazyListState()
    LaunchedEffect(feedState) {
        snapshotFlow { feedState.isScrollInProgress }.collect { sc ->
            EarthGate.scrolling = sc
            if (!sc) EarthGate.scrollEnd = SystemClock.uptimeMillis()
        }
    }
    Box(
        Modifier.fillMaxSize().pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val e = awaitPointerEvent(PointerEventPass.Initial)
                    val down = e.changes.any { it.pressed }
                    EarthGate.touching = down
                    if (!down) EarthGate.scrollEnd = SystemClock.uptimeMillis()
                }
            }
        }
    ) {
        AndroidView(factory = { c -> EarthGLView(c).also { EarthGate.view = it } }, modifier = Modifier.fillMaxSize())
        Sky()
        // Лента всегда живая в памяти (не пересобирается при переключении), скрытая просто не размещается.
        Box(
            Modifier.fillMaxSize().layout { m, c ->
                if (tab == 0) {
                    val pl = m.measure(c)
                    layout(pl.width, pl.height) { pl.placeRelative(0, 0) }
                } else {
                    layout(c.maxWidth, c.maxHeight) { }
                }
            }
        ) { Feed(feedState) }
        when (tab) {
            1 -> Simple("Чаты")
            2 -> Simple("Сеть")
            3 -> MeScreen()
            else -> {}
        }
        TopPill(Modifier.align(Alignment.TopCenter))
        Dock(
            sel = tab,
            onTab = {
                tab = it
                EarthGate.holdUntil = SystemClock.uptimeMillis() + 450
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            },
            m = Modifier.align(Alignment.BottomCenter)
        )
        FpsMeter(Modifier.align(Alignment.TopEnd))
    }
}

// Небо: только звёзды в верхней половине экрана (внизу Земля).
@Composable
fun Sky() {
    val stars = remember {
        val r = java.util.Random(7)
        List(70) { Triple(r.nextFloat(), r.nextFloat() * 0.48f, 0.4f + r.nextFloat() * 1.2f) }
    }
    Canvas(Modifier.fillMaxSize().graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)) {
        stars.forEach { (x, y, s) ->
            drawCircle(Color.White.copy(alpha = 0.35f + s * 0.25f), s, Offset(x * size.width, y * size.height))
        }
    }
}

@Composable
fun Feed(state: LazyListState) {
    LazyColumn(
        state = state,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 110.dp, bottom = 140.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (Store.posts.isEmpty()) {
            item { HintCard() }
        } else {
            items(count = Store.posts.size, key = { it }, contentType = { 0 }) { i -> GlassCard(Store.posts[i]) }
        }
    }
}

@Composable
fun GlassCard(p: Post) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.13f), Color.White.copy(alpha = 0.04f))))
            .border(BorderStroke(1.dp, Line), shape)
            .clickable(interactionSource = src, indication = null) {}
            .padding(16.dp)
    ) {
        Text(
            p.author + "  ·  " + fmt.format(Date(p.ts)),
            color = Color.White.copy(alpha = 0.55f),
            fontSize = 12.sp
        )
        Text(
            p.text,
            color = Color.White,
            fontSize = 16.sp,
            modifier = Modifier.padding(top = 6.dp)
        )
    }
}

@Composable
fun Simple(name: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun TopPill(m: Modifier) {
    Box(
        m.statusBarsPadding().padding(top = 10.dp)
            .clip(Pill).background(Color(0xF2121826)).border(1.dp, Line, Pill)
            .padding(horizontal = 22.dp, vertical = 10.dp)
    ) {
        Text("МЕГАСТУДИЯ", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
    }
}

@Composable
fun Dock(sel: Int, onTab: (Int) -> Unit, m: Modifier) {
    val names = listOf("Сегодня", "Чаты", "Сеть", "Я")
    Row(
        m.navigationBarsPadding().padding(bottom = 14.dp)
            .clip(Pill).background(Color(0xF2121826)).border(1.dp, Line, Pill).padding(6.dp)
    ) {
        names.forEachIndexed { i, n ->
            val on = i == sel
            val bg by animateColorAsState(
                targetValue = if (on) Color(0x407AA8FF) else Color.Transparent,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                label = "bg"
            )
            val src = remember { MutableInteractionSource() }
            val pressed by src.collectIsPressedAsState()
            val sc by animateFloatAsState(
                targetValue = if (pressed) 0.92f else 1f,
                animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
                label = "dsc"
            )
            Box(
                Modifier
                    .graphicsLayer { scaleX = sc; scaleY = sc }
                    .clip(Pill).background(bg)
                    .clickable(interactionSource = src, indication = null) { onTab(i) }
                    .padding(horizontal = 18.dp, vertical = 11.dp)
            ) {
                Text(
                    n,
                    color = if (on) Color.White else Color.White.copy(alpha = 0.6f),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

// Счётчик кадров: средний fps и число «лагов» (кадр дольше 25 мс)
@Composable
fun FpsMeter(m: Modifier) {
    val view = LocalView.current
    var txt by remember { mutableStateOf("…") }
    LaunchedEffect(Unit) {
        var last = 0L
        var n = 0
        var sum = 0L
        var lag = 0
        var worst = 0L
        while (true) {
            val t = withFrameNanos { it }
            if (last != 0L) {
                val d = t - last
                if (d < 500_000_000L) {
                    sum += d
                    n++
                    if (d > 25_000_000L) lag++
                    if (d > worst) worst = d
                }
            }
            last = t
            if (n >= 60) {
                val hz = view.display?.refreshRate?.toInt() ?: 0
                txt = "${(1e9 * n / sum).toInt()} fps · экран $hz Гц · худший ${worst / 1_000_000} мс · лаги $lag · Земля ${EarthGate.renderMs.toInt()} мс${if (EarthGate.lite) " лайт" else ""}"
                n = 0
                sum = 0L
                worst = 0L
            }
        }
    }
    Text(txt, color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp, modifier = m.statusBarsPadding().padding(10.dp))
}

@Composable
fun HintCard() {
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape)
            .background(Color.White.copy(alpha = 0.08f)).border(BorderStroke(1.dp, Line), shape).padding(16.dp)
    ) {
        Text("Лента пока пустая", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(
            "Вкладка «Я» → «Импорт копии»: выбери файл копии из старого приложения.",
            color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
fun MeScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var raw by remember { mutableStateOf<String?>(null) }
    var pw by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                raw = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                pw = ""
                err = ""
                note = ""
            } catch (_: Throwable) {
                note = "Не удалось прочитать файл"
            }
        }
    }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Я", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Постов: ${Store.posts.size}", color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
        Box(
            Modifier.padding(top = 20.dp).clip(Pill).background(Color(0x407AA8FF)).border(1.dp, Line, Pill)
                .clickable { pick.launch(arrayOf("*/*")) }.padding(horizontal = 24.dp, vertical = 13.dp)
        ) { Text("Импорт копии", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
        if (note.isNotEmpty()) Text(note, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp))
    }
    val r = raw
    if (r != null) {
        AlertDialog(
            onDismissRequest = { if (!busy) raw = null },
            title = { Text("Пароль копии") },
            text = {
                Column {
                    OutlinedTextField(
                        value = pw, onValueChange = { pw = it }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                    if (err.isNotEmpty()) Text(err, color = Color(0xFFFF8A80), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    busy = true
                    err = ""
                    val p = pw
                    scope.launch {
                        val res = withContext(Dispatchers.Default) { runCatching { Store.parse(r, p) } }
                        val o = res.getOrNull()
                        if (o != null) {
                            runCatching { Store.commit(ctx, o) }
                            raw = null
                            note = "Готово: постов ${Store.posts.size}"
                        } else {
                            err = if (res.exceptionOrNull() is javax.crypto.AEADBadTagException) "Неверный пароль" else "Файл не подходит"
                        }
                        busy = false
                    }
                }) { Text(if (busy) "Считаю…" else "Открыть") }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { raw = null }) { Text("Отмена") } }
        )
    }
}
