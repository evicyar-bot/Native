package app.megastudiya.nativeapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.runtime.DisposableEffect
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.activity.compose.BackHandler
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import android.os.SystemClock
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.withFrameNanos

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Store.load(this)
        Place.load(this)
        News.load(this)
        Snd.init(this)
        setHighRefresh()
        setContent { MegaApp() }
    }

    override fun onPause() {
        super.onPause()
        EarthGate.view?.onPause()
    }

    override fun onResume() {
        super.onResume()
        EarthGate.view?.onResume()
    }

    // просим у системы максимальную частоту экрана (90/120 Гц, если есть)
    private fun setHighRefresh() {
        try {
            @Suppress("DEPRECATION")
            val d = windowManager.defaultDisplay
            val best = d.supportedModes.maxByOrNull { it.refreshRate } ?: return
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            window.attributes = lp
        } catch (_: Throwable) {
        }
    }
}

private val Bg = Color(0xFF0B0D12)
private val Pill = RoundedCornerShape(999.dp)
private val Line = Color.White.copy(alpha = 0.14f)

// «Жидкое стекло» из v99: диагональный блик, верхняя кромка света. Без размытия фона, чтобы не грузить телефон.
private fun Modifier.glass(shape: androidx.compose.ui.graphics.Shape): Modifier = this
    .clip(shape)
    .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.05f))))
    .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.38f), Color.White.copy(alpha = 0.08f))), shape)
private val fmt = SimpleDateFormat("d MMM, HH:mm", Locale("ru"))

@Composable
fun MegaApp() {
    var tab by remember { mutableIntStateOf(0) }
    var zen by remember { mutableStateOf(false) }
    LaunchedEffect(zen) { EarthGate.contemplate = zen }
    val haptic = LocalHapticFeedback.current
    val feedState = rememberLazyListState()
    LaunchedEffect(feedState) {
        snapshotFlow { feedState.isScrollInProgress }.collect { sc ->
            EarthGate.scrolling = sc
            if (!sc) EarthGate.scrollEnd = SystemClock.uptimeMillis()
        }
    }
    Box(
        Modifier.fillMaxSize().pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val e = awaitPointerEvent(PointerEventPass.Initial)
                    val down = e.changes.any { it.pressed }
                    EarthGate.touching = down
                    if (!down) EarthGate.scrollEnd = SystemClock.uptimeMillis()
                }
            }
        }
    ) {
        AndroidView(factory = { c -> EarthGLView(c).also { EarthGate.view = it } }, modifier = Modifier.fillMaxSize())
        if (!zen) Sky()
        // Лента всегда живая в памяти (не пересобирается при переключении), скрытая просто не размещается.
        Box(
            Modifier.fillMaxSize().graphicsLayer { alpha = if (zen) 0f else 1f }.layout { m, c ->
                if (tab == 0) {
                    val pl = m.measure(c)
                    layout(pl.width, pl.height) { pl.placeRelative(0, 0) }
                } else {
                    layout(c.maxWidth, c.maxHeight) { }
                }
            }
        ) { Feed(feedState) }
        if (tab == 0 && !zen) NewPost(Modifier.align(Alignment.BottomEnd))
        if (!zen) when (tab) {
            1 -> Simple("Чаты")
            2 -> Simple("Сеть")
            3 -> MeScreen()
            else -> {}
        }
        if (!zen) TopPill(Modifier.align(Alignment.TopCenter)) { zen = true }
        if (!zen) Dock(
            sel = tab,
            onTab = {
                tab = it
                EarthGate.holdUntil = SystemClock.uptimeMillis() + 450
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            },
            m = Modifier.align(Alignment.BottomCenter)
        )
        FpsMeter(Modifier.align(Alignment.TopEnd))
        if (zen) Zen { zen = false }
    }
}

// Небо: только звёзды в верхней половине экрана (внизу Земля).
@Composable
fun Sky() {
    val stars = remember {
        val r = java.util.Random(7)
        List(70) { Triple(r.nextFloat(), r.nextFloat() * 0.48f, 0.4f + r.nextFloat() * 1.2f) }
    }
    Canvas(Modifier.fillMaxSize().graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)) {
        stars.forEach { (x, y, s) ->
            drawCircle(Color.White.copy(alpha = 0.35f + s * 0.25f), s, Offset(x * size.width, y * size.height))
        }
    }
}

@Composable
fun Feed(state: LazyListState) {
    val ctx = LocalContext.current
    var ft by remember { mutableIntStateOf(0) }
    val list = remember(ft, Store.posts.size) {
        val day = System.currentTimeMillis() - 86_400_000L
        if (ft == 3) emptyList() else Store.posts.filter {
            when (ft) {
                0 -> it.ts >= day
                1 -> true
                else -> it.mine || it.aid == Store.meId || it.aid in Store.follows
            }
        }
    }
    LaunchedEffect(ft) { if (ft == 3) News.refresh(ctx) }
    LaunchedEffect(Place.cityName) { Place.loadWx(ctx) }
    LazyColumn(
        state = state,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 110.dp, bottom = 140.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "tabs") { FeedTabs(ft) { ft = it } }
        if (ft == 0) item(key = "wx") {
            EmptyCard(if (Place.cityName.isEmpty()) "Укажи город во вкладке «Я», здесь появится погода" else Place.cityName + " · " + Place.wx)
        }
        if (ft == 3) {
            if (News.status.isNotEmpty()) item(key = "st") { EmptyCard(News.status) }
            items(count = News.items.size, key = { it }) { i -> NewsCard(News.items[i]) }
        } else if (Store.posts.isEmpty()) {
            item(key = "hint") { HintCard() }
        } else if (list.isEmpty()) {
            item(key = "empty") { EmptyCard(if (ft == 0) "За сутки тишина. Загляни во «Все»." else "Здесь пока пусто.") }
        } else {
            items(count = list.size, key = { it }, contentType = { 0 }) { i -> GlassCard(list[i]) }
        }
    }
}

@Composable
fun NewsCard(n: NewsItem) {
    val ctx = LocalContext.current
    val ago = ((System.currentTimeMillis() - n.ts) / 3_600_000L).coerceAtLeast(0)
    Column(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp))
            .clickable { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(n.link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
            .padding(16.dp)
    ) {
        Text(n.src + " · " + (if (ago < 24) "$ago ч назад" else "${ago / 24} дн назад"), color = Color(0xFF6EA8FF), fontSize = 12.sp)
        Text(n.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
        if (n.desc.isNotEmpty()) Text(n.desc, color = Color.White.copy(alpha = 0.65f), fontSize = 13.sp, maxLines = 3, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
fun FeedTabs(sel: Int, onSel: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("Сегодня", "Все", "Читаю", "Новости").forEachIndexed { i, n ->
            val on = i == sel
            Box(
                Modifier.glass(Pill).then(if (on) Modifier.background(Color(0x406EA8FF), Pill) else Modifier).clickable { onSel(i) }.padding(horizontal = 12.dp, vertical = 8.dp)
            ) { Text(n, color = if (on) Color.White else Color.White.copy(alpha = 0.6f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
fun EmptyCard(t: String) {
    Text(t, color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
}

@Composable
fun GlassCard(p: Post) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .glass(shape)
            .clickable(interactionSource = src, indication = null) {}
            .padding(16.dp)
    ) {
        Text(
            p.author + "  ·  " + fmt.format(Date(p.ts)),
            color = Color.White.copy(alpha = 0.55f),
            fontSize = 12.sp
        )
        Text(
            p.text,
            color = Color.White,
            fontSize = 16.sp,
            modifier = Modifier.padding(top = 6.dp)
        )
    }
}

@Composable
fun NewPost(m: Modifier) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    Box(
        m.navigationBarsPadding().padding(end = 16.dp, bottom = 84.dp)
            .clip(Pill).background(Brush.linearGradient(listOf(Color(0xFF6EA8FF), Color(0xFFB58CFF)))).clickable { open = true }
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) { Text("＋ Пост", color = Bg, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text("Новый пост") },
            text = {
                OutlinedTextField(
                    value = Store.draft, onValueChange = { Store.setDraft(ctx, it) },
                    modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 8,
                    placeholder = { Text("Черновик сохраняется сам") }
                )
            },
            confirmButton = {
                TextButton(enabled = Store.draft.isNotBlank(), onClick = { Store.publish(ctx); Snd.play(); open = false }) { Text("Опубликовать") }
            },
            dismissButton = { TextButton(onClick = { open = false }) { Text("Закрыть") } }
        )
    }
}

@Composable
fun Simple(name: String) {
    val text = if (name == "Чаты") "Здесь будут переписки: личные и по кругу близких. Они появятся вместе с «Связью», когда устройства научатся находить друг друга напрямую."
    else "Здесь будут устройства рядом и статус каждого канала доставки. Появится вместе с «Связью»."
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(26.dp)).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(text, color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp))
            Text("Скоро", color = Color(0xFF6EA8FF), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 14.dp))
        }
    }
}

@Composable
fun TopPill(m: Modifier, onClick: () -> Unit) {
    Box(
        m.statusBarsPadding().padding(top = 10.dp)
            .clip(Pill).background(Color(0xCC0E121E)).glass(Pill).clickable { onClick() }
            .padding(horizontal = 22.dp, vertical = 10.dp)
    ) {
        Text("МЕГАСТУДИЯ", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
    }
}

@Composable
fun Dock(sel: Int, onTab: (Int) -> Unit, m: Modifier) {
    val names = listOf("Сегодня", "Чаты", "Сеть", "Я")
    val xs = remember { mutableStateListOf(0, 0, 0, 0) }
    val ws = remember { mutableStateListOf(0, 0, 0, 0) }
    var hh by remember { mutableIntStateOf(0) }
    val spec = spring<Int>(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow)
    val ix by animateIntAsState(xs[sel], spec, label = "ix")
    val iw by animateIntAsState(ws[sel], spec, label = "iw")
    val dens = LocalDensity.current
    Box(
        m.navigationBarsPadding().padding(bottom = 14.dp)
            .clip(Pill).background(Color(0xCC0E121E)).glass(Pill).padding(6.dp)
    ) {
        if (iw > 0) Box(
            Modifier.offset { IntOffset(ix, 0) }
                .size(with(dens) { iw.toDp() }, with(dens) { hh.toDp() })
                .clip(Pill).background(Color(0x336EA8FF)).border(1.dp, Color(0x4D6EA8FF), Pill)
        )
        Row {
            names.forEachIndexed { i, n ->
                val on = i == sel
                val src = remember { MutableInteractionSource() }
                val pressed by src.collectIsPressedAsState()
                val sc by animateFloatAsState(
                    targetValue = if (pressed) 0.92f else 1f,
                    animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
                    label = "dsc"
                )
                Box(
                    Modifier
                        .onGloballyPositioned { xs[i] = it.positionInParent().x.toInt(); ws[i] = it.size.width; hh = it.size.height }
                        .graphicsLayer { scaleX = sc; scaleY = sc }
                        .clip(Pill)
                        .clickable(interactionSource = src, indication = null) { onTab(i) }
                        .padding(horizontal = 18.dp, vertical = 11.dp)
                ) {
                    Text(
                        n,
                        color = if (on) Color.White else Color.White.copy(alpha = 0.6f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
fun FpsMeter(m: Modifier) {
    val view = LocalView.current
    var txt by remember { mutableStateOf("…") }
    LaunchedEffect(Unit) {
        var last = 0L
        var n = 0
        var sum = 0L
        var lag = 0
        var worst = 0L
        while (true) {
            val t = withFrameNanos { it }
            if (last != 0L) {
                val d = t - last
                if (d < 500_000_000L) {
                    sum += d
                    n++
                    if (d > 25_000_000L) lag++
                    if (d > worst) worst = d
                }
            }
            last = t
            if (n >= 60) {
                val hz = view.display?.refreshRate?.toInt() ?: 0
                txt = "${(1e9 * n / sum).toInt()} fps · экран $hz Гц · худший ${worst / 1_000_000} мс · лаги $lag · Земля ${EarthGate.renderMs.toInt()} мс${if (EarthGate.lite) " лайт" else ""}"
                n = 0
                sum = 0L
                worst = 0L
            }
        }
    }
    Text(txt, color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp, modifier = m.statusBarsPadding().padding(10.dp))
}

@Composable
fun HintCard() {
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape)
            .background(Color.White.copy(alpha = 0.08f)).border(BorderStroke(1.dp, Line), shape).padding(16.dp)
    ) {
        Text("Лента пока пустая", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(
            "Вкладка «Я» → «Импорт копии»: выбери файл копии из старого приложения.",
            color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
fun MeScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var raw by remember { mutableStateOf<String?>(null) }
    var pw by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var page by remember { mutableIntStateOf(0) }
    var br by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                raw = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                pw = ""
                err = ""
                note = ""
            } catch (_: Throwable) {
                note = "Не удалось прочитать файл"
            }
        }
    }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Я", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = Store.name, onValueChange = { Store.setName(ctx, it) }, singleLine = true,
            label = { Text("Твоё имя") }, modifier = Modifier.padding(top = 12.dp)
        )
        var cin by remember { mutableStateOf("") }
        OutlinedTextField(
            value = cin, onValueChange = { cin = it }, singleLine = true,
            label = { Text(if (Place.cityName.isEmpty()) "Город" else "Город: " + Place.cityName) }, modifier = Modifier.padding(top = 8.dp)
        )
        MenuBtn("Найти город") {
            val q = cin.trim()
            if (q.isNotEmpty()) scope.launch {
                note = "Ищу…"
                try {
                    val g = Place.geocode(q)
                    if (g == null) note = "Не нашёл такой город" else {
                        Place.setCity(ctx, g)
                        cin = ""
                        note = "Город: " + g.name
                        Place.loadWx(ctx)
                    }
                } catch (_: Throwable) {
                    note = "Нет интернета"
                }
            }
        }
        Text("Постов: ${Store.posts.size}", color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
        Box(
            Modifier.padding(top = 20.dp).clip(Pill).background(Color(0x407AA8FF)).border(1.dp, Line, Pill)
                .clickable { pick.launch(arrayOf("*/*")) }.padding(horizontal = 24.dp, vertical = 13.dp)
        ) { Text("Импорт копии", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
        MenuBtn("Подышать") { br = true }
        MenuBtn(if (Snd.on) "Звук: вкл" else "Звук: выкл") { Snd.toggle(ctx) }
        MenuBtn("О проекте") { page = 1 }
        MenuBtn("Правила") { page = 2 }
        if (note.isNotEmpty()) Text(note, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp))
    }
    if (br) Breathe { br = false }
    if (page != 0) {
        BackHandler { page = 0 }
        TextPage(if (page == 1) "О проекте" else "Правила", if (page == 1) ABOUT else RULES) { page = 0 }
    }
    val r = raw
    if (r != null) {
        AlertDialog(
            onDismissRequest = { if (!busy) raw = null },
            title = { Text("Пароль копии") },
            text = {
                Column {
                    OutlinedTextField(
                        value = pw, onValueChange = { pw = it }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                    if (err.isNotEmpty()) Text(err, color = Color(0xFFFF8A80), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    busy = true
                    err = ""
                    val p = pw
                    scope.launch {
                        val res = withContext(Dispatchers.Default) { runCatching { Store.parse(r, p) } }
                        val o = res.getOrNull()
                        if (o != null) {
                            runCatching { Store.commit(ctx, o) }
                            raw = null
                            note = "Готово: постов ${Store.posts.size}"
                        } else {
                            err = if (res.exceptionOrNull() is javax.crypto.AEADBadTagException) "Неверный пароль" else "Файл не подходит"
                        }
                        busy = false
                    }
                }) { Text(if (busy) "Считаю…" else "Открыть") }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { raw = null }) { Text("Отмена") } }
        )
    }
}

private const val ABOUT = "Канал, который живёт у тебя. Сеть без центра: каждое устройство часть сервера. Её нельзя отключить в одном месте.\n\nТри круга\nЗаметки: только у меня.\nКруг: избранным.\nВсем: публичный канал.\n\nЯдро\n1. Своя копия у каждого, без интернета.\n2. Слияние без потерь.\n3. Несколько каналов доставки.\n4. Знакомство без сервера.\n5. Честные статусы.\n6. Копия одним файлом.\n7. Любое устройство."
private const val RULES = "Здесь нет модератора: ты сам решаешь, что видеть. Нельзя публиковать незаконное, угрозы, чужие личные данные и материалы с насилием над детьми. Ты отвечаешь за то, что публикуешь.\n\nПосты нельзя подделать, но и стереть у всех нельзя. «Пожаловаться» скрывает пост у тебя и больше не пересылает его дальше; «Скрыть» убирает автора целиком.\n\nДля обмена бери копию без личного. Полная копия защищена паролем. «Личный» пост никуда не уходит. Анонимности сеть не обещает."

@Composable
fun MenuBtn(t: String, onClick: () -> Unit) {
    Box(
        Modifier.padding(top = 12.dp).glass(Pill)
            .clickable { onClick() }.padding(horizontal = 24.dp, vertical = 12.dp)
    ) { Text(t, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun TextPage(title: String, body: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().padding(24.dp)) {
        Text("← Назад", color = Color(0xFF6EA8FF), fontSize = 15.sp, modifier = Modifier.clickable { onBack() }.padding(bottom = 16.dp))
        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(body, color = Color.White.copy(alpha = 0.8f), fontSize = 16.sp, modifier = Modifier.padding(top = 12.dp))
    }
}

private class Stop(val name: String, val lat: Double, val lon: Double)

private val WORLD = listOf(
    Stop("Москва", 55.75, 37.62), Stop("Санкт-Петербург", 59.94, 30.31), Stop("Лондон", 51.51, -0.13),
    Stop("Нью-Йорк", 40.71, -74.0), Stop("Рио-де-Жанейро", -22.91, -43.17), Stop("Кейптаун", -33.92, 18.42),
    Stop("Каир", 30.04, 31.24), Stop("Дубай", 25.2, 55.27), Stop("Мумбаи", 19.08, 72.88),
    Stop("Пекин", 39.9, 116.4), Stop("Токио", 35.68, 139.69), Stop("Сидней", -33.87, 151.21),
    Stop("Сан-Франциско", 37.77, -122.42)
)

// Режим созерцания: интерфейс гаснет, планета в центре. Щипок — зум, «Лететь» — следующий город, тап — выход.
@Composable
fun Zen(onExit: () -> Unit) {
    val stops = remember { (if (Place.cityName.isEmpty()) emptyList() else listOf(Stop(Place.cityName, Place.lat, Place.lon))) + WORLD }
    var i by remember { mutableIntStateOf(0) }
    LaunchedEffect(i) {
        EarthGate.focusLat = Math.toRadians(stops[i].lat)
        EarthGate.focusLon = Math.toRadians(stops[i].lon)
    }
    DisposableEffect(Unit) { onDispose { EarthGate.zoom = 1f } }
    BackHandler { onExit() }
    val mine = Store.posts.count { it.mine || (Store.meId.isNotEmpty() && it.aid == Store.meId) }
    val hung = Store.posts.count { (it.mine || (Store.meId.isNotEmpty() && it.aid == Store.meId)) && it.text.contains("#подвешено", ignoreCase = true) }
    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) { detectTransformGestures { _, _, z, _ -> EarthGate.zoom = (EarthGate.zoom * z).coerceIn(0.6f, 3.2f) } }
            .pointerInput(Unit) { detectTapGestures { onExit() } }
    ) {
        Text(
            if (mine == 0) "" else "$mine звёзд" + (if (hung > 0) " · $hung подвешено" else ""),
            color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp,
            modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 16.dp)
        )
        Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(stops[i].name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("щипок — зум · тап — назад", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            MenuBtn("Лететь ›") { i = (i + 1) % stops.size }
        }
    }
}

// «Подышать»: 5 циклов, вдох 4 секунды, выдох 6, как в v99
@Composable
fun Breathe(onClose: () -> Unit) {
    var say by remember { mutableStateOf("Вдох…") }
    val sc = remember { Animatable(0.45f) }
    LaunchedEffect(Unit) {
        repeat(5) {
            say = "Вдох…"
            sc.animateTo(1f, tween(4000))
            say = "Выдох…"
            sc.animateTo(0.45f, tween(6000))
        }
        say = "Хорошо. Можно возвращаться."
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Подышать") },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Canvas(Modifier.size(160.dp)) {
                    drawCircle(Color(0x667AA8FF), radius = size.minDimension / 2 * sc.value)
                }
                Text(say, modifier = Modifier.padding(top = 8.dp))
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Закрыть") } }
    )
}
