package app.megastudiya.nativeapp

import android.content.Context
import org.json.JSONObject
import kotlin.math.pow
import kotlin.math.sqrt

// Вкус: интерес к темам и источникам считается на самом телефоне и никуда не уходит.
// Сигналы копятся (открыл, дочитал, нравится), снижаются (скрыл, не нравится) и раз в сутки чуть забываются.
// Вся логика ленты: оценка = интерес × 0,5^(возраст / 24 ч) + немного случайности.
object Taste {
    private val w = HashMap<String, Float>()
    private var loaded = false
    private val stop = setOf(
        "после", "который", "которые", "которая", "также", "только", "этого", "когда", "более", "между", "через", "будет",
        "может", "стали", "своих", "почему", "сообщил", "заявил", "рассказал", "сказал", "новый", "новые", "новая", "около",
        "перед", "этом", "этой", "этот", "были", "было", "была", "очень", "чтобы", "пока", "если", "стало", "после", "время"
    )
    private val tagRe = Regex("#([\\p{L}\\d_]{2,})")
    private val wordRe = Regex("\\p{L}{5,}")

    fun keyOf(x: Any): String = if (x is Post) "p" + x.id else "n" + (x as NewsItem).link

    private fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val p = ctx.getSharedPreferences("ms", Context.MODE_PRIVATE)
        runCatching {
            val o = JSONObject(p.getString("taste", "{}") ?: "{}")
            val t = p.getLong("tasteT", System.currentTimeMillis())
            val days = ((System.currentTimeMillis() - t) / 86_400_000L).toInt().coerceAtLeast(0)
            val k = 0.97f.pow(days)
            o.keys().forEach { key -> w[key] = o.getDouble(key).toFloat() * k }
        }
    }

    private fun save(ctx: Context) {
        if (w.size > 300) { // оставляем самые сильные
            val keep = w.entries.sortedByDescending { kotlin.math.abs(it.value) }.take(240).map { it.key }.toSet()
            w.keys.retainAll(keep)
        }
        val o = JSONObject()
        w.forEach { (k, v) -> o.put(k, v.toDouble()) }
        ctx.getSharedPreferences("ms", Context.MODE_PRIVATE).edit().putString("taste", o.toString()).putLong("tasteT", System.currentTimeMillis()).apply()
    }

    fun tags(text: String): List<String> {
        val out = LinkedHashSet<String>()
        tagRe.findAll(text).forEach { out.add("#" + it.groupValues[1].lowercase()) }
        wordRe.findAll(text.lowercase()).forEach { if (it.value !in stop) out.add(it.value.take(6)) }
        return out.take(24)
    }

    // d > 0 нравится, d < 0 не нравится
    fun add(ctx: Context, text: String, src: String, d: Float) {
        load(ctx)
        for (t in tags(text)) w[t] = ((w[t] ?: 0f) + d).coerceIn(-6f, 6f)
        w["src:$src"] = ((w["src:$src"] ?: 0f) + d * 0.5f).coerceIn(-6f, 6f)
        save(ctx)
    }

    private fun noise(key: String): Float = (((key.hashCode() * 2654435761L) ushr 8) and 0xFFFF).toFloat() / 65535f * 0.15f

    private class Ent(val x: Any, val src: String, val s: Float)

    fun rank(ctx: Context, all: List<Any>): List<Any> {
        load(ctx)
        val now = System.currentTimeMillis()
        val seen = HashSet<String>()
        val l = ArrayList<Ent>()
        for (x in all) {
            val key = keyOf(x)
            if (!seen.add(key)) continue // дубли отбрасываем
            val text: String; val src: String; val ts: Long; val boost: Float
            if (x is Post) { text = x.text; src = x.author; ts = x.ts; boost = if (x.mine) 0.6f else 0f }
            else { val n = x as NewsItem; text = n.title + " " + n.desc.take(200); src = n.src; ts = n.ts; boost = 0f }
            val tg = tags(text)
            var si = 0f
            for (t in tg) si += w[t] ?: 0f
            if (tg.isNotEmpty()) si /= sqrt(tg.size.toFloat())
            si += w["src:$src"] ?: 0f
            if (si < -2.5f && x !is Post) continue // то, что ты не любишь, больше не показываем
            val age = ((now - ts) / 3_600_000f).coerceAtLeast(0f)
            l.add(Ent(x, src, (1f + si + boost).coerceAtLeast(0.05f) * 0.5f.pow(age / 24f) + noise(key)))
        }
        l.sortByDescending { it.s }
        // разбавление: не больше двух подряд из одного источника
        val out = ArrayList<Any>(l.size)
        val rest = ArrayList(l)
        var last = ""
        var run = 0
        while (rest.isNotEmpty()) {
            var i = 0
            if (run >= 2) { i = rest.indexOfFirst { it.src != last }; if (i < 0) i = 0 }
            val e = rest.removeAt(i)
            run = if (e.src == last) run + 1 else 1
            last = e.src
            out.add(e.x)
        }
        return out
    }
}
