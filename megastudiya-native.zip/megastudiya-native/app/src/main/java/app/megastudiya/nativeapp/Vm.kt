package app.megastudiya.nativeapp

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.round

// МАШИНА ЯДРА: язык программ, которые ядро пишет и меняет само.
// 8 регистров, память на 16 ячеек, условные переходы (в том числе назад, то есть циклы), 18 признаков темы на входе (14 исходных и 4 производных, которые ядро придумывает само).
// Программа считает оценку темы. Это чистая функция: у неё нет доступа к файлам, сети, базе и телефону,
// каждый запуск ограничен 300 шагами, любое «не число» превращается в 0. Размер до 24 команд.
// Команды (op a b c): 1 загрузить константу c в r[a]; 2 r[a]=r[b]; 3 +; 4 −; 5 ×; 6 ÷ (r[a]=r[b] op r[c]);
// 7 min; 8 max; 9 r[a]=ln(1+|r[b]|); 11 r[a]=признак b; 12 r[a]=память[b]; 13 память[b]=r[a];
// 14 если r[a] < r[b], перейти на c команд (c может быть отрицательным); 16 вернуть r[a].
object Vm {
    const val NF = 18
    const val MAXLEN = 24
    private const val MAXSTEPS = 300

    class Ins(val op: Int, val a: Int, val b: Int, val c: Float)

    private val rnd = java.util.Random()

    private fun sane(x: Float): Float = if (x.isNaN() || x.isInfinite()) 0f else x.coerceIn(-1e6f, 1e6f)

    fun parse(s: String): List<Ins> {
        if (!s.startsWith("P:")) throw IllegalArgumentException("kind")
        val body = s.substring(2)
        if (body.isEmpty()) throw IllegalArgumentException("empty")
        val parts = body.split(";")
        if (parts.size > MAXLEN) throw IllegalArgumentException("len")
        return parts.map { p ->
            val q = p.split(",")
            if (q.size != 4) throw IllegalArgumentException("ins")
            val op = q[0].toInt()
            if (op < 0 || op > 16) throw IllegalArgumentException("op")
            Ins(op, q[1].toInt(), q[2].toInt(), q[3].toFloat())
        }
    }

    fun toStr(p: List<Ins>): String =
        "P:" + p.joinToString(";") { it.op.toString() + "," + it.a + "," + it.b + "," + String.format(java.util.Locale.ROOT, "%.3f", it.c) }

    fun run(p: List<Ins>, f: FloatArray): Float {
        val r = FloatArray(8)
        val m = FloatArray(16)
        var pc = 0
        var steps = 0
        while (pc >= 0 && pc < p.size) {
            steps++
            if (steps > MAXSTEPS) return 0f
            val i = p[pc]
            pc++
            val a = Math.floorMod(i.a, 8)
            val b8 = Math.floorMod(i.b, 8)
            val c8 = Math.floorMod(i.c.toInt(), 8)
            when (i.op) {
                1 -> { r[a] = i.c }
                2 -> { r[a] = r[b8] }
                3 -> { r[a] = r[b8] + r[c8] }
                4 -> { r[a] = r[b8] - r[c8] }
                5 -> { r[a] = r[b8] * r[c8] }
                6 -> { r[a] = if (abs(r[c8]) < 1e-4f) 0f else r[b8] / r[c8] }
                7 -> { r[a] = minOf(r[b8], r[c8]) }
                8 -> { r[a] = maxOf(r[b8], r[c8]) }
                9 -> { r[a] = ln(1f + abs(r[b8])) }
                11 -> {
                    val k = Math.floorMod(i.b, NF)
                    r[a] = if (k < f.size) f[k] else 0f
                }
                12 -> { r[a] = m[Math.floorMod(i.b, 16)] }
                13 -> { m[Math.floorMod(i.b, 16)] = r[a] }
                14 -> { if (r[a] < r[b8]) pc += i.c.toInt() }
                16 -> return sane(r[a])
                else -> { }
            }
            r[a] = sane(r[a])
        }
        return sane(r[0])
    }

    private fun randIns(): Ins {
        val ops = intArrayOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 11, 11, 12, 13, 14)
        val op = ops[rnd.nextInt(ops.size)]
        val a = rnd.nextInt(8)
        val b = when (op) {
            11 -> { var k = rnd.nextInt(NF); if (k == 6) k = 7; k } // признак «случайность» не берём
            12, 13 -> rnd.nextInt(16)
            else -> rnd.nextInt(8)
        }
        val c = when (op) {
            1 -> round((rnd.nextFloat() * 6f - 3f) * 100f) / 100f
            14 -> (rnd.nextInt(9) - 4).toFloat()
            else -> rnd.nextInt(8).toFloat()
        }
        return Ins(op, a, b, c)
    }

    fun random(len: Int): List<Ins> {
        val out = ArrayList<Ins>()
        for (k in 0 until len.coerceIn(2, MAXLEN)) out.add(randIns())
        return out
    }

    // Мутация: заменить команду, вставить, удалить, подправить константу или поменять две команды местами
    fun mutate(p: List<Ins>): List<Ins> {
        val q = p.toMutableList()
        if (q.isEmpty()) return random(4)
        when (rnd.nextInt(5)) {
            0 -> { q[rnd.nextInt(q.size)] = randIns() }
            1 -> { if (q.size < MAXLEN) q.add(rnd.nextInt(q.size + 1), randIns()) }
            2 -> { if (q.size > 2) q.removeAt(rnd.nextInt(q.size)) }
            3 -> {
                val k = rnd.nextInt(q.size)
                val x = q[k]
                q[k] = Ins(x.op, x.a, x.b, if (x.op == 1) round((x.c + rnd.nextFloat() - 0.5f) * 100f) / 100f else x.c)
            }
            else -> {
                val i = rnd.nextInt(q.size)
                val j = rnd.nextInt(q.size)
                val t = q[i]
                q[i] = q[j]
                q[j] = t
            }
        }
        return q
    }
}
