package app.megastudiya.nativeapp

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

// Загрузчик картинок без сторонних библиотек: память (LruCache) -> диск (cacheDir/img) -> сеть.
// Не больше трёх загрузок одновременно, лимит размера файла, сбой одной картинки ничего не ломает.
object Img {
    private val mem = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val gate = Semaphore(3)
    private val bad = HashSet<String>()

    private fun fix(u: String): String = if (u.startsWith("http://")) "https://" + u.removePrefix("http://") else u

    fun peek(url: String): ImageBitmap? = mem.get(fix(url))?.asImageBitmap()

    suspend fun load(ctx: Context, url0: String): ImageBitmap? {
        val url = fix(url0)
        mem.get(url)?.let { return it.asImageBitmap() }
        if (synchronized(bad) { url in bad }) return null
        return withContext(Dispatchers.IO) {
            gate.withPermit {
                try {
                    val dir = File(ctx.cacheDir, "img").apply { mkdirs() }
                    val f = File(dir, Integer.toHexString(url.hashCode()) + url.length)
                    if (!f.exists() || f.length() == 0L) download(url, f)
                    val b = decode(f)
                    if (b == null) {
                        synchronized(bad) { bad.add(url) }
                        null
                    } else {
                        mem.put(url, b)
                        b.asImageBitmap()
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Throwable) {
                    synchronized(bad) { bad.add(url) }
                    null
                }
            }
        }
    }

    private fun download(url: String, f: File) {
        val c = URL(url).openConnection() as HttpURLConnection
        val tmp = File(f.parentFile, f.name + ".tmp")
        try {
            c.connectTimeout = 8000
            c.readTimeout = 10000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Megastudiya")
            if (c.responseCode != 200) error("http " + c.responseCode)
            c.inputStream.use { ins ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(16384)
                    var total = 0
                    while (true) {
                        val r = ins.read(buf)
                        if (r < 0) break
                        total += r
                        if (total > 3_000_000) error("too big")
                        out.write(buf, 0, r)
                    }
                }
            }
            if (!tmp.renameTo(f)) error("rename")
        } catch (e: Throwable) {
            tmp.delete()
            throw e
        } finally {
            c.disconnect()
        }
    }

    private fun decode(f: File): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        // не картинка или крошечный значок/пиксель-счётчик
        if (o.outWidth < 200 || o.outHeight < 100) {
            f.delete()
            return null
        }
        var s = 1
        while (o.outWidth / (s * 2) >= 900) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        val b = BitmapFactory.decodeFile(f.path, o2)
        if (b == null) f.delete()
        return b
    }

    // Дисковый кэш не растёт бесконечно: сверх 80 МБ удаляем самые старые до 50 МБ.
    fun trim(ctx: Context) {
        runCatching {
            val fs = File(ctx.cacheDir, "img").listFiles() ?: return
            var total = fs.sumOf { it.length() }
            if (total <= 80_000_000L) return
            for (f in fs.sortedBy { it.lastModified() }) {
                if (total <= 50_000_000L) break
                total -= f.length()
                f.delete()
            }
        }
    }
}

@Composable
fun NewsImage(url: String, h: Dp) {
    val ctx = LocalContext.current
    var bmp by remember(url) { mutableStateOf(Img.peek(url)) }
    var failed by remember(url) { mutableStateOf(false) }
    LaunchedEffect(url) {
        if (bmp == null) {
            val b = Img.load(ctx, url)
            if (b != null) bmp = b else failed = true
        }
    }
    if (!failed) Box(
        Modifier.padding(bottom = 12.dp).fillMaxWidth().height(h).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.06f))
    ) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}
