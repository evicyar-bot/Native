package app.megastudiya.nativeapp

import android.content.Context
import android.util.Base64
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONObject
import java.io.File
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

data class Post(val id: String, val author: String, val text: String, val ts: Long)

// Локальное хранилище: копия лежит в закрытой папке приложения, сети нет.
object Store {
    val posts = mutableStateListOf<Post>()

    fun load(ctx: Context) {
        try {
            val f = File(ctx.filesDir, "copy.json")
            if (f.exists()) apply(JSONObject(f.readText()))
        } catch (_: Throwable) {
        }
    }

    // Файл «Копия» из старого приложения: либо зашифрованный (enc=1), либо обычный.
    // Бросает исключение при неверном пароле или чужом файле.
    fun parse(raw: String, pw: String): JSONObject {
        val o = JSONObject(raw)
        if (!o.has("enc")) return o
        val salt = Base64.decode(o.getString("salt"), Base64.DEFAULT)
        val iv = Base64.decode(o.getString("iv"), Base64.DEFAULT)
        val ct = Base64.decode(o.getString("data"), Base64.DEFAULT)
        val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pw.toCharArray(), salt, 250000, 256)).encoded
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return JSONObject(String(c.doFinal(ct), Charsets.UTF_8))
    }

    fun commit(ctx: Context, o: JSONObject) {
        File(ctx.filesDir, "copy.json").writeText(o.toString())
        apply(o)
    }

    private fun apply(o: JSONObject) {
        val authors = o.optJSONObject("authors") ?: JSONObject()
        val arr = o.optJSONArray("posts") ?: return
        val list = ArrayList<Post>(arr.length())
        for (i in 0 until arr.length()) {
            val p = arr.optJSONObject(i) ?: continue
            val a = p.optString("author")
            list.add(Post(p.optString("id", i.toString()), authors.optString(a, a), p.optString("text"), p.optLong("ts")))
        }
        list.sortByDescending { it.ts }
        posts.clear()
        posts.addAll(list)
    }
}
