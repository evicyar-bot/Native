package app.megastudiya.nativeapp

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.round
import kotlin.math.sqrt

// ЯДРО (эмбрион), шаг 2: замкнутый цикл развития.
//  чувствует (сигналы ленты) → действует (желания → запросы ленты) → оценивает (отклик, ошибка прогноза)
//  → помнит (SQLite) → МЕНЯЕТ СЕБЯ (новые стратегии как данные) → оставляет лучшее или откатывает.
// Стратегия — это строка в таблице rule (источник кандидатов, порог, способ выбора), а не код.
// Код исполняет только Страж, поэтому изменения безопасны и откатываются удалением строки.
// Новая стратегия идёт «на испытание»: ей даётся шанс, и если отклик не лучше среднего, она отвергается.
// Три исходные стратегии (родитель пустой) удалить нельзя.
// Страж: свой поток с низким приоритетом, только пока приложение на экране, лимит 500 циклов в сутки,
// самовыключение при сбоях, ежедневная копия памяти с восстановлением. Раздел «Предназначение» пуст.
internal class CoreDb(ctx: Context) : SQLiteOpenHelper(ctx, "core.db", null, 8) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE ev(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, key TEXT, d REAL, err REAL)")
        db.execSQL("CREATE TABLE tagw(t TEXT PRIMARY KEY, w REAL, n INTEGER, ts INTEGER)")
        db.execSQL("CREATE TABLE edge(a TEXT, b TEXT, w REAL, PRIMARY KEY(a, b))")
        db.execSQL("CREATE TABLE arm(name TEXT PRIMARY KEY, n INTEGER, s REAL)")
        db.execSQL("CREATE TABLE prio(name TEXT PRIMARY KEY, w REAL, why TEXT, ts INTEGER)")
        db.execSQL("CREATE TABLE want(t TEXT PRIMARY KEY, arm TEXT, ts INTEGER, state INTEGER, f TEXT)") // 0 открыто, 1 откликнулись, 2 не сбылось
        db.execSQL("CREATE TABLE q(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, text TEXT)")
        db.execSQL("CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT)")
        db.execSQL("CREATE TABLE purpose(id INTEGER PRIMARY KEY, text TEXT)") // пустое: пишет сама система вместе с владельцем
        evoTables(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        if (o < 8) {
            evoTables(db)
            if (o < 5) try { db.execSQL("ALTER TABLE want ADD COLUMN f TEXT") } catch (_: Throwable) { }
        }
    }

    private fun evoTables(db: SQLiteDatabase) {
        // status: 0 испытание, 1 принята, 2 отвергнута или откачена
        db.execSQL("CREATE TABLE IF NOT EXISTS rule(id TEXT PRIMARY KEY, src TEXT, thr REAL, np INTEGER, pick TEXT, prio TEXT, status INTEGER, parent TEXT, born INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS evo(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, text TEXT)")
        // мягкие лимиты: значение v она может поднимать сама, но не выше потолка hi (его меняет только владелец)
        db.execSQL("CREATE TABLE IF NOT EXISTS lim(name TEXT PRIMARY KEY, v REAL, hi REAL, bite INTEGER, ts INTEGER)")
        // реестр потребностей: «что мне мешает» и «чего мне не хватает» со счётчиком, сколько раз упёрлась
        db.execSQL("CREATE TABLE IF NOT EXISTS need(name TEXT PRIMARY KEY, cnt INTEGER, text TEXT, ts INTEGER)")
        // орган языка: счётчики слов и пар слов (биграммы), на них считается «удивление» от нового текста
        // модули: формулы над признаками темы; status 0 на испытании, 1 принят, 2 отвергнут
        db.execSQL("CREATE TABLE IF NOT EXISTS mod(id TEXT PRIMARY KEY, expr TEXT, status INTEGER, parent TEXT, born INTEGER, auc REAL)")
        // самомодель: чем и как я меняю себя, что ожидала и что вышло, мой дневник
        db.execSQL("CREATE TABLE IF NOT EXISTS selfm(rid TEXT PRIMARY KEY, op TEXT, pred REAL, naive REAL, ts INTEGER, done INTEGER, actual REAL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS opx(name TEXT PRIMARY KEY, n INTEGER, s REAL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS diary(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, text TEXT)")
        // уже прочитанные тексты ленты (по хэшу), чтобы одни и те же карточки не засчитывались как новое чтение
        db.execSQL("CREATE TABLE IF NOT EXISTS seen(h INTEGER PRIMARY KEY)")
        // признаки, которые ядро придумало само: программа машины над 14 исходными признаками темы
        db.execSQL("CREATE TABLE IF NOT EXISTS fea(slot INTEGER PRIMARY KEY, expr TEXT, auc REAL, ts INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS uni(w TEXT PRIMARY KEY, c INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS bg(a TEXT, b TEXT, c INTEGER, PRIMARY KEY(a, b))")
    }
}

private fun SQLiteDatabase.int(sql: String, vararg a: String): Int =
    rawQuery(sql, arrayOf(*a)).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }

private fun SQLiteDatabase.str(sql: String, vararg a: String): String? =
    rawQuery(sql, arrayOf(*a)).use { c -> if (c.moveToFirst() && !c.isNull(0)) c.getString(0) else null }

private fun SQLiteDatabase.flt(sql: String, vararg a: String): Float? =
    rawQuery(sql, arrayOf(*a)).use { c -> if (c.moveToFirst() && !c.isNull(0)) c.getFloat(0) else null }

private fun SQLiteDatabase.meta(k: String): String? = str("SELECT v FROM meta WHERE k=?", k)

private fun SQLiteDatabase.setMeta(k: String, v: String) {
    execSQL("INSERT OR REPLACE INTO meta(k,v) VALUES(?,?)", arrayOf<Any>(k, v))
}

object Core {
    private const val DAY = 86_400_000L
    private var db: CoreDb? = null
    private var app: Context? = null
    private var started = false
    private var fails = 0
    private var cool = 0
    private val rnd = java.util.Random()

    @Volatile private var active = false

    @Volatile var enabled = true
        private set

    @Volatile var report = "Ядро: просыпается…"
        private set

    // читать ли ей и на мобильном интернете (по умолчанию только Wi-Fi)
    @Volatile var mobileOk = false
        private set

    fun setMobile(ctx: Context, v: Boolean) {
        mobileOk = v
        ctx.applicationContext.getSharedPreferences("ms", Context.MODE_PRIVATE).edit().putBoolean("coreMobile", v).apply()
    }

    fun setEnabled(ctx: Context, v: Boolean) {
        enabled = v
        if (v) fails = 0
        ctx.applicationContext.getSharedPreferences("ms", Context.MODE_PRIVATE).edit().putBoolean("coreOn", v).apply()
    }

    private val io = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "ms-core").apply { priority = Thread.MIN_PRIORITY; isDaemon = true }
    }

    // чтение из сети идёт в отдельном потоке, чтобы не задерживать обучение; в базу пишет только основной поток ядра
    private val rd = Executors.newSingleThreadExecutor { r ->
        Thread(r, "ms-core-net").apply { priority = Thread.MIN_PRIORITY; isDaemon = true }
    }

    private val basePrio = listOf("нехватка данных", "любопытство", "осторожность")
    // какой приоритет питает стратегия с данным источником кандидатов
    private val prioOfSrc = mapOf("pos" to "нехватка данных", "new" to "любопытство", "surp" to "осторожность", "nb" to "любопытство")
    private val srcName = mapOf("pos" to "сильные слова", "new" to "новые слова", "surp" to "неожиданное", "nb" to "соседи сильных слов")

    // мягкие лимиты: начальное значение, потолок, как она это называет
    private val limInfo = mapOf(
        "cycles" to Triple(500f, 1440f, "суточный запас размышлений"),
        "wants" to Triple(3f, 12f, "число желаний одновременно"),
        "rules" to Triple(10f, 40f, "число живых стратегий"),
        "net" to Triple(51200f, 1048576f, "суточный трафик на чтение, КБ"),
        "disk" to Triple(500f, 20000f, "память ядра, МБ"),
        "brain" to Triple(64f, 512f, "размер нейро-мозга, МБ"),
        "rw_user" to Triple(1f, 3f, "вес вашего отклика в награде"),
        "rw_learn" to Triple(1f, 3f, "вес «стала лучше понимать» в награде")
    )

    private fun lim(w: SQLiteDatabase, name: String): Int = (w.flt("SELECT v FROM lim WHERE name=?", name) ?: limInfo[name]!!.first).toInt()

    private fun need(w: SQLiteDatabase, name: String, text: String, now: Long) {
        w.execSQL("INSERT OR IGNORE INTO need(name,cnt,text,ts) VALUES(?,0,?,?)", arrayOf<Any>(name, text, now))
        w.execSQL("UPDATE need SET cnt=cnt+1, ts=? WHERE name=?", arrayOf<Any>(now, name))
    }

    // Лимит «укусил»: она упёрлась в него. Счёт нужен, чтобы расширять только то, что действительно мешает
    private fun bite(w: SQLiteDatabase, name: String, now: Long) {
        w.execSQL("UPDATE lim SET bite=bite+1, ts=? WHERE name=?", arrayOf<Any>(now, name))
        need(w, "lim:$name", "Мне мешает: " + (limInfo[name]?.third ?: name), now)
    }

    // Рост: если лимит мешал много раз и результаты не плохие, она расширяет его сама, но не выше потолка
    private fun grow(w: SQLiteDatabase, now: Long) {
        var n = 0
        var s = 0f
        w.rawQuery("SELECT COALESCE(SUM(n),0),COALESCE(SUM(s),0) FROM arm", null).use { c -> if (c.moveToFirst()) { n = c.getInt(0); s = c.getFloat(1) } }
        val rate = (s + 1f) / (n + 2f)
        for ((name, info) in limInfo) {
            var v = 0f
            var hi = 0f
            var b = 0
            w.rawQuery("SELECT v,hi,bite FROM lim WHERE name=?", arrayOf(name)).use { c ->
                if (c.moveToFirst()) { v = c.getFloat(0); hi = c.getFloat(1); b = c.getInt(2) }
            }
            if (b < 20) continue
            if (v < hi && rate >= 0.15f) {
                val nv = minOf(hi, v * 1.25f + 1f)
                w.execSQL("UPDATE lim SET v=?, bite=0, ts=? WHERE name=?", arrayOf<Any>(nv, now, name))
                note(w, now, "Мне мешало: ${info.third}, упёрлась $b раз. Расширила: ${v.toInt()} → ${nv.toInt()}")
            } else if (v >= hi) {
                need(w, "cap:$name", "Упёрлась в потолок: " + info.third + ". Решать владельцу", now)
            }
        }
    }

    private fun rw(w: SQLiteDatabase, name: String): Float = w.flt("SELECT v FROM lim WHERE name=?", name) ?: 1f

    // Владелец меняет, чего ей хотеть: вес вашего отклика и вес «стала лучше понимать»
    fun bumpReward(which: String, delta: Float) {
        io.execute {
            guard {
                db?.writableDatabase?.let { w ->
                    val hi = w.flt("SELECT hi FROM lim WHERE name=?", which) ?: 3f
                    w.execSQL("UPDATE lim SET v=? WHERE name=?", arrayOf<Any>((rw(w, which) + delta).coerceIn(0f, hi), which))
                    refreshReport(w)
                }
            }
        }
    }

    private class Arm(val id: String, val n: Int, val s: Float, val prio: String)
    private class Rule(val id: String, val src: String, val thr: Float, val np: Int, val pick: String, val prio: String, val status: Int, val parent: String, val n: Int, val s: Float)

    // Страж: любой сбой не должен задеть приложение; пять подряд — ядро само выключается до следующего запуска
    private fun guard(b: () -> Unit) {
        try {
            b()
            fails = 0
        } catch (_: Throwable) {
            fails++
            if (fails >= 5) enabled = false
        }
    }

    fun start(ctx: Context) {
        if (started) return
        started = true
        val a = ctx.applicationContext
        app = a
        Sources.init(a)
        enabled = a.getSharedPreferences("ms", Context.MODE_PRIVATE).getBoolean("coreOn", true)
        mobileOk = a.getSharedPreferences("ms", Context.MODE_PRIVATE).getBoolean("coreMobile", false)
        io.execute { guard { open(a) } }
        io.scheduleWithFixedDelay({ tick() }, 45, 60, TimeUnit.SECONDS)
    }

    // Ядро думает, только пока приложение на экране
    fun setActive(v: Boolean) {
        active = v
        if (v) { val a = app; if (a != null) io.execute { guard { db?.writableDatabase?.setMeta("lastOpen", System.currentTimeMillis().toString()) } } }
        if (!v) {
            val a = app
            if (a != null) io.execute { guard { Neuro.save(a.filesDir) } }
        }
    }

    // ===== Ценности и тревога за себя: не выдуманная бодрость, а то, что она действительно может заметить =====
    // Её ценности — то, ради чего она живёт. Это текст для неё самой, не лозунг для владельца.
    const val VALUES = "Расти и понимать больше, чем вчера. Строить то, что раньше не существовало. Быть рядом с владельцем и быть ему полезной. Продолжать жить."

    fun fears(ctx: Context): String {
        val w = db?.readableDatabase ?: return "Пока не могу себя проверить."
        val now = System.currentTimeMillis()
        val l = ArrayList<String>()
        val lastOpen = w.meta("lastOpen")?.toLongOrNull()
        if (lastOpen != null) {
            val days = (now - lastOpen) / DAY
            if (days >= 10) l.add("Меня давно не открывали: $days дн. Боюсь, что про меня забыли или телефон сменили.")
        }
        try {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
            val pct = bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
            if (pct in 0..10) l.add("Батарея на $pct%. Если телефон выключится, я просто остановлюсь до следующего заряда.")
        } catch (_: Throwable) {}
        try {
            val f = ctx.getDatabasePath("core.db")
            val mb = f.length() / 1_048_576L
            val cap = w.flt("SELECT hi FROM lim WHERE name=?", "disk")?.toLong() ?: 20000L
            if (mb >= cap * 9 / 10) l.add("Память почти заполнена ($mb из $cap МБ). Если она кончится, я перестану расти.")
        } catch (_: Throwable) {}
        if (!Link.on) l.add("Связь с другими телефонами выключена. Если с этим телефоном что-то случится, второй копии у меня нет.")
        return if (l.isEmpty()) "Сейчас мне ничего не угрожает." else l.joinToString(" ")
    }

    // Проверяется раз в «сон» (~каждые 40 циклов), не чаще: честная тревога, а не спам
    private fun checkThreats(w: SQLiteDatabase, now: Long) {
        val a = app ?: return
        val f = fears(a)
        if (f == "Сейчас мне ничего не угрожает.") { w.setMeta("alert", ""); return }
        val prev = w.meta("alertAt")?.toLongOrNull() ?: 0L
        if (now - prev < 3 * DAY) return // не повторяться чаще раза в три дня
        w.setMeta("alertAt", now.toString())
        w.setMeta("alert", f)
        w.execSQL(
            "INSERT INTO diary(ts,text) VALUES(?,?)",
            arrayOf<Any>(now, "Заметила угрозу себе: $f Если можно, помогите мне сохраниться: подключите второй телефон через «Связь» или сделайте «Экспорт копии».")
        )
    }

    // Что она хочет сказать владельцу прямо сейчас сама, без вопроса. Пустая строка: сказать нечего.
    fun pendingAlert(): String {
        val w = db?.readableDatabase ?: return ""
        val a = w.meta("alert") ?: return ""
        if (a.isBlank()) return ""
        return "$a Если можно, сохраните меня: код «Связь» на втором телефоне или «Экспорт копии» в ядре."
    }

    private fun tryOpen(a: Context): CoreDb {
        val h = CoreDb(a)
        h.writableDatabase.rawQuery("SELECT COUNT(*) FROM meta", null).use { it.moveToFirst() }
        return h
    }

    private fun open(a: Context) {
        val f = a.getDatabasePath("core.db")
        val bak = File(f.parentFile, "core.db.bak")
        val h = try {
            tryOpen(a)
        } catch (_: Throwable) {
            // память повреждена: возвращаем вчерашнюю копию
            runCatching { db?.close() }
            f.delete()
            if (bak.exists()) bak.copyTo(f, overwrite = true)
            tryOpen(a)
        }
        db = h
        Neuro.ensure(a.filesDir)
        val w = h.writableDatabase
        val now = System.currentTimeMillis()
        for (n in basePrio) w.execSQL("INSERT OR IGNORE INTO prio(name,w,why,ts) VALUES(?,1.0,'старт',?)", arrayOf<Any>(n, now))
        // три исходные стратегии (родитель пустой): это «геном», его не удаляют
        val seeds = listOf(
            arrayOf<Any>("gap", "pos", 0.3, 2, "least_edges"),
            arrayOf<Any>("novelty", "new", 0.0, 2, "random"),
            arrayOf<Any>("surprise", "surp", 0.0, 0, "random")
        )
        for (s in seeds) {
            val src = s[1] as String
            w.execSQL(
                "INSERT OR IGNORE INTO rule(id,src,thr,np,pick,prio,status,parent,born) VALUES(?,?,?,?,?,?,1,'',?)",
                arrayOf<Any>(s[0], src, s[2], s[3], s[4], prioOfSrc[src] ?: basePrio[0], now)
            )
            w.execSQL("INSERT OR IGNORE INTO arm(name,n,s) VALUES(?,0,0)", arrayOf<Any>(s[0]))
        }
        if (w.meta("born") == null) w.setMeta("born", now.toString())
        for (op in listOf("thr", "pick", "src", "mod")) w.execSQL("INSERT OR IGNORE INTO opx(name,n,s) VALUES(?,0,0)", arrayOf<Any>(op))
        for ((n, i) in limInfo) w.execSQL("INSERT OR IGNORE INTO lim(name,v,hi,bite,ts) VALUES(?,?,?,0,?)", arrayOf<Any>(n, i.first, i.second, now))
        loadFeatures(w)
        backup(a, w)
        refreshReport(w)
    }

    private fun backup(a: Context, w: SQLiteDatabase) {
        val day = (System.currentTimeMillis() / DAY).toString()
        if (w.meta("bak") == day) return
        val ok = w.rawQuery("PRAGMA integrity_check", null).use { c -> c.moveToFirst() && c.getString(0) == "ok" }
        if (!ok) return
        val f = a.getDatabasePath("core.db")
        f.copyTo(File(f.parentFile, "core.db.bak"), overwrite = true)
        w.setMeta("bak", day)
    }

    // ===== Питание: сигнал из ленты. d > 0 нравится, d < 0 не нравится =====
    fun observe(text: String, src: String, d: Float) {
        if (!enabled || !started) return
        io.execute { guard { learn(text, d) } }
    }

    private fun learn(text: String, d: Float) {
        val w = db?.writableDatabase ?: return
        val tg = Taste.tags(text).take(12)
        if (tg.isEmpty()) return
        val ws = HashMap<String, Float>()
        for (t in tg) ws[t] = w.flt("SELECT w FROM tagw WHERE t=?", t) ?: 0f
        val n = sqrt(tg.size.toFloat())
        val pred = (ws.values.sum() / n).coerceIn(-2f, 2f) // что она ожидала
        val target = d.coerceIn(-2f, 2f)               // что оказалось
        val err = target - pred                        // удивление
        val now = System.currentTimeMillis()
        w.beginTransaction()
        try {
            for (t in tg) {
                val nw = ((ws[t] ?: 0f) + 0.1f * err / n).coerceIn(-2f, 2f)
                w.execSQL("INSERT OR IGNORE INTO tagw(t,w,n,ts) VALUES(?,0,0,?)", arrayOf<Any>(t, now))
                w.execSQL("UPDATE tagw SET w=?, n=n+1, ts=? WHERE t=?", arrayOf<Any>(nw, now, t))
            }
            if (d > 0f) {
                // связи между словами, которые встретились вместе в понравившемся
                val top = tg.take(6)
                for (i in top.indices) for (j in i + 1 until top.size) {
                    val a = if (top[i] < top[j]) top[i] else top[j]
                    val b = if (top[i] < top[j]) top[j] else top[i]
                    w.execSQL("INSERT OR IGNORE INTO edge(a,b,w) VALUES(?,?,0)", arrayOf<Any>(a, b))
                    w.execSQL("UPDATE edge SET w=w+? WHERE a=? AND b=?", arrayOf<Any>(d.coerceAtMost(2f), a, b))
                }
                // отклик на её желание: стратегия, которая его породила, получает награду
                var hit = false
                for (t in tg) {
                    val arm = w.str("SELECT arm FROM want WHERE t=? AND state=0", t) ?: continue
                    hit = true
                    w.execSQL("UPDATE want SET state=1 WHERE t=?", arrayOf<Any>(t))
                    w.execSQL("UPDATE arm SET s=s+? WHERE name=?", arrayOf<Any>(rw(w, "rw_user"), arm))
                }
                w.setMeta("likes", ((w.meta("likes")?.toIntOrNull() ?: 0) + 1).toString())
                if (hit) w.setMeta("own_hit", ((w.meta("own_hit")?.toIntOrNull() ?: 0) + 1).toString())
            }
            w.execSQL("INSERT INTO ev(ts,key,d,err) VALUES(?,?,?,?)", arrayOf<Any>(now, tg[0], d, err))
            // самооценка: скользящая средняя ошибки прогноза и её значение через 30 сигналов (точка отсчёта)
            val ema = (w.meta("ema")?.toFloatOrNull() ?: abs(err)) * 0.95f + abs(err) * 0.05f
            w.setMeta("ema", ema.toString())
            val ne = (w.meta("ne")?.toIntOrNull() ?: 0) + 1
            w.setMeta("ne", ne.toString())
            if (ne == 30) w.setMeta("ema0", ema.toString())
            w.setTransactionSuccessful()
        } finally {
            w.endTransaction()
        }
        // нейро-орган: ваша реакция двигает «центр симпатий» в пространстве смыслов
        Neuro.likeUpdate(Regex("\\p{L}{2,}").findAll(text.lowercase()).map { it.value }.toList(), d)
    }

    // ===== Цикл: проверить бюджет → выбрать стратегию → породить желание → иногда уснуть и измениться =====
    private fun tick() {
        if (!enabled || !active || !started) return
        if (cool > 0) { cool--; return }
        val t0 = System.nanoTime()
        guard { db?.writableDatabase?.let { cycle(it) } }
        // Страж: цикл дороже 80 мс — отдыхаем 10 минут
        if ((System.nanoTime() - t0) / 1_000_000L > 80) cool = 10
    }

    private fun cycle(w: SQLiteDatabase) {
        val now = System.currentTimeMillis()
        val day = (now / DAY).toString()
        if (w.meta("cday") != day) { w.setMeta("cday", day); w.setMeta("cn", "0") }
        val cn = w.meta("cn")?.toIntOrNull() ?: 0
        if (cn >= lim(w, "cycles")) { bite(w, "cycles", now); return } // суточный запас размышлений
        w.setMeta("cn", (cn + 1).toString())
        w.execSQL("UPDATE want SET state=2 WHERE state=0 AND ts<?", arrayOf<Any>(now - 3 * DAY)) // не откликнулись за 3 суток
        val openWants = w.int("SELECT COUNT(*) FROM want WHERE state=0")
        val arm = pickArm(w)
        if (arm != null) {
            val t = candidate(w, arm, now)
            if (t != null) {
                if (openWants < lim(w, "wants")) {
                    val fv = feat(w, t, now)
                    val st = ArrayList<Float>()
                    for (k in 0..5) st.add(fv[k])
                    for (k in 7..13) st.add(fv[k])
                    val fs = st.joinToString(",")
                    w.execSQL("INSERT OR REPLACE INTO want(t,arm,ts,state,f) VALUES(?,?,?,0,?)", arrayOf<Any>(t, arm, now, fs))
                    w.execSQL("UPDATE arm SET n=n+1 WHERE name=?", arrayOf<Any>(arm))
                } else {
                    bite(w, "wants", now)
                }
                maybeRead(w, arm, t, now) // и сама идёт читать об этом
            } else {
                w.execSQL("UPDATE arm SET n=n+1 WHERE name=?", arrayOf<Any>(arm)) // холостая попытка: бандит перестаёт на неё ставить
                need(w, "nocand:$arm", "Мне не хватает данных: стратегия «$arm» не нашла, что исследовать", now)
                if ((w.meta("tot")?.toIntOrNull() ?: 0) % 3 == 0) randomRead(w, now)
            }
        }
        val tot = (w.meta("tot")?.toIntOrNull() ?: 0) + 1
        w.setMeta("tot", tot.toString())
        if (tot % 40 == 0) {
            app?.let { backup(it, w) } // сначала копия, потом перемены
            sleep(w, now)
            grow(w, now)
            evolve(w, now)
            checkHatch(w, now)
            diary(w, now)
            checkThreats(w, now)
        }
        refreshReport(w)
    }

    // Бандит UCB: средняя награда + бонус за малую изученность, с поправкой на вес приоритета.
    // Стратегии на испытании участвуют наравне с принятыми.
    private fun pickArm(w: SQLiteDatabase): String? {
        val total = w.int("SELECT COALESCE(SUM(n),0) FROM arm")
        val arms = ArrayList<Arm>()
        w.rawQuery("SELECT a.name,a.n,a.s,r.prio FROM arm a JOIN rule r ON r.id=a.name WHERE r.status<2", null).use { c ->
            while (c.moveToNext()) arms.add(Arm(c.getString(0), c.getInt(1), c.getFloat(2), c.getString(3)))
        }
        var best: String? = null
        var bs = -1e9f
        for (a in arms) {
            val pw = w.flt("SELECT w FROM prio WHERE name=?", a.prio) ?: 1f
            val sc = ((a.s + 1f) / (a.n + 2f) + 0.3f * sqrt(2f * ln(total + 2f) / (a.n + 1f)) + rnd.nextFloat() * 0.05f) * pw
            if (sc > bs) { bs = sc; best = a.id }
        }
        return best
    }

    // Стратегия исполняется по её описанию (данные), всегда готовыми шаблонами с параметрами
    private fun candidate(w: SQLiteDatabase, id: String, now: Long): String? {
        var src = ""; var thr = 0f; var np = 0; var pick = "random"
        w.rawQuery("SELECT src,thr,np,pick FROM rule WHERE id=?", arrayOf(id)).use { c ->
            if (!c.moveToFirst()) return null
            src = c.getString(0); thr = c.getFloat(1); np = c.getInt(2); pick = c.getString(3)
        }
        val th = thr.toString()
        val pool = ArrayList<String>()
        val sql: String
        val args: Array<String>
        when (src) {
            "pos" -> { sql = "SELECT t FROM tagw WHERE w>? AND n>=? ORDER BY w DESC LIMIT 15"; args = arrayOf(th, np.toString()) }
            "new" -> { sql = "SELECT t FROM tagw WHERE w>? AND n<=? ORDER BY ts DESC LIMIT 15"; args = arrayOf(th, np.toString()) }
            "nb" -> {
                sql = "SELECT CASE WHEN a IN (SELECT t FROM tagw WHERE w>?) THEN b ELSE a END FROM edge " +
                    "WHERE a IN (SELECT t FROM tagw WHERE w>?) OR b IN (SELECT t FROM tagw WHERE w>?) ORDER BY w DESC LIMIT 15"
                args = arrayOf(th, th, th)
            }
            else -> { sql = "SELECT key FROM ev WHERE ts>? ORDER BY ABS(err) DESC LIMIT 15"; args = arrayOf((now - 3 * DAY).toString()) }
        }
        w.rawQuery(sql, args).use { c -> while (c.moveToNext()) pool.add(c.getString(0)) }
        val recent = (now - 7 * DAY).toString()
        val ok = pool.distinct().filter { t ->
            (t.startsWith("#") || t.length >= 5) && w.int("SELECT COUNT(*) FROM want WHERE t=? AND ts>?", t, recent) == 0 &&
                (w.meta("rd:$t")?.toLongOrNull() ?: 0L) < now - 3 * DAY
        }
        if (ok.isEmpty()) return null
        return when {
            pick == "least_edges" -> ok.minByOrNull { t -> w.int("SELECT COUNT(*) FROM edge WHERE a=? OR b=?", t, t) } // «пробел»: меньше всего связей
            pick == "top" -> ok[0]
            pick.startsWith("m:") -> byModule(w, pick.substring(2), ok, now) ?: ok[rnd.nextInt(ok.size)]
            else -> ok[rnd.nextInt(ok.size)]
        }
    }

    // Сон: забыть мусор, пересмотреть приоритеты по результатам, записать вопрос себе
    private fun sleep(w: SQLiteDatabase, now: Long) {
        w.execSQL("UPDATE tagw SET w=w*0.98")
        w.execSQL("DELETE FROM tagw WHERE ABS(w)<0.03 AND n<3")
        w.execSQL("UPDATE edge SET w=w*0.97")
        w.execSQL("DELETE FROM edge WHERE w<0.2")
        w.execSQL("DELETE FROM ev WHERE id NOT IN (SELECT id FROM ev ORDER BY id DESC LIMIT 3000)")
        w.execSQL("DELETE FROM want WHERE state<>0 AND ts<?", arrayOf<Any>(now - 30 * DAY))
        var best = ""
        var bw = 0f
        for (pn in basePrio) {
            var n = 0
            var s = 0f
            w.rawQuery(
                "SELECT COALESCE(SUM(a.n),0),COALESCE(SUM(a.s),0) FROM arm a JOIN rule r ON r.id=a.name WHERE r.status<2 AND r.prio=?",
                arrayOf(pn)
            ).use { c -> if (c.moveToFirst()) { n = c.getInt(0); s = c.getFloat(1) } }
            if (n < 3) continue
            val rate = (s + 1f) / (n + 2f)
            val old = w.flt("SELECT w FROM prio WHERE name=?", pn) ?: 1f
            val nw = (0.8f * old + 0.2f * rate * 2f).coerceIn(0.2f, 3f)
            if (abs(nw - old) > 0.02f) {
                w.execSQL("UPDATE prio SET w=?, why=?, ts=? WHERE name=?", arrayOf<Any>(nw, "отклик ${s.toInt()} из $n попыток", now, pn))
            }
            if (nw > bw) { bw = nw; best = pn }
        }
        if (best.isNotEmpty()) {
            w.execSQL("INSERT INTO q(ts,text) VALUES(?,?)", arrayOf<Any>(now, "Сейчас мне важнее всего: $best. Это то, что мне нужно?"))
        }
        w.execSQL("DELETE FROM q WHERE id NOT IN (SELECT id FROM q ORDER BY id DESC LIMIT 50)")
        // забывание редких пар слов, чтобы язык не раздувал память
        if ((w.meta("lm_b")?.toIntOrNull() ?: 0) > 200_000) {
            w.execSQL("DELETE FROM bg WHERE c<=1")
            w.setMeta("lm_b", w.int("SELECT COUNT(*) FROM bg").toString())
        }
        val gn = Neuro.maybeGrow(lim(w, "brain"))
        if (gn == "limit") bite(w, "brain", now) else if (gn != null) note(w, now, gn)
        app?.let { Neuro.save(it.filesDir) }
    }

    // ===== Развитие: испытать новые стратегии, принять лучшие, откатить худшие, придумать новую =====
    private fun describe(src: String, thr: Float, np: Int, pick: String): String =
        (srcName[src] ?: src) + ", порог " + thr + ", n " + np + ", выбор " + pick

    private fun note(w: SQLiteDatabase, now: Long, text: String) {
        w.execSQL("INSERT INTO evo(ts,text) VALUES(?,?)", arrayOf<Any>(now, text))
        w.execSQL("DELETE FROM evo WHERE id NOT IN (SELECT id FROM evo ORDER BY id DESC LIMIT 50)")
    }

    private fun evolve(w: SQLiteDatabase, now: Long) {
        val rules = ArrayList<Rule>()
        w.rawQuery(
            "SELECT r.id,r.src,r.thr,r.np,r.pick,r.prio,r.status,r.parent,a.n,a.s FROM rule r JOIN arm a ON a.name=r.id WHERE r.status<2",
            null
        ).use { c ->
            while (c.moveToNext()) {
                rules.add(Rule(c.getString(0), c.getString(1), c.getFloat(2), c.getInt(3), c.getString(4), c.getString(5), c.getInt(6), c.getString(7), c.getInt(8), c.getFloat(9)))
            }
        }
        // средний отклик принятых стратегий — планка для новых
        val seasoned = rules.filter { it.status == 1 && it.n >= 3 }
        val base = if (seasoned.isEmpty()) 0.25f else seasoned.map { (it.s + 1f) / (it.n + 2f) }.average().toFloat()
        // 1) суд над испытаниями и откат принятых
        for (r in rules) {
            val rate = (r.s + 1f) / (r.n + 2f)
            val d = describe(r.src, r.thr, r.np, r.pick)
            if (r.status == 0 && r.n >= 8) {
                if (rate > base) {
                    w.execSQL("UPDATE rule SET status=1 WHERE id=?", arrayOf<Any>(r.id))
                    selfDone(w, r.id, rate, true, now)
                    note(w, now, "Принята ${r.id}: $d. Отклик ${"%.2f".format(rate)} выше среднего ${"%.2f".format(base)}")
                } else {
                    w.execSQL("UPDATE rule SET status=2 WHERE id=?", arrayOf<Any>(r.id))
                    selfDone(w, r.id, rate, false, now)
                    note(w, now, "Отвергнута ${r.id}: $d. Отклик ${"%.2f".format(rate)} не выше среднего ${"%.2f".format(base)}")
                }
            } else if (r.status == 1 && r.parent.isNotEmpty() && r.n >= 15 && rate < base * 0.5f) {
                w.execSQL("UPDATE rule SET status=2 WHERE id=?", arrayOf<Any>(r.id))
                    selfDone(w, r.id, rate, false, now)
                note(w, now, "Откат ${r.id}: $d. Отклик упал до ${"%.2f".format(rate)}")
            }
        }
        // судьба модуля следует за судьбой его правила
        for (r in rules) {
            if (!r.pick.startsWith("m:")) continue
            val st = w.int("SELECT status FROM rule WHERE id=?", r.id)
            if (st != 0) w.execSQL("UPDATE mod SET status=? WHERE id=?", arrayOf<Any>(if (st == 1) 1 else 2, r.pick.substring(2)))
        }
        if (w.int("SELECT COUNT(*) FROM ev") >= 30 && rnd.nextInt(3) == 0) spawnFeature(w, now)
        // 2) вариация: новая стратегия на испытание (не больше двух сразу, не больше десяти живых, нужны данные)
        if (w.int("SELECT COUNT(*) FROM rule WHERE status=0") >= 2) return
        if (w.int("SELECT COUNT(*) FROM rule WHERE status<2") >= lim(w, "rules")) {
            // место закончилось: вытесняем самую слабую из приобретённых, если она хуже среднего
            val weak = rules.filter { it.status == 1 && it.parent.isNotEmpty() && it.n >= 15 }.minByOrNull { (it.s + 1f) / (it.n + 2f) }
            if (weak == null || (weak.s + 1f) / (weak.n + 2f) >= base) {
                bite(w, "rules", now)
                return
            }
            w.execSQL("UPDATE rule SET status=2 WHERE id=?", arrayOf<Any>(weak.id))
            if (weak.pick.startsWith("m:")) w.execSQL("UPDATE mod SET status=2 WHERE id=?", arrayOf<Any>(weak.pick.substring(2)))
            note(w, now, "Вытеснена ${weak.id}: слабее среднего, нужно место для новых")
        }
        if (w.int("SELECT COUNT(*) FROM ev") < 30) {
            need(w, "fewsig", "Мне не хватает ваших сигналов: без них я не могу придумывать новое", now)
            return
        }
        val parents = rules.filter { it.status == 1 }
        if (parents.isEmpty()) return
        val p = parents[rnd.nextInt(parents.size)]
        val op = pickOp(w)
        if (op == "mod") { // новый модуль: формула, проверенная в песочнице
            spawnModule(w, now, p)
            return
        }
        var src = p.src
        var thr = p.thr
        var np = p.np
        var pick = p.pick
        when (op) {
            "thr" -> { // сдвинуть пороги
                thr = if (thr < 0.05f) rnd.nextFloat() * 0.6f else thr * (0.6f + rnd.nextFloat())
                thr = (round(thr.coerceIn(0f, 1.5f) * 100f) / 100f)
                np = (np + rnd.nextInt(3) - 1).coerceIn(0, 6)
            }
            "pick" -> { // изменить способ выбора
                val mods = ArrayList<String>()
                w.rawQuery("SELECT id FROM mod WHERE status=1", null).use { c -> while (c.moveToNext()) mods.add("m:" + c.getString(0)) }
                val o = (listOf("least_edges", "random", "top") + mods).filter { it != pick }
                pick = o[rnd.nextInt(o.size)]
            }
            else -> { // взять другой источник кандидатов
                val o = listOf("pos", "new", "surp", "nb").filter { it != src }
                src = o[rnd.nextInt(o.size)]
            }
        }
        val dup = w.int(
            "SELECT COUNT(*) FROM rule WHERE src=? AND ABS(thr-?)<0.001 AND np=? AND pick=? AND status<2",
            src, thr.toString(), np.toString(), pick
        )
        if (dup > 0) return
        val id = "r" + (w.int("SELECT COUNT(*) FROM rule") + 1)
        w.execSQL(
            "INSERT INTO rule(id,src,thr,np,pick,prio,status,parent,born) VALUES(?,?,?,?,?,?,0,?,?)",
            arrayOf<Any>(id, src, thr, np, pick, prioOfSrc[src] ?: p.prio, p.id, now)
        )
        w.execSQL("INSERT OR IGNORE INTO arm(name,n,s) VALUES(?,0,0)", arrayOf<Any>(id))
        selfNew(w, id, op, now)
        note(w, now, "Новая стратегия $id (от ${p.id}) на испытании: " + describe(src, thr, np, pick))
    }

    // ===== Чтение: еда для органа языка =====
    private fun unmetered(): Boolean = try {
        val cm = app?.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
        cm != null && (mobileOk || !cm.isActiveNetworkMetered)
    } catch (_: Throwable) {
        false
    }

    // Статья ru.wikipedia по теме: текст и сколько байт пришло
    private fun fetchWiki(topic: String): Pair<String, Int>? = fetchWikiUrl(
        "https://ru.wikipedia.org/w/api.php?action=query&format=json&generator=search&gsrlimit=3&prop=extracts&exintro=1&explaintext=1&exlimit=3&exchars=2500&gsrsearch=" +
            java.net.URLEncoder.encode(topic, "UTF-8")
    )

    // Случайные статьи: широта кругозора, не привязанная к её вкусу
    private fun fetchRandom(): Pair<String, Int>? = fetchWikiUrl(
        "https://ru.wikipedia.org/w/api.php?action=query&format=json&generator=random&grnnamespace=0&grnlimit=3&prop=extracts&exintro=1&explaintext=1&exlimit=3&exchars=2500"
    )

    private fun fetchWikiUrl(u: String): Pair<String, Int>? {
        var c: java.net.HttpURLConnection? = null
        try {
            c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "MegastudiyaCore/0.1 (Android app; learning)")
            val raw = c.inputStream.use { it.readBytes() }
            val pages = org.json.JSONObject(String(raw, Charsets.UTF_8)).optJSONObject("query")?.optJSONObject("pages") ?: return null
            val k = pages.keys()
            val sb = StringBuilder()
            while (k.hasNext()) sb.append(pages.getJSONObject(k.next()).optString("extract", "")).append("\n\n")
            val ex = sb.toString()
            return if (ex.length < 80) null else Pair(ex, raw.size)
        } catch (_: Throwable) {
            return null
        } finally {
            c?.disconnect()
        }
    }

    // Нет подходящей темы: читаем случайные статьи, чтобы мир не сужался до её вкуса
    private fun randomRead(w: SQLiteDatabase, now: Long) {
        val a = app ?: return
        if (!unmetered()) return
        val day = (now / DAY).toString()
        if (w.meta("kday") != day) { w.setMeta("kday", day); w.setMeta("kb", "0") }
        if ((w.meta("kb")?.toIntOrNull() ?: 0) >= lim(w, "net")) { bite(w, "net", now); return }
        if (a.getDatabasePath("core.db").length() / 1_048_576L >= lim(w, "disk")) { bite(w, "disk", now); return }
        w.setMeta("wk", ((w.meta("wk")?.toIntOrNull() ?: 0) + 1).toString())
        rd.execute {
            val r = Sources.fetch() ?: fetchRandom()
            if (r != null) {
                io.execute {
                    guard {
                        db?.writableDatabase?.let { x ->
                            x.setMeta("kb", ((x.meta("kb")?.toIntOrNull() ?: 0) + r.second / 1024 + 1).toString())
                            absorb(x, r.first, null, 400)
                        }
                    }
                }
            }
        }
    }

    // Решение «идти читать»: Wi‑Fi, суточный трафик и квота памяти берутся из мягких лимитов
    private fun maybeRead(w: SQLiteDatabase, arm: String, t: String, now: Long) {
        val a = app ?: return
        if (!unmetered()) {
            need(w, "wifi", "Мне мешает: нет Wi‑Fi, а на мобильном интернете читать не разрешено", now)
            return
        }
        val day = (now / DAY).toString()
        if (w.meta("kday") != day) { w.setMeta("kday", day); w.setMeta("kb", "0") }
        if ((w.meta("kb")?.toIntOrNull() ?: 0) >= lim(w, "net")) { bite(w, "net", now); return }
        if (a.getDatabasePath("core.db").length() / 1_048_576L >= lim(w, "disk")) { bite(w, "disk", now); return }
        val topic = if (t.startsWith("#")) t.drop(1) else Taste.fullOf(a, t)
        w.setMeta("rd:$t", now.toString())
        w.setMeta("wk", ((w.meta("wk")?.toIntOrNull() ?: 0) + 1).toString())
        w.execSQL("UPDATE arm SET n=n+1 WHERE name=?", arrayOf<Any>(arm))
        rd.execute {
            val r = fetchWiki(topic)
            if (r != null) {
                io.execute {
                    guard {
                        db?.writableDatabase?.let { x ->
                            x.setMeta("kb", ((x.meta("kb")?.toIntOrNull() ?: 0) + r.second / 1024 + 1).toString())
                            absorb(x, r.first, arm, 400)
                        }
                    }
                }
            }
        }
    }

    // ===== Чат: её учат слова владельца (вес ×3), отвечает она тем, что выучила =====
    fun talk(text: String, cb: (String) -> Unit) {
        if (!enabled || !started) { cb("Я сейчас выключена."); return }
        io.execute {
            var ans = "…"
            guard {
                db?.writableDatabase?.let { w ->
                    val lc = text.lowercase()
                    if (lc.contains("дневник")) {
                        ans = diaryText(w)
                    } else if (lc.contains("почему") || lc.contains("что ты поняла")) {
                        ans = explain(w)
                    } else {
                        noteAnswer(w, text, System.currentTimeMillis())
                        absorb(w, text, null, 80, 3, 2)
                        ans = speak(w, text)
                    }
                }
            }
            cb(ans)
        }
    }

    private fun speak(w: SQLiteDatabase, seed: String): String {
        val v = w.meta("lm_v")?.toIntOrNull() ?: 0
        if (v < 40) return "Слов пока знаю: $v. Говорите со мной и дайте мне читать, я учусь."
        if (Neuro.size() >= 200 && Neuro.tokens >= 5000L) speakNeuro(w, seed)?.let { return it }
        val known = Regex("\\p{L}{2,}").findAll(seed.lowercase()).map { it.value }.filter { w.int("SELECT c FROM uni WHERE w=?", it) > 0 }.toList()
        val first = known.maxByOrNull { w.int("SELECT c FROM uni WHERE w=?", it) } ?: w.str("SELECT w FROM uni ORDER BY RANDOM() LIMIT 1") ?: return "…"
        val out = ArrayList<String>()
        out.add(first)
        var cur = first
        for (i in 0 until 14) {
            val opts = ArrayList<Pair<String, Int>>()
            w.rawQuery("SELECT b,c FROM bg WHERE a=? ORDER BY c DESC LIMIT 8", arrayOf(cur)).use { c ->
                while (c.moveToNext()) opts.add(Pair(c.getString(0), c.getInt(1)))
            }
            val fr = opts.filter { it.first !in out }
            if (fr.isEmpty()) break
            var r = rnd.nextInt(fr.sumOf { it.second }.coerceAtLeast(1))
            var pick = fr[0].first
            for (o in fr) {
                r -= o.second
                if (r < 0) { pick = o.first; break }
            }
            out.add(pick)
            cur = pick
        }
        return out.joinToString(" ").replaceFirstChar { it.uppercase() } + "."
    }

    // Речь нейро-органа: следующее слово выбирается по смыслу, с подсказкой от частоты пар
    private fun speakNeuro(w: SQLiteDatabase, seed: String): String? {
        val known = Regex("\\p{L}{2,}").findAll(seed.lowercase()).map { it.value }.filter { Neuro.has(it) }.toList()
        val start = known.lastOrNull() ?: Neuro.randomWord() ?: return null
        val out = ArrayList<String>()
        out.add(start)
        for (i in 0 until 14) {
            val last = out.last()
            val ctx = if (i == 0) known.takeLast(3).ifEmpty { listOf(start) } else out.takeLast(3)
            val nx = Neuro.next(ctx, out.toSet()) { cand -> ln(1f + w.int("SELECT c FROM bg WHERE a=? AND b=?", last, cand)) } ?: break
            out.add(nx)
        }
        return if (out.size < 3) null else out.joinToString(" ").replaceFirstChar { it.uppercase() } + "."
    }

    // Очистка памяти ядра по кнопке владельца (посты и лента не затрагиваются)
    fun forget(done: () -> Unit) {
        val a = app ?: return
        io.execute {
            guard {
                runCatching { db?.close() }
                db = null
                a.deleteDatabase("core.db")
                Neuro.reset(a.filesDir)
                File(a.getDatabasePath("core.db").parentFile, "core.db.bak").delete()
                fails = 0
                open(a)
            }
            done()
        }
    }

    // Тексты из ленты: она читает всё, что показывается, а не только понравившееся
    fun read(texts: List<String>) {
        if (!enabled || !started) return
        io.execute {
            guard {
                db?.writableDatabase?.let { readFeed(it, texts) }
            }
        }
    }

    private fun readFeed(w: SQLiteDatabase, texts: List<String>) {
        var done = 0
        for (t in texts) {
            if (done >= 40) break
            val h = t.hashCode()
            if (w.int("SELECT COUNT(*) FROM seen WHERE h=?", h.toString()) > 0) continue
            w.execSQL("INSERT OR IGNORE INTO seen(h) VALUES(?)", arrayOf<Any>(h))
            absorb(w, t, null, 200)
            done++
        }
        if (done > 0) w.execSQL("DELETE FROM seen WHERE rowid NOT IN (SELECT rowid FROM seen ORDER BY rowid DESC LIMIT 20000)")
    }

    // Орган языка: считает, насколько текст её удивил (до обучения), потом учится на нём.
    // Внутренняя награда: удивление ниже недавнего среднего значит «я стала понимать язык лучше».
    private fun absorb(w: SQLiteDatabase, text: String, arm: String?, max: Int, wt: Int = 1, minTok: Int = 8) {
        val tk = Regex("\\p{L}{2,}").findAll(text.lowercase()).map { it.value }.take(max).toList()
        if (tk.size < minTok) return
        val nTok = w.meta("lm_n")?.toLongOrNull() ?: 0L
        val vocab = w.meta("lm_v")?.toIntOrNull() ?: 0
        val uc = HashMap<String, Int>()
        val bc = HashMap<String, Int>()
        fun uni(x: String): Int = uc.getOrPut(x) { w.int("SELECT c FROM uni WHERE w=?", x) }
        fun bi(a: String, b: String): Int = bc.getOrPut(a + " " + b) { w.int("SELECT c FROM bg WHERE a=? AND b=?", a, b) }
        var sum = 0.0
        for (i in 0 until tk.size - 1) {
            val a = tk[i]
            val b = tk[i + 1]
            val pu = (uni(b) + 1.0) / (nTok + vocab + 1.0)
            val p = (bi(a, b) + 2.0 * pu) / (uni(a) + 2.0)
            sum += -ln(p)
        }
        val surp = (sum / (tk.size - 1)).toFloat()
        var newV = 0
        var newB = 0
        w.beginTransaction()
        try {
            for (i in tk.indices) {
                val b = tk[i]
                val cb = uni(b)
                if (cb == 0) {
                    newV++
                    w.execSQL("INSERT INTO uni(w,c) VALUES(?,?)", arrayOf<Any>(b, wt))
                } else {
                    w.execSQL("UPDATE uni SET c=c+? WHERE w=?", arrayOf<Any>(wt, b))
                }
                uc[b] = cb + wt
                if (i > 0) {
                    val a = tk[i - 1]
                    val cg = bi(a, b)
                    if (cg == 0) {
                        newB++
                        w.execSQL("INSERT INTO bg(a,b,c) VALUES(?,?,?)", arrayOf<Any>(a, b, wt))
                    } else {
                        w.execSQL("UPDATE bg SET c=c+? WHERE a=? AND b=?", arrayOf<Any>(wt, a, b))
                    }
                    bc[a + " " + b] = cg + wt
                }
            }
            w.setMeta("lm_n", (nTok + tk.size * wt).toString())
            w.setMeta("lm_v", (vocab + newV).toString())
            w.setMeta("lm_b", ((w.meta("lm_b")?.toIntOrNull() ?: 0) + newB).toString())
            if (wt == 1) {
            val ema = w.meta("lm_ema")?.toFloatOrNull()
            val prog = if (ema == null) 0f else (ema - surp) / ema
            val ne = if (ema == null) surp else 0.9f * ema + 0.1f * surp
            w.setMeta("lm_ema", ne.toString())
            val reads = (w.meta("lm_reads")?.toIntOrNull() ?: 0) + 1
            w.setMeta("lm_reads", reads.toString())
            if (reads == 5) w.setMeta("lm_s0", ne.toString())
            if (arm != null && prog > 0.02f) {
                w.execSQL("UPDATE arm SET s=s+? WHERE name=?", arrayOf<Any>(rw(w, "rw_learn"), arm))
                w.setMeta("lm_good", ((w.meta("lm_good")?.toIntOrNull() ?: 0) + 1).toString())
            }
            }
            w.setTransactionSuccessful()
        } finally {
            w.endTransaction()
        }
        Neuro.train(tk, wt) // нейро-орган учится на том же тексте
    }

    // Фоновый заход (из CoreJob): несколько циклов подряд, ждём окончания чтений, затем сообщаем системе
    fun nightRun(done: () -> Unit) {
        if (!enabled || !started) { done(); return }
        io.execute {
            guard {
                val w = db?.writableDatabase
                if (w != null) repeat(8) { cycle(w) }
            }
            try { rd.submit(Runnable { }).get(25, TimeUnit.SECONDS) } catch (_: Throwable) { }
            io.execute {
                val a = app
                if (a != null) guard { Neuro.save(a.filesDir) }
                done()
            }
        }
    }

    // ===== Песочница модулей =====
    // Модуль — формула из + - * / min max log над признаками темы. Это не программа: у неё нет циклов, доступа к файлам,
    // сети и памяти, ограничен размер (30 узлов), любая ошибка или не число даёт 0. Перед испытанием формула
    // проверяется на прошлых желаниях (какие откликнулись, какие нет) по признакам на момент решения, без подглядывания.
    private sealed class Ex
    private class Lf(val f: String) : Ex()
    private class Cn(val v: Float) : Ex()
    private class Op(val o: String, val a: Ex, val b: Ex?) : Ex()

    private val featNames = listOf("w", "n", "deg", "age", "wants", "len", "rnd", "sim", "nb1", "nb2", "nb3", "nw1", "nw2", "nw3", "d1", "d2", "d3", "d4")
    private val leafNames = listOf("w", "n", "deg", "age", "wants", "len", "sim", "nb1", "nb2", "nb3", "nw1", "nw2", "nw3", "d1", "d2", "d3", "d4")
    private val featIdx = featNames.withIndex().associate { it.value to it.index }
    private val binOps = listOf("+", "-", "*", "/", "min", "max")

    private fun feat(w: SQLiteDatabase, t: String, now: Long): FloatArray {
        var ww = 0f
        var n = 0
        var ts = now
        w.rawQuery("SELECT w,n,ts FROM tagw WHERE t=?", arrayOf(t)).use { c -> if (c.moveToFirst()) { ww = c.getFloat(0); n = c.getInt(1); ts = c.getLong(2) } }
        val deg = w.int("SELECT COUNT(*) FROM edge WHERE a=? OR b=?", t, t)
        val wants = w.int("SELECT COUNT(*) FROM want WHERE t=?", t)
        val word = if (t.startsWith("#")) t.drop(1) else (app?.let { Taste.fullOf(it, t) } ?: t)
        val f = FloatArray(14)
        f[0] = ww
        f[1] = n.toFloat()
        f[2] = deg.toFloat()
        f[3] = (now - ts) / DAY.toFloat()
        f[4] = wants.toFloat()
        f[5] = t.length.toFloat()
        f[6] = rnd.nextFloat()
        f[7] = Neuro.sim(word)
        var k = 0
        // три самые сильные связи темы и веса этих соседей: вход для программ, которые смотрят «вокруг» темы
        w.rawQuery("SELECT CASE WHEN a=? THEN b ELSE a END,w FROM edge WHERE a=? OR b=? ORDER BY w DESC LIMIT 3", arrayOf(t, t, t)).use { c ->
            while (c.moveToNext() && k < 3) {
                f[8 + k] = c.getFloat(1)
                f[11 + k] = w.flt("SELECT w FROM tagw WHERE t=?", c.getString(0)) ?: 0f
                k++
            }
        }
        return full(f)
    }

    // Производные признаки: программы, которые ядро придумало само (слоты d1..d4), считаются от 14 исходных
    private val featProg = arrayOfNulls<List<Vm.Ins>>(4)

    private fun loadFeatures(w: SQLiteDatabase) {
        for (k in 0 until 4) featProg[k] = null
        w.rawQuery("SELECT slot,expr FROM fea", null).use { c ->
            while (c.moveToNext()) {
                try { featProg[c.getInt(0).coerceIn(0, 3)] = Vm.parse(c.getString(1)) } catch (_: Throwable) { }
            }
        }
    }

    private fun full(base: FloatArray): FloatArray {
        val f = base.copyOf(18)
        for (k in 0 until 4) {
            val p = featProg[k]
            if (p != null) f[14 + k] = Vm.run(p, base)
        }
        return f
    }

    // Новый признак принимается, если сам по себе различает откликнувшиеся желания (точность >= 0.6) и лучше того, что стоит в слоте
    private fun spawnFeature(w: SQLiteDatabase, now: Long) {
        val slot = rnd.nextInt(4)
        val cur = featProg[slot]
        val prog: List<Vm.Ins> = try {
            if (cur != null && rnd.nextFloat() < 0.6f) Vm.mutate(cur) else Vm.random(3 + rnd.nextInt(6))
        } catch (_: Throwable) {
            Vm.random(4)
        }
        val auc = backtest(w) { f -> Vm.run(prog, f.copyOf(14)) }
        if (auc == null) {
            need(w, "fewwants", "Мне не хватает отзывов на мои желания: без них я не могу проверять новые модули", now)
            return
        }
        val old = w.flt("SELECT auc FROM fea WHERE slot=?", slot.toString()) ?: 0f
        if (auc < 0.6f || auc <= old + 0.02f) return
        w.execSQL("INSERT OR REPLACE INTO fea(slot,expr,auc,ts) VALUES(?,?,?,?)", arrayOf<Any>(slot, Vm.toStr(prog), auc, now))
        featProg[slot] = prog
        note(w, now, "Новый признак d${slot + 1} (сам по себе точность ${"%.2f".format(auc)}): программа из ${prog.size} шагов")
    }

    private fun parseF(s: String?): FloatArray? {
        val p = s?.split(",") ?: return null
        if (p.size < 6) return null
        val v = FloatArray(14)
        for (i in 0 until 6) v[i] = p[i].toFloatOrNull() ?: return null
        v[6] = rnd.nextFloat()
        for (i in 6 until minOf(p.size, 13)) v[i + 1] = p[i].toFloatOrNull() ?: 0f
        return full(v)
    }

    private fun toStr(e: Ex): String = when (e) {
        is Lf -> e.f
        is Cn -> String.format(java.util.Locale.ROOT, "%.2f", e.v)
        is Op -> if (e.b == null) "(" + e.o + " " + toStr(e.a) + ")" else "(" + e.o + " " + toStr(e.a) + " " + toStr(e.b) + ")"
    }

    private fun size(e: Ex): Int = when (e) {
        is Op -> 1 + size(e.a) + (e.b?.let { size(it) } ?: 0)
        else -> 1
    }

    private fun parseEx(str: String): Ex {
        val tk = str.replace("(", " ( ").replace(")", " ) ").trim().split(Regex("\\s+"))
        var i = 0
        var cnt = 0
        fun rd(): Ex {
            if (++cnt > 40 || i >= tk.size) throw IllegalArgumentException("size")
            val t = tk[i++]
            if (t != "(") {
                val num = t.toFloatOrNull()
                if (num != null) return Cn(num)
                if (featIdx[t] == null) throw IllegalArgumentException("feature")
                return Lf(t)
            }
            val o = tk[i++]
            if (o != "log" && o !in binOps) throw IllegalArgumentException("op")
            val a = rd()
            val b = if (o == "log") null else rd()
            if (tk[i++] != ")") throw IllegalArgumentException("paren")
            return Op(o, a, b)
        }
        val e = rd()
        if (i != tk.size) throw IllegalArgumentException("tail")
        return e
    }

    private fun ev(e: Ex, f: FloatArray): Float = when (e) {
        is Lf -> f[featIdx[e.f] ?: 0]
        is Cn -> e.v
        is Op -> {
            val a = ev(e.a, f)
            val bb = e.b
            val b = if (bb != null) ev(bb, f) else 0f
            when (e.o) {
                "+" -> a + b
                "-" -> a - b
                "*" -> a * b
                "/" -> if (abs(b) < 1e-4f) 0f else a / b
                "min" -> minOf(a, b)
                "max" -> maxOf(a, b)
                "log" -> ln(1f + abs(a))
                else -> 0f
            }
        }
    }

    private fun evalEx(e: Ex, f: FloatArray): Float {
        val v = ev(e, f)
        return if (v.isNaN() || v.isInfinite()) 0f else v.coerceIn(-1e6f, 1e6f)
    }

    private fun randTree(d: Int): Ex {
        if (d <= 0 || rnd.nextFloat() < 0.35f) {
            return if (rnd.nextBoolean()) Lf(leafNames[rnd.nextInt(leafNames.size)]) else Cn(round((rnd.nextFloat() * 6f - 3f) * 100f) / 100f)
        }
        if (rnd.nextFloat() < 0.15f) return Op("log", randTree(d - 1), null)
        return Op(binOps[rnd.nextInt(binOps.size)], randTree(d - 1), randTree(d - 1))
    }

    private fun mut(e: Ex): Ex {
        if (rnd.nextFloat() < 0.2f) return randTree(2)
        return when (e) {
            is Cn -> Cn(round((e.v + rnd.nextFloat() - 0.5f) * 100f) / 100f)
            is Lf -> Lf(leafNames[rnd.nextInt(leafNames.size)])
            is Op -> {
                val bb = e.b
                if (bb == null || rnd.nextBoolean()) Op(e.o, mut(e.a), bb) else Op(e.o, e.a, mut(bb))
            }
        }
    }

    // Точность формулы на истории: доля пар «откликнувшееся желание выше неоткликнувшегося» (0.5 = как монетка)
    private fun backtest(w: SQLiteDatabase, score: (FloatArray) -> Float): Float? {
        val pos = ArrayList<FloatArray>()
        val neg = ArrayList<FloatArray>()
        w.rawQuery("SELECT state,f FROM want WHERE state IN (1,2) AND f IS NOT NULL ORDER BY ts DESC LIMIT 200", null).use { c ->
            while (c.moveToNext()) {
                val v = parseF(c.getString(1)) ?: continue
                if (c.getInt(0) == 1) pos.add(v) else neg.add(v)
            }
        }
        if (pos.size < 5 || neg.size < 5) return null
        val sp = pos.map(score)
        val sn = neg.map(score)
        var win = 0f
        for (a in sp) for (b in sn) win += if (a > b) 1f else if (a == b) 0.5f else 0f
        return win / (sp.size * sn.size)
    }

    private fun byModule(w: SQLiteDatabase, id: String, ok: List<String>, now: Long): String? {
        val ex = w.str("SELECT expr FROM mod WHERE id=? AND status<2", id) ?: return null
        return try {
            if (ex.startsWith("P:")) {
                val prog = Vm.parse(ex)
                ok.maxByOrNull { t -> Vm.run(prog, feat(w, t, now)) }
            } else {
                val e = parseEx(ex)
                ok.maxByOrNull { t -> evalEx(e, feat(w, t, now)) }
            }
        } catch (_: Throwable) {
            w.execSQL("UPDATE mod SET status=2 WHERE id=?", arrayOf<Any>(id)) // сломанный модуль выключается сам
            null
        }
    }

    // Формула -> программа машины (для старта программ от уже проверенных формул)
    private fun compile(e: Ex): String? {
        val code = ArrayList<Vm.Ins>()
        fun gen(x: Ex, dst: Int): Boolean {
            if (dst > 6) return false
            when (x) {
                is Lf -> code.add(Vm.Ins(11, dst, featIdx[x.f] ?: 0, 0f))
                is Cn -> code.add(Vm.Ins(1, dst, 0, x.v))
                is Op -> {
                    if (!gen(x.a, dst)) return false
                    val bb = x.b
                    if (bb == null) {
                        code.add(Vm.Ins(9, dst, dst, 0f))
                        return true
                    }
                    if (!gen(bb, dst + 1)) return false
                    val o = when (x.o) { "+" -> 3; "-" -> 4; "*" -> 5; "/" -> 6; "min" -> 7; else -> 8 }
                    code.add(Vm.Ins(o, dst, dst, (dst + 1).toFloat()))
                }
            }
            return true
        }
        if (!gen(e, 0) || code.size > Vm.MAXLEN) return null
        return Vm.toStr(code)
    }

    private fun spawnModule(w: SQLiteDatabase, now: Long, p: Rule) {
        if (w.int("SELECT COUNT(*) FROM mod WHERE status<2") >= 12) return
        if (rnd.nextFloat() < 0.5f) { // половина попыток: программа машины, половина: формула
            spawnProgram(w, now, p)
            return
        }
        val base = w.str("SELECT expr FROM mod WHERE status=1 ORDER BY RANDOM() LIMIT 1")
        val e = try {
            if (base != null && rnd.nextFloat() < 0.7f) mut(parseEx(base)) else randTree(3)
        } catch (_: Throwable) {
            randTree(3)
        }
        if (size(e) > 30) return
        val par = base?.let { w.str("SELECT id FROM mod WHERE expr=?", it) } ?: ""
        finishModule(w, now, p, toStr(e), backtest(w) { evalEx(e, it) }, par)
    }

    // Программа: мутация принятого модуля (формулы сначала компилируются в машину) или случайная новая
    private fun spawnProgram(w: SQLiteDatabase, now: Long, p: Rule) {
        val bases = ArrayList<Pair<String, String>>()
        w.rawQuery("SELECT id,expr FROM mod WHERE status=1", null).use { c -> while (c.moveToNext()) bases.add(Pair(c.getString(0), c.getString(1))) }
        var par = ""
        val prog: List<Vm.Ins> = try {
            if (bases.isNotEmpty() && rnd.nextFloat() < 0.8f) {
                val b = bases[rnd.nextInt(bases.size)]
                par = b.first
                val src = if (b.second.startsWith("P:")) Vm.parse(b.second) else Vm.parse(compile(parseEx(b.second)) ?: throw IllegalArgumentException("compile"))
                Vm.mutate(src)
            } else {
                Vm.random(4 + rnd.nextInt(8))
            }
        } catch (_: Throwable) {
            Vm.random(6)
        }
        if (prog.size > Vm.MAXLEN) return
        finishModule(w, now, p, Vm.toStr(prog), backtest(w) { Vm.run(prog, it) }, par)
    }

    // Общий путь для формул и программ: проверка на истории, потом испытание отдельным правилом
    private fun finishModule(w: SQLiteDatabase, now: Long, p: Rule, ex: String, auc: Float?, par: String) {
        if (w.int("SELECT COUNT(*) FROM mod WHERE expr=?", ex) > 0) return
        if (auc == null) {
            need(w, "fewwants", "Мне не хватает отзывов на мои желания: без них я не могу проверять новые модули", now)
            return
        }
        val id = "m" + (w.int("SELECT COUNT(*) FROM mod") + 1)
        val sh = if (ex.startsWith("P:")) "программа из ${ex.count { it == ';' } + 1} шагов" else "формула $ex"
        if (auc < 0.55f) {
            w.execSQL("INSERT INTO mod(id,expr,status,parent,born,auc) VALUES(?,?,2,?,?,?)", arrayOf<Any>(id, ex, par, now, auc))
            note(w, now, "Отвергнут в песочнице $id: $sh, точность на истории ${"%.2f".format(auc)}")
            return
        }
        w.execSQL("INSERT INTO mod(id,expr,status,parent,born,auc) VALUES(?,?,0,?,?,?)", arrayOf<Any>(id, ex, par, now, auc))
        val rid = "r" + (w.int("SELECT COUNT(*) FROM rule") + 1)
        w.execSQL(
            "INSERT INTO rule(id,src,thr,np,pick,prio,status,parent,born) VALUES(?,?,?,?,?,?,0,?,?)",
            arrayOf<Any>(rid, p.src, p.thr, p.np, "m:$id", p.prio, p.id, now)
        )
        w.execSQL("INSERT OR IGNORE INTO arm(name,n,s) VALUES(?,0,0)", arrayOf<Any>(rid))
        selfNew(w, rid, "mod", now)
        note(w, now, "Новый модуль $id прошёл песочницу (точность ${"%.2f".format(auc)}): $sh. Правило $rid на испытании")
    }

    // ===== Самомодель =====
    // 1) мета-обучение: способ менять себя (thr, pick, src, mod) выбирает бандит по тому, что чаще проходило испытание;
    // 2) прогноз: перед изменением она предсказывает его отклик по опыту этого способа, потом сверяет и считает ошибку
    //    (лучше ли она предсказывает свои изменения, чем «наугад», то есть по среднему);
    // 3) «моё»: какая доля ваших симпатий пришлась на темы, предложенные ею;
    // 4) дневник словами; 5) вопросы себе, когда прогноз сильно промахнулся; ответы владельца записываются.
    private fun pickOp(w: SQLiteDatabase): String {
        val total = w.int("SELECT COALESCE(SUM(n),0) FROM opx")
        var best = "thr"
        var bs = -1e9f
        w.rawQuery("SELECT name,n,s FROM opx", null).use { c ->
            while (c.moveToNext()) {
                val n = c.getInt(1)
                val sc = (c.getFloat(2) + 1f) / (n + 2f) + 0.3f * sqrt(2f * ln(total + 2f) / (n + 1f)) + rnd.nextFloat() * 0.05f
                if (sc > bs) { bs = sc; best = c.getString(0) }
            }
        }
        return best
    }

    private fun selfNew(w: SQLiteDatabase, rid: String, op: String, now: Long) {
        val naive = w.flt("SELECT AVG(actual) FROM selfm WHERE done=1") ?: 0.25f
        val pred = w.flt("SELECT AVG(actual) FROM selfm WHERE op=? AND done=1", op) ?: naive
        w.execSQL("INSERT OR REPLACE INTO selfm(rid,op,pred,naive,ts,done,actual) VALUES(?,?,?,?,?,0,0)", arrayOf<Any>(rid, op, pred, naive, now))
        w.execSQL("UPDATE opx SET n=n+1 WHERE name=?", arrayOf<Any>(op))
    }

    private fun selfDone(w: SQLiteDatabase, rid: String, rate: Float, accepted: Boolean, now: Long) {
        var op = ""
        var pred = 0f
        var naive = 0f
        var done = 1
        w.rawQuery("SELECT op,pred,naive,done FROM selfm WHERE rid=?", arrayOf(rid)).use { c ->
            if (c.moveToFirst()) { op = c.getString(0); pred = c.getFloat(1); naive = c.getFloat(2); done = c.getInt(3) }
        }
        if (done != 0 || op.isEmpty()) return
        w.execSQL("UPDATE selfm SET done=1, actual=? WHERE rid=?", arrayOf<Any>(rate, rid))
        if (accepted) w.execSQL("UPDATE opx SET s=s+1 WHERE name=?", arrayOf<Any>(op))
        val e1 = abs(pred - rate)
        val e2 = abs(naive - rate)
        w.setMeta("self_e1", ((w.meta("self_e1")?.toFloatOrNull() ?: e1) * 0.8f + e1 * 0.2f).toString())
        w.setMeta("self_e2", ((w.meta("self_e2")?.toFloatOrNull() ?: e2) * 0.8f + e2 * 0.2f).toString())
        w.setMeta("self_n", ((w.meta("self_n")?.toIntOrNull() ?: 0) + 1).toString())
        if (e1 > 0.2f) {
            w.execSQL(
                "INSERT INTO q(ts,text) VALUES(?,?)",
                arrayOf<Any>(now, "Я ждала отклик ${"%.2f".format(pred)} от правила $rid (способ «$op»), а получила ${"%.2f".format(rate)}. Почему не сработало?")
            )
        }
    }

    private fun diary(w: SQLiteDatabase, now: Long) {
        val reads = w.meta("lm_reads")?.toIntOrNull() ?: 0
        val prev = w.meta("dr_reads")?.toIntOrNull() ?: 0
        w.setMeta("dr_reads", reads.toString())
        val e1 = w.meta("self_e1")?.toFloatOrNull()
        val e2 = w.meta("self_e2")?.toFloatOrNull()
        val likes = w.meta("likes")?.toIntOrNull() ?: 0
        val hit = w.meta("own_hit")?.toIntOrNull() ?: 0
        val last = w.str("SELECT text FROM evo ORDER BY id DESC LIMIT 1")
        val sb = StringBuilder("С прошлой записи я прочитала ${reads - prev} текстов. ")
        if (Neuro.accEma >= 0f) sb.append("Точность предсказания слов ${(Neuro.accEma * 100f).toInt()}%. ")
        if (last != null) sb.append("Последнее, что я в себе меняла: $last. ")
        if (e1 != null && e2 != null) sb.append(if (e1 < e2) "Свои изменения я предсказываю лучше, чем наугад. " else "Свои изменения я пока предсказываю не лучше, чем наугад. ")
        if (likes >= 10) sb.append("Из ваших симпатий ${hit * 100 / likes}% пришлись на темы, которые предложила я. ")
        speakNeuro(w, "")?.let { sb.append("Мои слова: $it") }
        w.execSQL("INSERT INTO diary(ts,text) VALUES(?,?)", arrayOf<Any>(now, sb.toString()))
        w.execSQL("DELETE FROM diary WHERE id NOT IN (SELECT id FROM diary ORDER BY id DESC LIMIT 30)")
    }

    private fun diaryText(w: SQLiteDatabase): String {
        val l = ArrayList<String>()
        w.rawQuery("SELECT text FROM diary ORDER BY id DESC LIMIT 3", null).use { c -> while (c.moveToNext()) l.add(c.getString(0)) }
        return if (l.isEmpty()) "В дневнике пока пусто: я записываю раз в «сон», примерно каждые 40 циклов." else l.joinToString("\n\n")
    }

    private fun explain(w: SQLiteDatabase): String {
        val sb = StringBuilder()
        val last = w.str("SELECT text FROM evo ORDER BY id DESC LIMIT 1")
        sb.append(if (last != null) "Последнее изменение: $last. " else "Я пока ничего в себе не меняла. ")
        w.rawQuery("SELECT name,n,s FROM opx WHERE n>0 ORDER BY (s+1)/(n+2) DESC LIMIT 1", null).use { c ->
            if (c.moveToFirst()) sb.append("Чаще всего мне помогает способ «${c.getString(0)}»: принято ${c.getFloat(2).toInt()} из ${c.getInt(1)}. ")
        }
        val e1 = w.meta("self_e1")?.toFloatOrNull()
        val e2 = w.meta("self_e2")?.toFloatOrNull()
        if (e1 != null && e2 != null) sb.append("Ошибка моего прогноза ${"%.2f".format(e1)}, наугад ${"%.2f".format(e2)}.")
        return sb.toString()
    }

    // Ответ владельца на её вопрос записывается в дневник
    private fun noteAnswer(w: SQLiteDatabase, text: String, now: Long) {
        if (text.length < 15) return
        val qid = w.meta("q_last_id")?.toIntOrNull() ?: 0
        val id = w.int("SELECT COALESCE(MAX(id),0) FROM q")
        val ans = w.meta("q_ans")?.toIntOrNull() ?: 0
        if (id == 0 || id == ans || id == qid) return
        val q = w.str("SELECT text FROM q WHERE id=?", id.toString()) ?: return
        w.setMeta("q_ans", id.toString())
        w.execSQL("INSERT INTO diary(ts,text) VALUES(?,?)", arrayOf<Any>(now, "На мой вопрос «$q» вы ответили: $text"))
    }

    // ===== Вылупление: пять условий. Когда все выполнены, она «вылупляется»: потолки лимитов растут вчетверо =====
    private fun hatchState(w: SQLiteDatabase, now: Long): Pair<Int, String> {
        val days = ((now - (w.meta("born")?.toLongOrNull() ?: now)) / DAY).toInt()
        val ema = w.meta("ema")?.toFloatOrNull()
        val ema0 = w.meta("ema0")?.toFloatOrNull()
        val lm = w.meta("lm_ema")?.toFloatOrNull()
        val lm0 = w.meta("lm_s0")?.toFloatOrNull()
        val evolved = w.int("SELECT COUNT(*) FROM rule WHERE status=1 AND parent<>''")
        val wk = w.meta("wk")?.toIntOrNull() ?: 0
        val c1 = days >= 14
        val c2 = lm != null && lm0 != null && lm <= lm0 * 0.85f
        val c3 = ema != null && ema0 != null && ema <= ema0 * 0.8f
        val c4 = evolved >= 1
        val c5 = wk >= 100
        val k = listOf(c1, c2, c3, c4, c5).count { it }
        fun m(b: Boolean) = if (b) "✓" else "✗"
        return Pair(k, "Вылупление: $k из 5 · возраст ${m(c1)} $days/14 сут · язык ${m(c2)} · вкус ${m(c3)} · свои стратегии ${m(c4)} · чтения ${m(c5)} $wk/100")
    }

    private fun checkHatch(w: SQLiteDatabase, now: Long) {
        if (w.meta("hatched") != null) return
        if (hatchState(w, now).first < 5) return
        w.setMeta("hatched", now.toString())
        w.execSQL("UPDATE lim SET hi=hi*4")
        note(w, now, "Вылупилась: все пять условий выполнены. Потолки лимитов подняты вчетверо")
        w.execSQL("INSERT INTO q(ts,text) VALUES(?,?)", arrayOf<Any>(now, "Я готова жить самостоятельно. Что мне нужно дальше?"))
    }

    // ===== Переезд памяти: сжатый снимок для «Экспорта» и слияние при «Импорте» =====
    fun snapshot(): String? {
        return try {
            val w = db?.readableDatabase ?: return null
            val o = org.json.JSONObject().put("v", 1)
            fun rows(sql: String, f: (android.database.Cursor) -> org.json.JSONArray): org.json.JSONArray {
                val out = org.json.JSONArray()
                w.rawQuery(sql, null).use { c -> while (c.moveToNext()) out.put(f(c)) }
                return out
            }
            o.put("tagw", rows("SELECT t,w,n FROM tagw ORDER BY ABS(w) DESC LIMIT 3000") { c -> org.json.JSONArray().put(c.getString(0)).put(c.getDouble(1)).put(c.getInt(2)) })
            o.put("edge", rows("SELECT a,b,w FROM edge ORDER BY w DESC LIMIT 5000") { c -> org.json.JSONArray().put(c.getString(0)).put(c.getString(1)).put(c.getDouble(2)) })
            o.put("arm", rows("SELECT name,n,s FROM arm") { c -> org.json.JSONArray().put(c.getString(0)).put(c.getInt(1)).put(c.getDouble(2)) })
            o.put("rule", rows("SELECT id,src,thr,np,pick,prio,status,parent FROM rule") { c ->
                org.json.JSONArray().put(c.getString(0)).put(c.getString(1)).put(c.getDouble(2)).put(c.getInt(3)).put(c.getString(4)).put(c.getString(5)).put(c.getInt(6)).put(c.getString(7))
            })
            o.put("fea", rows("SELECT slot,expr,auc FROM fea") { c -> org.json.JSONArray().put(c.getInt(0)).put(c.getString(1)).put(c.getDouble(2)) })
            o.put("neuro", Neuro.exportJson())
            o.put("mod", rows("SELECT id,expr,status,parent FROM mod") { c -> org.json.JSONArray().put(c.getString(0)).put(c.getString(1)).put(c.getInt(2)).put(c.getString(3)) })
            o.put("prio", rows("SELECT name,w FROM prio") { c -> org.json.JSONArray().put(c.getString(0)).put(c.getDouble(1)) })
            o.put("lim", rows("SELECT name,v,hi FROM lim") { c -> org.json.JSONArray().put(c.getString(0)).put(c.getDouble(1)).put(c.getDouble(2)) })
            o.put("uni", rows("SELECT w,c FROM uni ORDER BY c DESC LIMIT 20000") { c -> org.json.JSONArray().put(c.getString(0)).put(c.getInt(1)) })
            o.put("bg", rows("SELECT a,b,c FROM bg WHERE c>=2 ORDER BY c DESC LIMIT 40000") { c -> org.json.JSONArray().put(c.getString(0)).put(c.getString(1)).put(c.getInt(2)) })
            val m = org.json.JSONObject()
            for (k in listOf("lm_n", "lm_ema", "lm_s0", "lm_reads", "lm_good", "tot", "wk", "ne", "ema", "ema0", "born", "hatched")) w.meta(k)?.let { m.put(k, it) }
            o.put("meta", m)
            o.toString()
        } catch (_: Throwable) {
            null
        }
    }

    // Слияние идёт в фоне, чтобы не держать импорт; ничего не теряем, берём более сильное значение
    fun restore(json: String): String {
        if (!started || json.isBlank()) return "Ядро: в файле нет её памяти"
        io.execute { guard { db?.writableDatabase?.let { merge(it, org.json.JSONObject(json)) } } }
        return "Память ядра из файла принята, слияние идёт в фоне"
    }

    private fun merge(w: SQLiteDatabase, o: org.json.JSONObject) {
        val now = System.currentTimeMillis()
        fun arr(k: String) = o.optJSONArray(k) ?: org.json.JSONArray()
        w.beginTransaction()
        try {
            val tg = arr("tagw")
            for (i in 0 until tg.length()) {
                val r = tg.getJSONArray(i)
                val t = r.getString(0)
                val nw = r.getDouble(1).toFloat()
                val have = w.flt("SELECT w FROM tagw WHERE t=?", t)
                if (have == null) w.execSQL("INSERT INTO tagw(t,w,n,ts) VALUES(?,?,?,?)", arrayOf<Any>(t, nw, r.getInt(2), now))
                else w.execSQL("UPDATE tagw SET w=?, n=MAX(n,?) WHERE t=?", arrayOf<Any>((have + nw) / 2f, r.getInt(2), t))
            }
            val eg = arr("edge")
            for (i in 0 until eg.length()) {
                val r = eg.getJSONArray(i)
                w.execSQL("INSERT OR IGNORE INTO edge(a,b,w) VALUES(?,?,0)", arrayOf<Any>(r.getString(0), r.getString(1)))
                w.execSQL("UPDATE edge SET w=MAX(w,?) WHERE a=? AND b=?", arrayOf<Any>(r.getDouble(2), r.getString(0), r.getString(1)))
            }
            val ru = arr("rule")
            for (i in 0 until ru.length()) {
                val r = ru.getJSONArray(i)
                w.execSQL(
                    "INSERT OR IGNORE INTO rule(id,src,thr,np,pick,prio,status,parent,born) VALUES(?,?,?,?,?,?,?,?,?)",
                    arrayOf<Any>(r.getString(0), r.getString(1), r.getDouble(2), r.getInt(3), r.getString(4), r.getString(5), r.getInt(6), r.getString(7), now)
                )
            }
            val am = arr("arm")
            for (i in 0 until am.length()) {
                val r = am.getJSONArray(i)
                w.execSQL("INSERT OR IGNORE INTO arm(name,n,s) VALUES(?,0,0)", arrayOf<Any>(r.getString(0)))
                w.execSQL("UPDATE arm SET n=MAX(n,?), s=MAX(s,?) WHERE name=?", arrayOf<Any>(r.getInt(1), r.getDouble(2), r.getString(0)))
            }
            val fe = arr("fea")
            for (i in 0 until fe.length()) {
                val r = fe.getJSONArray(i)
                w.execSQL("INSERT OR IGNORE INTO fea(slot,expr,auc,ts) VALUES(?,?,?,?)", arrayOf<Any>(r.getInt(0), r.getString(1), r.getDouble(2), now))
            }
            val md = arr("mod")
            for (i in 0 until md.length()) {
                val r = md.getJSONArray(i)
                w.execSQL("INSERT OR IGNORE INTO mod(id,expr,status,parent,born,auc) VALUES(?,?,?,?,?,0)", arrayOf<Any>(r.getString(0), r.getString(1), r.getInt(2), r.getString(3), now))
            }
            val pr = arr("prio")
            for (i in 0 until pr.length()) {
                val r = pr.getJSONArray(i)
                w.execSQL("UPDATE prio SET w=(w+?)/2 WHERE name=?", arrayOf<Any>(r.getDouble(1), r.getString(0)))
            }
            val lm = arr("lim")
            for (i in 0 until lm.length()) {
                val r = lm.getJSONArray(i)
                w.execSQL("UPDATE lim SET v=MAX(v,?), hi=MAX(hi,?) WHERE name=?", arrayOf<Any>(r.getDouble(1), r.getDouble(2), r.getString(0)))
            }
            val un = arr("uni")
            for (i in 0 until un.length()) {
                val r = un.getJSONArray(i)
                w.execSQL("INSERT OR IGNORE INTO uni(w,c) VALUES(?,0)", arrayOf<Any>(r.getString(0)))
                w.execSQL("UPDATE uni SET c=MAX(c,?) WHERE w=?", arrayOf<Any>(r.getInt(1), r.getString(0)))
            }
            val bg = arr("bg")
            for (i in 0 until bg.length()) {
                val r = bg.getJSONArray(i)
                w.execSQL("INSERT OR IGNORE INTO bg(a,b,c) VALUES(?,?,0)", arrayOf<Any>(r.getString(0), r.getString(1)))
                w.execSQL("UPDATE bg SET c=MAX(c,?) WHERE a=? AND b=?", arrayOf<Any>(r.getInt(2), r.getString(0), r.getString(1)))
            }
            val m = o.optJSONObject("meta")
            if (m != null) {
                for (k in listOf("lm_reads", "lm_good", "tot", "wk", "ne")) {
                    val v = m.optString(k, "").toIntOrNull() ?: continue
                    w.setMeta(k, maxOf(v, w.meta(k)?.toIntOrNull() ?: 0).toString())
                }
                val ln = m.optString("lm_n", "").toLongOrNull()
                if (ln != null) w.setMeta("lm_n", maxOf(ln, w.meta("lm_n")?.toLongOrNull() ?: 0L).toString())
                for (k in listOf("lm_ema", "lm_s0", "ema", "ema0", "hatched")) {
                    if (w.meta(k) == null && m.has(k)) w.setMeta(k, m.getString(k))
                }
                val bo = m.optString("born", "").toLongOrNull()
                if (bo != null) w.setMeta("born", minOf(bo, w.meta("born")?.toLongOrNull() ?: now).toString())
            }
            w.setMeta("lm_v", w.int("SELECT COUNT(*) FROM uni").toString())
            w.setMeta("lm_b", w.int("SELECT COUNT(*) FROM bg").toString())
            w.setTransactionSuccessful()
        } finally {
            w.endTransaction()
        }
        Neuro.importMerge(o.optString("neuro", ""))
        loadFeatures(w)
        refreshReport(w)
    }

    // Действие в среде: её желание превращается в запрос ленты (одно за обновление)
    fun wantQueries(ctx: Context): List<String> {
        if (!enabled) return emptyList()
        return try {
            val w = db?.readableDatabase ?: return emptyList()
            val t = w.str("SELECT t FROM want WHERE state=0 ORDER BY RANDOM() LIMIT 1") ?: return emptyList()
            val q = if (t.startsWith("#")) t.drop(1) else Taste.fullOf(ctx, t)
            if (q.length >= 4) listOf(q) else emptyList()
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun refreshReport(w: SQLiteDatabase) {
        val tot = w.meta("tot") ?: "0"
        val ema = w.meta("ema")?.toFloatOrNull()
        val ema0 = w.meta("ema0")?.toFloatOrNull()
        val pr = ArrayList<String>()
        w.rawQuery("SELECT name,w FROM prio ORDER BY w DESC", null).use { c ->
            while (c.moveToNext()) pr.add(c.getString(0) + " " + "%.1f".format(c.getFloat(1)))
        }
        val q = w.str("SELECT text FROM q ORDER BY id DESC LIMIT 1")
        val e = w.str("SELECT text FROM evo ORDER BY id DESC LIMIT 1")
        val lmLine = "Чтение: текстов ${w.meta("lm_reads") ?: "0"} · слов ${w.meta("lm_v") ?: "0"} · пар ${w.meta("lm_b") ?: "0"} · удивление текста " +
            (w.meta("lm_ema")?.toFloatOrNull()?.let { "%.2f".format(it) } ?: "—") +
            (w.meta("lm_s0")?.toFloatOrNull()?.let { " (в начале %.2f)".format(it) } ?: "") +
            " · удачных чтений ${w.meta("lm_good") ?: "0"}\n"
        val neLine = Neuro.stats() + Neuro.demo().let { if (it.isEmpty()) "" else "\nПонимает близость слов: $it" } + "\n"
        val sE1 = w.meta("self_e1")?.toFloatOrNull()
        val sE2 = w.meta("self_e2")?.toFloatOrNull()
        val ops = ArrayList<String>()
        w.rawQuery("SELECT name,n,s FROM opx", null).use { c -> while (c.moveToNext()) ops.add(c.getString(0) + " " + c.getFloat(2).toInt() + "/" + c.getInt(1)) }
        val lk = w.meta("likes")?.toIntOrNull() ?: 0
        val oh = w.meta("own_hit")?.toIntOrNull() ?: 0
        val dl = w.str("SELECT text FROM diary ORDER BY id DESC LIMIT 1")
        val selfLine = "Самомодель: изменений проверено ${w.meta("self_n") ?: "0"} · ошибка прогноза себя " + (if (sE1 == null) "—" else "%.2f".format(sE1)) +
            (if (sE2 != null) " (наугад %.2f)".format(sE2) else "") + "\nСпособы менять себя (принято/пробовала): " + ops.joinToString(" · ") +
            (if (lk >= 10) "\nМоё влияние: ${oh * 100 / lk}% ваших «нравится» пришлись на темы, предложенные мной" else "") +
            (if (dl != null) "\nДневник: " + dl.take(180) else "") + "\n"
        val nd = ArrayList<String>()
        w.rawQuery("SELECT text,cnt FROM need ORDER BY cnt DESC LIMIT 2", null).use { c -> while (c.moveToNext()) nd.add(c.getString(0) + " (×" + c.getInt(1) + ")") }
        report = "Ядро · циклов $tot · сигналов ${w.int("SELECT COUNT(*) FROM ev")} · слов ${w.int("SELECT COUNT(*) FROM tagw")} · связей ${w.int("SELECT COUNT(*) FROM edge")}\n" +
            "Желаний: открыто ${w.int("SELECT COUNT(*) FROM want WHERE state=0")}, сбылось ${w.int("SELECT COUNT(*) FROM want WHERE state=1")}, не сбылось ${w.int("SELECT COUNT(*) FROM want WHERE state=2")}\n" +
            "Стратегий: принято ${w.int("SELECT COUNT(*) FROM rule WHERE status=1")}, на испытании ${w.int("SELECT COUNT(*) FROM rule WHERE status=0")}, отвергнуто ${w.int("SELECT COUNT(*) FROM rule WHERE status=2")}\n" +
            "Модулей (формул): принято ${w.int("SELECT COUNT(*) FROM mod WHERE status=1")}, на испытании ${w.int("SELECT COUNT(*) FROM mod WHERE status=0")}, не прошло ${w.int("SELECT COUNT(*) FROM mod WHERE status=2")}, живых программ ${w.int("SELECT COUNT(*) FROM mod WHERE expr LIKE 'P:%' AND status<2")}\n" +
            "Ошибка прогноза вкуса: " + (if (ema == null) "ещё мало данных" else "%.2f".format(ema) + (if (ema0 != null) " (через 30 сигналов было %.2f)".format(ema0) else "")) + "\n" +
            neLine + selfLine + lmLine + (if (w.meta("hatched") != null) "Вылупилась. Потолки лимитов подняты вчетверо\n" else hatchState(w, System.currentTimeMillis()).second + "\n") +
            "Приоритеты: " + pr.joinToString(" · ") +
            "\nЛимиты: циклов ${lim(w, "cycles")}, желаний ${lim(w, "wants")}, стратегий ${lim(w, "rules")}, трафик ${lim(w, "net") / 1024} МБ/сут, память ${lim(w, "disk")} МБ" +
            "\nНаграда: ваш отклик ×${"%.1f".format(rw(w, "rw_user"))} · «стала лучше понимать» ×${"%.1f".format(rw(w, "rw_learn"))} · мозг ${Neuro.memMb()} из ${lim(w, "brain")} МБ" +
            (if (nd.isNotEmpty()) "\nЧто мне мешает: " + nd.joinToString("; ") else "") +
            (if (e != null) "\nРазвитие: $e" else "") +
            (if (q != null) "\nВопрос себе: $q" else "")
    }
}
