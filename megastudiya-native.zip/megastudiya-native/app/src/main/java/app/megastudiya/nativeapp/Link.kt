package app.megastudiya.nativeapp

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

// СВЯЗЬ ТЕЛЕФОНОВ. Два телефона с одним кодом в одной Wi-Fi сети находят друг друга (NSD), доказывают знание кода
// друг другу (HMAC по случайным числам обеих сторон), обмениваются снимками памяти ядра (сжато и зашифровано AES-GCM,
// ключ из кода и случайных чисел сессии) и сливают их: берётся более сильное значение, ничего не теряется.
// Работает, только пока приложение открыто. Пока без передачи задач: только память, нейро-мозг, признаки, модули.
object Link {
    private const val TYPE = "_megacore._tcp."
    private const val MAXBYTES = 40_000_000

    @Volatile var status = "Связь телефонов: выключена"
        private set

    @Volatile var on = false
        private set

    @Volatile var code = ""
        private set

    private var app: Context? = null
    private var myId = ""
    private var myName = ""
    private var running = false
    private var server: ServerSocket? = null
    private var nsd: NsdManager? = null
    private var reg: NsdManager.RegistrationListener? = null
    private var disc: NsdManager.DiscoveryListener? = null
    private val last = HashMap<String, Long>()
    private val rnd = SecureRandom()

    private fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }

    private fun load(a: Context) {
        val p = a.getSharedPreferences("ms", Context.MODE_PRIVATE)
        on = p.getBoolean("linkOn", false)
        var c = p.getString("linkCode", "") ?: ""
        var id = p.getString("linkId", "") ?: ""
        val ed = p.edit()
        if (c.isEmpty()) {
            val abc = "abcdefghjkmnpqrstuvwxyz23456789"
            c = (1..10).map { abc[rnd.nextInt(abc.length)] }.joinToString("")
            ed.putString("linkCode", c)
        }
        if (id.isEmpty()) {
            id = hex(ByteArray(4).also { rnd.nextBytes(it) })
            ed.putString("linkId", id)
        }
        ed.apply()
        code = c
        myId = id
    }

    fun init(ctx: Context) {
        app = ctx.applicationContext
        load(ctx.applicationContext)
    }

    fun setOn(ctx: Context, v: Boolean) {
        val a = ctx.applicationContext
        a.getSharedPreferences("ms", Context.MODE_PRIVATE).edit().putBoolean("linkOn", v).apply()
        load(a)
        if (v) resume(a) else { pause(); status = "Связь телефонов: выключена" }
    }

    fun setCode(ctx: Context, c: String) {
        val a = ctx.applicationContext
        a.getSharedPreferences("ms", Context.MODE_PRIVATE).edit().putString("linkCode", c.trim()).apply()
        code = c.trim()
    }

    fun syncNow(ctx: Context) {
        synchronized(last) { last.clear() }
        pause()
        resume(ctx)
    }

    fun resume(ctx: Context) {
        val a = ctx.applicationContext
        app = a
        load(a)
        if (!on) return
        if (code.length < 6) { status = "Связь: код короче 6 знаков"; return }
        if (running) return
        running = true
        try {
            val ss = ServerSocket(0)
            server = ss
            Thread { acceptLoop(ss) }.apply { isDaemon = true; name = "ms-link-srv" }.start()
            val m = a.getSystemService(Context.NSD_SERVICE) as NsdManager
            nsd = m
            myName = "megacore-$myId"
            val info = NsdServiceInfo()
            info.serviceName = myName
            info.serviceType = TYPE
            info.port = ss.localPort
            val rl = object : NsdManager.RegistrationListener {
                override fun onServiceRegistered(i: NsdServiceInfo) {}
                override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) { status = "Связь: не удалось объявить себя в сети ($e)" }
                override fun onServiceUnregistered(i: NsdServiceInfo) {}
                override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
            }
            reg = rl
            m.registerService(info, NsdManager.PROTOCOL_DNS_SD, rl)
            val dl = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(t: String) { status = "Связь: ищу телефон в этой Wi-Fi сети…" }
                override fun onServiceFound(s: NsdServiceInfo) {
                    val n = s.serviceName ?: return
                    if (!n.startsWith("megacore-") || n.startsWith(myName)) return
                    val pid = n.removePrefix("megacore-").substringBefore(" ")
                    if (myId >= pid) return // соединение начинает телефон с меньшим идентификатором
                    m.resolveService(s, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(i: NsdServiceInfo, e: Int) {}
                        override fun onServiceResolved(r: NsdServiceInfo) {
                            val h = r.host?.hostAddress ?: return
                            connect(pid, h, r.port)
                        }
                    })
                }
                override fun onServiceLost(s: NsdServiceInfo) {}
                override fun onDiscoveryStopped(t: String) {}
                override fun onStartDiscoveryFailed(t: String, e: Int) { status = "Связь: поиск не запустился ($e)" }
                override fun onStopDiscoveryFailed(t: String, e: Int) {}
            }
            disc = dl
            m.discoverServices(TYPE, NsdManager.PROTOCOL_DNS_SD, dl)
        } catch (_: Throwable) {
            status = "Связь: не удалось запуститься"
            running = false
        }
    }

    fun pause() {
        if (!running) return
        running = false
        try { disc?.let { nsd?.stopServiceDiscovery(it) } } catch (_: Throwable) { }
        try { reg?.let { nsd?.unregisterService(it) } } catch (_: Throwable) { }
        try { server?.close() } catch (_: Throwable) { }
        disc = null
        reg = null
        server = null
    }

    private fun nonce(): String = hex(ByteArray(16).also { rnd.nextBytes(it) })

    private fun hmac(msg: String): String {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(code.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return hex(m.doFinal(msg.toByteArray(Charsets.UTF_8)))
    }

    private fun key(n1: String, n2: String): ByteArray =
        MessageDigest.getInstance("SHA-256").digest(("K$code$n1$n2").toByteArray(Charsets.UTF_8))

    private fun stamp(): String = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())

    private fun connect(pid: String, host: String, port: Int) {
        val now = System.currentTimeMillis()
        synchronized(last) {
            if (now - (last[pid] ?: 0L) < 20 * 60_000L) return
            last[pid] = now
        }
        Thread {
            try {
                Socket().use { s ->
                    s.connect(InetSocketAddress(host, port), 5000)
                    s.soTimeout = 20_000
                    client(s)
                }
            } catch (_: Throwable) {
                status = "Связь: не удалось связаться с телефоном"
                synchronized(last) { last.remove(pid) }
            }
        }.apply { isDaemon = true; name = "ms-link-cli" }.start()
    }

    private fun client(s: Socket) {
        val i = DataInputStream(BufferedInputStream(s.getInputStream()))
        val o = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
        val n1 = nonce()
        o.writeUTF(myId)
        o.writeUTF(n1)
        o.flush()
        val srv = i.readUTF()
        val n2 = i.readUTF()
        val mac2 = i.readUTF()
        if (n2.length > 64 || mac2 != hmac("S$n1$n2$srv$myId")) { status = "Связь: код не подошёл"; return }
        o.writeUTF(hmac("C$n1$n2$myId$srv"))
        o.flush()
        val k = key(n1, n2)
        send(o, k)
        receive(i, k)
        status = "Связь: синхронизировано с телефоном $srv в ${stamp()}"
    }

    private fun acceptLoop(ss: ServerSocket) {
        while (running) {
            val s = try { ss.accept() } catch (_: Throwable) { return }
            Thread {
                try {
                    s.soTimeout = 20_000
                    serve(s)
                } catch (_: Throwable) {
                } finally {
                    try { s.close() } catch (_: Throwable) { }
                }
            }.apply { isDaemon = true; name = "ms-link-conn" }.start()
        }
    }

    private fun serve(s: Socket) {
        val i = DataInputStream(BufferedInputStream(s.getInputStream()))
        val o = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
        val cid = i.readUTF()
        val n1 = i.readUTF()
        if (n1.length > 64 || cid.length > 64) return
        val n2 = nonce()
        o.writeUTF(myId)
        o.writeUTF(n2)
        o.writeUTF(hmac("S$n1$n2$myId$cid"))
        o.flush()
        val macC = i.readUTF()
        if (macC != hmac("C$n1$n2$cid$myId")) { status = "Связь: телефон с другим кодом пытался подключиться"; return }
        val k = key(n1, n2)
        receive(i, k)
        send(o, k)
        status = "Связь: синхронизировано с телефоном $cid в ${stamp()}"
    }

    private fun send(o: DataOutputStream, k: ByteArray) {
        val raw = Core.snapshot() ?: ""
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(raw.toByteArray(Charsets.UTF_8)) }
        val iv = ByteArray(12)
        rnd.nextBytes(iv)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(k, "AES"), GCMParameterSpec(128, iv))
        val enc = c.doFinal(bos.toByteArray())
        o.writeInt(iv.size + enc.size)
        o.write(iv)
        o.write(enc)
        o.flush()
    }

    private fun receive(i: DataInputStream, k: ByteArray) {
        val n = i.readInt()
        if (n < 13 || n > MAXBYTES) throw IOException("size")
        val b = ByteArray(n)
        i.readFully(b)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(k, "AES"), GCMParameterSpec(128, b.copyOfRange(0, 12)))
        val gz = c.doFinal(b, 12, n - 12)
        val json = GZIPInputStream(ByteArrayInputStream(gz)).use { String(it.readBytes(), Charsets.UTF_8) }
        Core.restore(json)
    }
}
