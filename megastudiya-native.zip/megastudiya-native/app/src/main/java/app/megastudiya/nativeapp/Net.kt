package app.megastudiya.nativeapp

import android.content.Context
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.common.model.DownloadConditions
import com.google.android.gms.tasks.Task
import android.util.Xml
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.roundToInt

object Net {
    fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Megastudiya")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}

data class NewsItem(val title: String, val link: String, val desc: String, val ts: Long, val src: String, val full: String = "", val img: String = "")

// Новости: премиальная подборка уровня топ-менеджмента: бизнес, рынки, дизайн и архитектура, статус, наука. Без региональной хроники., кэш в файле, обновление не чаще раза в 30 минут.
object News {
    val items = mutableStateListOf<NewsItem>()
    var status by mutableStateOf("")
    var rev by mutableIntStateOf(0)            // растёт при любом изменении списка, чтобы лента пересобралась
        private set
    var hiddenSrc by mutableStateOf<Set<String>>(emptySet())
        private set
    var hiddenLinks by mutableStateOf<Set<String>>(emptySet())
        private set
    private val foreign = setOf("Bloomberg", "The Economist", "Dezeen", "Robb Report", "Nature") // не по-русски: только с переводом
    private val tr = HashMap<String, Array<String>>()                                          // ссылка -> заголовок, описание, текст
    private var last = 0L

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ms", Context.MODE_PRIVATE)

    // Лента видит только то, что не скрыто, а иностранное только после перевода
    fun visible(): List<NewsItem> = items.filter { it.src !in hiddenSrc && it.link !in hiddenLinks && (it.src !in foreign || it.link in tr) }

    fun hideSource(ctx: Context, src: String) {
        hiddenSrc = hiddenSrc + src
        prefs(ctx).edit().putStringSet("hsrc", hiddenSrc).apply()
        rev++
    }

    fun hideItem(ctx: Context, link: String) {
        hiddenLinks = (hiddenLinks + link).toList().takeLast(400).toSet()
        prefs(ctx).edit().putStringSet("hlnk", hiddenLinks).apply()
        rev++
    }

    private fun applyTr(l: List<NewsItem>) = l.map { n -> tr[n.link]?.let { n.copy(title = it[0], desc = it[1], full = it[2]) } ?: n }

    private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { c ->
        addOnSuccessListener { c.resume(it) }
        addOnFailureListener { c.resumeWithException(it) }
    }

    private suspend fun trLong(t: Translator, text: String): String {
        val out = StringBuilder()
        for (p in text.take(6000).split("\n")) {
            if (out.isNotEmpty()) out.append('\n')
            out.append(if (p.isBlank()) p else runCatching { t.translate(p).await() }.getOrDefault(p))
        }
        return out.toString()
    }

    // Перевод на устройстве (ML Kit): модель en→ru скачивается один раз (~30 МБ), дальше работает без сети.
    // Переводим только новое, готовое сохраняем. Пока перевода нет, иностранные материалы в ленте не показываются.
    private suspend fun translateNew(ctx: Context) {
        val todo = items.filter { it.src in foreign && it.link !in tr }
        if (todo.isEmpty()) return
        val tl = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.RUSSIAN).build())
        try {
            tl.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            for (n in todo) {
                val t = runCatching { tl.translate(n.title).await() }.getOrNull() ?: continue
                val d = if (n.desc.isNotEmpty()) runCatching { tl.translate(n.desc).await() }.getOrDefault(n.desc) else ""
                val f = if (n.full.length > n.desc.length + 40) trLong(tl, n.full) else d
                tr[n.link] = arrayOf(t, d, f)
                withContext(Dispatchers.Main) {
                    val i = items.indexOfFirst { x -> x.link == n.link }
                    if (i >= 0) items[i] = items[i].copy(title = t, desc = d, full = f)
                    rev++
                }
            }
            withContext(Dispatchers.IO) {
                runCatching {
                    val live = items.map { it.link }.toSet()
                    val o = JSONObject()
                    tr.filterKeys { it in live }.forEach { (k, v) -> o.put(k, JSONArray(v.toList())) }
                    File(ctx.filesDir, "tr1.json").writeText(o.toString())
                }
            }
        } catch (_: Throwable) {
            if (items.any { it.src in foreign && it.link !in tr }) status = "Перевод пока недоступен: нужны сервисы Google и сеть для первой загрузки модели"
        } finally {
            tl.close()
        }
    }

    private fun loadExtra(ctx: Context) {
        val p = prefs(ctx)
        hiddenSrc = p.getStringSet("hsrc", emptySet()) ?: emptySet()
        hiddenLinks = p.getStringSet("hlnk", emptySet()) ?: emptySet()
        runCatching {
            val f = File(ctx.filesDir, "tr1.json")
            if (f.exists()) {
                val o = JSONObject(f.readText())
                o.keys().forEach { k -> val a = o.getJSONArray(k); tr[k] = arrayOf(a.getString(0), a.getString(1), a.getString(2)) }
            }
        }
    }

    private val sources = listOf(
        "Forbes" to "https://www.forbes.ru/newrss.php",
        "Ведомости" to "https://www.vedomosti.ru/rss/news",
        "РБК" to "https://rssexport.rbc.ru/rbcnews/news/30/full.rss",
        "Коммерсантъ" to "https://www.kommersant.ru/RSS/news.xml",
        "Bloomberg" to "https://feeds.bloomberg.com/markets/news.rss",
        "The Economist" to "https://www.economist.com/business/rss.xml",
        "Dezeen" to "https://www.dezeen.com/feed/",
        "Robb Report" to "https://robbreport.com/feed/",
        "Nature" to "https://www.nature.com/nature.rss"
    )

    fun load(ctx: Context) {
        loadExtra(ctx)
        try {
            val f = File(ctx.filesDir, "news4.json")
            if (!f.exists()) return
            last = f.lastModified()
            val a = JSONArray(f.readText())
            val l = ArrayList<NewsItem>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                l.add(NewsItem(o.getString("t"), o.getString("l"), o.optString("d"), o.optLong("ts"), o.optString("s"), o.optString("f"), o.optString("i")))
            }
            items.clear()
            items.addAll(applyTr(l))
            rev++
            if (l.any { it.full.isEmpty() }) last = 0L // старый кэш без полного текста: обновить при запуске
        } catch (_: Throwable) {
        }
    }

    suspend fun refresh(ctx: Context, force: Boolean = false) {
        if (!force && items.isNotEmpty() && System.currentTimeMillis() - last < 1_800_000) return
        status = "Обновляю…"
        val res = withContext(Dispatchers.IO) {
            coroutineScope {
                sources.map { s -> async { runCatching { parse(s.first, Net.get(s.second)) }.getOrDefault(emptyList()).sortedByDescending { it.ts }.take(8) } }
                    .awaitAll().flatten()
            }
        }
        if (res.isEmpty()) {
            status = if (items.isEmpty()) "Нет интернета" else "Нет связи, показан кэш"
            return
        }
        val all = applyTr(res.sortedByDescending { it.ts }.take(80))
        items.clear()
        items.addAll(all)
        rev++
        withContext(Dispatchers.IO) {
            runCatching {
                val a = JSONArray()
                all.forEach { a.put(JSONObject().put("t", it.title).put("l", it.link).put("d", it.desc).put("ts", it.ts).put("s", it.src).put("f", it.full).put("i", it.img)) }
                File(ctx.filesDir, "news4.json").writeText(a.toString())
            }
        }
        last = System.currentTimeMillis()
        status = ""
        translateNew(ctx)
    }

    private val dateFmt = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.US)
    private val tags = Regex("<[^>]+>")
    private val spaces = Regex("\\s+")

    private fun clean(s: String): String =
        tags.replace(s, " ").replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", "\"")
            .replace("&#39;", "'").replace("&laquo;", "«").replace("&raquo;", "»")
            .let { spaces.replace(it, " ").trim() }

    private val blockEnd = Regex("(?i)</p>|<br\\s*/?>|</li>|</h\\d>|</div>")
    private val hspaces = Regex("[ \\t\\u00A0]+")
    private val blankLines = Regex("\\s*\\n\\s*(\\n\\s*)+")
    private val numEnt = Regex("&#(\\d+);")
    private val imgExt = Regex("(?i)\\.(jpe?g|png|webp|gif)(\\?|$)")
    private val imgTag = Regex("(?i)<img[^>]+src=[\"']([^\"']+)[\"']")

    // Полный текст статьи: абзацы сохраняются, теги и сущности убираются.
    private fun cleanFull(s: String): String {
        var r = blockEnd.replace(s, "\n\n")
        r = tags.replace(r, " ")
        r = numEnt.replace(r) { m -> runCatching { String(Character.toChars(m.groupValues[1].toInt())) }.getOrDefault(" ") }
        r = r.replace("&nbsp;", " ").replace("&quot;", "\"").replace("&laquo;", "«").replace("&raquo;", "»")
            .replace("&mdash;", "—").replace("&ndash;", "–").replace("&hellip;", "…").replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
        r = hspaces.replace(r, " ")
        r = r.lines().joinToString("\n") { it.trim() }
        r = blankLines.replace(r, "\n\n")
        return r.trim()
    }

    private fun firstImg(html: String): String {
        val u = imgTag.find(html)?.groupValues?.get(1)?.replace("&amp;", "&") ?: return ""
        return if (u.startsWith("//")) "https:$u" else if (u.startsWith("http")) u else ""
    }

    private fun parse(src: String, xml: String): List<NewsItem> {
        val p = Xml.newPullParser()
        p.setInput(StringReader(xml))
        val out = ArrayList<NewsItem>()
        var inItem = false
        var t = ""
        var l = ""
        var d = ""
        var f = ""
        var im = ""
        var ts = 0L
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "item" -> { inItem = true; t = ""; l = ""; d = ""; f = ""; im = ""; ts = 0L }
                    "title" -> if (inItem) t = p.nextText()
                    "link" -> if (inItem) l = p.nextText().trim()
                    "description" -> if (inItem) d = p.nextText()
                    "content:encoded", "encoded" -> if (inItem) f = p.nextText()
                    "enclosure", "media:content", "media:thumbnail" -> if (inItem && im.isEmpty()) {
                        val u = p.getAttributeValue(null, "url") ?: ""
                        val ty = (p.getAttributeValue(null, "type") ?: "") + (p.getAttributeValue(null, "medium") ?: "")
                        if (u.startsWith("http") && (ty.contains("image") || p.name == "media:thumbnail" || imgExt.containsMatchIn(u))) im = u
                    }
                    "pubDate" -> if (inItem) ts = runCatching { synchronized(dateFmt) { dateFmt.parse(p.nextText().trim())?.time } }.getOrNull() ?: 0L
                }
            } else if (ev == XmlPullParser.END_TAG && p.name == "item") {
                inItem = false
                if (t.isNotBlank() && l.startsWith("http")) {
                    val body = cleanFull(if (f.length > d.length) f else d)
                    out.add(NewsItem(clean(t), l, clean(d).take(220), if (ts > 0) ts else System.currentTimeMillis(), src, body.take(6000), im.ifEmpty { firstImg(f.ifEmpty { d }) }))
                }
            }
            ev = p.next()
        }
        return out.take(20)
    }
}

data class Geo(val name: String, val lat: Double, val lon: Double)

// Город и погода (Open-Meteo, без ключей). Город хранится на телефоне.
object Place {
    var cityName by mutableStateOf("")
        private set
    var wx by mutableStateOf("")
        private set
    var wcode by mutableIntStateOf(-1)   // код погоды WMO; -1 — ещё неизвестен
        private set
    var isDay by mutableStateOf(true)
        private set
    var lat = 0.0
        private set
    var lon = 0.0
        private set

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ms", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val p = prefs(ctx)
        val n = p.getString("city", "") ?: ""
        if (n.isNotEmpty()) apply(n, p.getFloat("clat", 0f).toDouble(), p.getFloat("clon", 0f).toDouble())
        wx = p.getString("wxs", "") ?: ""
        wcode = p.getInt("wxc", -1)
        isDay = p.getBoolean("wxd", true)
    }

    private fun apply(n: String, la: Double, lo: Double) {
        cityName = n
        lat = la
        lon = lo
        EarthGate.cityLat = Math.toRadians(la)
        EarthGate.cityLon = Math.toRadians(lo)
        EarthGate.hasCity = true
    }

    fun setCity(ctx: Context, g: Geo) {
        apply(g.name, g.lat, g.lon)
        prefs(ctx).edit().putString("city", g.name).putFloat("clat", g.lat.toFloat()).putFloat("clon", g.lon.toFloat())
            .remove("wxt").apply()
        wx = ""
        wcode = -1
    }

    // null, если такого города нет; исключение, если нет сети
    suspend fun geocode(q: String): Geo? = withContext(Dispatchers.IO) {
        val j = JSONObject(Net.get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=ru&name=" + URLEncoder.encode(q, "UTF-8")))
        val r = j.optJSONArray("results")?.optJSONObject(0) ?: return@withContext null
        Geo(r.getString("name"), r.getDouble("latitude"), r.getDouble("longitude"))
    }

    suspend fun loadWx(ctx: Context) {
        if (cityName.isEmpty()) return
        val p = prefs(ctx)
        if (wx.isNotEmpty() && wcode >= 0 && System.currentTimeMillis() - p.getLong("wxt", 0L) < 1_800_000) return
        try {
            val s = withContext(Dispatchers.IO) {
                val j = JSONObject(Net.get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=weather_code,temperature_2m,is_day&timezone=auto"))
                val c = j.getJSONObject("current")
                val t = c.getDouble("temperature_2m").roundToInt()
                Triple((if (t > 0) "+$t°" else "$t°") + " · " + desc(c.getInt("weather_code")), c.getInt("weather_code"), c.optInt("is_day", 1) == 1)
            }
            wx = s.first
            wcode = s.second
            isDay = s.third
            p.edit().putString("wxs", s.first).putInt("wxc", s.second).putBoolean("wxd", s.third).putLong("wxt", System.currentTimeMillis()).apply()
        } catch (_: Throwable) {
            if (wx.isEmpty()) wx = "нет связи"
        }
    }

    private fun desc(c: Int) = when {
        c == 0 -> "ясно"
        c <= 2 -> "малооблачно"
        c == 3 -> "пасмурно"
        c == 45 || c == 48 -> "туман"
        c in 51..57 -> "морось"
        c in 61..67 -> "дождь"
        c in 71..77 || c == 85 || c == 86 -> "снег"
        c in 80..82 -> "ливень"
        c >= 95 -> "гроза"
        else -> "облачно"
    }
}
