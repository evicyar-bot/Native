package app.megastudiya.nativeapp

import android.content.Context
import aqua.adapters.file.DurableResearchEventJournal
import aqua.adapters.file.DurableResearchRepositories
import aqua.adapters.file.DurableTaskPlanRepository
import aqua.dataformat.FileDurableBundleStore
import aqua.research.EventId
import aqua.research.EventOutcome
import aqua.research.ResearchEvent
import java.io.File
import java.util.UUID

/**
 * Android host adapter for AQUA Step105. This is part of the Megastudiya process,
 * uses app-private storage, and deliberately never starts a second application.
 */
object AquaStep105Runtime {
    private const val PREFS = "aqua_step105_host"
    private const val SCHEMA = 1
    @Volatile private var initialized = false
    @Volatile private var initializationError: String? = null
    private var research: DurableResearchRepositories? = null
    private var journal: DurableResearchEventJournal? = null
    private var plans: DurableTaskPlanRepository? = null

    @Synchronized
    fun initialize(context: Context) {
        if (initialized) return
        try {
            val root = File(context.filesDir, "aqua-step105")
            root.mkdirs()
            val bundleStore = FileDurableBundleStore(root.toPath().resolve("research-bundles"))
            val repos = DurableResearchRepositories(bundleStore, "megastudiya-research-v1")
            check(repos.initialize()) { "Research bundle storage could not be loaded: ${repos.error()}" }
            val eventJournal = DurableResearchEventJournal(File(root, "research-events.log").toPath())
            val planRepo = DurableTaskPlanRepository(File(root, "task-plans.db"))
            research = repos
            journal = eventJournal
            plans = planRepo
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("schema", SCHEMA).apply()
            initialized = true
            initializationError = null
            record("runtime.initialized", EventOutcome.SUCCEEDED, "durable research, event journal and plans ready")
        } catch (t: Throwable) {
            initializationError = t.message ?: t.javaClass.simpleName
            // Do not mark initialized: the host may retry after transient storage trouble.
        }
    }

    fun record(action: String, outcome: EventOutcome = EventOutcome.SUCCEEDED, details: String = "") {
        val sink = journal ?: return
        runCatching {
            sink.append(ResearchEvent(
                id = EventId("ms-aqua-${UUID.randomUUID()}"),
                occurredAtEpochMs = System.currentTimeMillis().coerceAtLeast(0),
                actor = "megastudiya-aqua",
                action = action.take(120),
                outcome = outcome,
                details = details.take(500)
            ))
        }
    }

    fun status(context: Context): String {
        initialize(context)
        if (!initialized) return "AQUA Step105 встроена, но хранилище пока не инициализировано: ${initializationError ?: "ошибка"}. Повтори команду позже."
        val r = research ?: return "Research storage недоступно."
        val j = journal ?: return "Event journal недоступен."
        val p = plans ?: return "Task-plan storage недоступно."
        val evidence = runCatching { r.evidence.list().size }.getOrDefault(-1)
        val claims = runCatching { r.claim.list().size }.getOrDefault(-1)
        val decisions = runCatching { r.decision.list().size }.getOrDefault(-1)
        return buildString {
            appendLine("AQUA Step105 — интегрированный контур Megastudiya")
            appendLine("Состояние: READY (локальные долговременные хранилища открыты)")
            appendLine("Исследовательские записи: источники $evidence, утверждения $claims, решения $decisions")
            appendLine("Журнал событий: ${j.latestSequence()} записей")
            appendLine("Планы задач: ${p.list().size}")
            appendLine("Граф знаний, память опыта, планирование и execution ledger доступны как встроенные Kotlin-модули")
            append("Исполнение внешних действий и автономный live-run не активируются этим контуром; требуется отдельный разрешённый исполнитель.")
        }
    }
}
