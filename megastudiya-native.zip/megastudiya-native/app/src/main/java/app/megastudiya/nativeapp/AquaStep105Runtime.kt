package app.megastudiya.nativeapp

import android.content.Context
import aqua.dataformat.FileDurableBundleStore
import aqua.research.EventOutcome
import java.io.File
import java.nio.charset.StandardCharsets
import java.util.UUID

/** Android host adapter for AQUA Step105 inside the single Megastudiya process. */
object AquaStep105Runtime {
    private const val PREFS = "aqua_step105_host"
    private const val SCHEMA = 1
    @Volatile private var initialized = false
    @Volatile private var initializationError: String? = null
    private var bundleStore: FileDurableBundleStore? = null
    private var eventLog: File? = null

    @Synchronized
    fun initialize(context: Context) {
        if (initialized) return
        try {
            val root = File(context.filesDir, "aqua-step105")
            check(root.exists() || root.mkdirs()) { "Cannot create AQUA private storage" }
            val store = FileDurableBundleStore(File(root, "research-bundles").toPath())
            bundleStore = store
            eventLog = File(root, "research-events.log")
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("schema", SCHEMA).apply()
            initialized = true
            initializationError = null
            record("runtime.initialized", EventOutcome.SUCCEEDED, "AQUA Step105 host storage initialized")
        } catch (t: Throwable) {
            initializationError = t.message ?: t.javaClass.simpleName
        }
    }

    @Synchronized
    fun record(action: String, outcome: EventOutcome = EventOutcome.SUCCEEDED, details: String = "") {
        val file = eventLog ?: return
        runCatching {
            // Tab-separated, bounded and escaped event line; no chat message content is recorded.
            val line = listOf(System.currentTimeMillis().coerceAtLeast(0).toString(),
                "ms-aqua-${UUID.randomUUID()}", action.take(120).replace("\\t", " "),
                outcome.name, details.take(300).replace("\\t", " ").replace("\\n", " "))
                .joinToString("\\t") + "\\n"
            file.appendText(line, StandardCharsets.UTF_8)
        }
    }

    fun status(context: Context): String {
        initialize(context)
        if (!initialized) return "AQUA Step105 встроена, но хранилище не инициализировано: ${initializationError ?: "ошибка"}."
        val keys = runCatching { bundleStore?.keys().orEmpty() }.getOrDefault(emptyList())
        val events = runCatching { eventLog?.readLines(StandardCharsets.UTF_8)?.size ?: 0 }.getOrDefault(0)
        return buildString {
            appendLine("AQUA Step105 — встроенный контур Megastudiya")
            appendLine("Состояние: локальное хранилище доступно")
            appendLine("Исследовательских bundle: ${keys.size}")
            appendLine("Записей журнала: $events")
            append("Модели исследований, планирования, графа знаний и orchestration включены в исходный Android-модуль; выполнение внешних действий отдельно не запускается.")
        }
    }
}
