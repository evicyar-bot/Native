package app.megastudiya.nativeapp

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sin

// Тот же «звон», что в v99: низкий удар 210→70 Гц и три тихих обертона. Звук считается один раз.
object Snd {
    var on by mutableStateOf(true)
        private set
    private const val SR = 22050
    private var pcm: ShortArray? = null
    private var last: AudioTrack? = null

    fun init(ctx: Context) {
        on = ctx.getSharedPreferences("ms", Context.MODE_PRIVATE).getBoolean("snd", true)
    }

    fun toggle(ctx: Context) {
        on = !on
        ctx.getSharedPreferences("ms", Context.MODE_PRIVATE).edit().putBoolean("snd", on).apply()
        if (on) play()
    }

    private fun build(): ShortArray {
        val n = (SR * 0.3).toInt()
        val out = ShortArray(n)
        var ph = 0.0
        val parts = arrayOf(doubleArrayOf(1480.0, .03, .22), doubleArrayOf(2310.0, .018, .16), doubleArrayOf(3720.0, .008, .1))
        for (i in 0 until n) {
            val t = i.toDouble() / SR
            val f = if (t < .14) 210.0 * (70.0 / 210.0).pow(t / .14) else 70.0
            ph += 2 * PI * f / SR
            val env = if (t < .004) t / .004 else exp(ln(.0001 / 1.0) * (t - .004) / .176).coerceAtMost(1.0)
            var v = if (t < .2) sin(ph) * .16 * env else 0.0
            for (p in parts) {
                if (t < p[2] + .05) {
                    val e = if (t < .003) t / .003 else exp(ln(.0001) * (t - .003) / (p[2] - .003))
                    v += sin(2 * PI * p[0] * t) * p[1] * e
                }
            }
            out[i] = (v * 3.2 * 32767).coerceIn(-32767.0, 32767.0).toInt().toShort()
        }
        return out
    }

    fun play() {
        if (!on) return
        runCatching {
            val d = pcm ?: build().also { pcm = it }
            last?.release()
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(d.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(d, 0, d.size)
            t.play()
            last = t
        }
    }
    // ───────── Звук заставки ─────────
    // Тоннель (шум с растущим срезом + нарастающий тон) → зажигание → колокольчик на каждом узле (пентатоника вверх,
    // в такт вспышкам и вибро) → удар и тёплый аккорд при замыкании кольца → два лёгких «тинь» при посадке в пилюлю.
    private const val SR2 = 24000
    private var introPcm: ShortArray? = null
    private var introTrack: AudioTrack? = null

    fun prepIntro() { if (introPcm == null) introPcm = buildIntro() }

    private fun buildIntro(): ShortArray {
        val n = SR2 * 58 / 10
        val b = FloatArray(n)
        val sr = SR2.toFloat()
        fun add(t0: Float, len: Float, f: (Float) -> Float) {
            val i0 = (t0 * sr).toInt(); val m = (len * sr).toInt()
            for (i in 0 until m) { val j = i0 + i; if (j >= n) break; b[j] += f(i / sr) }
        }
        // тоннель
        var seed = 12345; var lp = 0f; var ph = 0.0
        add(0f, 3.2f) { t ->
            seed = seed * 1103515245 + 12345
            val nz = ((seed ushr 16) and 0x7fff) / 16384f - 1f
            val k = 0.02f + 0.30f * (t / 3.2f) * (t / 3.2f)
            lp += (nz - lp) * k
            val env = if (t < 2.3f) (t / 2.3f) * (t / 2.3f) else (1f - (t - 2.3f) / 0.9f).coerceAtLeast(0f).let { it * it }
            ph += 2 * PI * (70.0 + 150.0 * (t / 2.6) * (t / 2.6)) / SR2
            lp * 0.14f * Math.sqrt(((2f - k) / k).toDouble()).toFloat() * env * 0.9f + sin(ph).toFloat() * 0.16f * env
        }
        // зажигание
        add(0f, 0.6f) { t -> sin(2 * PI * 48.0 * t).toFloat() * exp(-t * 7f) * 0.2f }
        // колокольчики на узлах
        val semi = intArrayOf(0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24)
        val hs = IntroPlan.hits
        for (i in hs.indices) {
            val f0 = 440.0 * 2.0.pow(semi[i % semi.size] / 12.0)
            val a = 0.15f - 0.05f * i / hs.size
            add(hs[i] / 1000f, 1.1f) { t ->
                val e = if (t < .004f) t / .004f else 1f
                e * a * (sin(2 * PI * f0 * t).toFloat() * exp(-t * 4.5f) + .4f * sin(2 * PI * f0 * 2.01 * t).toFloat() * exp(-t * 7f) + .18f * sin(2 * PI * f0 * 3.0 * t).toFloat() * exp(-t * 10f))
            }
        }
        // замыкание кольца: удар + аккорд
        var ph2 = 0.0
        add(3.54f, 0.7f) { t ->
            ph2 += 2 * PI * (130.0 * (42.0 / 130.0).pow((t / .35).coerceAtMost(1.0))) / SR2
            sin(ph2).toFloat() * exp(-t * 5f) * 0.75f
        }
        for ((fr, g) in listOf(220.0 to .1f, 329.63 to .09f, 440.0 to .09f, 554.37 to .07f, 659.25 to .06f)) {
            add(3.52f, 2.05f) { t ->
                val e = (if (t < .08f) t / .08f else 1f) * exp(-t * 1.9f) * g
                e * (sin(2 * PI * fr * t).toFloat() + sin(2 * PI * (fr + 0.9) * t).toFloat())
            }
        }
        // посадка в пилюлю
        add(4.20f, 0.25f) { t -> sin(2 * PI * 2637.0 * t).toFloat() * exp(-t * 30f) * 0.12f }
        add(4.27f, 0.25f) { t -> sin(2 * PI * 3136.0 * t).toFloat() * exp(-t * 30f) * 0.09f }
        val out = ShortArray(n)
        for (i in 0 until n) out[i] = (kotlin.math.tanh(b[i] * 1.4f) * 0.8f * 32767f).toInt().toShort()
        return out
    }

    fun playIntro() {
        if (!on) return
        runCatching {
            val d = introPcm ?: return
            stopIntro()
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR2).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(d.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(d, 0, d.size)
            t.play()
            introTrack = t
        }
    }

    fun stopIntro() { runCatching { introTrack?.run { stop(); release() } }; introTrack = null }
}
