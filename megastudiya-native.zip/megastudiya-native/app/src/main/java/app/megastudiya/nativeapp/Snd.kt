package app.megastudiya.nativeapp

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sin

// Тот же «звон», что в v99: низкий удар 210→70 Гц и три тихих обертона. Звук считается один раз.
object Snd {
    var on by mutableStateOf(true)
        private set
    private const val SR = 22050
    private var pcm: ShortArray? = null
    private var last: AudioTrack? = null

    fun init(ctx: Context) {
        on = ctx.getSharedPreferences("ms", Context.MODE_PRIVATE).getBoolean("snd", true)
    }

    fun toggle(ctx: Context) {
        on = !on
        ctx.getSharedPreferences("ms", Context.MODE_PRIVATE).edit().putBoolean("snd", on).apply()
        if (on) play()
    }

    private fun build(): ShortArray {
        val n = (SR * 0.3).toInt()
        val out = ShortArray(n)
        var ph = 0.0
        val parts = arrayOf(doubleArrayOf(1480.0, .03, .22), doubleArrayOf(2310.0, .018, .16), doubleArrayOf(3720.0, .008, .1))
        for (i in 0 until n) {
            val t = i.toDouble() / SR
            val f = if (t < .14) 210.0 * (70.0 / 210.0).pow(t / .14) else 70.0
            ph += 2 * PI * f / SR
            val env = if (t < .004) t / .004 else exp(ln(.0001 / 1.0) * (t - .004) / .176).coerceAtMost(1.0)
            var v = if (t < .2) sin(ph) * .16 * env else 0.0
            for (p in parts) {
                if (t < p[2] + .05) {
                    val e = if (t < .003) t / .003 else exp(ln(.0001) * (t - .003) / (p[2] - .003))
                    v += sin(2 * PI * p[0] * t) * p[1] * e
                }
            }
            out[i] = (v * 3.2 * 32767).coerceIn(-32767.0, 32767.0).toInt().toShort()
        }
        return out
    }

    fun play() {
        if (!on) return
        runCatching {
            val d = pcm ?: build().also { pcm = it }
            last?.release()
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(d.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(d, 0, d.size)
            t.play()
            last = t
        }
    }
}
