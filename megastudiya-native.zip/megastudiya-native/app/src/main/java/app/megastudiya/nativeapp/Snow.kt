package app.megastudiya.nativeapp

import android.graphics.Bitmap
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// СНЕГОПАД. Частицы в три независимых слоя с глубиной (как на кадре-ориентире):
//  • дальний — много мелких тусклых точек, медленно, почти не боковит;
//  • средний — снежинки разной формы (мягкие точки, комки-хлопья, тонкие кристаллы с редкими бликами);
//  • передний — единицы больших расфокусированных «боке» совсем рядом с экраном, быстро и очень прозрачно.
// У каждой частицы своя скорость, размер, прозрачность, фаза и частота бокового качания; ветер общий, плавный, с порывами,
// на слои действует по-разному (передний сильнее). Появление и исчезновение — только за краями и через плавное затухание.
// Спрайты рисуются один раз; кадр — несколько сотен drawBitmap без аллокаций. Качество само снижается, если телефону тяжело.
private const val NB = 110
private const val NM = 50
private const val NF = 12
private const val NT = NB + NM + NF
private val WIND_K = floatArrayOf(0.5f, 1.0f, 2.2f)

private fun ssn(a: Float, b: Float, x: Float): Float { val q = ((x - a) / (b - a)).coerceIn(0f, 1f); return q * q * (3f - 2f * q) }
private fun wa(a: Int, c: Int) = (a shl 24) or (c and 0xFFFFFF)

private fun radial(size: Int, stops: FloatArray, alphas: IntArray): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val cv = android.graphics.Canvas(bmp)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    val c = size / 2f
    p.shader = RadialGradient(c, c, c, IntArray(alphas.size) { wa(alphas[it], 0xFFFFFF) }, stops, Shader.TileMode.CLAMP)
    cv.drawCircle(c, c, c, p)
    return bmp
}

// комок-хлопья: несколько мягких пятен с разбросом, у каждого варианта свой рисунок
private fun flakeSprite(size: Int, seed: Long): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val cv = android.graphics.Canvas(bmp)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    val r = java.util.Random(seed)
    val c = size / 2f
    for (k in 0 until 7) {
        val cx = c + (r.nextFloat() - 0.5f) * size * 0.34f
        val cy = c + (r.nextFloat() - 0.5f) * size * 0.34f
        val rad = size * (0.11f + 0.12f * r.nextFloat())
        p.shader = RadialGradient(cx, cy, rad, intArrayOf(wa(215, 0xFFFFFF), wa(120, 0xFFFFFF), wa(0, 0xFFFFFF)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, rad, p)
    }
    return bmp
}

// тонкий шестилучевой кристалл с боковыми веточками, мягкое свечение вокруг
private fun crystalSprite(size: Int, seed: Long): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val cv = android.graphics.Canvas(bmp)
    val r = java.util.Random(seed)
    val c = size / 2f
    val g = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    g.shader = RadialGradient(c, c, c * 0.55f, intArrayOf(wa(120, 0xFFFFFF), wa(0, 0xFFFFFF)), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
    cv.drawCircle(c, c, c * 0.55f, g)
    val L = c * (0.70f + 0.12f * r.nextFloat())
    val b1 = 0.38f + 0.1f * r.nextFloat(); val b2 = 0.62f + 0.1f * r.nextFloat()
    val l1 = L * (0.26f + 0.08f * r.nextFloat()); val l2 = L * (0.18f + 0.08f * r.nextFloat())
    for (pass in 0 until 2) {
        val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        p.style = android.graphics.Paint.Style.STROKE
        p.strokeCap = android.graphics.Paint.Cap.ROUND
        p.strokeWidth = if (pass == 0) size / 15f else size / 42f
        p.color = wa(if (pass == 0) 38 else 235, 0xFFFFFF)
        for (k in 0 until 6) {
            cv.save()
            cv.rotate(k * 60f + 90f, c, c)
            cv.drawLine(c, c, c, c - L, p)
            for ((f, bl) in listOf(b1 to l1, b2 to l2)) {
                val y = c - L * f
                cv.drawLine(c, y, c - bl * 0.5f, y - bl * 0.87f, p)
                cv.drawLine(c, y, c + bl * 0.5f, y - bl * 0.87f, p)
            }
            cv.restore()
        }
    }
    return bmp
}

private class SnowSprites {
    // 0 мягкая точка, 1 расфокусированное боке, 2–4 хлопья, 5–7 кристаллы
    val all: Array<Bitmap> = arrayOf(
        radial(32, floatArrayOf(0f, 0.28f, 0.62f, 1f), intArrayOf(255, 205, 70, 0)),
        radial(96, floatArrayOf(0f, 0.55f, 0.86f, 1f), intArrayOf(120, 150, 215, 0)),
        flakeSprite(48, 1), flakeSprite(48, 2), flakeSprite(48, 3),
        crystalSprite(72, 11), crystalSprite(72, 12), crystalSprite(72, 13)
    )
}

private class SnowSim {
    var w = 0f; var h = 0f
    var time = 0f
    var act = 1f
    private var lastAct = 0f
    private var ready = false
    private var dens = 3f
    private val rnd = java.util.Random(77)
    private val x = FloatArray(NT); private val y = FloatArray(NT); private val vy = FloatArray(NT)
    private val amp = FloatArray(NT); private val freq = FloatArray(NT); private val ph = FloatArray(NT)
    private val sz = FloatArray(NT); private val a = FloatArray(NT); private val rot = FloatArray(NT); private val rotV = FloatArray(NT)
    private val tw = FloatArray(NT); private val twf = FloatArray(NT); private val pm = FloatArray(NT)
    private val spr = IntArray(NT)
    private val dst = RectF()

    private fun r() = rnd.nextFloat()
    private fun layerStart(l: Int) = if (l == 0) 0 else if (l == 1) NB else NB + NM
    private fun layerN(l: Int) = if (l == 0) NB else if (l == 1) NM else NF
    private fun cnt(l: Int, f: Float) = Math.ceil((layerN(l) * f).toDouble()).toInt().coerceAtMost(layerN(l))

    private fun spawn(i: Int, scatter: Boolean) {
        val l = if (i < NB) 0 else if (i < NB + NM) 1 else 2
        when (l) {
            0 -> { sz[i] = (3.5f + 3.5f * r() * r()) * dens; a[i] = 0.28f + 0.32f * r(); vy[i] = (20f + 18f * r()) * dens; amp[i] = (3f + 6f * r()) * dens; freq[i] = 0.5f + 1.0f * r(); spr[i] = 0 }
            1 -> {
                val q = r()
                if (q < 0.30f) { spr[i] = 0; sz[i] = (6f + 4f * r()) * dens }
                else if (q < 0.70f) { spr[i] = 2 + (r() * 3f).toInt().coerceAtMost(2); sz[i] = (7f + 6f * r()) * dens }
                else { spr[i] = 5 + (r() * 3f).toInt().coerceAtMost(2); sz[i] = (9f + 7f * r()) * dens }
                a[i] = 0.45f + 0.35f * r(); vy[i] = (45f + 40f * r()) * dens; amp[i] = (8f + 14f * r()) * dens; freq[i] = 0.6f + 1.2f * r()
            }
            else -> { sz[i] = (16f + 18f * r() * r()) * dens; a[i] = 0.09f + 0.13f * r(); vy[i] = (120f + 80f * r()) * dens; amp[i] = (10f + 20f * r()) * dens; freq[i] = 0.4f + 0.8f * r(); spr[i] = 1 }
        }
        pm[i] = 0.7f + 0.6f * r(); ph[i] = r() * 6.2832f; rot[i] = r() * 6.2832f; rotV[i] = (r() - 0.5f) * 1.2f
        tw[i] = r() * 6.2832f; twf[i] = 0.6f + 1.6f * r()
        val m = 40f * dens
        if (scatter) { x[i] = r() * w; y[i] = r() * h }
        else { x[i] = -m + r() * (w + 2 * m); y[i] = -sz[i] * 1.5f - r() * h * 0.15f }
    }

    fun step(dt: Float, d: Float) {
        if (w <= 0f || h <= 0f) return
        dens = d
        if (!ready) { for (i in 0 until NT) spawn(i, true); lastAct = act; ready = true }
        time += dt
        if (act > lastAct + 0.01f) { for (l in 0..2) for (i in layerStart(l) + cnt(l, lastAct) until layerStart(l) + cnt(l, act)) spawn(i, false) }
        lastAct = act
        val t = time
        val g = max(0f, sin(0.045f * t))
        val wind = (14f * sin(0.11f * t + 0.5f) + 8f * sin(0.27f * t + 2.1f) + 10f * g * g * g) * dens
        val m = 40f * dens
        for (l in 0..2) {
            val s = layerStart(l)
            for (i in s until s + cnt(l, act)) {
                y[i] += vy[i] * dt
                x[i] += wind * WIND_K[l] * pm[i] * dt
                rot[i] += rotV[i] * dt
                if (y[i] > h + sz[i]) spawn(i, false)
                if (x[i] > w + m) x[i] -= w + 2 * m else if (x[i] < -m) x[i] += w + 2 * m
            }
        }
    }

    fun draw(cv: android.graphics.Canvas, sp: SnowSprites, paint: android.graphics.Paint) {
        if (!ready) return
        val gl = ssn(0f, 1.5f, time)
        for (l in 0..2) {
            val s = layerStart(l)
            for (i in s until s + cnt(l, act)) {
                val sy = y[i]
                val env = ssn(-sz[i], 0.10f * h, sy) * (1f - ssn(0.84f * h, h + 0.5f * sz[i], sy))
                var al = a[i] * env * gl
                if (spr[i] >= 5) { val sv = max(0f, sin(time * twf[i] + tw[i])); val s2 = sv * sv; al *= 1f + 1.4f * s2 * s2 * s2 * s2 * s2 }
                if (al <= 0.01f) continue
                paint.alpha = (min(al, 1f) * 255f).toInt()
                val sx = x[i] + amp[i] * sin(ph[i] + freq[i] * time)
                val d = sz[i] / 2f
                val bmp = sp.all[spr[i]]
                if (spr[i] >= 2) {
                    cv.save()
                    cv.translate(sx, sy)
                    cv.rotate(Math.toDegrees(rot[i].toDouble()).toFloat())
                    dst.set(-d, -d, d, d)
                    cv.drawBitmap(bmp, null, dst, paint)
                    cv.restore()
                } else {
                    dst.set(sx - d, sy - d, sx + d, sy + d)
                    cv.drawBitmap(bmp, null, dst, paint)
                }
            }
        }
    }
}

@Composable
fun SnowLayer(lit: Color) {
    val sim = remember { SnowSim() }
    val sp = remember { SnowSprites() }
    val dens = LocalDensity.current.density
    val paint = remember { android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG) }
    var frame by remember { mutableIntStateOf(0) }
    val fps = if (WxFx.q >= 2) 24 else 30
    val tint = lerp(Color(0xFFD6E4FF), lit, 0.18f).toArgb()
    val cf = remember(tint) { PorterDuffColorFilter(tint, PorterDuff.Mode.SRC_IN) }
    LaunchedEffect(fps) {
        val period = 1000L / fps
        var prev = 0L; var seen = 0; var slow = 0
        while (true) {
            delay(period - 6)
            androidx.compose.runtime.withFrameNanos { n ->
                if (prev != 0L) {
                    sim.act = when (WxFx.q) { 0 -> 1f; 1 -> 0.7f; else -> 0.45f }
                    sim.step(((n - prev) / 1e9f).coerceIn(0.001f, 0.08f), dens)
                    frame++
                    seen++
                    if ((n - prev) / 1_000_000L > period * 9 / 5) slow++
                    if (seen >= 45) {
                        // пятая часть кадров запоздала: телефону тяжело, частиц становится меньше
                        if (slow >= 9 && WxFx.q < 2) WxFx.q = WxFx.q + 1
                        seen = 0; slow = 0
                    }
                }
                prev = n
            }
        }
    }
    Canvas(Modifier.fillMaxSize().onSizeChanged { sim.w = it.width.toFloat(); sim.h = it.height.toFloat() }) {
        if (frame < 0) return@Canvas
        paint.colorFilter = cf
        sim.draw(drawContext.canvas.nativeCanvas, sp, paint)
    }
}
