package app.megastudiya.nativeapp

import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val CBg = Color(0xFF0B0D12)
private val CAcc = Color(0xFF6EA8FF)
private val CMuted = Color(0xFF8B93A5)

@Composable
private fun cFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedBorderColor = CAcc,
    unfocusedBorderColor = Color.White.copy(alpha = 0.25f),
    cursorColor = CAcc
)

// Экран ядра: её состояние, чат (она учится на ваших словах) и очистка памяти
@Composable
fun CoreScreen(onBack: () -> Unit) {
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(2000); tick++ } }
    val msgs = remember { mutableStateListOf<Pair<Boolean, String>>() } // true: говорит она
    var inp by remember { mutableStateOf("") }
    var wait by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf(false) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val sc = rememberScrollState()
    LaunchedEffect(msgs.size) { sc.animateScrollTo(sc.maxValue) }
    fun send() {
        val tx = inp.trim()
        if (tx.isEmpty() || wait) return
        msgs.add(Pair(false, tx))
        inp = ""
        wait = true
        Core.talk(tx) { ans -> Handler(Looper.getMainLooper()).post { msgs.add(Pair(true, ans)); wait = false } }
    }
    Column(Modifier.fillMaxSize().background(CBg).statusBarsPadding().imePadding().navigationBarsPadding().padding(horizontal = 20.dp)) {
        Text("← Назад", color = CAcc, fontSize = 15.sp, modifier = Modifier.clickable { onBack() }.padding(top = 16.dp, bottom = 12.dp))
        Text("Ядро (эмбрион)", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Column(Modifier.weight(1f).verticalScroll(sc)) {
            val t = tick
            Text(Core.report + if (t < 0) "" else "", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
            Text(
                "Чат: пишите ей, она учится на ваших словах (они весят втрое). Пока она лепечет, фразы станут связнее по мере чтения.",
                color = CMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp)
            )
            for ((she, text) in msgs) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = if (she) Arrangement.Start else Arrangement.End) {
                    Box(
                        Modifier.background(if (she) Color(0x337AA8FF) else Color.White.copy(alpha = 0.10f), RoundedCornerShape(16.dp))
                            .padding(horizontal = 14.dp, vertical = 9.dp)
                    ) { Text(text, color = Color.White, fontSize = 15.sp) }
                }
            }
            if (wait) Text("…", color = CMuted, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp))
            val t2 = tick
            Text(
                (if (Core.enabled) "Ядро: включено (нажмите, чтобы выключить)" else "Ядро: выключено (нажмите, чтобы включить)") + if (t2 < 0) "" else "",
                color = CMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 20.dp).clickable { Core.setEnabled(ctx, !Core.enabled); tick++ }
            )
            Text(
                if (Core.mobileOk) "Читать и на мобильном интернете: да (нажмите, чтобы только Wi‑Fi)" else "Читать и на мобильном интернете: нет (нажмите, чтобы разрешить)",
                color = CMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp).clickable { Core.setMobile(ctx, !Core.mobileOk); tick++ }
            )
            Text(
                "Очистить память ядра", color = CMuted, fontSize = 13.sp,
                modifier = Modifier.padding(top = 10.dp, bottom = 8.dp).clickable { dlg = true }
            )
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                colors = cFieldColors(), value = inp, onValueChange = { inp = it }, singleLine = true,
                placeholder = { Text("Скажите ей что-нибудь") }, modifier = Modifier.weight(1f)
            )
            Box(
                Modifier.padding(start = 8.dp).background(Color(0x407AA8FF), RoundedCornerShape(999.dp)).clickable { send() }
                    .padding(horizontal = 18.dp, vertical = 14.dp)
            ) { Text("→", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        }
    }
    if (dlg) {
        AlertDialog(
            onDismissRequest = { dlg = false },
            title = { Text("Очистить память ядра?") },
            text = { Text("Она забудет слова, связи, стратегии и желания и начнёт с нуля. Посты и лента не пострадают.", fontSize = 14.sp) },
            confirmButton = {
                TextButton(onClick = {
                    dlg = false
                    Core.forget { Handler(Looper.getMainLooper()).post { msgs.clear() } }
                }) { Text("Очистить") }
            },
            dismissButton = { TextButton(onClick = { dlg = false }) { Text("Отмена") } }
        )
    }
}
