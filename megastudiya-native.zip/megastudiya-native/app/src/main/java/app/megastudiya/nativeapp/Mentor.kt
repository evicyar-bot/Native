package app.megastudiya.nativeapp

import android.content.Context
import java.io.File
import java.util.concurrent.Executors

// Наставник: внешний ИИ как инструмент, не как её мозг. Работает только если владелец дал свой ключ.
// Ответы наставника она читает и учится на них. Суточный потолок вызовов бережёт деньги владельца.
// Мастерская: проекты, которые она строит, лежат обычными файлами в папке приложения.
object Mentor {
    private const val DAILY = 40
    private const val MODEL = "claude-sonnet-5-5"
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "ms-mentor").apply { isDaemon = true } }

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("ms", Context.MODE_PRIVATE)

    fun hasKey(c: Context) = prefs(c).getString("mentorKey", "").orEmpty().isNotBlank()

    fun setKey(c: Context, k: String): String {
        val t = k.trim()
        if (t.length < 20 || t.contains(" ")) return "Ключ не похож на настоящий."
        prefs(c).edit().putString("mentorKey", t).apply()
        return "Ключ сохранила в памяти приложения. Теперь могу спрашивать наставника: «спроси: …» и «построй: …»."
    }

    fun clearKey(c: Context): String {
        prefs(c).edit().remove("mentorKey").apply()
        return "Ключ удалила."
    }

    // Мастерская
    private fun dir(c: Context) = File(c.filesDir, "workshop").apply { mkdirs() }

    fun projects(c: Context): List<String> = dir(c).listFiles()?.sortedByDescending { it.lastModified() }?.map { it.name.removeSuffix(".md") } ?: emptyList()

    fun open(c: Context, name: String): String? {
        val f = File(dir(c), name.trim().replace(Regex("[^\\p{L}\\p{N}_ -]"), "") + ".md")
        return if (f.exists()) f.readText() else null
    }

    private fun save(c: Context, title: String, body: String): String {
        val slug = title.replace(Regex("[^\\p{L}\\p{N}_ -]"), "").trim().take(50).ifEmpty { "проект" }
        File(dir(c), "$slug.md").writeText(body)
        return slug
    }

    private fun quota(c: Context): Boolean {
        val p = prefs(c)
        val day = (System.currentTimeMillis() / 86_400_000L).toString()
        if (p.getString("mentorDay", "") != day) p.edit().putString("mentorDay", day).putInt("mentorN", 0).apply()
        val n = p.getInt("mentorN", 0)
        if (n >= DAILY) return false
        p.edit().putInt("mentorN", n + 1).apply()
        return true
    }

    // build = true: результат сохраняется проектом в мастерскую
    fun ask(c: Context, prompt: String, build: Boolean, cb: (String) -> Unit) {
        val key = prefs(c).getString("mentorKey", "").orEmpty()
        if (key.isBlank()) { cb("Нужен ключ наставника: «ключ: …». Без него я учусь только сама."); return }
        if (!quota(c)) { cb("На сегодня вызовов наставника хватит ($DAILY). Завтра продолжим."); return }
        io.execute {
            val ans = try { call(key, prompt, build) } catch (e: Throwable) { "Не вышло связаться с наставником: " + (e.message ?: "ошибка").take(120) }
            var out = ans
            if (build && !ans.startsWith("Не вышло")) {
                val title = ans.lineSequence().firstOrNull { it.isNotBlank() }?.trim('#', ' ', '*') ?: "проект"
                val slug = runCatching { save(c, title, ans) }.getOrNull()
                out = (if (slug != null) "Положила в мастерскую: «$slug».\n\n" else "") + ans.take(1200)
            }
            if (!ans.startsWith("Не вышло")) Core.read(listOf(ans.take(3000))) // она учится на ответах наставника
            cb(out)
        }
    }

    private fun call(key: String, prompt: String, build: Boolean): String {
        val sys = if (build)
            "Ты мастерская автономного ядра по имени Аква. Верни проект по запросу: первой строкой название, затем цель, короткий план шагов и нужные файлы или текст. По-русски, ясно, без воды."
        else "Ты наставник автономного ядра по имени Аква. Отвечай по-русски, коротко и по делу."
        val body = org.json.JSONObject()
            .put("model", MODEL).put("max_tokens", if (build) 3000 else 1200).put("system", sys)
            .put("messages", org.json.JSONArray().put(org.json.JSONObject().put("role", "user").put("content", prompt)))
        val c = java.net.URL("https://api.anthropic.com/v1/messages").openConnection() as java.net.HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 90000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream).use { String(it.readBytes(), Charsets.UTF_8) }
            if (code !in 200..299) return "Не вышло: код $code" + if (code == 401) " (ключ не подошёл)" else ""
            val arr = org.json.JSONObject(txt).optJSONArray("content") ?: return "Не вышло: пустой ответ"
            val sb = StringBuilder()
            for (i in 0 until arr.length()) sb.append(arr.getJSONObject(i).optString("text", ""))
            return sb.toString().trim().ifEmpty { "Не вышло: пустой ответ" }
        } finally {
            c.disconnect()
        }
    }
}
