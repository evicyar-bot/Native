package app.megastudiya.nativeapp

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context

// Фоновая жизнь ядра: раз в ~30 минут система будит приложение, и она делает несколько циклов,
// пока приложение закрыто. Только при не низком заряде. Использует тот же дневной запас размышлений.
class CoreJob : JobService() {
    override fun onStartJob(p: JobParameters): Boolean {
        Core.start(applicationContext)
        Core.nightRun { jobFinished(p, false) }
        return true
    }

    override fun onStopJob(p: JobParameters): Boolean = true

    companion object {
        private const val ID = 4711

        fun schedule(ctx: Context) {
            try {
                val js = ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
                if (js.getPendingJob(ID) != null) return
                val info = JobInfo.Builder(ID, ComponentName(ctx, CoreJob::class.java))
                    .setPeriodic(30 * 60 * 1000L)
                    .setRequiresBatteryNotLow(true)
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .build()
                js.schedule(info)
            } catch (_: Throwable) {
            }
        }
    }
}
