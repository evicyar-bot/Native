package app.megastudiya.nativeapp

import android.graphics.Bitmap
import android.graphics.LinearGradient
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

// ЦИКЛ ЗАПУСКА (см. ANIMATIONS.md): тоннель звёзд → звёзды стягиваются в кольцо → официальное кольцо (ms_ring.webp)
// проявляется волной по кругу, узлы вспыхивают (в такт звуку и вибро) → удар, ореол → проявляется слово →
// слово летит в верхнюю пилюлю, кольцо расходится в небо ленты → лента.
// Один раз за запуск процесса, тап пропускает. Приложение под заставкой не рисуется, пока она не передаст эстафету.
object IntroGate {
    var shown = false
    var flying by mutableStateOf(true) // пока заставка несёт логотип к пилюле, логотип самой пилюли скрыт
}

private val IntroBg = Color(0xFF0B0D12)
private val Gold = Color(0xFFFFB84D)
private val Pale = Color(0xFFFFE2AA)

private fun ss(a: Float, b: Float, x: Float): Float { val q = ((x - a) / (b - a)).coerceIn(0f, 1f); return q * q * (3f - 2f * q) }

private fun tunZ(z0: Float, sp: Float, time: Float): Float = (((z0 - time * 3.2f * sp) % 1f) + 1f) % 1f // 1 далеко, 0 рядом

private fun argb(a: Int, r: Int, g: Int, b: Int) = (a shl 24) or (r shl 16) or (g shl 8) or b

// мягкое свечение звезды; spikes — дифракционные лучи у ярких звёзд
private fun glowSprite(size: Int, r: Int, g: Int, b: Int, spikes: Boolean): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val cv = android.graphics.Canvas(bmp)
    val c = size / 2f
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    p.shader = RadialGradient(
        c, c, c,
        intArrayOf(argb(255, 255, 255, 255), argb(235, (r + 255) / 2, (g + 255) / 2, (b + 255) / 2), argb(110, r, g, b), argb(28, r, g, b), argb(0, r, g, b)),
        floatArrayOf(0f, 0.14f, 0.30f, 0.60f, 1f), Shader.TileMode.CLAMP
    )
    cv.drawCircle(c, c, c, p)
    if (spikes) {
        val sp = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        for (k in 0 until 4) {
            val long = k % 2 == 0
            val len = if (long) c else c * 0.55f
            val th = if (long) size * 0.016f else size * 0.011f
            val a0 = if (long) 215 else 110
            sp.shader = LinearGradient(c - len, c, c + len, c, intArrayOf(argb(0, r, g, b), argb(a0, r, g, b), argb(0, r, g, b)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            cv.save()
            cv.rotate(k * 45f, c, c)
            cv.drawRect(c - len, c - th, c + len, c + th, sp)
            cv.restore()
        }
    }
    return bmp
}

// Млечный Путь: розово-красная диагональная полоса с тёмными пылевыми рукавами (рисуется один раз, мелким битмапом)
private fun nebulaBitmap(): Bitmap {
    val w = 180; val h = 320
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val cv = android.graphics.Canvas(bmp)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    val r = java.util.Random(21)
    val cols = arrayOf(intArrayOf(255, 110, 150), intArrayOf(230, 60, 100), intArrayOf(150, 90, 235), intArrayOf(70, 110, 230), intArrayOf(255, 170, 120))
    for (i in 0 until 120) {
        val s = r.nextFloat()
        val off = (r.nextGaussian() * 0.05).toFloat()
        val x = (0.04f + 0.92f * s + off * 0.6f) * w
        val y = (0.94f - 0.88f * s + off * 0.5f) * h
        val rad = (0.06f + 0.15f * r.nextFloat()) * w
        val c = cols[r.nextInt(cols.size)]
        val a = 22 + r.nextInt(40)
        p.shader = RadialGradient(x, y, rad, intArrayOf(argb(a, c[0], c[1], c[2]), argb(0, c[0], c[1], c[2])), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, rad, p)
    }
    for (i in 0 until 26) {
        val s = r.nextFloat()
        val off = (r.nextGaussian() * 0.035).toFloat()
        val x = (0.06f + 0.88f * s + off * 0.6f) * w
        val y = (0.92f - 0.84f * s + off * 0.5f) * h
        val rad = (0.03f + 0.06f * r.nextFloat()) * w
        p.shader = RadialGradient(x, y, rad, intArrayOf(argb(60 + r.nextInt(40), 0, 0, 4), argb(0, 0, 0, 4)), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, rad, p)
    }
    return bmp
}

private val REAL = arrayOf(intArrayOf(170, 190, 255), intArrayOf(235, 240, 255), intArrayOf(255, 238, 200), intArrayOf(255, 205, 150), intArrayOf(255, 165, 125))
private val BRAND = arrayOf(intArrayOf(255, 184, 77), intArrayOf(255, 226, 170), intArrayOf(120, 160, 255), intArrayOf(205, 200, 215))

private class Sprites {
    val real = Array(5) { glowSprite(64, REAL[it][0], REAL[it][1], REAL[it][2], false) }
    val realSp = Array(5) { glowSprite(128, REAL[it][0], REAL[it][1], REAL[it][2], true) }
    val brand = Array(4) { glowSprite(64, BRAND[it][0], BRAND[it][1], BRAND[it][2], false) }
    val hub = glowSprite(160, 255, 200, 110, true)
    val dust = glowSprite(24, 235, 240, 255, false)
    val neb = nebulaBitmap()
}

private class SpriteDrawer {
    val add = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG).also { it.xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD) }
    val plain = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
    val dst = RectF()
    // спрайт растягивается вдоль движения: у летящей звезды получается светящийся хвост без дорогих штрихов
    fun draw(cv: android.graphics.Canvas, bmp: Bitmap, x: Float, y: Float, len: Float, th: Float, deg: Float, alpha: Float) {
        val a = (alpha * 255f).toInt()
        if (a <= 2) return
        add.alpha = if (a > 255) 255 else a
        cv.save()
        cv.translate(x, y)
        if (deg != 0f) cv.rotate(deg)
        dst.set(-len / 2f, -th / 2f, len / 2f, th / 2f)
        cv.drawBitmap(bmp, null, dst, add)
        cv.restore()
    }
}

// Раскладка заставки, общая для картинки, звука и вибро: узлы-звёзды на кольце (x, y в долях картинки, доля обхода от верха
// по часовой, размер вспышки). Время вспышки узла считается отсюда, поэтому звук и вибро идут строго в такт.
internal object IntroPlan {
    const val TOTAL_MS = 3400
    val nodes: Array<FloatArray> by lazy {
        arrayOf(
            floatArrayOf(742f, 106f, 0.8f), floatArrayOf(872f, 254f, 1.0f), floatArrayOf(948f, 419f, 0.7f), floatArrayOf(1077f, 530f, 0.65f),
            floatArrayOf(996f, 712f, 0.9f), floatArrayOf(1079f, 803f, 0.6f), floatArrayOf(777f, 1003f, 1.0f), floatArrayOf(369f, 918f, 0.9f),
            floatArrayOf(271f, 548f, 1.0f), floatArrayOf(160f, 466f, 0.65f), floatArrayOf(453f, 252f, 1.0f)
        ).map {
            val nx = it[0] / 1254f; val ny = it[1] / 1254f
            var f = (Math.atan2((nx - 0.5f).toDouble(), -(ny - 0.5f).toDouble()) / (2 * Math.PI)).toFloat()
            if (f < 0f) f += 1f
            floatArrayOf(nx, ny, f, it[2])
        }.sortedBy { it[2] }.toTypedArray()
    }
    // момент (мс), когда фронт проявления доходит до узла с долей обхода frac
    fun ms(frac: Float): Float = (0.52f + 0.28f * ((frac + 0.03f) / 1.06f).coerceAtMost(1f)) * TOTAL_MS
}

@Composable
fun StarIntro(onReveal: () -> Unit, onDone: () -> Unit) {
    val t = remember { Animatable(0f) }
    var skip by remember { mutableStateOf(false) }
    var boxH by remember { mutableStateOf(0) }
    val dens = LocalDensity.current
    val topInset = WindowInsets.statusBars.getTop(dens)
    val ring = ImageBitmap.imageResource(R.drawable.ms_ring)
    val n = 90
    // на звезду: угол, задержка схода, стартовая глубина, скорость, величина
    val rnd = remember { val r = java.util.Random(5); FloatArray(n * 5) { r.nextFloat() } }
    val ca = remember { FloatArray(n) { Math.cos(rnd[it * 5] * 6.2832).toFloat() } }
    val sa = remember { FloatArray(n) { Math.sin(rnd[it * 5] * 6.2832).toFloat() } }
    // место звезды на кольце: угол от +x по часовой, разброс по ширине полосы, доля обхода от верха
    val ang = remember { FloatArray(n) { (it + rnd[it * 5 + 1] * 0.8f) / n * 6.2832f } }
    val rr = remember { FloatArray(n) { 0.95f + 0.10f * rnd[it * 5 + 4] } }
    val fr = remember { FloatArray(n) { (ang[it] / 6.2832f + 0.25f) % 1f } }
    val tc = remember { val r = java.util.Random(9); IntArray(n) { val q = r.nextFloat(); when { q < 0.12f -> 0; q < 0.42f -> 1; q < 0.70f -> 2; q < 0.90f -> 3; else -> 4 } } }
    val dust = remember { val r = java.util.Random(13); FloatArray(130 * 4) { r.nextFloat() } }
    val spr = remember { Sprites() }
    val drawer = remember { SpriteDrawer() }
    val maskPaint = remember { Paint() }

    LaunchedEffect(Unit) {
        IntroGate.flying = true
        withContext(Dispatchers.Default) { Snd.prepIntro() }
        if (!skip) {
            Snd.playIntro(); Hap.intro()
            t.animateTo(1f, tween(IntroPlan.TOTAL_MS, easing = LinearEasing))
            IntroGate.flying = false
            onDone()
        }
    }
    LaunchedEffect(Unit) {
        snapshotFlow { t.value >= 0.80f }.first { it }
        onReveal()
    }
    LaunchedEffect(skip) {
        if (skip) {
            Snd.stopIntro(); Hap.cancel(); Hap.click()
            onReveal()
            t.animateTo(1f, tween(260, easing = LinearEasing))
            IntroGate.flying = false
            onDone()
        }
    }
    Box(
        Modifier.fillMaxSize()
            .onSizeChanged { boxH = it.height }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent()
                        e.changes.forEach { it.consume() }
                        if (e.changes.any { !it.pressed && it.previousPressed }) skip = true
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxSize().graphicsLayer { alpha = 1f - ss(0.86f, 1f, t.value) }.background(IntroBg))
        Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = 1f - ss(0.86f, 1f, t.value) }) {
            val tt = t.value
            val cv = drawContext.canvas.nativeCanvas
            val w = size.width; val h = size.height
            val cx = w / 2f; val cy = h / 2f
            val c = Offset(cx, cy)
            val base = minOf(w, h * 0.62f)
            val sz0 = 0.94f * base                      // сторона картинки кольца
            val maxR = Math.hypot(cx.toDouble(), cy.toDouble()).toFloat() * 1.1f
            val ex = ss(0.84f, 1f, tt)
            val sE = 1f + 0.45f * ex                    // в конце кольцо расходится в небо
            val phi = 0.30f * ss(0.20f, 1f, tt)         // медленный поворот
            val deg = Math.toDegrees(phi.toDouble()).toFloat()
            val cp = Math.cos(phi.toDouble()).toFloat(); val sp = Math.sin(phi.toDouble()).toFloat()
            val rp = ((tt - 0.52f) / 0.28f).coerceIn(0f, 1f) // проявление кольца
            val head = rp * 1.06f                       // фронт, доли обхода от верха по часовой
            val ringR = 0.385f * sz0 * sE

            // 1) Млечный Путь: летим сквозь него, потом он гаснет
            val nebA = (1f - ss(0.30f, 0.72f, tt)) * 0.9f
            if (nebA > 0.01f) {
                val z = 1f + 0.35f * ss(0f, 0.7f, tt)
                drawer.dst.set(cx - w * z / 2f, cy - h * z / 2f, cx + w * z / 2f, cy + h * z / 2f)
                drawer.plain.alpha = (nebA * 255f).toInt()
                cv.drawBitmap(spr.neb, null, drawer.dst, drawer.plain)
            }
            // 2) далёкая звёздная пыль для глубины
            val dustA = (1f - 0.6f * ss(0.4f, 0.8f, tt)) * (1f - ex)
            for (k in 0 until 130) {
                val px = cx + (dust[k * 4] * w - cx) * (1f + 0.25f * tt)
                val py = cy + (dust[k * 4 + 1] * h - cy) * (1f + 0.25f * tt)
                val s = (2f + dust[k * 4 + 2] * 5f) * density
                val tw = 0.6f + 0.4f * Math.sin((tt * 18f + dust[k * 4 + 3] * 6.28f).toDouble()).toFloat()
                drawer.draw(cv, spr.dust, px, py, s, s, 0f, 0.55f * tw * dustA)
            }
            // 3) звёзды: тоннель → точки на окружности кольца; гаснут, когда фронт проявления доходит до их места
            for (i in 0 until n) {
                val gone = 1f - ss(fr[i] - 0.03f, fr[i] + 0.05f, head)
                if (gone <= 0f) continue
                val a = ang[i] + phi
                val tx = cx + Math.cos(a.toDouble()).toFloat() * ringR * rr[i]
                val ty = cy + Math.sin(a.toDouble()).toFloat() * ringR * rr[i]
                val dl = rnd[i * 5 + 1]
                val u = ss(0.22f + 0.14f * dl, 0.52f + 0.12f * dl, tt)
                val z0 = rnd[i * 5 + 2]; val spd = 0.7f + 0.6f * rnd[i * 5 + 3]; val mag = rnd[i * 5 + 4]
                val z = tunZ(z0, spd, tt); val zp = tunZ(z0, spd, tt - 0.016f)
                val r1 = (1f - z) * (1f - z) * maxR; val r0 = (1f - zp) * (1f - zp) * maxR
                val x1 = cx + ca[i] * r1; val y1 = cy + sa[i] * r1
                val x0 = cx + ca[i] * r0; val y0 = cy + sa[i] * r0
                val px1 = x1 + (tx - x1) * u; val py1 = y1 + (ty - y1) * u
                val px0 = x0 + (tx - x0) * u; val py0 = y0 + (ty - y0) * u
                val near = 1f - z
                val tunA = (1.15f * near + 0.12f).coerceIn(0f, 1f)
                val sT = (3f + near * near * 16f) * (0.55f + 0.9f * mag) * density
                val sR = (5f + 5f * mag) * density
                val size = sT + (sR - sT) * u
                val dx = px1 - px0; val dy = py1 - py0
                val trail = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
                val len = size + trail * 1.4f
                val dg = if (trail > 0.5f) Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble())).toFloat() else 0f
                val mx = (px1 + px0) / 2f; val my = (py1 + py0) / 2f
                if (u < 0.5f) {
                    val sprite = if (mag > 0.88f && near > 0.25f) spr.realSp[tc[i]] else spr.real[tc[i]]
                    drawer.draw(cv, sprite, mx, my, len, size, dg, tunA * (1f - u * 0.9f) * gone)
                } else {
                    val tw = if (u > 0.98f) 0.82f + 0.18f * Math.sin((tt * 26f + i).toDouble()).toFloat() else 1f
                    drawer.draw(cv, spr.brand[tc[i] % 4], mx, my, len, size, dg, (tunA + (0.9f - tunA) * u) * tw * gone)
                }
            }
            // 4) официальное кольцо: проявляется волной по кругу (мягкий фронт), потом дышит
            if (head > 0.002f) {
                val sz = (sz0 * sE).toInt()
                val off = IntOffset((cx - sz / 2f).toInt(), (cy - sz / 2f).toInt())
                val dsz = IntSize(sz, sz)
                val breathe = 0.92f + 0.08f * Math.sin((tt * 14f).toDouble()).toFloat()
                rotate(deg, c) {
                    if (rp < 1f) {
                        val b0 = Rect(off.x.toFloat(), off.y.toFloat(), (off.x + sz).toFloat(), (off.y + sz).toFloat())
                        val a1 = (head - 0.07f).coerceAtLeast(0.0001f)
                        val b1 = head.coerceAtMost(1f)
                        drawIntoCanvas { cnv ->
                            cnv.saveLayer(b0, maskPaint)
                            drawImage(ring, dstOffset = off, dstSize = dsz, alpha = breathe)
                            rotate(-90f, c) {
                                drawRect(
                                    brush = Brush.sweepGradient(0f to Color.White, a1 to Color.White, b1 to Color.Transparent, 1f to Color.Transparent, center = c),
                                    topLeft = b0.topLeft, size = b0.size, blendMode = BlendMode.DstIn
                                )
                            }
                            cnv.restore()
                        }
                    } else {
                        drawImage(ring, dstOffset = off, dstSize = dsz, alpha = breathe)
                    }
                    // вспышка при замыкании кольца (ореол)
                    val pulse = ss(0.78f, 0.81f, tt) * (1f - ss(0.81f, 0.89f, tt))
                    if (pulse > 0f) drawImage(ring, dstOffset = off, dstSize = dsz, alpha = 0.6f * pulse, blendMode = BlendMode.Plus)
                }
                // «орбитальный призрак»: вторая копия, медленно вращается навстречу, добавляет нитей и глубины
                val ghost = 0.30f * ss(0.78f, 0.92f, tt)
                if (ghost > 0f) rotate(-1.6f * deg - 4f * (tt - 0.78f), c) {
                    scale(1.035f, c) { drawImage(ring, dstOffset = off, dstSize = dsz, alpha = ghost, blendMode = BlendMode.Plus) }
                }
            }
            // 5) узлы-звёзды вспыхивают, когда фронт доходит до них, и пускают сигнал; потом мерцают
            val nodes = IntroPlan.nodes
            for (k in nodes.indices) {
                val nd = nodes[k]
                val lit = ((head - 0.03f - nd[2]) / 0.05f).coerceIn(0f, 1f)
                if (lit <= 0f) continue
                val dx = (nd[0] - 0.5f) * sz0 * sE; val dy = (nd[1] - 0.5f) * sz0 * sE
                val px = cx + dx * cp - dy * sp; val py = cy + dx * sp + dy * cp
                val tw = if (rp >= 1f) 0.8f + 0.2f * Math.sin((tt * 22f + k * 1.7f).toDouble()).toFloat() else 1f
                val hs = sz0 * 0.20f * nd[3] * (0.5f + 0.5f * lit) * sE
                drawer.draw(cv, spr.hub, px, py, hs, hs, 0f, lit * tw)
                val pp = ((head - 0.03f - nd[2]) * 6f).coerceIn(0f, 1f)
                if (pp > 0f && pp < 1f) drawCircle(Gold.copy(alpha = 0.5f * (1f - pp)), radius = sz0 * (0.012f + 0.06f * pp), center = Offset(px, py), style = Stroke(width = (0.004f * sz0).coerceAtLeast(1f)))
            }
        }
        // слово проявляется в центре кольца, затем летит в верхнюю пилюлю
        Image(
            painterResource(R.drawable.ms_logo),
            contentDescription = null,
            modifier = Modifier.size(150.dp, 38.dp).graphicsLayer {
                val a = ss(0.74f, 0.90f, t.value)
                val e = ss(0.84f, 1f, t.value)
                val targetY = topInset + 33.5f * dens.density
                translationY = e * (targetY - boxH / 2f)
                val s = (1f - e * (1f - 106f / 150f)) * (0.9f + 0.1f * a)
                scaleX = s; scaleY = s
                alpha = a
            }
        )
    }
}
