package app.megastudiya.nativeapp

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

// Заставка: звёзды летят тоннелем, сходятся в кольцо из иконки (тысячи маленьких устройств в одну систему),
// узлы загораются и связываются дугами, в центре проявляется логотип. Один раз за запуск процесса, тап пропускает.
object IntroGate { var shown = false }

private val IntroBg = Color(0xFF0B0D12)
private val Gold = Color(0xFFFFB84D)
private val Pale = Color(0xFFFFE2AA)
private val Blue = Color(0xFF78A0FF)
private val Neb = Color(0xFF2850BE)
private val Core = Color(0xFFFFF6DE)
private val Pink = Color(0xFFFF9EC4)

private fun ss(a: Float, b: Float, x: Float): Float { val q = ((x - a) / (b - a)).coerceIn(0f, 1f); return q * q * (3f - 2f * q) }

// точка сетки иконки (108×108) -> экран, с поворотом кольца
private fun ringPt(x: Float, y: Float, cx: Float, cy: Float, sc: Float, cp: Float, sp: Float): Offset {
    val dx = (x - 54f) * sc; val dy = (y - 54f) * sc
    return Offset(cx + dx * cp - dy * sp, cy + dx * sp + dy * cp)
}

private fun tunPos(ca: Float, sa: Float, z0: Float, sp: Float, time: Float, cx: Float, cy: Float, maxR: Float): Offset {
    val z = (((z0 - time * 3.2f * sp) % 1f) + 1f) % 1f // 1 далеко, 0 рядом
    val r = (1f - z) * (1f - z) * maxR
    return Offset(cx + ca * r, cy + sa * r)
}

private fun tunZ(z0: Float, sp: Float, time: Float): Float = (((z0 - time * 3.2f * sp) % 1f) + 1f) % 1f

@Composable
fun StarIntro(onDone: () -> Unit) {
    val t = remember { Animatable(0f) }
    var skip by remember { mutableStateOf(false) }
    val n = RingData.dots.size / 5
    val rnd = remember {
        val r = java.util.Random(5)
        FloatArray(n * 5) { i ->
            when (i % 5) {
                0 -> { r.nextFloat() } // угол: сохраняем как [0,1), cos/sin считаем ниже
                else -> r.nextFloat()
            }
        }
    }
    val ca = remember { FloatArray(n) { Math.cos(rnd[it * 5] * 6.2832).toFloat() } }
    val sa = remember { FloatArray(n) { Math.sin(rnd[it * 5] * 6.2832).toFloat() } }
    LaunchedEffect(Unit) {
        t.animateTo(1f, tween(3300, easing = LinearEasing))
        onDone()
    }
    LaunchedEffect(skip) {
        if (skip) { t.animateTo(1f, tween(220, easing = LinearEasing)); onDone() }
    }
    Box(
        Modifier.fillMaxSize()
            .graphicsLayer { alpha = 1f - ss(0.90f, 1f, t.value) }
            .background(IntroBg)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent()
                        e.changes.forEach { it.consume() }
                        if (e.changes.any { !it.pressed && it.previousPressed }) skip = true
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val tt = t.value
            val w = size.width; val h = size.height
            val cx = w / 2f; val cy = h / 2f
            val base = minOf(w, h * 0.62f)
            val sc = 0.36f * base / 28f
            val maxR = Math.hypot(cx.toDouble(), cy.toDouble()).toFloat() * 1.1f
            val phi = 0.38f * ss(0.20f, 1f, tt)
            val cp = Math.cos(phi.toDouble()).toFloat(); val sp = Math.sin(phi.toDouble()).toFloat()
            val nb = ss(0.50f, 0.80f, tt)
            val nl = ss(0.72f, 0.92f, tt)
            val c = Offset(cx, cy)

            // туманность и тонкие орбиты кольца
            if (nb > 0f) {
                for ((wd, al) in listOf(16f to 0.05f, 11f to 0.07f, 7f to 0.09f, 4f to 0.10f))
                    drawCircle(Neb.copy(alpha = al * nb), radius = 28f * sc, center = c, style = Stroke(width = wd * sc))
                for ((rr, al) in listOf(33.2f to 0.28f, 29.5f to 0.22f, 22.5f to 0.20f, 8.5f to 0.22f))
                    drawCircle(Gold.copy(alpha = al * nb), radius = rr * sc, center = c, style = Stroke(width = (0.22f * sc).coerceAtLeast(1f)))
            }
            // связи между соседними точками
            if (nl > 0f) {
                val ne = RingData.net
                var i = 0
                while (i < ne.size) {
                    drawLine(Gold.copy(alpha = 0.38f * nl), ringPt(ne[i], ne[i + 1], cx, cy, sc, cp, sp), ringPt(ne[i + 2], ne[i + 3], cx, cy, sc, cp, sp), strokeWidth = (0.16f * sc).coerceAtLeast(1f))
                    i += 4
                }
                val ch = RingData.chords
                i = 0
                while (i < ch.size) {
                    val a = ringPt(ch[i], ch[i + 1], cx, cy, sc, cp, sp); val m = ringPt(ch[i + 2], ch[i + 3], cx, cy, sc, cp, sp); val b = ringPt(ch[i + 4], ch[i + 5], cx, cy, sc, cp, sp)
                    drawLine(Gold.copy(alpha = 0.28f * nl), a, m, strokeWidth = (0.14f * sc).coerceAtLeast(1f))
                    drawLine(Gold.copy(alpha = 0.28f * nl), m, b, strokeWidth = (0.14f * sc).coerceAtLeast(1f))
                    i += 6
                }
            }
            // звёзды -> точки кольца
            val d = RingData.dots
            for (i in 0 until n) {
                val tx = d[i * 5]; val ty = d[i * 5 + 1]; val rd = d[i * 5 + 2]; val ci = d[i * 5 + 3].toInt(); val fa = d[i * 5 + 4]
                val tgt = ringPt(tx, ty, cx, cy, sc, cp, sp)
                val dl = rnd[i * 5 + 1]
                val u0 = ss(0.26f + 0.14f * dl, 0.58f + 0.14f * dl, tt)
                val u = u0 * u0 * (3f - 2f * u0)
                val z0 = rnd[i * 5 + 2]; val spd = 0.7f + 0.6f * rnd[i * 5 + 3]
                val p1 = tunPos(ca[i], sa[i], z0, spd, tt, cx, cy, maxR)
                val p0 = tunPos(ca[i], sa[i], z0, spd, tt - 0.02f, cx, cy, maxR)
                val pos = Offset(p1.x + (tgt.x - p1.x) * u, p1.y + (tgt.y - p1.y) * u)
                val pre = Offset(p0.x + (tgt.x - p0.x) * u, p0.y + (tgt.y - p0.y) * u)
                val z = tunZ(z0, spd, tt)
                val tunA = (1.2f * (1f - z)).coerceIn(0f, 1f)
                val base0 = when { ci == 2 -> Blue; ci == 1 -> Pale; i % 5 == 0 -> Pink; else -> Gold }
                val col = if (u < 0.5f) base0 else if (ci == 0) Gold else base0
                val tw = if (u > 0.98f) 0.82f + 0.18f * Math.sin((tt * 26f + i).toDouble()).toFloat() else 1f
                val a = (tunA + (fa - tunA) * u) * tw
                if (u < 0.995f) {
                    val wTun = (0.8f + (1f - z) * 2.4f) * density
                    val wEnd = (2f * rd * sc).coerceAtLeast(1.2f)
                    drawLine(col.copy(alpha = a.coerceIn(0f, 1f)), pre, pos, strokeWidth = wTun + (wEnd - wTun) * u, cap = StrokeCap.Round)
                } else drawCircle(col.copy(alpha = a.coerceIn(0f, 1f)), radius = (rd * sc).coerceAtLeast(0.7f), center = pos)
            }
            // дуги между узлами рисуются по кругу
            val pa = ss(0.58f, 0.84f, tt)
            if (pa > 0f) {
                val ar = RingData.arcs
                var i = 0
                while (i < ar.size) {
                    var prev = ringPt(ar[i], ar[i + 1], cx, cy, sc, cp, sp)
                    for (j in 1..12) {
                        val a0 = (j - 1) / 12f
                        if (a0 >= pa) break
                        val q = minOf(j / 12f, pa); val m = 1f - q
                        val qx = m * m * ar[i] + 2f * m * q * ar[i + 2] + q * q * ar[i + 4]
                        val qy = m * m * ar[i + 1] + 2f * m * q * ar[i + 3] + q * q * ar[i + 5]
                        val cur = ringPt(qx, qy, cx, cy, sc, cp, sp)
                        drawLine(Pale.copy(alpha = 0.75f), prev, cur, strokeWidth = (0.3f * sc).coerceAtLeast(1.2f), cap = StrokeCap.Round)
                        prev = cur
                    }
                    i += 6
                }
            }
            // узлы загораются по очереди, от каждого уходит волна сигнала
            val hb = RingData.hubs
            for (k in 0 until hb.size / 2) {
                val lit = ss(0.60f + 0.015f * k, 0.68f + 0.015f * k, tt)
                if (lit <= 0f) continue
                val hp = ringPt(hb[k * 2], hb[k * 2 + 1], cx, cy, sc, cp, sp)
                for ((rr, al) in listOf(4.6f to 0.10f, 3.3f to 0.18f, 2.2f to 0.32f))
                    drawCircle(Gold.copy(alpha = al * lit), radius = rr * sc * (0.6f + 0.4f * lit), center = hp)
                drawCircle(Core.copy(alpha = lit), radius = 1.25f * sc * (1f + 0.5f * (1f - lit)), center = hp)
                val L = 3.8f * sc
                drawLine(Pale.copy(alpha = 0.8f * lit), Offset(hp.x - L, hp.y), Offset(hp.x + L, hp.y), strokeWidth = (0.22f * sc).coerceAtLeast(1f))
                drawLine(Pale.copy(alpha = 0.8f * lit), Offset(hp.x, hp.y - L), Offset(hp.x, hp.y + L), strokeWidth = (0.22f * sc).coerceAtLeast(1f))
                if (k % 3 == 0) drawCircle(Gold.copy(alpha = 0.7f * lit), radius = 5.6f * sc, center = hp, style = Stroke(width = (0.3f * sc).coerceAtLeast(1f)))
                val pp = ((tt - 0.64f - 0.015f * k) * 2.4f).coerceIn(0f, 1f)
                if (pp > 0f && pp < 1f) drawCircle(Gold.copy(alpha = 0.5f * (1f - pp)), radius = sc * (2f + 9f * pp), center = hp, style = Stroke(width = (0.25f * sc).coerceAtLeast(1f)))
            }
        }
        Image(
            painterResource(R.drawable.ms_logo),
            contentDescription = null,
            modifier = Modifier.size(150.dp, 38.dp).graphicsLayer {
                val a = ss(0.70f, 0.88f, t.value)
                alpha = a
                scaleX = 0.9f + 0.1f * a; scaleY = scaleX
            }
        )
    }
}
