package app.megastudiya.nativeapp

import android.graphics.Bitmap
import android.graphics.LinearGradient
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

// ЗАПУСК (см. ANIMATIONS.md): полёт сквозь объёмное звёздное поле (настоящая перспектива, камера вперёд по Z: старт медленно →
// ускорение с радиальными следами → плавное торможение). Часть звёзд по одной отрывается от поля и по своим кривым летит
// в узлы официального кольца; каждая прилетевшая звезда зажигает свой участок, и нити прорисовываются независимо
// (у каждого участка свой старт, направление, скорость). В конце всё сплавляется в целое кольцо → слово → пилюля.
// Один раз за запуск процесса, тап пропускает. Приложение под заставкой не рисуется, пока она не передаст эстафету.
object IntroGate {
    var shown = false
    var flying by mutableStateOf(true) // пока заставка несёт логотип к пилюле, логотип самой пилюли скрыт
}

private val IntroBg = Color(0xFF0B0D12)
private val Gold = Color(0xFFFFB84D)
private val Pale = Color(0xFFFFE2AA)

private fun ss(a: Float, b: Float, x: Float): Float { val q = ((x - a) / (b - a)).coerceIn(0f, 1f); return q * q * (3f - 2f * q) }

private fun tunZ(z0: Float, sp: Float, time: Float): Float = (((z0 - time * 3.2f * sp) % 1f) + 1f) % 1f // 1 далеко, 0 рядом

private fun argb(a: Int, r: Int, g: Int, b: Int) = (a shl 24) or (r shl 16) or (g shl 8) or b

// мягкое свечение звезды; spikes — дифракционные лучи у ярких звёзд
private fun glowSprite(size: Int, r: Int, g: Int, b: Int, spikes: Boolean): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val cv = android.graphics.Canvas(bmp)
    val c = size / 2f
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    p.shader = RadialGradient(
        c, c, c,
        intArrayOf(argb(255, 255, 255, 255), argb(235, (r + 255) / 2, (g + 255) / 2, (b + 255) / 2), argb(110, r, g, b), argb(28, r, g, b), argb(0, r, g, b)),
        floatArrayOf(0f, 0.14f, 0.30f, 0.60f, 1f), Shader.TileMode.CLAMP
    )
    cv.drawCircle(c, c, c, p)
    if (spikes) {
        val sp = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        for (k in 0 until 4) {
            val long = k % 2 == 0
            val len = if (long) c else c * 0.55f
            val th = if (long) size * 0.016f else size * 0.011f
            val a0 = if (long) 215 else 110
            sp.shader = LinearGradient(c - len, c, c + len, c, intArrayOf(argb(0, r, g, b), argb(a0, r, g, b), argb(0, r, g, b)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            cv.save()
            cv.rotate(k * 45f, c, c)
            cv.drawRect(c - len, c - th, c + len, c + th, sp)
            cv.restore()
        }
    }
    return bmp
}

// Млечный Путь: розово-красная диагональная полоса с тёмными пылевыми рукавами (рисуется один раз, мелким битмапом)
private fun nebulaBitmap(): Bitmap {
    val w = 180; val h = 320
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val cv = android.graphics.Canvas(bmp)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    val r = java.util.Random(21)
    val cols = arrayOf(intArrayOf(255, 110, 150), intArrayOf(230, 60, 100), intArrayOf(150, 90, 235), intArrayOf(70, 110, 230), intArrayOf(255, 170, 120))
    for (i in 0 until 120) {
        val s = r.nextFloat()
        val off = (r.nextGaussian() * 0.05).toFloat()
        val x = (0.04f + 0.92f * s + off * 0.6f) * w
        val y = (0.94f - 0.88f * s + off * 0.5f) * h
        val rad = (0.06f + 0.15f * r.nextFloat()) * w
        val c = cols[r.nextInt(cols.size)]
        val a = 22 + r.nextInt(40)
        p.shader = RadialGradient(x, y, rad, intArrayOf(argb(a, c[0], c[1], c[2]), argb(0, c[0], c[1], c[2])), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, rad, p)
    }
    for (i in 0 until 26) {
        val s = r.nextFloat()
        val off = (r.nextGaussian() * 0.035).toFloat()
        val x = (0.06f + 0.88f * s + off * 0.6f) * w
        val y = (0.92f - 0.84f * s + off * 0.5f) * h
        val rad = (0.03f + 0.06f * r.nextFloat()) * w
        p.shader = RadialGradient(x, y, rad, intArrayOf(argb(60 + r.nextInt(40), 0, 0, 4), argb(0, 0, 0, 4)), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, rad, p)
    }
    return bmp
}

// маленькая спиральная галактика: золотое ядро и два голубоватых рукава из мягких пятен
private fun spiralSprite(size: Int): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val cv = android.graphics.Canvas(bmp)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    val c = size / 2f
    for (arm in 0 until 2) for (i in 0 until 46) {
        val q = i / 46f
        val a = arm * Math.PI + q * 5.2
        val r = q * c * 0.86f
        val x = c + (Math.cos(a) * r).toFloat(); val y = c + (Math.sin(a) * r).toFloat()
        val rad = c * (0.07f + 0.07f * (1f - q))
        p.shader = RadialGradient(x, y, rad, intArrayOf(argb((150 * (1f - q * 0.7f)).toInt(), 170, 190, 255), argb(0, 170, 190, 255)), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, rad, p)
    }
    p.shader = RadialGradient(c, c, c * 0.34f, intArrayOf(argb(255, 255, 225, 160), argb(120, 255, 190, 100), argb(0, 255, 190, 100)), floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
    cv.drawCircle(c, c, c * 0.34f, p)
    return bmp
}

private val REAL = arrayOf(intArrayOf(170, 190, 255), intArrayOf(235, 240, 255), intArrayOf(255, 238, 200), intArrayOf(255, 205, 150), intArrayOf(255, 165, 125))
private val BRAND = arrayOf(intArrayOf(255, 184, 77), intArrayOf(255, 226, 170), intArrayOf(120, 160, 255), intArrayOf(205, 200, 215))

private class Sprites {
    val real = Array(5) { glowSprite(64, REAL[it][0], REAL[it][1], REAL[it][2], false) }
    val realSp = Array(5) { glowSprite(128, REAL[it][0], REAL[it][1], REAL[it][2], true) }
    val brand = Array(4) { glowSprite(64, BRAND[it][0], BRAND[it][1], BRAND[it][2], false) }
    val hub = glowSprite(160, 255, 200, 110, true)
    val dust = glowSprite(24, 235, 240, 255, false)
    val ice = glowSprite(64, 70, 160, 255, false)     // голубое тело следа
    val galE = glowSprite(64, 255, 205, 130, false)   // далёкая эллиптическая галактика (растягивается спрайтом)
    val galS = spiralSprite(64)                       // далёкая спираль
}

private class SpriteDrawer {
    val add = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG).also { it.xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD) }
    val plain = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
    val dst = RectF()
    // спрайт растягивается вдоль движения: у летящей звезды получается светящийся хвост без дорогих штрихов
    fun draw(cv: android.graphics.Canvas, bmp: Bitmap, x: Float, y: Float, len: Float, th: Float, deg: Float, alpha: Float) {
        val a = (alpha * 255f).toInt()
        if (a <= 2) return
        add.alpha = if (a > 255) 255 else a
        cv.save()
        cv.translate(x, y)
        if (deg != 0f) cv.rotate(deg)
        dst.set(-len / 2f, -th / 2f, len / 2f, th / 2f)
        cv.drawBitmap(bmp, null, dst, add)
        cv.restore()
    }
}

// Раскладка заставки, общая для картинки, звука и вибро.
// Узлы-звёзды на кольце: x, y (доли картинки), доля обхода от верха по часовой, размер вспышки.
internal object IntroPlan {
    const val TOTAL_MS = 4400
    val nodes: Array<FloatArray> by lazy {
        arrayOf(
            floatArrayOf(742f, 106f, 0.8f), floatArrayOf(872f, 254f, 1.0f), floatArrayOf(948f, 419f, 0.7f), floatArrayOf(1077f, 530f, 0.65f),
            floatArrayOf(996f, 712f, 0.9f), floatArrayOf(1079f, 803f, 0.6f), floatArrayOf(777f, 1003f, 1.0f), floatArrayOf(369f, 918f, 0.9f),
            floatArrayOf(271f, 548f, 1.0f), floatArrayOf(160f, 466f, 0.65f), floatArrayOf(453f, 252f, 1.0f)
        ).map {
            val nx = it[0] / 1254f; val ny = it[1] / 1254f
            var f = (Math.atan2((nx - 0.5f).toDouble(), -(ny - 0.5f).toDouble()) / (2 * Math.PI)).toFloat()
            if (f < 0f) f += 1f
            floatArrayOf(nx, ny, f, it[2])
        }.sortedBy { it[2] }.toTypedArray()
    }

    // участок кольца между двумя узлами: от доли a0 до a1 (a1 может быть > 1 на переходе через верх), одно направление, свой старт и длительность (доли таймлайна)
    class Seg(val a0: Float, val a1: Float, val fw: Boolean, val start: Float, val dur: Float, val ex: Float)
    private class Plan(val arrive: FloatArray, val fdur: FloatArray, val segs: List<Seg>, val end: Float, val hits: FloatArray)

    private val plan: Plan by lazy {
        val nd = nodes; val n = nd.size
        val r = java.util.Random(31)
        val order = (0 until n).shuffled(r) // узлы зажигаются в перемешанном порядке, не по кругу
        val arrive = FloatArray(n); val fdur = FloatArray(n)
        for (rank in 0 until n) {
            val i = order[rank]
            arrive[i] = 0.40f + 0.26f * rank / (n - 1) + 0.012f * (r.nextFloat() - 0.5f)
            fdur[i] = 0.15f + 0.07f * r.nextFloat()
        }
        val segs = ArrayList<Seg>()
        fun mk(x0: Float, x1: Float, fw: Boolean, st: Float) {
            val dur = (0.09f + 0.08f * r.nextFloat()).coerceAtMost(0.80f - st).coerceAtLeast(0.05f)
            segs.add(Seg(x0, x1, fw, st, dur, 0.8f + 0.8f * r.nextFloat()))
        }
        for (k in 0 until n) {
            val j = (k + 1) % n
            val a0 = nd[k][2]; var a1 = nd[j][2]; if (a1 <= a0) a1 += 1f
            when (r.nextInt(3)) {
                0 -> mk(a0, a1, true, arrive[k])
                1 -> mk(a0, a1, false, arrive[j])
                else -> { val m = a0 + (a1 - a0) * (0.35f + 0.3f * r.nextFloat()); mk(a0, m, true, arrive[k]); mk(m, a1, false, arrive[j]) }
            }
        }
        val hits = FloatArray(n) { arrive[it] * TOTAL_MS }.also { it.sort() }
        Plan(arrive, fdur, segs, segs.maxOf { it.start + it.dur }, hits)
    }
    val arrive: FloatArray get() = plan.arrive
    val fdur: FloatArray get() = plan.fdur
    val segs: List<Seg> get() = plan.segs
    val drawEnd: Float get() = plan.end
    val hits: FloatArray get() = plan.hits   // мс, по возрастанию: прилёты звёзд в узлы (звук и вибро идут на них)
}

private const val NS = 140
private const val NSF = 700 // далёкие звёзды-точки (рисуются пачками линий)
private const val ZR = 3f
private const val NH = 35 // 11 звёзд-узлов + 24 мелких, которые вливаются в нити

private fun camV(tau: Float): Float {
    val a = ss(0.04f, 0.46f, tau)
    return 2.2f * (0.02f + Math.pow(a.toDouble(), 1.6).toFloat() * (1f - 0.93f * ss(0.50f, 0.82f, tau)))
}

// пройденный камерой путь (единицы глубины) к моменту tau, таблица считается один раз
private val camTab: FloatArray by lazy {
    val n = 400
    val a = FloatArray(n + 1)
    val dt = IntroPlan.TOTAL_MS / 1000f / n
    for (i in 1..n) a[i] = a[i - 1] + camV((i - 0.5f) / n) * dt
    a
}
private fun camDist(tau: Float): Float {
    val x = tau.coerceIn(0f, 1f) * 400f
    val i = x.toInt().coerceAtMost(399)
    return camTab[i] + (camTab[i + 1] - camTab[i]) * (x - i)
}

private fun h01(i: Int, c: Int, s: Int): Float {
    var x = i * 374761393 + c * 668265263 + s * 1274126177
    x = (x xor (x ushr 13)) * 1274126177
    x = x xor (x ushr 16)
    return (x and 0xFFFFFF) / 16777216f
}

// Векторные нити логотипа: трассировка ms_ring (assets/ring_paths.txt). Каждая нить — своя кривая со своим стартом:
// свет растекается от прилетевших звёзд-узлов, поэтому чем дальше нить от узла, тем позже она начинает рисоваться.
private class RPath(val xy: FloatArray, val cum: FloatArray, val len: Float, val cls: Int, val start: Float, val dur: Float, val ex: Float, val bright: Float)

private fun loadRingPaths(ctx: android.content.Context): List<RPath> {
    val lines = runCatching { ctx.assets.open("ring_paths.txt").bufferedReader().readLines() }.getOrDefault(emptyList())
    val r = java.util.Random(17)
    val nd = IntroPlan.nodes; val arr = IntroPlan.arrive
    class Raw(val xy: FloatArray, val b: Float)
    val raws = lines.mapNotNull { ln ->
        val sp = ln.split(';')
        if (sp.size < 2) return@mapNotNull null
        val c = sp[1].split(',')
        Raw(FloatArray(c.size) { c[it].toFloat() / 4095f - 0.5f }, sp[0].toFloat())
    }
    fun len(xy: FloatArray): Float { var l = 0f; for (i in 1 until xy.size / 2) l += Math.hypot((xy[i * 2] - xy[i * 2 - 2]).toDouble(), (xy[i * 2 + 1] - xy[i * 2 - 1]).toDouble()).toFloat(); return l }
    val maxLen = raws.maxOfOrNull { len(it.xy) } ?: 1f
    return raws.map { rw ->
        var xy = rw.xy
        val n = xy.size / 2
        fun nearest(x: Float, y: Float): Pair<Int, Float> {
            var bj = 0; var bd = 9f
            for (j in nd.indices) { val d = Math.hypot((x - (nd[j][0] - 0.5f)).toDouble(), (y - (nd[j][1] - 0.5f)).toDouble()).toFloat(); if (d < bd) { bd = d; bj = j } }
            return bj to bd
        }
        val a = nearest(xy[0], xy[1]); val b = nearest(xy[n * 2 - 2], xy[n * 2 - 1])
        if (b.second < a.second) { val rv = FloatArray(xy.size); for (i in 0 until n) { rv[i * 2] = xy[(n - 1 - i) * 2]; rv[i * 2 + 1] = xy[(n - 1 - i) * 2 + 1] }; xy = rv }
        val nn = if (b.second < a.second) b else a
        val cum = FloatArray(n)
        for (i in 1 until n) cum[i] = cum[i - 1] + Math.hypot((xy[i * 2] - xy[i * 2 - 2]).toDouble(), (xy[i * 2 + 1] - xy[i * 2 - 1]).toDouble()).toFloat()
        val ln = cum[n - 1]
        val dur = (0.05f + 0.11f * Math.sqrt((ln / maxLen).toDouble()).toFloat()) * (0.8f + 0.5f * r.nextFloat())
        var st = arr[nn.first] + nn.second * 0.25f + 0.012f * r.nextFloat()
        if (st + dur > 0.80f) st = 0.80f - dur
        RPath(xy, cum, ln, if (rw.b >= 150f) 0 else if (rw.b >= 70f) 1 else 2, st, dur, 0.8f + 0.7f * r.nextFloat(), rw.b / 255f)
    }
}

private class Heroes {
    val arr = FloatArray(NH); val dur = FloatArray(NH); val z = FloatArray(NH); val ang = FloatArray(NH); val rad = FloatArray(NH)
    val ap = FloatArray(NH); val mag = FloatArray(NH); val fr = FloatArray(NH); val rr = FloatArray(NH)
    init {
        val r = java.util.Random(8)
        for (j in 0 until NH) {
            if (j < 11) { arr[j] = IntroPlan.arrive[j]; dur[j] = IntroPlan.fdur[j] }
            else { arr[j] = 0.34f + 0.34f * r.nextFloat(); dur[j] = 0.14f + 0.08f * r.nextFloat(); fr[j] = r.nextFloat(); rr[j] = 0.94f + 0.12f * r.nextFloat() }
            z[j] = 0.55f + 0.85f * r.nextFloat(); ang[j] = r.nextFloat() * 6.2832f; rad[j] = r.nextFloat()
            ap[j] = r.nextFloat() * 6.2832f; mag[j] = r.nextFloat()
        }
    }
}

@Composable
fun StarIntro(onReveal: () -> Unit, onDone: () -> Unit) {
    val t = remember { Animatable(0f) }
    var skip by remember { mutableStateOf(false) }
    var boxH by remember { mutableStateOf(0) }
    val dens = LocalDensity.current
    val topInset = WindowInsets.statusBars.getTop(dens)
    val ring = ImageBitmap.imageResource(R.drawable.ms_ring)
    val zf = remember { val r = java.util.Random(5); FloatArray(NS) { r.nextFloat() } }
    val mg = remember { val r = java.util.Random(6); FloatArray(NS) { r.nextFloat() * r.nextFloat() * 0.6f + 0.4f * r.nextFloat() } }
    val cl = remember { val r = java.util.Random(9); IntArray(NS) { val q = r.nextFloat(); when { q < 0.38f -> 0; q < 0.66f -> 1; q < 0.84f -> 2; q < 0.94f -> 3; else -> 4 } } }
    val he = remember { Heroes() }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val rps = remember { loadRingPaths(ctx) }
    val buckets = remember { Array(3) { Path() } }
    val hx = remember { FloatArray(256) }
    val zf2 = remember { val r = java.util.Random(15); FloatArray(NSF) { r.nextFloat() } }
    val mg2 = remember { val r = java.util.Random(16); FloatArray(NSF) { r.nextFloat() * r.nextFloat() } }
    val fl = remember { Array(6) { FloatArray(NSF * 4) } }
    val fc = remember { IntArray(6) }
    val paintL = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).also { it.style = android.graphics.Paint.Style.STROKE; it.strokeCap = android.graphics.Paint.Cap.ROUND } }
    val gal = remember { val r = java.util.Random(23); FloatArray(16 * 6) { r.nextFloat() } }
    val spr = remember { Sprites() }
    val drawer = remember { SpriteDrawer() }
    val path = remember { Path() }
    val bz = remember { FloatArray(4) }

    LaunchedEffect(Unit) {
        IntroGate.flying = true
        withContext(Dispatchers.Default) { Snd.prepIntro() }
        if (!skip) {
            Snd.playIntro(); Hap.intro()
            t.animateTo(1f, tween(IntroPlan.TOTAL_MS, easing = LinearEasing))
            IntroGate.flying = false
            onDone()
        }
    }
    LaunchedEffect(Unit) {
        snapshotFlow { t.value >= 0.80f }.first { it }
        onReveal()
    }
    LaunchedEffect(skip) {
        if (skip) {
            Snd.stopIntro(); Hap.cancel(); Hap.click()
            onReveal()
            t.animateTo(1f, tween(260, easing = LinearEasing))
            IntroGate.flying = false
            onDone()
        }
    }
    Box(
        Modifier.fillMaxSize()
            .onSizeChanged { boxH = it.height }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent()
                        e.changes.forEach { it.consume() }
                        if (e.changes.any { !it.pressed && it.previousPressed }) skip = true
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxSize().graphicsLayer { alpha = 1f - ss(0.88f, 1f, t.value) }.background(IntroBg))
        Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = 1f - ss(0.88f, 1f, t.value) }) {
            val tt = t.value
            val cv = drawContext.canvas.nativeCanvas
            val w = size.width; val h = size.height
            val cx = w / 2f; val cy = h / 2f
            val c = Offset(cx, cy)
            val m = minOf(w, h)
            val k = 0.45f * m
            val base = minOf(w, h * 0.62f)
            val sz0 = 0.94f * base                       // сторона картинки кольца
            val ex = ss(0.86f, 1f, tt)
            val sE = 1f + 0.45f * ex                     // в конце кольцо расходится в небо
            val phi = 0.12f * ss(0.40f, 1f, tt)
            val deg = Math.toDegrees(phi.toDouble()).toFloat()
            val cp = Math.cos(phi.toDouble()).toFloat(); val sp = Math.sin(phi.toDouble()).toFloat()
            val ringR = 0.385f * sz0 * sE
            val spaceA = ss(0f, 0.10f, tt) * (1f - ss(0.70f, 0.88f, tt))
            fun vpx(tau: Float) = cx + 0.015f * w * Math.sin((tau * 5.1f).toDouble()).toFloat()
            val vpy = cy - 0.03f * h
            val dNow = camDist(tt)
            val vNow = camV(tt)
            val ax = w / m; val ay = h / m
            val dz = vNow * 0.05f

            fun star(bmp: Bitmap, x1: Float, y1: Float, x0: Float, y0: Float, size: Float, alpha: Float) {
                val dx = x1 - x0; val dy = y1 - y0
                val trail = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
                val deg2 = if (trail > 0.5f) Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble())).toFloat() else 0f
                drawer.draw(cv, bmp, (x1 + x0) / 2f, (y1 + y0) / 2f, size + trail, size, deg2, alpha)
            }
            fun pick(code: Int): Bitmap = when (code) { 0 -> spr.real[1]; 1 -> spr.real[0]; 2 -> spr.brand[3]; 3 -> spr.real[2]; else -> spr.brand[0] }

            // 0) дальний план в конце: редкие далёкие галактики (золото и холодные спирали), едва заметные
            val galA = ss(0.50f, 0.72f, tt) * (1f - ss(0.80f, 0.92f, tt)) * 0.55f
            if (galA > 0.01f) for (i in 0 until 16) {
                val gs = (10f + 26f * gal[i * 6 + 2]) * density * (1f + 0.12f * tt)
                val gx = gal[i * 6] * w; val gy = gal[i * 6 + 1] * h
                val gd = gal[i * 6 + 3] * 180f; val gb = 0.45f + 0.55f * gal[i * 6 + 4]
                if (i % 8 < 5) drawer.draw(cv, spr.galE, gx, gy, gs * 2.2f, gs * (0.6f + 0.5f * gal[i * 6 + 5]), gd, galA * gb)
                else drawer.draw(cv, spr.galS, gx, gy, gs * 1.5f, gs * 1.5f * (0.55f + 0.4f * gal[i * 6 + 5]), gd, galA * gb)
            }

            // 1) звёздное поле: звёзды лежат в объёме с разной глубиной, камера летит вперёд по Z, настоящая перспективная проекция
            if (spaceA > 0f) {
                val vx = vpx(tt)
                // 1а) тысячи далёких звёзд: тихие точки, при разгоне превращаются в тонкие радиальные нити (пачки линий, без спрайтов)
                for (b in 0 until 6) fc[b] = 0
                for (i in 0 until NSF) {
                    val u = zf2[i] * ZR - dNow
                    val cyc = Math.floor((u / ZR).toDouble()).toInt()
                    val z = u - cyc * ZR
                    if (z < 0.12f) continue
                    val fx = (h01(i + 1000, cyc, 1) * 2f - 1f) * ax
                    val fy = (h01(i + 1000, cyc, 2) * 2f - 1f) * ay
                    val x1 = vx + fx * k / z; val y1 = vpy + fy * k / z
                    if (x1 < -4f || x1 > w + 4f || y1 < -4f || y1 > h + 4f) continue
                    val a = (0.2f + 0.8f * (1f - z / ZR)) * (0.3f + 0.7f * mg2[i]) * ss(ZR, ZR * 0.85f, z) * spaceA
                    val bk = (if (a < 0.22f) 0 else if (a < 0.45f) 1 else 2) * 2 + (if (i % 3 == 0) 1 else 0)
                    val ar = fl[bk]; val n = fc[bk]
                    ar[n] = x1; ar[n + 1] = y1; ar[n + 2] = vx + fx * k / (z + dz) + 0.3f; ar[n + 3] = vpy + fy * k / (z + dz)
                    fc[bk] = n + 4
                }
                for (bk in 0 until 6) if (fc[bk] > 0) {
                    val bin = bk / 2
                    paintL.color = if (bk % 2 == 0) argb((255 * (0.30f + 0.28f * bin)).toInt(), 235, 240, 255) else argb((255 * (0.30f + 0.28f * bin)).toInt(), 140, 195, 255)
                    paintL.strokeWidth = (0.9f + 0.35f * bin) * density
                    cv.drawLines(fl[bk], 0, fc[bk], paintL)
                }
                // 1б) яркие звёзды: голубое тело-след и белая голова (как на референсе); следы длиннее, чем у дальних
                val dzB = vNow * 0.085f
                for (i in 0 until NS) {
                    val u = zf[i] * ZR - dNow
                    val cyc = Math.floor((u / ZR).toDouble()).toInt()
                    val z = u - cyc * ZR
                    if (z < 0.08f) continue
                    val fx = (h01(i, cyc, 1) * 2f - 1f) * ax
                    val fy = (h01(i, cyc, 2) * 2f - 1f) * ay
                    val x1 = vx + fx * k / z; val y1 = vpy + fy * k / z
                    if (x1 < -24f || x1 > w + 24f || y1 < -24f || y1 > h + 24f) continue
                    val x0 = vx + fx * k / (z + dzB); val y0 = vpy + fy * k / (z + dzB)
                    val near = 1f - z / ZR
                    val a = (0.25f + 0.75f * Math.pow(near.toDouble(), 0.8).toFloat()) * (0.35f + 0.65f * mg[i]) * ss(ZR, ZR * 0.85f, z) * ss(0.08f, 0.25f, z) * spaceA
                    val sz = ((1.6f + 2.2f * mg[i]) * density * (0.7f + 0.9f / (z + 0.25f))).coerceAtMost(11f * density)
                    if (Math.abs(x1 - x0) + Math.abs(y1 - y0) > 3f) star(spr.ice, x1, y1, x0, y0, sz, a * 0.8f)
                    val head = if (mg[i] > 0.85f && z < 1.3f) spr.realSp[if (cl[i] == 1) 0 else if (cl[i] == 3) 2 else 1] else pick(cl[i])
                    star(head, x1, y1, x1, y1, sz * 0.9f, a)
                }
            }

            // 2) кольцо: ВЕКТОРНЫЕ нити (трассировка логотипа). Каждая прорисовывается по своей кривой от начала к концу,
            // у каждой свой старт (свет растекается от прилетевших звёзд), скорость и яркость; в конце проявляется исходная картинка
            if (tt > 0.38f) {
                val szf = sz0 * sE
                val sz = szf.toInt()
                val off = IntOffset((cx - sz / 2f).toInt(), (cy - sz / 2f).toInt())
                val dsz = IntSize(sz, sz)
                val breathe = 0.92f + 0.08f * Math.sin((tt * 14f).toDouble()).toFloat()
                val vecA = 1f - ss(0.78f, 0.90f, tt)
                var nh = 0
                if (vecA > 0f) {
                    for (b in 0 until 3) buckets[b].reset()
                    for (pt in rps) {
                        val p = ((tt - pt.start) / pt.dur).coerceIn(0f, 1f)
                        if (p <= 0f) continue
                        val e = Math.pow(ss(0f, 1f, p).toDouble(), pt.ex.toDouble()).toFloat()
                        val target = e * pt.len
                        val bp = buckets[pt.cls]
                        val xy = pt.xy
                        val np = pt.cum.size
                        var lx = cx + xy[0] * szf; var ly = cy + xy[1] * szf
                        bp.moveTo(lx, ly)
                        for (i in 1 until np) {
                            val px = cx + xy[i * 2] * szf; val py = cy + xy[i * 2 + 1] * szf
                            if (pt.cum[i] <= target) { bp.lineTo(px, py); lx = px; ly = py }
                            else {
                                val f = ((target - pt.cum[i - 1]) / (pt.cum[i] - pt.cum[i - 1]).coerceAtLeast(1e-6f)).coerceIn(0f, 1f)
                                val hxp = lx + (px - lx) * f; val hyp = ly + (py - ly) * f
                                bp.lineTo(hxp, hyp)
                                if (nh < 85) { hx[nh * 3] = hxp; hx[nh * 3 + 1] = hyp; hx[nh * 3 + 2] = (0.45f + 0.5f * pt.bright) * (1f - ss(0.85f, 1f, p)); nh++ }
                                break
                            }
                        }
                    }
                }
                rotate(deg, c) {
                    if (vecA > 0f) {
                        val cols = intArrayOf(0xFFFFE2AA.toInt(), 0xFFFFBE5A.toInt(), 0xFFE6963C.toInt())
                        val wd = floatArrayOf(0.0024f, 0.0017f, 0.0012f)
                        val al = floatArrayOf(0.95f, 0.8f, 0.6f)
                        for (b in 0 until 3) {
                            drawPath(buckets[b], Color(cols[b]), alpha = 0.16f * vecA, style = Stroke(width = wd[b] * szf * 4.5f, cap = StrokeCap.Round, join = StrokeJoin.Round), blendMode = BlendMode.Plus)
                            drawPath(buckets[b], Color(cols[b]), alpha = al[b] * vecA, style = Stroke(width = wd[b] * szf, cap = StrokeCap.Round, join = StrokeJoin.Round), blendMode = BlendMode.Plus)
                        }
                    }
                    val ra = ss(0.70f, 0.84f, tt)
                    if (ra > 0f) drawImage(ring, dstOffset = off, dstSize = dsz, alpha = ra * breathe)
                    // вспышка: все элементы становятся целой структурой
                    val pulse = ss(0.80f, 0.83f, tt) * (1f - ss(0.83f, 0.90f, tt))
                    if (pulse > 0f) drawImage(ring, dstOffset = off, dstSize = dsz, alpha = 0.6f * pulse, blendMode = BlendMode.Plus)
                }
                val ghost = 0.30f * ss(0.82f, 0.94f, tt)
                if (ghost > 0f) rotate(-1.6f * deg - 4f * (tt - 0.82f), c) {
                    scale(1.035f, c) { drawImage(ring, dstOffset = off, dstSize = dsz, alpha = ghost, blendMode = BlendMode.Plus) }
                }
                // светящиеся головки рисующихся нитей (кадр уже повёрнут вручную, потому что головки считались без поворота)
                val hs = sz0 * 0.05f
                for (i in 0 until nh) {
                    val dx = hx[i * 3] - cx; val dy = hx[i * 3 + 1] - cy
                    drawer.draw(cv, spr.hub, cx + dx * cp - dy * sp, cy + dx * sp + dy * cp, hs, hs, 0f, hx[i * 3 + 2] * vecA)
                }
            }

            // 3) звёзды-герои: отрываются от поля в разное время и каждая по своей кривой летит в своё место на кольце
            for (j in 0 until NH) {
                val arr = he.arr[j]; val det = arr - he.dur[j]
                if (tt < 0.02f) continue
                val main = j < 11
                val tx: Float; val ty: Float
                val hsEnd: Float
                if (main) {
                    val nd = IntroPlan.nodes[j]
                    val dx = (nd[0] - 0.5f) * sz0 * sE; val dy = (nd[1] - 0.5f) * sz0 * sE
                    tx = cx + dx * cp - dy * sp; ty = cy + dx * sp + dy * cp
                    hsEnd = sz0 * 0.20f * nd[3] * sE
                } else {
                    val th = he.fr[j] * 6.2832f
                    val dx = Math.sin(th.toDouble()).toFloat() * ringR * he.rr[j]; val dy = -Math.cos(th.toDouble()).toFloat() * ringR * he.rr[j]
                    tx = cx + dx * cp - dy * sp; ty = cy + dx * sp + dy * cp
                    hsEnd = 6f * density
                }
                val zd = he.z[j]
                val vd = vpx(det)
                val r0 = 0.5f * h * (0.12f + 0.28f * he.rad[j])
                val s0x = vd + Math.cos(he.ang[j].toDouble()).toFloat() * r0; val s0y = vpy + Math.sin(he.ang[j].toDouble()).toFloat() * r0
                val fa = ss(0.02f, 0.12f, tt)
                val mag = he.mag[j]
                if (tt < det) {
                    // ещё летит в общем потоке
                    val fx = (s0x - vd) * zd / k; val fy = (s0y - vpy) * zd / k
                    val z = zd + camDist(det) - dNow
                    val vx = vpx(tt)
                    val sz = ((3.2f + 2.4f * mag) * density * (0.7f + 0.9f / (z + 0.25f))).coerceAtMost(14f * density)
                    star(spr.hub, vx + fx * k / z, vpy + fy * k / z, vx + fx * k / (z + dz), vpy + fy * k / (z + dz), sz, 0.9f * fa)
                } else {
                    val u = ((tt - det) / he.dur[j]).coerceIn(0f, 1f)
                    val dist = Math.hypot((tx - s0x).toDouble(), (ty - s0y).toDouble()).toFloat()
                    val dox = s0x - vd; val doy = s0y - vpy
                    val dl = Math.hypot(dox.toDouble(), doy.toDouble()).toFloat().coerceAtLeast(1f)
                    val p1x = s0x + dox / dl * dist * 0.35f; val p1y = s0y + doy / dl * dist * 0.35f
                    val p2x = tx + Math.cos(he.ap[j].toDouble()).toFloat() * dist * 0.30f; val p2y = ty + Math.sin(he.ap[j].toDouble()).toFloat() * dist * 0.30f
                    fun bez(e: Float) {
                        val q = 1f - e
                        bz[0] = q * q * q * s0x + 3 * q * q * e * p1x + 3 * q * e * e * p2x + e * e * e * tx
                        bz[1] = q * q * q * s0y + 3 * q * q * e * p1y + 3 * q * e * e * p2y + e * e * e * ty
                    }
                    fun ez(x: Float) = 0.35f * x + 0.65f * (x * x * (3f - 2f * x))
                    val e1 = ez(u); val e0 = ez((u - 0.04f).coerceAtLeast(0f))
                    bez(e1); val bx1 = bz[0]; val by1 = bz[1]
                    bez(e0); val bx0 = bz[0]; val by0 = bz[1]
                    val sStart = (3.2f + 2.4f * mag) * density * (0.7f + 0.9f / (zd + 0.25f))
                    val sz = sStart + (hsEnd - sStart) * e1
                    if (main) {
                        // дошла: вспыхивает узлом, мерцает, пускает круговой сигнал
                        val lit = ss(arr, arr + 0.03f, tt)
                        val twk = if (tt >= IntroPlan.drawEnd) 0.8f + 0.2f * Math.sin((tt * 22f + j * 1.7f).toDouble()).toFloat() else 1f
                        star(spr.hub, bx1, by1, bx0, by0, if (u < 1f) sz else hsEnd * (0.5f + 0.5f * lit), (if (u < 1f) 1f else lit.coerceAtLeast(0.6f)) * twk * fa)
                        val pp = ((tt - arr) * 20f).coerceIn(0f, 1f)
                        if (u >= 1f && pp < 1f) drawCircle(Gold.copy(alpha = 0.5f * (1f - pp)), radius = sz0 * (0.012f + 0.06f * pp), center = Offset(tx, ty), style = Stroke(width = (0.004f * sz0).coerceAtLeast(1f)))
                    } else {
                        // мелкая звезда: прилетела и растворилась в нити
                        val melt = 1f - ss(arr + 0.01f, arr + 0.05f, tt)
                        if (melt > 0f) star(spr.brand[(j % 2) * 3], bx1, by1, bx0, by0, sz, 0.95f * melt * fa)
                    }
                }
            }
        }
        // слово проявляется в центре кольца, затем летит в верхнюю пилюлю
        Image(
            painterResource(R.drawable.ms_logo),
            contentDescription = null,
            modifier = Modifier.size(150.dp, 38.dp).graphicsLayer {
                val a = ss(0.76f, 0.90f, t.value)
                val e = ss(0.86f, 1f, t.value)
                val targetY = topInset + 33.5f * dens.density
                translationY = e * (targetY - boxH / 2f)
                val s = (1f - e * (1f - 106f / 150f)) * (0.9f + 0.1f * a)
                scaleX = s; scaleY = s
                alpha = a
            }
        )
    }
}
