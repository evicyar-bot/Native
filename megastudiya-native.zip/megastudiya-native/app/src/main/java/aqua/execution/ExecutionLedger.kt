package aqua.execution

/** Execution bookkeeping only. This module does not invoke tools or perform external actions. */
enum class StepExecutionStatus { PENDING, READY, RUNNING, WAITING, INTERRUPTED, SUCCEEDED, FAILED, SKIPPED, CANCELLED }
enum class ExecutionEventType { CREATED, READY, STARTED, CHECKPOINT, WAITING, INTERRUPTED, SUCCEEDED, FAILED, RETRY, SKIPPED, CANCELLED }

data class ExecutionEvent(
    val eventId: String, val stepId: String, val type: ExecutionEventType,
    val atEpochMs: Long, val attempt: Int, val note: String = ""
) { init { require(eventId.isNotBlank() && stepId.isNotBlank() && atEpochMs > 0 && attempt >= 0) } }

data class StepExecution(
    val stepId: String, val status: StepExecutionStatus = StepExecutionStatus.PENDING,
    val attempts: Int = 0, val startedAtEpochMs: Long? = null, val finishedAtEpochMs: Long? = null,
    val checkpoint: String? = null, val lastError: String? = null
) { init { require(stepId.isNotBlank() && attempts >= 0) } }

data class ExecutionLedger(
    val planId: String, val planVersion: Int, val steps: List<StepExecution>,
    val events: List<ExecutionEvent> = emptyList(), val createdAtEpochMs: Long
) { init { require(planId.isNotBlank() && planVersion > 0 && createdAtEpochMs > 0 && steps.map { it.stepId }.distinct().size == steps.size) } }

class ExecutionLedgerService {
    fun create(planId: String, planVersion: Int, stepIds: List<String>, at: Long): ExecutionLedger {
        require(stepIds.isNotEmpty() && stepIds.all(String::isNotBlank) && stepIds.distinct().size == stepIds.size)
        return ExecutionLedger(planId, planVersion, stepIds.map(::StepExecution), createdAtEpochMs = at)
    }
    fun transition(ledger: ExecutionLedger, stepId: String, target: StepExecutionStatus, at: Long, eventId: String, note: String = ""): ExecutionLedger {
        require(at > 0 && eventId.isNotBlank())
        require(ledger.events.none { it.eventId == eventId }) { "Duplicate event ID" }
        val index = ledger.steps.indexOfFirst { it.stepId == stepId }; require(index >= 0) { "Unknown step" }
        val old = ledger.steps[index]; require(allowed(old.status, target)) { "Invalid transition ${old.status} -> $target" }
        val attempt = if (target == StepExecutionStatus.RUNNING) old.attempts + 1 else old.attempts
        val updated = old.copy(status=target, attempts=attempt,
            startedAtEpochMs=if (target == StepExecutionStatus.RUNNING && old.startedAtEpochMs == null) at else old.startedAtEpochMs,
            finishedAtEpochMs=if (target in terminal) at else null,
            lastError=if (target == StepExecutionStatus.FAILED) note else if (target == StepExecutionStatus.RUNNING) null else old.lastError)
        val eventType = when(target) { StepExecutionStatus.READY -> ExecutionEventType.READY; StepExecutionStatus.RUNNING -> if(old.status==StepExecutionStatus.FAILED) ExecutionEventType.RETRY else ExecutionEventType.STARTED; StepExecutionStatus.WAITING -> ExecutionEventType.WAITING; StepExecutionStatus.INTERRUPTED -> ExecutionEventType.INTERRUPTED; StepExecutionStatus.SUCCEEDED -> ExecutionEventType.SUCCEEDED; StepExecutionStatus.FAILED -> ExecutionEventType.FAILED; StepExecutionStatus.SKIPPED -> ExecutionEventType.SKIPPED; StepExecutionStatus.CANCELLED -> ExecutionEventType.CANCELLED; StepExecutionStatus.PENDING -> ExecutionEventType.CREATED }
        return ledger.copy(steps=ledger.steps.toMutableList().also { it[index]=updated }, events=ledger.events + ExecutionEvent(eventId,stepId,eventType,at,attempt,note))
    }
    fun checkpoint(ledger: ExecutionLedger, stepId: String, value: String, at: Long, eventId: String): ExecutionLedger {
        require(value.isNotBlank() && at > 0 && eventId.isNotBlank()); require(ledger.events.none { it.eventId==eventId })
        val i=ledger.steps.indexOfFirst { it.stepId==stepId }; require(i>=0); val step=ledger.steps[i]; require(step.status==StepExecutionStatus.RUNNING)
        val next=step.copy(checkpoint=value)
        return ledger.copy(steps=ledger.steps.toMutableList().also { it[i]=next }, events=ledger.events+ExecutionEvent(eventId,stepId,ExecutionEventType.CHECKPOINT,at,step.attempts,value))
    }
    fun summary(ledger: ExecutionLedger) = ledger.steps.groupingBy { it.status }.eachCount()
    private fun allowed(from: StepExecutionStatus, to: StepExecutionStatus): Boolean = when(from) {
        StepExecutionStatus.PENDING -> to in setOf(StepExecutionStatus.READY,StepExecutionStatus.SKIPPED,StepExecutionStatus.CANCELLED)
        StepExecutionStatus.READY -> to in setOf(StepExecutionStatus.RUNNING,StepExecutionStatus.SKIPPED,StepExecutionStatus.CANCELLED)
        StepExecutionStatus.RUNNING -> to in setOf(StepExecutionStatus.WAITING,StepExecutionStatus.SUCCEEDED,StepExecutionStatus.FAILED,StepExecutionStatus.CANCELLED)
        StepExecutionStatus.WAITING -> to in setOf(StepExecutionStatus.READY,StepExecutionStatus.CANCELLED)
        StepExecutionStatus.INTERRUPTED -> to in setOf(StepExecutionStatus.WAITING,StepExecutionStatus.READY,StepExecutionStatus.CANCELLED)
        StepExecutionStatus.FAILED -> to in setOf(StepExecutionStatus.READY,StepExecutionStatus.CANCELLED)
        else -> false
    }
    private val terminal = setOf(StepExecutionStatus.SUCCEEDED,StepExecutionStatus.FAILED,StepExecutionStatus.SKIPPED,StepExecutionStatus.CANCELLED)
}
