package aqua.execution

import java.io.File
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Base64

/** Durable checksummed snapshot store. Interrupted RUNNING steps are paused, never auto-replayed. */
class DurableExecutionLedgerStore(private val file: File) {
    private val lock = Any()
    fun save(ledger: ExecutionLedger) = synchronized(lock) { persist(ledger); ledger }
    fun load(): ExecutionLedger? = synchronized(lock) { if (!file.exists()) null else parse(file.readText(StandardCharsets.UTF_8)) }

    /** Converts persisted RUNNING states into INTERRUPTED with a recovery event and persists the result. */
    fun recoverAfterRestart(atEpochMs: Long): ExecutionLedger? = synchronized(lock) {
        require(atEpochMs > 0)
        val ledger = load() ?: return@synchronized null
        val interrupted = ledger.steps.filter { it.status == StepExecutionStatus.RUNNING }
        if (interrupted.isEmpty()) return@synchronized ledger
        var next = ledger
        interrupted.forEach { step ->
            next = next.copy(
                steps = next.steps.map { if (it.stepId == step.stepId) it.copy(status = StepExecutionStatus.INTERRUPTED, finishedAtEpochMs = null) else it },
                events = next.events + ExecutionEvent("recovery-${step.stepId}-${step.attempts}-$atEpochMs", step.stepId, ExecutionEventType.INTERRUPTED, atEpochMs, step.attempts, "Process restarted; manual reconciliation required")
            )
        }
        persist(next); next
    }

    /** Owner/operator reconciliation only: READY means explicitly approved to resume, WAITING means hold. */
    fun resolveInterrupted(stepId: String, target: StepExecutionStatus, atEpochMs: Long, eventId: String, note: String): ExecutionLedger = synchronized(lock) {
        require(target == StepExecutionStatus.READY || target == StepExecutionStatus.WAITING) { "Resolution must be READY or WAITING" }
        val current = load() ?: error("No ledger")
        val updated = ExecutionLedgerService().transition(current, stepId, target, atEpochMs, eventId, note)
        persist(updated); updated
    }

    private fun persist(ledger: ExecutionLedger) {
        file.parentFile?.mkdirs()
        val body = buildString {
            append("M\t${enc(ledger.planId)}\t${ledger.planVersion}\t${ledger.createdAtEpochMs}\n")
            ledger.steps.forEach { s -> append("S\t${enc(s.stepId)}\t${s.status}\t${s.attempts}\t${s.startedAtEpochMs ?: "-"}\t${s.finishedAtEpochMs ?: "-"}\t${enc(s.checkpoint ?: "")}\t${enc(s.lastError ?: "")}\n") }
            ledger.events.forEach { e -> append("E\t${enc(e.eventId)}\t${enc(e.stepId)}\t${e.type}\t${e.atEpochMs}\t${e.attempt}\t${enc(e.note)}\n") }
        }
        val payload = "AQUA_EXEC_LEDGER_V1\t${sha(body)}\n$body"
        val tmp = File(file.parentFile ?: File("."), file.name + ".tmp")
        tmp.writeText(payload, StandardCharsets.UTF_8)
        try { Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE) }
        catch (_: Exception) { Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING) }
    }
    private fun parse(raw: String): ExecutionLedger {
        val lines = raw.split('\n'); require(lines.isNotEmpty())
        val header = lines[0].split('\t'); require(header.size == 2 && header[0] == "AQUA_EXEC_LEDGER_V1") { "Unsupported ledger format" }
        val body = lines.drop(1).joinToString("\n").let { if (it.endsWith("\n")) it else it + "\n" }
        require(sha(body) == header[1]) { "Execution ledger checksum mismatch" }
        var meta: List<String>? = null; val steps = mutableListOf<StepExecution>(); val events = mutableListOf<ExecutionEvent>()
        lines.drop(1).filter { it.isNotBlank() }.forEach { line ->
            val f = line.split('\t'); when(f[0]) {
                "M" -> { require(f.size == 4 && meta == null); meta = f }
                "S" -> { require(f.size == 8); steps += StepExecution(dec(f[1]), StepExecutionStatus.valueOf(f[2]), f[3].toInt(), f[4].toLongOrNull(), f[5].toLongOrNull(), dec(f[6]).ifEmpty { null }, dec(f[7]).ifEmpty { null }) }
                "E" -> { require(f.size == 7); events += ExecutionEvent(dec(f[1]), dec(f[2]), ExecutionEventType.valueOf(f[3]), f[4].toLong(), f[5].toInt(), dec(f[6])) }
                else -> error("Unknown ledger record")
            }
        }
        val m = meta ?: error("Missing ledger metadata")
        return ExecutionLedger(dec(m[1]), m[2].toInt(), steps, events, m[3].toLong())
    }
    private fun enc(s: String) = Base64.getEncoder().encodeToString(s.toByteArray(StandardCharsets.UTF_8))
    private fun dec(s: String) = String(Base64.getDecoder().decode(s), StandardCharsets.UTF_8)
    private fun sha(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(StandardCharsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
