package aqua.research

@JvmInline value class EventId(val value: String) { init { require(value.isNotBlank()) } }

/** A traceable, append-only record of an AQUA operation. */
data class ResearchEvent(
    val id: EventId,
    val occurredAtEpochMs: Long,
    val actor: String,
    val action: String,
    val subjectId: String = "",
    val outcome: EventOutcome,
    val taskId: TaskId? = null,
    val reason: String = "",
    val details: String = "",
    val sequence: Long = 0L
) {
    init {
        require(occurredAtEpochMs >= 0)
        require(actor.isNotBlank())
        require(action.isNotBlank())
        require(sequence >= 0)
    }
}

enum class EventOutcome { STARTED, SUCCEEDED, FAILED, CANCELLED, BLOCKED, RETRYING }

data class EventQuery(
    val taskId: TaskId? = null,
    val actor: String? = null,
    val action: String? = null,
    val outcome: EventOutcome? = null,
    val afterSequence: Long = 0L,
    val limit: Int = 500
) {
    init { require(afterSequence >= 0); require(limit in 1..5000) }
}
