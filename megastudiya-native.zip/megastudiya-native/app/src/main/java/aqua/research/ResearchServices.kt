package aqua.research

import aqua.ports.*

/** Use-case layer: task isolation and reference integrity are enforced here, not by UI. */
class EvidenceService(private val repository: EvidenceRepository) {
    fun register(source: EvidenceSource): Boolean = repository.upsert(source)
    fun sources(task: TaskId): List<EvidenceSource> = repository.list(task)
    fun removeTask(task: TaskId): Int = repository.removeTask(task)
}
class ClaimService(private val claims: ClaimRepository, private val evidence: EvidenceRepository) {
    fun register(claim: Claim): Boolean {
        val validRefs = claim.evidenceSourceIds.all { id -> evidence.find(id)?.taskId == claim.taskId }
        if (!validRefs) return false
        return claims.upsert(claim)
    }
    fun review(id: ClaimId, status: ClaimReview, note: String): Boolean {
        val current = claims.find(id) ?: return false
        return claims.upsert(current.copy(review = status, reviewNote = note.take(1000)))
    }
    fun claims(task: TaskId): List<Claim> = claims.list(task)
    fun removeTask(task: TaskId): Int = claims.removeTask(task)
}
class DecisionService(private val decisions: DecisionRepository, private val claims: ClaimRepository) {
    fun register(decision: ResearchDecision): Boolean {
        val claimValid = decision.claimId?.let { claims.find(it)?.taskId == decision.taskId } ?: true
        if (!claimValid) return false
        return decisions.upsert(decision)
    }
    fun revise(id: DecisionId, decisionText: String, rationale: String, note: String, now: Long): Boolean {
        if (decisionText.isBlank() || rationale.isBlank()) return false
        val existing = decisions.find(id) ?: return false
        val revision = DecisionRevision(existing.decision, existing.rationale, note.take(800), now)
        return decisions.upsert(existing.copy(decision = decisionText.trim(), rationale = rationale.trim(),
            updatedAtEpochMs = now, history = existing.history + revision))
    }
    fun setStatus(id: DecisionId, status: DecisionStatus, now: Long): Boolean {
        val existing = decisions.find(id) ?: return false
        return decisions.upsert(existing.copy(status = status, updatedAtEpochMs = now))
    }
    fun decisions(task: TaskId): List<ResearchDecision> = decisions.list(task)
    fun removeTask(task: TaskId): Int = decisions.removeTask(task)
}
