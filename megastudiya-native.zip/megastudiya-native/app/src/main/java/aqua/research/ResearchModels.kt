package aqua.research

/** Portable AQUA research-domain models. Host apps and storage formats are deliberately absent. */
@JvmInline value class TaskId(val value: String) { init { require(value.isNotBlank()) } }
@JvmInline value class SourceId(val value: String) { init { require(value.isNotBlank()) } }
@JvmInline value class ClaimId(val value: String) { init { require(value.isNotBlank()) } }
@JvmInline value class DecisionId(val value: String) { init { require(value.isNotBlank()) } }
@JvmInline value class CriterionId(val value: String) { init { require(value.isNotBlank()) } }

 data class EvidenceSource(
    val id: SourceId, val taskId: TaskId, val title: String, val url: String,
    val query: String = "", val capturedAtEpochMs: Long,
    val review: SourceReview = SourceReview.UNREVIEWED
) { init { require(title.isNotBlank()); require(url.startsWith("https://")) } }
enum class SourceReview { UNREVIEWED, REVIEWED, REJECTED }

enum class ClaimType { FACT, HYPOTHESIS, INFERENCE }
enum class ClaimReview { UNREVIEWED, SUPPORTED, DISPUTED, UNSUPPORTED, INCONCLUSIVE }
data class Claim(
    val id: ClaimId, val taskId: TaskId, val statement: String, val type: ClaimType,
    val evidenceSourceIds: Set<SourceId> = emptySet(), val conflictKey: String = "",
    val createdAtEpochMs: Long, val review: ClaimReview = ClaimReview.UNREVIEWED,
    val reviewNote: String = ""
) { init { require(statement.isNotBlank()) } }

data class DecisionRevision(val decision: String, val rationale: String, val note: String, val atEpochMs: Long)
enum class DecisionStatus { ACTIVE, REVERSED, SUPERSEDED }
data class ResearchDecision(
    val id: DecisionId, val taskId: TaskId, val title: String, val decision: String,
    val rationale: String, val criterionId: CriterionId? = null, val claimId: ClaimId? = null,
    val alternatives: String = "", val createdAtEpochMs: Long, val updatedAtEpochMs: Long,
    val history: List<DecisionRevision> = emptyList(), val status: DecisionStatus = DecisionStatus.ACTIVE
) { init { require(title.isNotBlank()); require(decision.isNotBlank()); require(rationale.isNotBlank()) } }
