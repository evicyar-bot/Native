package aqua.dataformat

import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

/** Durable storage boundary: independent of Android and MegaStudio. */
interface DurableBundleStore {
    fun save(bundle: ResearchBundle, key: String): StoreSaveResult
    fun load(key: String): StoreLoadResult
    fun recover(key: String): StoreLoadResult
    fun keys(): List<String>
}
sealed class StoreSaveResult { data class Saved(val key: String, val generation: Long, val checksum: String): StoreSaveResult(); data class Failed(val reason: String): StoreSaveResult() }
sealed class StoreLoadResult { data class Loaded(val bundle: ResearchBundle, val generation: Long): StoreLoadResult(); data class Missing(val key: String): StoreLoadResult(); data class Failed(val reason: String): StoreLoadResult() }

/** Filesystem implementation uses per-key generation folders, manifest and staged commit. */
class FileDurableBundleStore(private val root: Path) : DurableBundleStore {
    private val safeKey = Regex("^[A-Za-z0-9._-]{1,80}$")
    override fun save(bundle: ResearchBundle, key: String): StoreSaveResult = try {
        require(safeKey.matches(key)) { "Invalid storage key" }
        val sealed = ResearchBundleFormat.seal(bundle)
        val validation = ResearchBundleFormat.validate(sealed)
        require(validation.valid) { validation.errors.joinToString("; ") }
        val bytes = ResearchBundleJsonCodec.encode(sealed)
        val dir = root.resolve(key); Files.createDirectories(dir)
        val previousGeneration = currentGeneration(key)
        val current = previousGeneration?.let { readManifest(dir.resolve("generation-$it/manifest.json"))?.generation } ?: 0L
        val generation = current + 1
        val stage = dir.resolve(".stage-$generation")
        if (Files.exists(stage)) stage.toFile().deleteRecursively()
        Files.createDirectories(stage)
        val payload = stage.resolve("bundle.json"); Files.write(payload, bytes)
        val digest = sha256(bytes)
        val manifest = "{\"manifestVersion\":1,\"generation\":$generation,\"bundleFile\":\"bundle.json\",\"sha256\":\"$digest\",\"bytes\":${bytes.size}}"
        Files.write(stage.resolve("manifest.json"), manifest.toByteArray(StandardCharsets.UTF_8))
        val committed = dir.resolve("generation-$generation")
        Files.move(stage, committed, StandardCopyOption.ATOMIC_MOVE)
        val pointerTmp = dir.resolve("current.tmp"); Files.write(pointerTmp, generation.toString().toByteArray(StandardCharsets.UTF_8))
        try { Files.move(pointerTmp, dir.resolve("current"), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE) }
        catch (_: Exception) { Files.move(pointerTmp, dir.resolve("current"), StandardCopyOption.REPLACE_EXISTING) }
        // Preserve last two generations for recovery; older ones are pruned only after commit.
        Files.list(dir).use { stream -> stream.filter { it.fileName.toString().startsWith("generation-") }.sorted(Comparator.comparingLong<Path> { generationOf(it) }.reversed()).skip(2).forEach { it.toFile().deleteRecursively() } }
        StoreSaveResult.Saved(key, generation, digest)
    } catch (e: Exception) { StoreSaveResult.Failed(e.message ?: e.javaClass.simpleName) }

    override fun load(key: String): StoreLoadResult = loadGeneration(key, currentGeneration(key))
    override fun recover(key: String): StoreLoadResult {
        val candidates = runCatching { Files.list(root.resolve(key)).use { s -> s.filter { it.fileName.toString().startsWith("generation-") }.map { generationOf(it) }.sorted(Comparator.reverseOrder()).toList() } }.getOrDefault(emptyList())
        for (g in candidates) { val result = loadGeneration(key, g); if (result is StoreLoadResult.Loaded) return result }
        return StoreLoadResult.Failed("No valid committed generation found")
    }
    override fun keys(): List<String> = if (!Files.exists(root)) emptyList() else Files.list(root).use { it.filter { Files.isDirectory(it) && safeKey.matches(it.fileName.toString()) }.map { it.fileName.toString() }.sorted().toList() }

    private fun currentGeneration(key: String): Long? = runCatching { Files.readString(root.resolve(key).resolve("current")).trim().toLong() }.getOrNull()
    private fun loadGeneration(key: String, generation: Long?): StoreLoadResult {
        if (generation == null) return StoreLoadResult.Missing(key)
        return try {
            val dir = root.resolve(key).resolve("generation-$generation")
            val manifest = readManifest(dir.resolve("manifest.json")) ?: return StoreLoadResult.Failed("Manifest missing or invalid")
            require(manifest.generation == generation && manifest.version == 1) { "Manifest version/generation mismatch" }
            val file = dir.resolve(manifest.file); val bytes = Files.readAllBytes(file)
            require(bytes.size == manifest.bytes) { "Payload size mismatch" }
            require(sha256(bytes) == manifest.sha) { "Payload checksum mismatch" }
            val imported = ResearchBundleFileTransfer.runCatchingImportBytes(bytes)
            when (imported) { is BundleImportResult.Accepted -> StoreLoadResult.Loaded(imported.bundle, generation); is BundleImportResult.Rejected -> StoreLoadResult.Failed(imported.errors.joinToString("; ")) }
        } catch (e: Exception) { StoreLoadResult.Failed(e.message ?: "Storage read failure") }
    }
    private data class Manifest(val version:Int,val generation:Long,val file:String,val sha:String,val bytes:Int)
    private fun readManifest(path:Path):Manifest? = runCatching {
        val text=Files.readString(path); fun n(name:String)=Regex("\\\"$name\\\":([0-9]+)").find(text)?.groupValues?.get(1)?.toLong() ?: error("manifest $name missing")
        fun s(name:String)=Regex("\\\"$name\\\":\\\"([^\\\"]+)\\\"").find(text)?.groupValues?.get(1) ?: error("manifest $name missing")
        Manifest(n("manifestVersion").toInt(),n("generation"),s("bundleFile"),s("sha256"),n("bytes").toInt())
    }.getOrNull()
    private fun generationOf(path:Path)=path.fileName.toString().removePrefix("generation-").toLongOrNull() ?: -1L
    private fun sha256(bytes:ByteArray)=MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
}

private fun ResearchBundleFileTransfer.runCatchingImportBytes(bytes: ByteArray): BundleImportResult = try { ResearchBundleFormat.import(ResearchBundleJsonCodec.decode(bytes)) } catch (e: Exception) { BundleImportResult.Rejected(listOf(e.message ?: "Decode failure")) }
