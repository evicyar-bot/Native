package aqua.dataformat

import aqua.research.*
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption

/** Strict JSON codec for portable research bundles. No third-party or host dependencies. */
object ResearchBundleJsonCodec {
    const val MAX_BYTES = 5 * 1024 * 1024
    fun encode(bundle: ResearchBundle): ByteArray {
        val json = buildString {
            append('{'); field("schemaVersion", bundle.schemaVersion); append(','); field("exportedAtEpochMs", bundle.exportedAtEpochMs); append(',')
            append("\"checksumSha256\":"); string(bundle.checksumSha256); append(',')
            append("\"sources\":[")
            bundle.sources.forEachIndexed { i, s -> if (i > 0) append(','); append('{'); field("id", s.id.value); append(','); field("taskId", s.taskId.value); append(','); field("title", s.title); append(','); field("url", s.url); append(','); field("query", s.query); append(','); field("capturedAtEpochMs", s.capturedAtEpochMs); append(','); field("review", s.review.name); append('}') }
            append("],\"claims\":[")
            bundle.claims.forEachIndexed { i, c -> if (i > 0) append(','); append('{'); field("id", c.id.value); append(','); field("taskId", c.taskId.value); append(','); field("statement", c.statement); append(','); field("type", c.type.name); append(','); append("\"evidenceSourceIds\":["); c.evidenceSourceIds.sortedBy { it.value }.forEachIndexed { j, id -> if (j > 0) append(','); string(id.value) }; append("],"); field("conflictKey", c.conflictKey); append(','); field("createdAtEpochMs", c.createdAtEpochMs); append(','); field("review", c.review.name); append(','); field("reviewNote", c.reviewNote); append('}') }
            append("],\"decisions\":[")
            bundle.decisions.forEachIndexed { i, d -> if (i > 0) append(','); append('{'); field("id", d.id.value); append(','); field("taskId", d.taskId.value); append(','); field("title", d.title); append(','); field("decision", d.decision); append(','); field("rationale", d.rationale); append(','); append("\"criterionId\":"); if (d.criterionId == null) append("null") else string(d.criterionId.value); append(','); append("\"claimId\":"); if (d.claimId == null) append("null") else string(d.claimId.value); append(','); field("alternatives", d.alternatives); append(','); field("createdAtEpochMs", d.createdAtEpochMs); append(','); field("updatedAtEpochMs", d.updatedAtEpochMs); append(','); field("status", d.status.name); append(','); append("\"history\":["); d.history.forEachIndexed { j, h -> if (j > 0) append(','); append('{'); field("decision", h.decision); append(','); field("rationale", h.rationale); append(','); field("note", h.note); append(','); field("atEpochMs", h.atEpochMs); append('}') }; append("]}") }
            append("]}")
        }
        return json.toByteArray(StandardCharsets.UTF_8).also { require(it.size <= MAX_BYTES) { "Bundle exceeds byte limit" } }
    }
    fun decode(bytes: ByteArray): ResearchBundle {
        require(bytes.isNotEmpty() && bytes.size <= MAX_BYTES) { "Invalid bundle size" }
        val root = JsonParser(bytes.toString(StandardCharsets.UTF_8)).parse() as? Map<*, *> ?: error("Root must be an object")
        fun obj(v: Any?) = v as? Map<*, *> ?: error("Expected object")
        fun str(m: Map<*, *>, k: String, default: String? = null): String = (m[k] as? String) ?: default ?: error("Missing string: $k")
        fun num(m: Map<*, *>, k: String, default: Long? = null): Long = (m[k] as? Number)?.toLong() ?: default ?: error("Missing number: $k")
        fun arr(m: Map<*, *>, k: String) = (m[k] as? List<*>) ?: error("Missing array: $k")
        val sources = arr(root,"sources").map { x -> val m=obj(x); EvidenceSource(SourceId(str(m,"id")),TaskId(str(m,"taskId")),str(m,"title"),str(m,"url"),str(m,"query",""),num(m,"capturedAtEpochMs"),SourceReview.valueOf(str(m,"review","UNREVIEWED"))) }
        val claims = arr(root,"claims").map { x -> val m=obj(x); Claim(ClaimId(str(m,"id")),TaskId(str(m,"taskId")),str(m,"statement"),ClaimType.valueOf(str(m,"type")),arr(m,"evidenceSourceIds").map { SourceId(it as? String ?: error("Evidence ID must be string")) }.toSet(),str(m,"conflictKey",""),num(m,"createdAtEpochMs"),ClaimReview.valueOf(str(m,"review","UNREVIEWED")),str(m,"reviewNote","")) }
        val decisions = arr(root,"decisions").map { x -> val m=obj(x); val hist=arr(m,"history").map { y -> val h=obj(y); DecisionRevision(str(h,"decision"),str(h,"rationale"),str(h,"note"),num(h,"atEpochMs")) }; ResearchDecision(DecisionId(str(m,"id")),TaskId(str(m,"taskId")),str(m,"title"),str(m,"decision"),str(m,"rationale"),(m["criterionId"] as? String)?.let(::CriterionId),(m["claimId"] as? String)?.let(::ClaimId),str(m,"alternatives",""),num(m,"createdAtEpochMs"),num(m,"updatedAtEpochMs"),hist,DecisionStatus.valueOf(str(m,"status","ACTIVE"))) }
        return ResearchBundle(num(root,"schemaVersion").toInt(),num(root,"exportedAtEpochMs"),sources,claims,decisions,str(root,"checksumSha256",""))
    }
    private fun StringBuilder.field(k: String, v: String) { append('"'); append(k); append("\":"); string(v) }
    private fun StringBuilder.field(k: String, v: Long) { append('"'); append(k); append("\":"); append(v) }
    private fun StringBuilder.field(k: String, v: Int) { append('"'); append(k); append("\":"); append(v) }
    private fun StringBuilder.string(v: String) { append('"'); v.forEach { c -> when(c) { '"' -> append("\\\""); '\\' -> append("\\\\"); '\n' -> append("\\n"); '\r' -> append("\\r"); '\t' -> append("\\t"); else -> if (c.code < 0x20) append("\\u%04x".format(c.code)) else append(c) } }; append('"') }
}

/** File-level transfer: writes atomically, retains previous file as .bak, validates before import. */
object ResearchBundleFileTransfer {
    data class ExportResult(val path: Path, val backupCreated: Boolean, val bytes: Int)
    fun export(bundle: ResearchBundle, target: Path): ExportResult {
        val sealed = ResearchBundleFormat.seal(bundle)
        val validation = ResearchBundleFormat.validate(sealed)
        require(validation.valid) { validation.errors.joinToString("; ") }
        val bytes = ResearchBundleJsonCodec.encode(sealed)
        Files.createDirectories(target.toAbsolutePath().parent)
        val tmp = target.resolveSibling(target.fileName.toString() + ".tmp")
        val bak = target.resolveSibling(target.fileName.toString() + ".bak")
        Files.write(tmp, bytes)
        if (Files.exists(target)) Files.copy(target, bak, StandardCopyOption.REPLACE_EXISTING)
        try { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE) }
        catch (_: Exception) { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING) }
        return ExportResult(target, Files.exists(bak), bytes.size)
    }
    fun import(path: Path): BundleImportResult {
        return try {
            val size = Files.size(path)
            if (size <= 0 || size > ResearchBundleJsonCodec.MAX_BYTES) BundleImportResult.Rejected(listOf("Invalid file size"))
            else ResearchBundleFormat.import(ResearchBundleJsonCodec.decode(Files.readAllBytes(path)))
        } catch (e: Exception) { BundleImportResult.Rejected(listOf("Import failed: ${e.message ?: e.javaClass.simpleName}")) }
    }
    fun restoreBackup(target: Path): Boolean {
        val bak = target.resolveSibling(target.fileName.toString() + ".bak")
        if (!Files.exists(bak)) return false
        val check = import(bak); if (check !is BundleImportResult.Accepted) return false
        Files.copy(bak, target, StandardCopyOption.REPLACE_EXISTING); return true
    }
}

/** Small strict JSON parser: rejects trailing content, duplicate keys, malformed escapes and unsupported values. */
private class JsonParser(private val s: String) {
    private var i = 0
    fun parse(): Any? { val v=value(); ws(); require(i==s.length) { "Trailing JSON content" }; return v }
    private fun value(): Any? { ws(); require(i<s.length) { "Unexpected end" }; return when(s[i]) { '{' -> obj(); '[' -> array(); '"' -> string(); 't' -> literal("true",true); 'f' -> literal("false",false); 'n' -> literal("null",null); else -> number() } }
    private fun obj(): Map<String,Any?> { i++; ws(); val m=linkedMapOf<String,Any?>(); if (take('}')) return m; while(true) { ws(); val k=string(); ws(); require(take(':')) { "Expected colon" }; require(!m.containsKey(k)) { "Duplicate key: $k" }; m[k]=value(); ws(); if(take('}')) return m; require(take(',')) { "Expected comma" } } }
    private fun array(): List<Any?> { i++; ws(); val a=mutableListOf<Any?>(); if(take(']')) return a; while(true) { a+=value(); ws(); if(take(']')) return a; require(take(',')) { "Expected comma" } } }
    private fun string(): String { require(take('"')) { "Expected string" }; val b=StringBuilder(); while(i<s.length) { val c=s[i++]; if(c=='"') return b.toString(); if(c=='\\') { require(i<s.length); when(val e=s[i++]) { '"','\\','/' -> b.append(e); 'b' -> b.append('\b'); 'f' -> b.append('\u000c'); 'n' -> b.append('\n'); 'r' -> b.append('\r'); 't' -> b.append('\t'); 'u' -> { require(i+4<=s.length); b.append(s.substring(i,i+4).toInt(16).toChar()); i+=4 }; else -> error("Invalid escape") } } else { require(c.code>=0x20) { "Control character in string" }; b.append(c) } }; error("Unterminated string") }
    private fun number(): Number { val start=i; if(i<s.length && s[i]=='-') i++; while(i<s.length && s[i].isDigit()) i++; require(i>start && s.substring(start,i)!="-") { "Invalid number" }; return s.substring(start,i).toLong() }
    private fun <T> literal(text:String, v:T):T { require(s.startsWith(text,i)); i+=text.length; return v }
    private fun take(c:Char):Boolean { if(i<s.length && s[i]==c) {i++; return true}; return false }
    private fun ws(){ while(i<s.length && s[i].isWhitespace()) i++ }
}
