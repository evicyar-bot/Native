package aqua.dataformat

import aqua.research.*
import java.security.MessageDigest

/** Versioned transport DTO. JSON encoding is delegated to an adapter; domain core has no JSON dependency. */
data class ResearchBundle(
    val schemaVersion: Int,
    val exportedAtEpochMs: Long,
    val sources: List<EvidenceSource>,
    val claims: List<Claim>,
    val decisions: List<ResearchDecision>,
    val checksumSha256: String = ""
)

data class BundleValidation(val valid: Boolean, val errors: List<String>)
sealed interface BundleImportResult {
    data class Accepted(val bundle: ResearchBundle, val migratedFrom: Int?) : BundleImportResult
    data class Rejected(val errors: List<String>) : BundleImportResult
}

object ResearchBundleFormat {
    const val CURRENT_SCHEMA = 1


    /** Length-prefix canonical form prevents ambiguous concatenation and is stable across list ordering. */
    fun canonical(bundle: ResearchBundle): String {
        val fields = mutableListOf<String>()
        fields += "schema=${bundle.schemaVersion}"
        fields += "exported=${bundle.exportedAtEpochMs}"
        bundle.sources.sortedBy { it.id.value }.forEach { s -> fields += listOf("S", s.id.value, s.taskId.value, s.title, s.url, s.query, s.capturedAtEpochMs.toString(), s.review.name).joinToString("") { encode(it) } }
        bundle.claims.sortedBy { it.id.value }.forEach { c -> fields += listOf("C", c.id.value, c.taskId.value, c.statement, c.type.name, c.evidenceSourceIds.map { it.value }.sorted().joinToString(","), c.conflictKey, c.createdAtEpochMs.toString(), c.review.name, c.reviewNote).joinToString("") { encode(it) } }
        bundle.decisions.sortedBy { it.id.value }.forEach { d ->
            fields += listOf("D", d.id.value, d.taskId.value, d.title, d.decision, d.rationale, d.criterionId?.value.orEmpty(), d.claimId?.value.orEmpty(), d.alternatives, d.createdAtEpochMs.toString(), d.updatedAtEpochMs.toString(), d.status.name).joinToString("") { encode(it) }
            d.history.forEach { h -> fields += listOf("H", h.decision, h.rationale, h.note, h.atEpochMs.toString()).joinToString("") { encode(it) } }
        }
        return fields.joinToString("\n")
    }
    fun checksum(bundle: ResearchBundle): String = sha256(canonical(bundle))
    fun seal(bundle: ResearchBundle): ResearchBundle = bundle.copy(schemaVersion = CURRENT_SCHEMA, checksumSha256 = checksum(bundle.copy(schemaVersion = CURRENT_SCHEMA, checksumSha256 = "")))

    fun validate(bundle: ResearchBundle, requireChecksum: Boolean = true): BundleValidation {
        val errors = mutableListOf<String>()
        if (bundle.schemaVersion != CURRENT_SCHEMA) errors += "Unsupported schema version: ${bundle.schemaVersion}"
        if (bundle.exportedAtEpochMs < 0) errors += "Negative export timestamp"
        val sourceIds = bundle.sources.map { it.id.value }
        val claimIds = bundle.claims.map { it.id.value }
        val decisionIds = bundle.decisions.map { it.id.value }
        if (sourceIds.size != sourceIds.toSet().size) errors += "Duplicate source IDs"
        if (claimIds.size != claimIds.toSet().size) errors += "Duplicate claim IDs"
        if (decisionIds.size != decisionIds.toSet().size) errors += "Duplicate decision IDs"
        val sources = bundle.sources.associateBy { it.id }
        bundle.claims.forEach { c -> c.evidenceSourceIds.forEach { id ->
            val source = sources[id]
            if (source == null) errors += "Claim ${c.id.value} references missing source ${id.value}"
            else if (source.taskId != c.taskId) errors += "Claim ${c.id.value} references source from another task"
        } }
        val claims = bundle.claims.associateBy { it.id }
        bundle.decisions.forEach { d -> d.claimId?.let { id ->
            val claim = claims[id]
            if (claim == null) errors += "Decision ${d.id.value} references missing claim ${id.value}"
            else if (claim.taskId != d.taskId) errors += "Decision ${d.id.value} references claim from another task"
        } }
        if (requireChecksum && bundle.checksumSha256.isBlank()) errors += "Checksum missing"
        if (bundle.checksumSha256.isNotBlank() && bundle.checksumSha256 != checksum(bundle.copy(checksumSha256 = ""))) errors += "Checksum mismatch"
        return BundleValidation(errors.isEmpty(), errors)
    }

    /** Migration v0 -> v1: legacy typed bundles may omit checksum; contents are retained and resealed. */
    fun import(bundle: ResearchBundle): BundleImportResult {
        if (bundle.schemaVersion !in 0..CURRENT_SCHEMA) return BundleImportResult.Rejected(listOf("Unsupported schema version: ${bundle.schemaVersion}"))
        if (bundle.schemaVersion == 0) {
            if (bundle.checksumSha256.isNotBlank() && bundle.checksumSha256 != checksum(bundle.copy(checksumSha256 = "")))
                return BundleImportResult.Rejected(listOf("Legacy checksum mismatch"))
            val migrated = seal(bundle.copy(schemaVersion = CURRENT_SCHEMA, checksumSha256 = ""))
            val check = validate(migrated)
            return if (check.valid) BundleImportResult.Accepted(migrated, 0) else BundleImportResult.Rejected(check.errors)
        }
        val check = validate(bundle)
        return if (check.valid) BundleImportResult.Accepted(bundle, null) else BundleImportResult.Rejected(check.errors)
    }

    private fun encode(value: String): String = "${value.length}:$value"
    private fun sha256(text: String): String = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
