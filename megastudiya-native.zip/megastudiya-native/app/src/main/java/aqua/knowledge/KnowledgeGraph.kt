package aqua.knowledge

/** Portable graph domain model; no host-app or Android dependencies. */
enum class NodeType { TASK, SOURCE, CLAIM, CRITERION, DECISION }
enum class EdgeType { HAS_SOURCE, SUPPORTS, CONTRADICTS, ADDRESSES, INFORMS, DEPENDS_ON, REVISES }

data class GraphNode(
    val id: String,
    val taskId: String,
    val type: NodeType,
    val label: String,
    val externalRef: String? = null
)

data class GraphEdge(
    val id: String,
    val taskId: String,
    val fromId: String,
    val toId: String,
    val type: EdgeType,
    val origin: LinkOrigin = LinkOrigin.MANUAL
)
enum class LinkOrigin { MANUAL, IMPORTED, INFERRED }

/** Graph intentionally stores relationships only; it does not infer truth from connectivity. */
class KnowledgeGraph {
    private val nodes = linkedMapOf<String, GraphNode>()
    private val edges = linkedMapOf<String, GraphEdge>()

    fun addNode(node: GraphNode): Boolean {
        if (node.id.isBlank() || node.taskId.isBlank() || node.label.isBlank()) return false
        nodes[node.id] = node.copy(label = node.label.trim())
        return true
    }

    fun addEdge(edge: GraphEdge): Boolean {
        if (edge.id.isBlank() || edge.taskId.isBlank()) return false
        val from = nodes[edge.fromId] ?: return false
        val to = nodes[edge.toId] ?: return false
        // Cross-task links are rejected by default to avoid accidental research mixing.
        if (from.taskId != edge.taskId || to.taskId != edge.taskId) return false
        edges[edge.id] = edge
        return true
    }

    fun nodes(taskId: String? = null): List<GraphNode> = nodes.values.filter { taskId == null || it.taskId == taskId }
    fun edges(taskId: String? = null): List<GraphEdge> = edges.values.filter { taskId == null || it.taskId == taskId }
    fun related(nodeId: String, taskId: String): List<GraphNode> {
        val ids = edges.values.filter { it.taskId == taskId && (it.fromId == nodeId || it.toId == nodeId) }
            .map { if (it.fromId == nodeId) it.toId else it.fromId }.toSet()
        return nodes.values.filter { it.taskId == taskId && it.id in ids }
    }
    fun clearTask(taskId: String) {
        edges.entries.removeAll { it.value.taskId == taskId }
        nodes.entries.removeAll { it.value.taskId == taskId }
    }
}
