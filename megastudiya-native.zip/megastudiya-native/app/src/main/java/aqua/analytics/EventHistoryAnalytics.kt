package aqua.analytics

import aqua.ports.ResearchEventJournal
import aqua.research.EventOutcome
import aqua.research.EventQuery
import aqua.research.ResearchEvent

/** A descriptive snapshot of event history. It never mutates AQUA state or triggers actions. */
data class EventHistoryReport(
    val totalEvents: Int,
    val outcomeCounts: Map<EventOutcome, Int>,
    val terminalEvents: Int,
    val successRatePercent: Double?,
    val actionStats: List<ActionStat>,
    val repeatedFailures: List<FailurePattern>,
    val recurringTasks: List<RecurringTask>,
    val observations: List<String>
)

data class ActionStat(val actor: String, val action: String, val terminalCount: Int, val successes: Int, val failures: Int, val successRatePercent: Double?, val evidenceEventIds: Set<String> = emptySet())
data class FailurePattern(val actor: String, val action: String, val normalizedReason: String, val occurrences: Int, val taskIds: Set<String>, val evidenceEventIds: Set<String> = emptySet())
data class RecurringTask(val taskId: String, val eventCount: Int, val failedCount: Int, val succeededCount: Int, val evidenceEventIds: Set<String> = emptySet())

class EventHistoryAnalytics(private val journal: ResearchEventJournal) {
    /** limit is bounded to prevent unbounded history scans; the journal's sequence order is retained. */
    fun analyze(taskId: aqua.research.TaskId? = null, limit: Int = 5000): EventHistoryReport {
        require(limit in 1..5000)
        val events = journal.query(EventQuery(taskId = taskId, limit = limit))
        val outcomeCounts = EventOutcome.values().associateWith { o -> events.count { it.outcome == o } }
        val terminal = events.filter { it.outcome in TERMINAL }
        val successes = terminal.count { it.outcome == EventOutcome.SUCCEEDED }
        val globalRate = percent(successes, terminal.size)

        val actionStats = events.groupBy { it.actor to it.action }.map { (key, group) ->
            val end = group.filter { it.outcome in TERMINAL }
            val ok = end.count { it.outcome == EventOutcome.SUCCEEDED }
            val bad = end.count { it.outcome in FAILURE_OUTCOMES }
            ActionStat(key.first, key.second, end.size, ok, bad, percent(ok, end.size), end.map { it.id.value }.toSet())
        }.sortedWith(compareByDescending<ActionStat> { it.terminalCount }.thenBy { it.actor }.thenBy { it.action })

        val failureGroups = events.filter { it.outcome in FAILURE_OUTCOMES }
            .groupBy { Triple(it.actor, it.action, normalizeReason(it.reason)) }
        val repeatedFailures = failureGroups.map { (key, group) ->
            FailurePattern(key.first, key.second, key.third, group.size, group.mapNotNull { it.taskId?.value }.toSet(), group.map { it.id.value }.toSet())
        }.filter { it.occurrences >= 2 }
            .sortedWith(compareByDescending<FailurePattern> { it.occurrences }.thenBy { it.actor }.thenBy { it.action })

        val recurringTasks = events.filter { it.taskId != null }.groupBy { it.taskId!!.value }.map { (id, group) ->
            RecurringTask(id, group.size, group.count { it.outcome in FAILURE_OUTCOMES }, group.count { it.outcome == EventOutcome.SUCCEEDED }, group.map { it.id.value }.toSet())
        }.filter { it.eventCount >= 3 }
            .sortedWith(compareByDescending<RecurringTask> { it.eventCount }.thenBy { it.taskId })

        val observations = buildList {
            repeatedFailures.forEach { add("Repeated failure: ${it.actor}/${it.action} — ${it.normalizedReason} (${it.occurrences} occurrences). Review this pathway.") }
            actionStats.filter { it.terminalCount >= 3 && it.successRatePercent != null && it.successRatePercent < 50.0 }
                .forEach { add("Low observed success for ${it.actor}/${it.action}: ${it.successRatePercent}% across ${it.terminalCount} terminal events.") }
            if (terminal.isNotEmpty() && globalRate != null && globalRate >= 90.0 && terminal.size >= 5)
                add("History shows a high terminal-event success rate (${globalRate}%) across ${terminal.size} events; treat as a historical signal, not a guarantee.")
            if (isEmpty() && events.isNotEmpty()) add("No recurring failure or low-success pattern met the current thresholds.")
            if (events.isEmpty()) add("No events available for this analysis scope.")
        }
        return EventHistoryReport(events.size, outcomeCounts, terminal.size, globalRate, actionStats, repeatedFailures, recurringTasks, observations)
    }

    private fun normalizeReason(reason: String): String = reason.trim().lowercase().replace(Regex("\\s+"), " ").ifBlank { "(no reason recorded)" }
    private fun percent(numerator: Int, denominator: Int): Double? = if (denominator == 0) null else (numerator * 100.0 / denominator)

    companion object {
        private val TERMINAL = setOf(EventOutcome.SUCCEEDED, EventOutcome.FAILED, EventOutcome.BLOCKED, EventOutcome.CANCELLED)
        private val FAILURE_OUTCOMES = setOf(EventOutcome.FAILED, EventOutcome.BLOCKED)
    }
}
