package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Base64

/** Durable, append-only recovery receipt ledger. A corrupt ledger is never silently reset. */
class DurableRecoveryAuditStore(private val path: Path) {
    private data class Record(val receipt: RecoveryAuditReceipt, val previousHash: String, val hash: String)
    private val records = mutableListOf<Record>()

    init { loadAndVerify() }

    @Synchronized fun append(receipt: RecoveryAuditReceipt) {
        val existing = records.firstOrNull { it.receipt.receiptId == receipt.receiptId }
        if (existing != null) {
            require(existing.receipt == receipt) { "Conflicting recovery receipt ID" }
            return
        }
        val previous = records.lastOrNull()?.hash ?: GENESIS
        val record = Record(receipt, previous, hash(previous, canonical(receipt)))
        val next = records + record
        persist(next)
        records.add(record)
    }

    @Synchronized fun snapshot(): List<RecoveryAuditReceipt> = records.map { it.receipt }

    @Synchronized fun verifyIntegrity(): Boolean {
        var previous = GENESIS
        for (record in records) {
            if (record.previousHash != previous || record.hash != hash(previous, canonical(record.receipt))) return false
            previous = record.hash
        }
        return true
    }

    private fun loadAndVerify() {
        if (!Files.exists(path)) return
        val lines = Files.readAllLines(path, UTF_8)
        require(lines.isNotEmpty() && lines.first() == HEADER) { "Unsupported or corrupt recovery audit journal" }
        var previous = GENESIS
        val seen = mutableSetOf<String>()
        for (line in lines.drop(1)) {
            require(line.isNotBlank()) { "Blank record in recovery audit journal" }
            val fields = line.split('|')
            require(fields.size == 12) { "Malformed recovery audit record" }
            val receipt = decode(fields)
            require(seen.add(receipt.receiptId)) { "Duplicate recovery receipt ID" }
            require(fields[10] == previous) { "Recovery audit chain predecessor mismatch" }
            val expected = hash(previous, canonical(receipt))
            require(fields[11] == expected) { "Recovery audit integrity check failed" }
            records.add(Record(receipt, previous, expected))
            previous = expected
        }
    }

    private fun persist(items: List<Record>) {
        val target = path.toAbsolutePath()
        target.parent?.let(Files::createDirectories)
        val content = buildString {
            append(HEADER).append('\n')
            items.forEach { r -> append(encode(r.receipt, r.previousHash, r.hash)).append('\n') }
        }
        val temp = Files.createTempFile(target.parent, target.fileName.toString(), ".pending")
        try {
            Files.writeString(temp, content, UTF_8)
            try { Files.move(temp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING) }
            catch (_: java.nio.file.AtomicMoveNotSupportedException) { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING) }
        } finally { Files.deleteIfExists(temp) }
    }

    private fun encode(r: RecoveryAuditReceipt, previous: String, hash: String): String {
        val strings = listOf(r.receiptId, r.archiveId)
        val encoded = strings.map { Base64.getUrlEncoder().withoutPadding().encodeToString(it.toByteArray(UTF_8)) }
        return listOf(encoded[0], r.createdAtMillis, encoded[1], r.archiveSha256, r.ownerDecision.name,
            r.outcome.name, r.added, r.skipped, r.conflicts, FORMAT, previous, hash).joinToString("|")
    }

    private fun decode(f: List<String>): RecoveryAuditReceipt {
        require(f[9] == FORMAT) { "Unsupported recovery audit record version" }
        fun decoded(s: String) = String(Base64.getUrlDecoder().decode(s), UTF_8)
        return RecoveryAuditReceipt(decoded(f[0]), f[1].toLong(), decoded(f[2]), f[3],
            OwnerRecoveryDecision.valueOf(f[4]), RecoveryOutcome.valueOf(f[5]),
            f[6].toInt(), f[7].toInt(), f[8].toInt())
    }

    private fun canonical(r: RecoveryAuditReceipt): String = listOf(r.receiptId, r.createdAtMillis,
        r.archiveId, r.archiveSha256, r.ownerDecision.name, r.outcome.name, r.added, r.skipped, r.conflicts)
        .joinToString("\t")

    private fun hash(previous: String, payload: String): String = MessageDigest.getInstance("SHA-256")
        .digest("$previous\n$payload".toByteArray(UTF_8)).joinToString("") { "%02x".format(it) }

    companion object {
        private const val HEADER = "AQUA_RECOVERY_AUDIT|1"
        private const val FORMAT = "1"
        private val GENESIS = "0".repeat(64)
    }
}
