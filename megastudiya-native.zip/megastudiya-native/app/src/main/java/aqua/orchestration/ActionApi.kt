package aqua.orchestration

/** Stable, typed boundary for future tools. Definitions describe capability; they do not execute it. */
enum class ActionMode { DRY_RUN }
enum class ActionStatus { ACCEPTED_FOR_SIMULATION, DENIED, INVALID, DUPLICATE }

data class ActionArgument(
    val name: String,
    val required: Boolean = true,
    val maxLength: Int = 4096
) {
    init { require(name.matches(Regex("[a-zA-Z][a-zA-Z0-9_]{0,63}"))); require(maxLength in 1..65536) }
}

data class ActionDefinition(
    val key: String,
    val description: String,
    val arguments: List<ActionArgument>,
    val requiredPermission: String,
    val risk: ActionRisk,
    val enabled: Boolean = true
) {
    init {
        require(key.matches(Regex("[a-z][a-z0-9_.-]{1,95}")))
        require(description.isNotBlank() && requiredPermission.isNotBlank())
        require(arguments.map { it.name }.toSet().size == arguments.size) { "Duplicate argument definition" }
    }
}

data class ActionRequest(
    val requestId: String,
    val actionKey: String,
    val arguments: Map<String, String>,
    val grantedPermissions: Set<String>,
    val mode: ActionMode = ActionMode.DRY_RUN
)

data class ActionResult(
    val requestId: String,
    val actionKey: String,
    val status: ActionStatus,
    val code: String,
    val message: String,
    val resultFingerprint: String
)

fun interface ActionPermissionPolicy { fun allows(permission: String, granted: Set<String>): Boolean }

/** Catalogue rejects duplicate keys; callers receive immutable snapshots. */
class ActionCatalog(definitions: List<ActionDefinition>) {
    private val byKey: Map<String, ActionDefinition>
    init {
        require(definitions.map { it.key }.toSet().size == definitions.size) { "Duplicate action key" }
        byKey = definitions.associateBy { it.key }
    }
    fun find(key: String): ActionDefinition? = byKey[key]
    fun snapshot(): List<ActionDefinition> = byKey.values.sortedBy { it.key }
}

/** The Step 47 dispatcher validates and simulates only. No live executor is exposed. */
class ActionApi(
    private val catalog: ActionCatalog,
    private val permissionPolicy: ActionPermissionPolicy = ActionPermissionPolicy { permission, granted -> permission in granted },
    private val journal: ActionResultJournal = InMemoryActionResultJournal()
) {
    private val completed = linkedMapOf<String, ActionResult>().apply {
        journal.snapshot().forEach { result ->
            val previous = put(result.requestId, result)
            require(previous == null || previous == result) { "Conflicting journal request ID" }
        }
    }

    @Synchronized fun submit(request: ActionRequest): ActionResult {
        require(request.requestId.isNotBlank()) { "requestId must not be blank" }
        completed[request.requestId]?.let { prior ->
            return if (prior.actionKey == request.actionKey && prior.resultFingerprint == fingerprint(request)) prior
            else result(request, ActionStatus.DUPLICATE, "REQUEST_ID_CONFLICT", "Request ID already used with different content")
        }
        val definition = catalog.find(request.actionKey)
            ?: return remember(request, result(request, ActionStatus.DENIED, "ACTION_NOT_REGISTERED", "Action is not registered"))
        if (!definition.enabled) return remember(request, result(request, ActionStatus.DENIED, "ACTION_DISABLED", "Action is disabled"))
        if (request.mode != ActionMode.DRY_RUN)
            return remember(request, result(request, ActionStatus.DENIED, "LIVE_MODE_UNAVAILABLE", "Only dry-run mode is supported"))
        val allowedNames = definition.arguments.map { it.name }.toSet()
        val unknown = request.arguments.keys - allowedNames
        if (unknown.isNotEmpty()) return remember(request, result(request, ActionStatus.INVALID, "UNKNOWN_ARGUMENT", "Unknown arguments: ${unknown.sorted().joinToString()}"))
        val missing = definition.arguments.filter { it.required && it.name !in request.arguments }
        if (missing.isNotEmpty()) return remember(request, result(request, ActionStatus.INVALID, "MISSING_ARGUMENT", "Missing arguments: ${missing.joinToString { it.name }}"))
        val tooLong = definition.arguments.firstOrNull { (request.arguments[it.name]?.length ?: 0) > it.maxLength }
        if (tooLong != null) return remember(request, result(request, ActionStatus.INVALID, "ARGUMENT_TOO_LONG", "Argument ${tooLong.name} exceeds its limit"))
        if (!permissionPolicy.allows(definition.requiredPermission, request.grantedPermissions))
            return remember(request, result(request, ActionStatus.DENIED, "PERMISSION_REQUIRED", "Required permission is not granted"))
        return remember(request, result(request, ActionStatus.ACCEPTED_FOR_SIMULATION, "DRY_RUN_ACCEPTED", "Validated; no action was executed"))
    }

    @Synchronized fun resultFor(requestId: String): ActionResult? = completed[requestId]
    @Synchronized fun auditSnapshot(): List<ActionResult> = completed.values.toList()

    private fun remember(request: ActionRequest, result: ActionResult): ActionResult {
        journal.append(result) // Durable append must succeed before publishing in memory.
        completed[request.requestId] = result
        return result
    }
    private fun result(request: ActionRequest, status: ActionStatus, code: String, message: String) =
        ActionResult(request.requestId, request.actionKey, status, code, message, fingerprint(request))
    private fun fingerprint(request: ActionRequest): String {
        val canonical = listOf(request.requestId, request.actionKey, request.mode.name,
            request.arguments.toSortedMap().entries.joinToString("\u001f") { "${it.key}=${it.value}" },
            request.grantedPermissions.sorted().joinToString("\u001f")).joinToString("\u001e")
        return java.security.MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}
