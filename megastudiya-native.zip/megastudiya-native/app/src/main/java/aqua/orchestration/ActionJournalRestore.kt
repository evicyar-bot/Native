package aqua.orchestration

import java.nio.file.Path
import java.security.MessageDigest

/** Preview-only classification; no journal is modified while preparing a plan. */
enum class RestoreDisposition { NEW_RECORD, IDENTICAL_DUPLICATE, CONFLICT }

data class RestoreItem(val requestId: String, val disposition: RestoreDisposition)
data class ActionJournalRestorePlan(
    val archive: Path,
    val archiveSha256: String,
    val targetSnapshotFingerprint: String,
    val items: List<RestoreItem>,
    val valid: Boolean,
    val error: String? = null
) {
    val importableCount: Int get() = items.count { it.disposition == RestoreDisposition.NEW_RECORD }
    val conflictCount: Int get() = items.count { it.disposition == RestoreDisposition.CONFLICT }
}

data class ActionJournalRestoreResult(val applied: Boolean, val imported: Int, val skippedDuplicates: Int, val error: String? = null)

/** Explicit two-phase restore. Planning is read-only; apply requires affirmative owner approval. */
object ActionJournalRestore {
    fun preview(archive: Path, target: ActionResultJournal): ActionJournalRestorePlan {
        val report = ActionJournalExport.verify(archive)
        val targetRecords = target.snapshot()
        val targetById = targetRecords.associateBy { it.requestId }
        val items = if (report.valid) report.records.map { incoming ->
            val current = targetById[incoming.requestId]
            RestoreItem(incoming.requestId, when {
                current == null -> RestoreDisposition.NEW_RECORD
                current == incoming -> RestoreDisposition.IDENTICAL_DUPLICATE
                else -> RestoreDisposition.CONFLICT
            })
        } else emptyList()
        return ActionJournalRestorePlan(archive, report.sha256, fingerprint(targetRecords), items,
            report.valid, report.error)
    }

    /** Re-verifies source and target immediately before append; never overwrites existing IDs. */
    @Synchronized fun apply(plan: ActionJournalRestorePlan, target: ActionResultJournal, ownerApproved: Boolean): ActionJournalRestoreResult {
        if (!ownerApproved) return ActionJournalRestoreResult(false, 0, 0, "Owner approval is required")
        if (!plan.valid) return ActionJournalRestoreResult(false, 0, 0, "Restore plan is invalid")
        val report = ActionJournalExport.verify(plan.archive)
        if (!report.valid || report.sha256 != plan.archiveSha256)
            return ActionJournalRestoreResult(false, 0, 0, "Archive changed or failed integrity verification")
        val before = target.snapshot()
        if (fingerprint(before) != plan.targetSnapshotFingerprint)
            return ActionJournalRestoreResult(false, 0, 0, "Target journal changed after preview; create a new plan")
        val fresh = preview(plan.archive, target)
        if (!fresh.valid || fresh.items != plan.items || fresh.conflictCount > 0)
            return ActionJournalRestoreResult(false, 0, 0, "Restore plan has conflicts or changed since preview")
        val byId = report.records.associateBy { it.requestId }
        var imported = 0
        var duplicates = 0
        try {
            fresh.items.forEach { item ->
                when (item.disposition) {
                    RestoreDisposition.NEW_RECORD -> { target.append(byId.getValue(item.requestId)); imported++ }
                    RestoreDisposition.IDENTICAL_DUPLICATE -> duplicates++
                    RestoreDisposition.CONFLICT -> error("Conflict must never be imported")
                }
            }
        } catch (failure: Exception) {
            return ActionJournalRestoreResult(false, imported, duplicates,
                "Import stopped after $imported records: ${failure.message ?: "journal append failed"}")
        }
        return ActionJournalRestoreResult(true, imported, duplicates)
    }

    private fun fingerprint(records: List<ActionResult>): String {
        val canonical = records.joinToString("\u001e") { listOf(it.requestId, it.actionKey, it.status.name,
            it.code, it.message, it.resultFingerprint).joinToString("\u001f") }
        return MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}
