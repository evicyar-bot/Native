package aqua.orchestration

import java.security.MessageDigest

/** Step 75: strict schema and invariant validation for exported queue records. */
data class RecoveryArchiveQueueValidationIssue(val code: String, val field: String, val message: String)
data class RecoveryArchiveQueueValidationResult(val valid: Boolean, val issues: List<RecoveryArchiveQueueValidationIssue>, val checkedItems: Int = 0)
object RecoveryArchiveQueueSchemaValidator {
    fun validate(queue: RecoveryArchiveRemediationQueue): RecoveryArchiveQueueValidationResult {
        val issues = mutableListOf<RecoveryArchiveQueueValidationIssue>()
        queue.items.forEachIndexed { index, item ->
            val prefix = "items[$index]"
            if (item.id.isBlank()) issues += RecoveryArchiveQueueValidationIssue("ID_EMPTY", "$prefix.id", "ID must not be blank")
            if (item.priority !in 0..100) issues += RecoveryArchiveQueueValidationIssue("PRIORITY_RANGE", "$prefix.priority", "Priority must be 0..100")
            if (item.group.isBlank()) issues += RecoveryArchiveQueueValidationIssue("GROUP_EMPTY", "$prefix.group", "Group must not be blank")
            if (item.executable) issues += RecoveryArchiveQueueValidationIssue("EXECUTABLE_FORBIDDEN", "$prefix.executable", "Advisory queue items must not be executable")
            if (item.path.isBlank()) issues += RecoveryArchiveQueueValidationIssue("PATH_EMPTY", "$prefix.path", "Path must not be blank")
        }
        if (queue.fingerprint.isBlank()) issues += RecoveryArchiveQueueValidationIssue("FINGERPRINT_EMPTY", "fingerprint", "Fingerprint is required")
        return RecoveryArchiveQueueValidationResult(issues.isEmpty(), issues, queue.items.size)
    }
}

/** Step 76: deterministic validation summary for dashboards and reports. */
data class RecoveryArchiveQueueValidationSummary(val checkedItems: Int, val issueCount: Int, val valid: Boolean, val issueCodes: List<String>)
object RecoveryArchiveQueueValidationSummarizer {
    fun summarize(result: RecoveryArchiveQueueValidationResult) = RecoveryArchiveQueueValidationSummary(
        result.checkedItems, result.issues.size, result.valid, result.issues.map { it.code }.distinct().sorted())
}

/** Step 77: stable canonical field ordering for item digests. */
object RecoveryArchiveQueueCanonicalizer {
    fun canonicalItem(item: RecoveryArchiveRemediationItem): String = listOf(item.id, item.findingCode,
        item.severity.name, item.path, item.archiveId.orEmpty(), item.title, item.operatorAction,
        item.risk, item.priority.toString(), item.group, item.requiresOwnerDecision.toString(), item.executable.toString())
        .joinToString("\u001f") { escape(it) }
    fun canonicalQueue(queue: RecoveryArchiveRemediationQueue): String = queue.items
        .sortedBy { it.id }.joinToString("\n") { canonicalItem(it) }
    private fun escape(value: String) = value.replace("\\", "\\\\").replace("\u001f", "\\u001f").replace("\n", "\\n")
}

/** Step 78: compute digest independently of generated timestamp or display order. */
object RecoveryArchiveQueueContentDigest {
    fun digest(queue: RecoveryArchiveRemediationQueue): String = sha256(RecoveryArchiveQueueCanonicalizer.canonicalQueue(queue))
    private fun sha256(text: String) = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}

/** Step 79: detect changed item content between two valid snapshots' associated queues. */
data class RecoveryArchiveQueueChangeSet(val addedIds: List<String>, val removedIds: List<String>, val changedIds: List<String>, val unchangedIds: List<String>)
object RecoveryArchiveQueueChangeDetector {
    fun detect(before: RecoveryArchiveRemediationQueue, after: RecoveryArchiveRemediationQueue): RecoveryArchiveQueueChangeSet {
        val b = before.items.associateBy { it.id }; val a = after.items.associateBy { it.id }
        val added = a.keys - b.keys; val removed = b.keys - a.keys
        val shared = b.keys intersect a.keys
        val changed = shared.filter { RecoveryArchiveQueueCanonicalizer.canonicalItem(b.getValue(it)) != RecoveryArchiveQueueCanonicalizer.canonicalItem(a.getValue(it)) }
        val unchanged = shared - changed.toSet()
        return RecoveryArchiveQueueChangeSet(added.sorted(), removed.sorted(), changed.sorted(), unchanged.sorted())
    }
}

/** Step 80: deterministic filter by group, severity and minimum priority. */
object RecoveryArchiveQueueFilter {
    fun filter(items: List<RecoveryArchiveRemediationItem>, group: String? = null,
               severity: RecoveryReportRepairArchiveFindingSeverity? = null, minimumPriority: Int = 0): List<RecoveryArchiveRemediationItem> {
        require(minimumPriority in 0..100)
        return items.filter { (group == null || it.group == group) && (severity == null || it.severity == severity) && it.priority >= minimumPriority }
            .sortedWith(compareByDescending<RecoveryArchiveRemediationItem> { it.priority }.thenBy { it.id }
        )
    }
}

/** Step 81: safe tabular export with CSV quoting; data only, never commands. */
object RecoveryArchiveQueueCsvExporter {
    private fun cell(value: String) = if (value.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"${value.replace("\"", "\"\"")}\"" else value
    fun export(queue: RecoveryArchiveRemediationQueue): String {
        val header = "id,code,severity,path,priority,group,action,executable"
        val rows = queue.items.map { item -> listOf(item.id, item.findingCode, item.severity.name, item.path, item.priority.toString(), item.group, item.operatorAction, "false").joinToString(",") { cell(it) } }
        return (listOf(header) + rows).joinToString("\n")
    }
}

/** Step 82: bounded search over advisory text and IDs. */
object RecoveryArchiveQueueSearch {
    fun search(items: List<RecoveryArchiveRemediationItem>, query: String, limit: Int = 50): List<RecoveryArchiveRemediationItem> {
        require(limit in 1..200)
        val needle = query.trim().lowercase()
        if (needle.isEmpty()) return emptyList()
        return items.filter { listOf(it.id, it.findingCode, it.path, it.title, it.operatorAction, it.group).any { s -> s.lowercase().contains(needle) } }
            .sortedWith(compareByDescending<RecoveryArchiveRemediationItem> { it.priority }.thenBy { it.id }).take(limit)
    }
}

/** Step 83: queue statistics by severity/group without mutation. */
data class RecoveryArchiveQueueStatisticsSummary(val total: Int, val bySeverity: Map<String, Int>, val byGroup: Map<String, Int>, val averagePriority: Double, val maxPriority: Int)
object RecoveryArchiveQueueStatistics {
    fun calculate(items: List<RecoveryArchiveRemediationItem>): RecoveryArchiveQueueStatisticsSummary = RecoveryArchiveQueueStatisticsSummary(
        items.size, items.groupingBy { it.severity.name }.eachCount().toSortedMap(), items.groupingBy { it.group }.eachCount().toSortedMap(),
        if (items.isEmpty()) 0.0 else items.map { it.priority }.average(), items.maxOfOrNull { it.priority } ?: 0)
}

/** Step 84: export manifest links schema, content digest and non-executable policy. */
data class RecoveryArchiveQueueExportManifest(val schemaVersion: Int, val itemCount: Int, val contentDigest: String, val queueFingerprint: String, val executableItems: Int)
object RecoveryArchiveQueueExportManifestBuilder {
    fun build(queue: RecoveryArchiveRemediationQueue): RecoveryArchiveQueueExportManifest {
        val validation = RecoveryArchiveQueueSchemaValidator.validate(queue)
        require(validation.valid) { "Queue fails schema validation" }
        return RecoveryArchiveQueueExportManifest(1, queue.total, RecoveryArchiveQueueContentDigest.digest(queue), queue.fingerprint, queue.items.count { it.executable })
    }
}
