package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Base64

/** Append-only result store contract used by the dry-run Action API. */
interface ActionResultJournal {
    fun append(result: ActionResult)
    fun snapshot(): List<ActionResult>
}

class InMemoryActionResultJournal : ActionResultJournal {
    private val entries = linkedMapOf<String, ActionResult>()
    @Synchronized override fun append(result: ActionResult) {
        val old = entries[result.requestId]
        require(old == null || old == result) { "Conflicting request ID" }
        if (old == null) entries[result.requestId] = result
    }
    @Synchronized override fun snapshot(): List<ActionResult> = entries.values.toList()
}

/**
 * Versioned, hash-chained journal. Each update is written to a sibling temporary file
 * and atomically replaced before it becomes visible to the caller. This stores only
 * simulation results; it never replays or executes an action.
 */
class DurableActionResultJournal(private val file: Path) : ActionResultJournal {
    private val entries = mutableListOf<ActionResult>()
    private var chainHead = ZERO_HASH

    init {
        if (Files.exists(file)) loadAndVerify()
    }

    @Synchronized override fun append(result: ActionResult) {
        val existing = entries.firstOrNull { it.requestId == result.requestId }
        require(existing == null || existing == result) { "Conflicting request ID" }
        if (existing != null) return
        val next = entries + result
        val encoded = encode(next)
        val parent = file.toAbsolutePath().parent
        if (parent != null) Files.createDirectories(parent)
        val temp = Files.createTempFile(parent, file.fileName.toString(), ".pending")
        try {
            Files.write(temp, encoded.toByteArray(UTF_8))
            try {
                Files.move(temp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
            } catch (_: java.nio.file.AtomicMoveNotSupportedException) {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING)
            }
        } finally {
            Files.deleteIfExists(temp)
        }
        entries.add(result)
        chainHead = hashLine(chainHead, payload(result))
    }

    @Synchronized override fun snapshot(): List<ActionResult> = entries.toList()

    private fun loadAndVerify() {
        val lines = Files.readAllLines(file, UTF_8)
        require(lines.firstOrNull() == HEADER) { "Unsupported action journal format" }
        var expectedParent = ZERO_HASH
        val restored = mutableListOf<ActionResult>()
        val ids = mutableSetOf<String>()
        for (line in lines.drop(1)) {
            if (line.isBlank()) continue
            val parts = line.split('\t')
            require(parts.size == 8) { "Malformed action journal entry" }
            val parent = parts[0]
            require(parent == expectedParent) { "Action journal chain mismatch" }
            val result = decode(parts.drop(1).take(6))
            require(ids.add(result.requestId)) { "Duplicate request ID in action journal" }
            val expectedHash = hashLine(parent, payload(result))
            require(parts[7] == expectedHash) { "Action journal integrity failure" }
            restored.add(result)
            expectedParent = expectedHash
        }
        entries.addAll(restored)
        chainHead = expectedParent
    }

    private fun encode(values: List<ActionResult>): String {
        val out = StringBuilder(HEADER).append('\n')
        var parent = ZERO_HASH
        values.forEach { result ->
            val fields = listOf(result.requestId, result.actionKey, result.status.name,
                result.code, result.message, result.resultFingerprint)
            val row = fields.joinToString("\t") { b64(it) }
            val hash = hashLine(parent, payload(result))
            out.append(parent).append('\t').append(row).append('\t').append(hash).append('\n')
            parent = hash
        }
        return out.toString()
    }

    private fun decode(encoded: List<String>): ActionResult {
        val fields = encoded.map(::unb64)
        return ActionResult(fields[0], fields[1], ActionStatus.valueOf(fields[2]),
            fields[3], fields[4], fields[5])
    }

    private fun payload(result: ActionResult): String = listOf(result.requestId, result.actionKey,
        result.status.name, result.code, result.message, result.resultFingerprint).joinToString("\u001f")

    private fun hashLine(parent: String, value: String): String = sha256(parent + "\u001e" + value)
    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(UTF_8)).joinToString("") { "%02x".format(it) }
    private fun b64(value: String): String = Base64.getUrlEncoder().withoutPadding().encodeToString(value.toByteArray(UTF_8))
    private fun unb64(value: String): String = String(Base64.getUrlDecoder().decode(value), UTF_8)

    companion object {
        private const val HEADER = "AQUA_ACTION_JOURNAL_V1"
        private const val ZERO_HASH = "0000000000000000000000000000000000000000000000000000000000000000"
    }
}
