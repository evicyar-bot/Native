package aqua.orchestration

import java.io.File
import java.security.MessageDigest

/** Review/freeze record only; it does not grant tool access or execute a queue. */
enum class ResumeApprovalDecision { APPROVE, REJECT }
data class FrozenResumeQueue(val planFingerprint: String, val queueFingerprint: String, val items: List<ResumeQueueItem>, val stopped: Boolean)
data class ResumeApprovalRecord(val planFingerprint: String, val queueFingerprint: String, val reviewer: String, val decision: ResumeApprovalDecision, val reviewedAtEpochMs: Long, val rationale: String)

object ResumeQueueApprovalService {
    fun freeze(queue: ResumeQueue): FrozenResumeQueue {
        val canonical = buildString {
            append(queue.planFingerprint).append('|').append(queue.stopped).append('\n')
            queue.items.forEach { append(it.stepId).append('|').append(it.disposition.name).append('|').append(it.rationale).append('\n') }
        }
        return FrozenResumeQueue(queue.planFingerprint, sha256(canonical), queue.items.toList(), queue.stopped)
    }
    fun record(frozen: FrozenResumeQueue, reviewer: String, decision: ResumeApprovalDecision, timestamp: Long, rationale: String): ResumeApprovalRecord {
        require(reviewer.isNotBlank() && timestamp > 0) { "Reviewer and positive timestamp required" }
        require(listOf(reviewer, rationale, frozen.planFingerprint, frozen.queueFingerprint).none { it.contains('\n') || it.contains('\r') }) { "Fields must be single-line" }
        require(!frozen.stopped) { "Stopped queue cannot be approved" }
        require(frozen.items.none { it.disposition == ResumeDisposition.NEEDS_RECONCILIATION || it.disposition == ResumeDisposition.BLOCKED_DEPENDENCY }) { "Queue contains unresolved items" }
        return ResumeApprovalRecord(frozen.planFingerprint, frozen.queueFingerprint, reviewer.trim(), decision, timestamp, rationale)
    }
    fun matches(approval: ResumeApprovalRecord, current: FrozenResumeQueue): Boolean =
        approval.planFingerprint == current.planFingerprint && approval.queueFingerprint == current.queueFingerprint && !current.stopped
    fun save(file: File, record: ResumeApprovalRecord) {
        val payload = listOf("AQUA_RESUME_APPROVAL_V1", record.planFingerprint, record.queueFingerprint, record.reviewer,
            record.decision.name, record.reviewedAtEpochMs.toString(), record.rationale).joinToString("\n")
        val data = payload + "\n" + sha256(payload)
        file.parentFile?.mkdirs(); val temp = File(file.parentFile ?: File("."), file.name + ".tmp")
        temp.writeText(data, Charsets.UTF_8)
        if (!temp.renameTo(file)) { temp.copyTo(file, overwrite = true); temp.delete() }
    }
    fun load(file: File): ResumeApprovalRecord {
        val lines = file.readLines(Charsets.UTF_8); require(lines.size == 8 && lines[0] == "AQUA_RESUME_APPROVAL_V1") { "Invalid approval record" }
        val payload = lines.take(7).joinToString("\n"); require(lines[7] == sha256(payload)) { "Approval checksum mismatch" }
        return ResumeApprovalRecord(lines[1], lines[2], lines[3], ResumeApprovalDecision.valueOf(lines[4]), lines[5].toLong(), lines[6])
    }
    private fun sha256(text: String): String = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
