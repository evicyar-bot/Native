package aqua.orchestration

import java.security.MessageDigest

/** Imported queue data is untrusted and is never executable. */
data class RecoveryArchiveQueueImportRecord(
    val id: String,
    val findingCode: String,
    val severity: String,
    val path: String,
    val priority: Int,
    val group: String,
    val operatorAction: String,
    val executable: Boolean = false
)

data class RecoveryArchiveQueueImportManifest(
    val schemaVersion: Int,
    val itemCount: Int,
    val contentDigest: String
)

data class RecoveryArchiveQueueImportIssue(val code: String, val field: String, val message: String)

data class RecoveryArchiveQueueImportValidation(
    val valid: Boolean,
    val issues: List<RecoveryArchiveQueueImportIssue>,
    val normalizedRecords: List<RecoveryArchiveQueueImportRecord>,
    val digest: String
)

/** Step 85: schema validation at the import boundary. */
object RecoveryArchiveQueueImportSchema {
    const val CURRENT_VERSION = 1
    fun validateVersion(version: Int): Boolean = version == CURRENT_VERSION
}

/** Step 86: bounded input validation before processing. */
object RecoveryArchiveQueueImportLimits {
    const val MAX_RECORDS = 10_000
    const val MAX_FIELD_LENGTH = 4_096
    const val MAX_TOTAL_TEXT = 2_000_000
    fun withinLimits(records: List<RecoveryArchiveQueueImportRecord>): Boolean =
        records.size <= MAX_RECORDS &&
            records.sumOf { it.id.length + it.findingCode.length + it.severity.length + it.path.length +
                it.group.length + it.operatorAction.length } <= MAX_TOTAL_TEXT &&
            records.all { listOf(it.id, it.findingCode, it.severity, it.path, it.group, it.operatorAction)
                .all { value -> value.length <= MAX_FIELD_LENGTH } }
}

/** Step 87: trim fields and normalize severity without changing path contents. */
object RecoveryArchiveQueueImportNormalizer {
    fun normalize(r: RecoveryArchiveQueueImportRecord): RecoveryArchiveQueueImportRecord = r.copy(
        id = r.id.trim(), findingCode = r.findingCode.trim(), severity = r.severity.trim().uppercase(),
        group = r.group.trim(), operatorAction = r.operatorAction.trim()
    )
}

/** Step 88: executable imports are rejected, never downgraded silently. */
object RecoveryArchiveQueueImportExecutionPolicy {
    fun safe(records: List<RecoveryArchiveQueueImportRecord>): Boolean = records.none { it.executable }
}

/** Step 89: stable IDs must be unique after normalization. */
object RecoveryArchiveQueueImportUniqueness {
    fun unique(records: List<RecoveryArchiveQueueImportRecord>): Boolean =
        records.map { it.id }.distinct().size == records.size
}

/** Step 90: digest format is validated and content digest is deterministic. */
object RecoveryArchiveQueueImportDigest {
    fun isSha256(value: String): Boolean = value.matches(Regex("^[a-fA-F0-9]{64}$"))
    fun digest(records: List<RecoveryArchiveQueueImportRecord>): String {
        val canonical = records.sortedBy { it.id }.joinToString("\\n") {
            listOf(it.id, it.findingCode, it.severity, it.path, it.priority.toString(), it.group,
                it.operatorAction, it.executable.toString()).joinToString("|")
        }
        return MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}

/** Step 91: field-level invariants, independent from schema/version checks. */
object RecoveryArchiveQueueImportFieldValidation {
    fun issues(r: RecoveryArchiveQueueImportRecord): List<RecoveryArchiveQueueImportIssue> = buildList {
        if (r.id.isBlank()) add(RecoveryArchiveQueueImportIssue("EMPTY_ID", "id", "ID must not be blank"))
        if (r.findingCode.isBlank()) add(RecoveryArchiveQueueImportIssue("EMPTY_CODE", "findingCode", "Code must not be blank"))
        if (r.severity !in setOf("ERROR", "WARNING", "INFO")) add(RecoveryArchiveQueueImportIssue("INVALID_SEVERITY", "severity", "Unsupported severity"))
        if (r.priority !in 0..100) add(RecoveryArchiveQueueImportIssue("INVALID_PRIORITY", "priority", "Priority must be 0..100"))
        if (r.group.isBlank()) add(RecoveryArchiveQueueImportIssue("EMPTY_GROUP", "group", "Group must not be blank"))
        if (r.path.any { it.code == 0 }) add(RecoveryArchiveQueueImportIssue("NUL_PATH", "path", "Path contains NUL"))
    }
}

/** Step 92: build a read-only import preview; no persistence or execution. */
data class RecoveryArchiveQueueImportPreview(val count: Int, val digest: String, val accepted: Boolean, val issues: List<RecoveryArchiveQueueImportIssue>)
object RecoveryArchiveQueueImportPreviewBuilder {
    fun preview(records: List<RecoveryArchiveQueueImportRecord>, manifest: RecoveryArchiveQueueImportManifest): RecoveryArchiveQueueImportPreview {
        val normalized = records.map(RecoveryArchiveQueueImportNormalizer::normalize)
        val issues = mutableListOf<RecoveryArchiveQueueImportIssue>()
        if (!RecoveryArchiveQueueImportSchema.validateVersion(manifest.schemaVersion))
            issues += RecoveryArchiveQueueImportIssue("SCHEMA_VERSION", "schemaVersion", "Unsupported schema version")
        if (!RecoveryArchiveQueueImportLimits.withinLimits(normalized))
            issues += RecoveryArchiveQueueImportIssue("INPUT_LIMIT", "records", "Input exceeds configured limits")
        if (!RecoveryArchiveQueueImportExecutionPolicy.safe(normalized))
            issues += RecoveryArchiveQueueImportIssue("EXECUTABLE_ENTRY", "executable", "Executable entries are prohibited")
        if (!RecoveryArchiveQueueImportUniqueness.unique(normalized))
            issues += RecoveryArchiveQueueImportIssue("DUPLICATE_ID", "id", "IDs must be unique")
        normalized.forEach { issues += RecoveryArchiveQueueImportFieldValidation.issues(it) }
        val digest = RecoveryArchiveQueueImportDigest.digest(normalized)
        if (manifest.itemCount != normalized.size)
            issues += RecoveryArchiveQueueImportIssue("COUNT_MISMATCH", "itemCount", "Manifest count does not match")
        if (!RecoveryArchiveQueueImportDigest.isSha256(manifest.contentDigest) || manifest.contentDigest != digest)
            issues += RecoveryArchiveQueueImportIssue("DIGEST_MISMATCH", "contentDigest", "Digest is invalid or does not match")
        return RecoveryArchiveQueueImportPreview(normalized.size, digest, issues.isEmpty(), issues)
    }
}

/** Step 93: import audit metadata without storing imported payloads. */
data class RecoveryArchiveQueueImportAudit(val schemaVersion: Int, val importedCount: Int, val digest: String, val accepted: Boolean, val issueCodes: List<String>)
object RecoveryArchiveQueueImportAuditBuilder {
    fun from(preview: RecoveryArchiveQueueImportPreview): RecoveryArchiveQueueImportAudit =
        RecoveryArchiveQueueImportAudit(RecoveryArchiveQueueImportSchema.CURRENT_VERSION, preview.count,
            preview.digest, preview.accepted, preview.issues.map { it.code }.distinct().sorted())
}

/** Step 94: explicit final result; accepted means validated preview only, not persisted. */
data class RecoveryArchiveQueueImportResult(val acceptedForReview: Boolean, val persisted: Boolean, val executable: Boolean, val audit: RecoveryArchiveQueueImportAudit)
object RecoveryArchiveQueueImportResultBuilder {
    fun from(preview: RecoveryArchiveQueueImportPreview): RecoveryArchiveQueueImportResult =
        RecoveryArchiveQueueImportResult(preview.accepted, false, false, RecoveryArchiveQueueImportAuditBuilder.from(preview))
}
