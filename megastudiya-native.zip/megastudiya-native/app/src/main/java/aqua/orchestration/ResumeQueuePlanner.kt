package aqua.orchestration

import aqua.execution.ExecutionLedger
import aqua.execution.StepExecutionStatus

/** Computes a reviewable resume queue from durable state; never starts work. */
enum class ResumeDisposition { ALREADY_COMPLETED, QUEUED, BLOCKED_DEPENDENCY, NEEDS_RECONCILIATION, NEEDS_APPROVAL, STOPPED }
data class ResumeQueueItem(val stepId: String, val disposition: ResumeDisposition, val rationale: String)
data class ResumeQueue(val planFingerprint: String, val items: List<ResumeQueueItem>, val requiresOwnerReview: Boolean, val stopped: Boolean)

class ResumeQueuePlanner {
    fun build(planFingerprint: String, steps: List<OrchestrationStep>, ledger: ExecutionLedger,
              session: OrchestrationSessionState, approvalRequired: Set<String> = emptySet()): ResumeQueue {
        require(planFingerprint.isNotBlank() && session.planFingerprint == planFingerprint) { "Plan/session fingerprint mismatch" }
        require(steps.map { it.stepId }.distinct().size == steps.size) { "Duplicate plan step" }
        require(steps.map { it.stepId }.toSet() == ledger.steps.map { it.stepId }.toSet()) { "Plan/ledger step mismatch" }
        require(steps.all { step -> step.dependsOn.all { dep -> steps.any { it.stepId == dep } } }) { "Unknown dependency" }
        val states = ledger.steps.associate { it.stepId to it.status }
        val items = mutableListOf<ResumeQueueItem>()
        for (step in steps) {
            val status = states.getValue(step.stepId)
            val disposition: ResumeDisposition; val reason: String
            if (session.stopRequested) { disposition = ResumeDisposition.STOPPED; reason = "Session stop flag is active; no resume queue is produced." }
            else when (status) {
                StepExecutionStatus.SUCCEEDED, StepExecutionStatus.SKIPPED -> { disposition = ResumeDisposition.ALREADY_COMPLETED; reason = "Terminal completed/skipped state is retained; not repeated." }
                StepExecutionStatus.RUNNING, StepExecutionStatus.INTERRUPTED -> { disposition = ResumeDisposition.NEEDS_RECONCILIATION; reason = "Interrupted or in-flight state must be reconciled by owner before resume." }
                StepExecutionStatus.CANCELLED -> { disposition = ResumeDisposition.NEEDS_APPROVAL; reason = "Cancelled work is not resumed automatically." }
                StepExecutionStatus.FAILED -> { disposition = ResumeDisposition.NEEDS_APPROVAL; reason = "Failed step requires explicit review before retry." }
                else -> if (step.dependsOn.any { states[it] != StepExecutionStatus.SUCCEEDED && states[it] != StepExecutionStatus.SKIPPED }) {
                    disposition = ResumeDisposition.BLOCKED_DEPENDENCY; reason = "One or more dependencies are not complete."
                } else if (step.stepId in approvalRequired || step.requiresApproval) {
                    disposition = ResumeDisposition.NEEDS_APPROVAL; reason = "Explicit owner approval required before queuing."
                } else { disposition = ResumeDisposition.QUEUED; reason = "Eligible for a reviewable resume queue; not executed." }
            }
            items += ResumeQueueItem(step.stepId, disposition, reason)
        }
        val review = items.any { it.disposition in setOf(ResumeDisposition.NEEDS_RECONCILIATION, ResumeDisposition.NEEDS_APPROVAL) }
        return ResumeQueue(planFingerprint, items, review, session.stopRequested)
    }
}
