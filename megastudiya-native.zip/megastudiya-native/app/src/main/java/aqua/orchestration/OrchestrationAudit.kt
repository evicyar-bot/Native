package aqua.orchestration

import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

/** Immutable audit record for a dry-run decision; it records, never executes. */
data class AuditRecord(val sequence: Long, val sessionId: String, val stepId: String, val actionKey: String,
    val decision: ActionDecision, val reason: String, val previousHash: String, val hash: String)

class OrchestrationAudit {
    private val records = mutableListOf<AuditRecord>()
    @Synchronized fun append(sessionId: String, stepId: String, actionKey: String, decision: ActionDecision, reason: String = ""): AuditRecord {
        require(sessionId.isNotBlank() && stepId.isNotBlank() && actionKey.isNotBlank())
        val prev = records.lastOrNull()?.hash ?: "GENESIS"
        val seq = records.size.toLong() + 1
        val payload = listOf(seq.toString(), sessionId, stepId, actionKey, decision.name, reason, prev).joinToString("\t")
        val rec = AuditRecord(seq, sessionId, stepId, actionKey, decision, reason, prev, sha(payload))
        records += rec; return rec
    }
    @Synchronized fun snapshot(): List<AuditRecord> = records.toList()
    @Synchronized fun verify(): Boolean = records.withIndex().all { (i, r) ->
        val expectedPrev = if (i == 0) "GENESIS" else records[i-1].hash
        r.sequence == i + 1L && r.previousHash == expectedPrev && r.hash == sha(payload(r))
    }
    @Synchronized fun save(file: File) {
        require(verify()) { "Audit chain failed verification" }
        file.parentFile?.mkdirs()
        val body = records.joinToString("\n") { listOf(it.sequence, enc(it.sessionId), enc(it.stepId), enc(it.actionKey), it.decision.name, enc(it.reason), it.previousHash, it.hash).joinToString("\t") }
        val temp = File(file.parentFile ?: File("."), file.name + ".tmp")
        temp.writeText("AQUA_AUDIT_V1\n" + body + if (body.isEmpty()) "" else "\n")
        try { Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE) }
        catch (_: Exception) { Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING) }
    }
    @Synchronized fun load(file: File) {
        val lines = file.readLines(); require(lines.firstOrNull() == "AQUA_AUDIT_V1") { "Invalid audit header" }
        val parsed = lines.drop(1).filter { it.isNotBlank() }.map { line ->
            val p = line.split('\t'); require(p.size == 8)
            AuditRecord(p[0].toLong(), dec(p[1]), dec(p[2]), dec(p[3]), ActionDecision.valueOf(p[4]), dec(p[5]), p[6], p[7])
        }
        records.clear(); records.addAll(parsed); require(verify()) { "Audit integrity failure" }
    }
    private fun payload(r: AuditRecord) = listOf(r.sequence.toString(), r.sessionId, r.stepId, r.actionKey, r.decision.name, r.reason, r.previousHash).joinToString("\t")
    private fun sha(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun enc(s: String) = java.util.Base64.getEncoder().encodeToString(s.toByteArray())
    private fun dec(s: String) = String(java.util.Base64.getDecoder().decode(s))
}
