package aqua.orchestration

import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

/** Persisted dry-run session state. Recovery never authorizes live execution. */
data class OrchestrationSessionState(
    val sessionId: String,
    val planFingerprint: String,
    val decisions: Map<String, ActionDecision>,
    val stopRequested: Boolean,
    val auditHeadHash: String,
    val updatedAtEpochMs: Long
) {
    init {
        require(sessionId.isNotBlank() && planFingerprint.isNotBlank())
        require(decisions.keys.all { it.isNotBlank() })
        require(auditHeadHash.isNotBlank() && updatedAtEpochMs >= 0)
    }
}

enum class SessionRecoveryStatus { RESTORED, STOPPED, PLAN_MISMATCH }
data class SessionRecoveryResult(val status: SessionRecoveryStatus, val state: OrchestrationSessionState?, val message: String)

class OrchestrationSessionStore {
    @Synchronized fun save(file: File, state: OrchestrationSessionState) {
        val encodedDecisions = state.decisions.toSortedMap().entries.joinToString(",") { enc(it.key) + ":" + it.value.name }
        val payload = listOf(enc(state.sessionId), enc(state.planFingerprint), encodedDecisions, state.stopRequested.toString(), enc(state.auditHeadHash), state.updatedAtEpochMs.toString()).joinToString("\t")
        file.parentFile?.mkdirs()
        val temp = File(file.parentFile ?: File("."), file.name + ".tmp")
        temp.writeText("AQUA_SESSION_V1\n$payload\n${sha(payload)}\n")
        try { Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE) }
        catch (_: Exception) { Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING) }
    }

    @Synchronized fun recover(file: File, expectedPlanFingerprint: String): SessionRecoveryResult {
        require(expectedPlanFingerprint.isNotBlank())
        if (!file.exists()) return SessionRecoveryResult(SessionRecoveryStatus.PLAN_MISMATCH, null, "No saved session.")
        val lines = file.readLines(); require(lines.size == 3 && lines[0] == "AQUA_SESSION_V1") { "Invalid session file" }
        val payload = lines[1]; require(sha(payload) == lines[2]) { "Session integrity failure" }
        val p = payload.split('\t'); require(p.size == 6) { "Invalid session payload" }
        val decisions = if (p[2].isBlank()) emptyMap() else p[2].split(',').associate { pair ->
            val parts = pair.split(':'); require(parts.size == 2); dec(parts[0]) to ActionDecision.valueOf(parts[1])
        }
        val state = OrchestrationSessionState(dec(p[0]), dec(p[1]), decisions, p[3].toBooleanStrict(), dec(p[4]), p[5].toLong())
        if (state.planFingerprint != expectedPlanFingerprint) return SessionRecoveryResult(SessionRecoveryStatus.PLAN_MISMATCH, state, "Plan fingerprint changed; review required.")
        if (state.stopRequested) return SessionRecoveryResult(SessionRecoveryStatus.STOPPED, state, "Stop flag restored; resume requires explicit review.")
        return SessionRecoveryResult(SessionRecoveryStatus.RESTORED, state, "Dry-run session restored; no actions executed.")
    }
    private fun sha(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun enc(s: String) = java.util.Base64.getEncoder().encodeToString(s.toByteArray())
    private fun dec(s: String) = String(java.util.Base64.getDecoder().decode(s))
}
