package aqua.orchestration

import java.nio.file.Path

/** Read-only reporting facade over the verified on-disk recovery receipt ledger. */
class DurableRecoveryAuditReporting(private val durable: DurableRecoveryAuditStore) {
    /** Refuses to publish a report if the backing journal fails its integrity check. */
    @Synchronized fun query(
        filter: RecoveryAuditFilter = RecoveryAuditFilter(),
        generatedAtMillis: Long
    ): RecoveryAuditReport {
        require(durable.verifyIntegrity()) { "Recovery audit journal integrity check failed" }
        val indexed = RecoveryAuditReceiptStore()
        durable.snapshot().forEach(indexed::append)
        return indexed.query(filter, generatedAtMillis)
    }

    /** Export is derived from a fresh verified snapshot; it never mutates the source ledger. */
    @Synchronized fun exportCsv(
        filter: RecoveryAuditFilter = RecoveryAuditFilter(),
        generatedAtMillis: Long,
        destination: Path
    ): RecoveryAuditReport {
        val report = query(filter, generatedAtMillis)
        val exporter = RecoveryAuditReceiptStore()
        report.receipts.forEach(exporter::append)
        exporter.exportCsv(report, destination)
        return report
    }
}
