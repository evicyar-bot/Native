package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Base64

data class RecoveryReportRepairReviewExportStatus(
    val valid: Boolean,
    val receiptCount: Int,
    val lastHash: String,
    val payloadHash: String,
    val error: String? = null
)

/** Explicit portable export. SHA-256 detects mismatch, but is not a digital signature. */
object RecoveryReportRepairReviewJournalExport {
    private const val HEADER = "AQUA_REPAIR_REVIEW_EXPORT|1"
    private val ZERO = "0".repeat(64)

    /** Exports one validated snapshot to a single self-contained file; source remains untouched. */
    fun export(sourceJournal: Path, destination: Path): RecoveryReportRepairReviewExportStatus {
        val source = sourceJournal.toAbsolutePath().normalize()
        val target = destination.toAbsolutePath().normalize()
        require(source != target) { "Export destination must differ from source journal" }
        require(Files.isRegularFile(source)) { "Source review journal does not exist" }
        val sourceBytes = Files.readAllBytes(source)
        val snapshot = validatePayload(sourceBytes, target.parent)
        require(snapshot.valid) { snapshot.error ?: "Source journal is invalid" }
        val body = listOf(
            HEADER, sha256(sourceBytes), snapshot.receiptCount.toString(), snapshot.lastHash,
            Base64.getEncoder().encodeToString(sourceBytes)
        ).joinToString("\n", postfix = "\n")
        atomicWrite(target, body.toByteArray(UTF_8))
        return verify(target)
    }

    /** Independently verifies export framing, digest, count and full receipt hash chain. */
    fun verify(exportPath: Path): RecoveryReportRepairReviewExportStatus = try {
        require(Files.isRegularFile(exportPath)) { "Export file is missing" }
        val lines = Files.readAllLines(exportPath, UTF_8)
        require(lines.size == 5 && lines[0] == HEADER) { "Unsupported or malformed repair-review export" }
        require(lines[1].matches(Regex("[0-9a-f]{64}"))) { "Malformed export payload digest" }
        require(lines[2].toIntOrNull() != null && lines[2].toInt() >= 0) { "Malformed receipt count" }
        require(lines[3].matches(Regex("[0-9a-f]{64}"))) { "Malformed terminal receipt hash" }
        val bytes = Base64.getDecoder().decode(lines[4])
        val digest = sha256(bytes)
        require(digest == lines[1]) { "Export payload digest mismatch" }
        val checked = validatePayload(bytes, exportPath.toAbsolutePath().normalize().parent)
        require(checked.valid) { checked.error ?: "Exported journal failed validation" }
        require(checked.receiptCount == lines[2].toInt()) { "Export receipt count mismatch" }
        require(checked.lastHash == lines[3]) { "Export terminal hash mismatch" }
        RecoveryReportRepairReviewExportStatus(true, checked.receiptCount, checked.lastHash, digest)
    } catch (e: Exception) {
        RecoveryReportRepairReviewExportStatus(false, 0, ZERO, "", e.message ?: "Export validation failed")
    }

    private fun validatePayload(bytes: ByteArray, parent: Path?): RecoveryReportRepairReviewExportStatus {
        val directory = parent ?: Path.of(".").toAbsolutePath().normalize()
        Files.createDirectories(directory)
        val temporary = Files.createTempFile(directory, "aqua-review-export-check-", ".log")
        return try {
            Files.write(temporary, bytes)
            val journal = RecoveryReportRepairReviewJournal(temporary)
            val status = journal.verify()
            require(status.valid) { status.error ?: "Journal chain invalid" }
            RecoveryReportRepairReviewExportStatus(true, status.receiptCount, status.lastHash, sha256(bytes))
        } finally { Files.deleteIfExists(temporary) }
    }

    private fun atomicWrite(target: Path, bytes: ByteArray) {
        target.parent?.let(Files::createDirectories)
        val parent = target.parent ?: Path.of(".").toAbsolutePath().normalize()
        val temporary = Files.createTempFile(parent, target.fileName.toString(), ".pending")
        try {
            Files.write(temporary, bytes)
            try { Files.move(temporary, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING) }
            catch (_: java.nio.file.AtomicMoveNotSupportedException) {
                Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING)
            }
        } finally { Files.deleteIfExists(temporary) }
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(it) }
}
