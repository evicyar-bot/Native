package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Base64

/** Owner decision captured for every restore attempt, including rejected attempts. */
data class RestoreAuditReceipt(
    val receiptId: String,
    val timestampEpochMillis: Long,
    val archiveSha256: String,
    val targetBeforeFingerprint: String,
    val ownerApproved: Boolean,
    val applied: Boolean,
    val imported: Int,
    val skippedDuplicates: Int,
    val error: String?
)

interface RestoreAuditStore {
    fun append(receipt: RestoreAuditReceipt)
    fun snapshot(): List<RestoreAuditReceipt>
}

class InMemoryRestoreAuditStore : RestoreAuditStore {
    private val receipts = linkedMapOf<String, RestoreAuditReceipt>()
    @Synchronized override fun append(receipt: RestoreAuditReceipt) {
        val old = receipts[receipt.receiptId]
        require(old == null || old == receipt) { "Conflicting receipt ID" }
        if (old == null) receipts[receipt.receiptId] = receipt
    }
    @Synchronized override fun snapshot(): List<RestoreAuditReceipt> = receipts.values.toList()
}

/** Append-only durable audit log with a SHA-256 hash chain and atomic replacement. */
class DurableRestoreAuditStore(private val file: Path) : RestoreAuditStore {
    private val receipts = mutableListOf<RestoreAuditReceipt>()

    init { if (Files.exists(file)) load() }

    @Synchronized override fun append(receipt: RestoreAuditReceipt) {
        val old = receipts.firstOrNull { it.receiptId == receipt.receiptId }
        require(old == null || old == receipt) { "Conflicting receipt ID" }
        if (old != null) return
        val next = receipts + receipt
        val content = encode(next)
        val absolute = file.toAbsolutePath()
        absolute.parent?.let(Files::createDirectories)
        val temp = Files.createTempFile(absolute.parent, absolute.fileName.toString(), ".receipt-pending")
        try {
            Files.writeString(temp, content, UTF_8)
            try { Files.move(temp, absolute, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING) }
            catch (_: java.nio.file.AtomicMoveNotSupportedException) {
                Files.move(temp, absolute, StandardCopyOption.REPLACE_EXISTING)
            }
        } finally { Files.deleteIfExists(temp) }
        receipts.add(receipt)
    }

    @Synchronized override fun snapshot(): List<RestoreAuditReceipt> = receipts.toList()

    private fun load() {
        val lines = Files.readAllLines(file, UTF_8)
        require(lines.firstOrNull() == HEADER) { "Unsupported restore audit format" }
        var parent = ZERO
        val ids = mutableSetOf<String>()
        val loaded = mutableListOf<RestoreAuditReceipt>()
        lines.drop(1).filter { it.isNotBlank() }.forEach { line ->
            val fields = line.split('\t')
            require(fields.size == 11) { "Malformed restore receipt" }
            require(fields[0] == parent) { "Restore audit chain mismatch" }
            val values = fields.drop(1).dropLast(1).map(::decode)
            val receipt = RestoreAuditReceipt(values[0], values[1].toLong(), values[2], values[3],
                values[4].toBooleanStrict(), values[5].toBooleanStrict(), values[6].toInt(),
                values[7].toInt(), values[8].ifEmpty { null })
            require(ids.add(receipt.receiptId)) { "Duplicate restore receipt ID" }
            require(fields.last() == hash(parent, payload(receipt))) { "Restore audit integrity failure" }
            parent = fields.last()
            loaded.add(receipt)
        }
        receipts.addAll(loaded)
    }

    private fun encode(values: List<RestoreAuditReceipt>): String = buildString {
        append(HEADER).append('\n')
        var parent = ZERO
        values.forEach { receipt ->
            val fields = listOf(receipt.receiptId, receipt.timestampEpochMillis.toString(), receipt.archiveSha256,
                receipt.targetBeforeFingerprint, receipt.ownerApproved.toString(), receipt.applied.toString(),
                receipt.imported.toString(), receipt.skippedDuplicates.toString(), receipt.error.orEmpty())
            val row = fields.joinToString("\t", transform = ::encodeField)
            val digest = hash(parent, payload(receipt))
            append(parent).append('\t').append(row).append('\t').append(digest).append('\n')
            parent = digest
        }
    }

    private fun payload(r: RestoreAuditReceipt): String = listOf(r.receiptId, r.timestampEpochMillis.toString(),
        r.archiveSha256, r.targetBeforeFingerprint, r.ownerApproved.toString(), r.applied.toString(),
        r.imported.toString(), r.skippedDuplicates.toString(), r.error.orEmpty()).joinToString("\u001f")
    private fun hash(parent: String, value: String): String = MessageDigest.getInstance("SHA-256")
        .digest((parent + "\u001e" + value).toByteArray(UTF_8)).joinToString("") { "%02x".format(it) }
    private fun encodeField(value: String): String = Base64.getUrlEncoder().withoutPadding().encodeToString(value.toByteArray(UTF_8))
    private fun decode(value: String): String = String(Base64.getUrlDecoder().decode(value), UTF_8)

    companion object {
        private const val HEADER = "AQUA_RESTORE_AUDIT_V1"
        private const val ZERO = "0000000000000000000000000000000000000000000000000000000000000000"
    }
}

/** Wraps restore apply and records the owner's decision plus the exact before-state fingerprint. */
class AuditedActionJournalRestore(
    private val target: ActionResultJournal,
    private val audit: RestoreAuditStore,
    private val clock: () -> Long = System::currentTimeMillis
) {
    @Synchronized fun apply(plan: ActionJournalRestorePlan, ownerApproved: Boolean, receiptId: String): ActionJournalRestoreResult {
        require(receiptId.isNotBlank()) { "Receipt ID is required" }
        val before = target.snapshot()
        val beforeFingerprint = fingerprint(before)
        val result = ActionJournalRestore.apply(plan, target, ownerApproved)
        audit.append(RestoreAuditReceipt(receiptId, clock(), plan.archiveSha256, beforeFingerprint,
            ownerApproved, result.applied, result.imported, result.skippedDuplicates, result.error))
        return result
    }

    private fun fingerprint(records: List<ActionResult>): String {
        val canonical = records.joinToString("\u001e") { listOf(it.requestId, it.actionKey, it.status.name,
            it.code, it.message, it.resultFingerprint).joinToString("\u001f") }
        return MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray(UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}
