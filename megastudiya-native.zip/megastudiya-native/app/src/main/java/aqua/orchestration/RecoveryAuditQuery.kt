package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

/** Immutable audit fact for one owner-mediated archive recovery attempt. */
data class RecoveryAuditReceipt(
    val receiptId: String,
    val createdAtMillis: Long,
    val archiveId: String,
    val archiveSha256: String,
    val ownerDecision: OwnerRecoveryDecision,
    val outcome: RecoveryOutcome,
    val added: Int,
    val skipped: Int,
    val conflicts: Int
) {
    init {
        require(receiptId.isNotBlank() && archiveId.isNotBlank())
        require(createdAtMillis >= 0 && added >= 0 && skipped >= 0 && conflicts >= 0)
        require(archiveSha256.matches(Regex("[0-9a-f]{64}")))
    }
}

enum class OwnerRecoveryDecision { APPROVED, REJECTED }
enum class RecoveryOutcome { COMPLETED, PARTIAL, REJECTED, FAILED }

data class RecoveryAuditFilter(
    val fromMillis: Long? = null,
    val throughMillis: Long? = null,
    val decision: OwnerRecoveryDecision? = null,
    val archiveId: String? = null,
    val outcome: RecoveryOutcome? = null
) {
    init { require(fromMillis == null || fromMillis >= 0); require(throughMillis == null || throughMillis >= 0) }
}

data class RecoveryAuditReport(
    val generatedAtMillis: Long,
    val totalMatched: Int,
    val approved: Int,
    val rejected: Int,
    val completed: Int,
    val partial: Int,
    val failed: Int,
    val receipts: List<RecoveryAuditReceipt>,
    val sha256: String
)

/** Query/report layer is read-only: it never edits or deletes audit receipts. */
class RecoveryAuditReceiptStore {
    private val receipts = linkedMapOf<String, RecoveryAuditReceipt>()

    @Synchronized fun append(receipt: RecoveryAuditReceipt) {
        val previous = receipts[receipt.receiptId]
        require(previous == null || previous == receipt) { "Conflicting receipt ID" }
        if (previous == null) receipts[receipt.receiptId] = receipt
    }

    @Synchronized fun snapshot(): List<RecoveryAuditReceipt> = receipts.values.toList()

    @Synchronized fun query(filter: RecoveryAuditFilter = RecoveryAuditFilter(), generatedAtMillis: Long): RecoveryAuditReport {
        require(filter.fromMillis == null || filter.throughMillis == null || filter.fromMillis <= filter.throughMillis)
        val matched = receipts.values.filter { r ->
            (filter.fromMillis == null || r.createdAtMillis >= filter.fromMillis) &&
            (filter.throughMillis == null || r.createdAtMillis <= filter.throughMillis) &&
            (filter.decision == null || r.ownerDecision == filter.decision) &&
            (filter.archiveId == null || r.archiveId == filter.archiveId) &&
            (filter.outcome == null || r.outcome == filter.outcome)
        }.sortedWith(compareBy<RecoveryAuditReceipt> { it.createdAtMillis }.thenBy { it.receiptId })
        val canonical = matched.joinToString("\n") { listOf(it.receiptId, it.createdAtMillis, it.archiveId,
            it.archiveSha256, it.ownerDecision, it.outcome, it.added, it.skipped, it.conflicts).joinToString("\t") }
        return RecoveryAuditReport(generatedAtMillis, matched.size,
            matched.count { it.ownerDecision == OwnerRecoveryDecision.APPROVED },
            matched.count { it.ownerDecision == OwnerRecoveryDecision.REJECTED },
            matched.count { it.outcome == RecoveryOutcome.COMPLETED },
            matched.count { it.outcome == RecoveryOutcome.PARTIAL },
            matched.count { it.outcome == RecoveryOutcome.FAILED }, matched, sha256(canonical))
    }

    /** Writes a human-readable CSV report atomically; source receipts remain untouched. */
    @Synchronized fun exportCsv(report: RecoveryAuditReport, destination: Path) {
        val header = "receipt_id,created_at_ms,archive_id,archive_sha256,owner_decision,outcome,added,skipped,conflicts"
        val rows = report.receipts.map { r -> listOf(r.receiptId, r.createdAtMillis.toString(), r.archiveId,
            r.archiveSha256, r.ownerDecision.name, r.outcome.name, r.added.toString(), r.skipped.toString(),
            r.conflicts.toString()).joinToString(",") { csv(it) } }
        val content = (listOf(header) + rows).joinToString("\n", postfix = "\n")
        val target = destination.toAbsolutePath()
        target.parent?.let(Files::createDirectories)
        val temp = Files.createTempFile(target.parent, target.fileName.toString(), ".audit-pending")
        try {
            Files.writeString(temp, content, UTF_8)
            try { Files.move(temp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING) }
            catch (_: java.nio.file.AtomicMoveNotSupportedException) { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING) }
        } finally { Files.deleteIfExists(temp) }
    }

    private fun csv(value: String): String = "\"${value.replace("\"", "\"\"")}\""
    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(UTF_8)).joinToString("") { "%02x".format(it) }
}
