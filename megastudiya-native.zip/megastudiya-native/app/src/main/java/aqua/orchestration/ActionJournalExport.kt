package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Base64

/** Result of an explicit, read-only archive verification. */
data class ActionJournalExportReport(
    val valid: Boolean,
    val recordCount: Int,
    val sha256: String,
    val records: List<ActionResult>,
    val error: String? = null
)

/**
 * Operator-invoked export/verification. Export never mutates the source journal;
 * it writes a self-contained snapshot with a whole-file payload digest.
 */
object ActionJournalExport {
    private const val HEADER = "AQUA_ACTION_EXPORT_V1"
    private const val TRAILER = "SHA256"

    @Synchronized fun export(journal: ActionResultJournal, destination: Path): ActionJournalExportReport {
        val snapshot = journal.snapshot()
        require(snapshot.map { it.requestId }.toSet().size == snapshot.size) { "Source journal contains duplicate request IDs" }
        val body = buildString {
            append(HEADER).append('\n')
            snapshot.forEach { result -> append(encode(result)).append('\n') }
        }
        val digest = sha256(body)
        val complete = body + TRAILER + "\t" + digest + "\n"
        val absolute = destination.toAbsolutePath()
        val parent = absolute.parent
        if (parent != null) Files.createDirectories(parent)
        val temp = Files.createTempFile(parent, absolute.fileName.toString(), ".export-pending")
        try {
            Files.write(temp, complete.toByteArray(UTF_8))
            try {
                Files.move(temp, absolute, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
            } catch (_: java.nio.file.AtomicMoveNotSupportedException) {
                Files.move(temp, absolute, StandardCopyOption.REPLACE_EXISTING)
            }
        } finally {
            Files.deleteIfExists(temp)
        }
        return ActionJournalExportReport(true, snapshot.size, digest, snapshot.toList())
    }

    @Synchronized fun verify(archive: Path): ActionJournalExportReport {
        return try {
            val text = String(Files.readAllBytes(archive), UTF_8)
            require(text.endsWith("\n")) { "Archive must end with newline" }
            val lines = text.dropLast(1).split('\n')
            require(lines.size >= 2 && lines.first() == HEADER) { "Unsupported export format" }
            val trailer = lines.last().split('\t')
            require(trailer.size == 2 && trailer[0] == TRAILER) { "Missing export digest" }
            val body = lines.dropLast(1).joinToString("\n", postfix = "\n")
            val actual = sha256(body)
            require(actual == trailer[1]) { "Export digest mismatch" }
            val records = lines.drop(1).dropLast(1).map(::decode)
            require(records.map { it.requestId }.toSet().size == records.size) { "Duplicate request ID in export" }
            ActionJournalExportReport(true, records.size, actual, records)
        } catch (failure: Exception) {
            ActionJournalExportReport(false, 0, "", emptyList(), failure.message ?: "Export verification failed")
        }
    }

    private fun encode(result: ActionResult): String = listOf(result.requestId, result.actionKey,
        result.status.name, result.code, result.message, result.resultFingerprint)
        .joinToString("\t") { Base64.getUrlEncoder().withoutPadding().encodeToString(it.toByteArray(UTF_8)) }

    private fun decode(line: String): ActionResult {
        val fields = line.split('\t')
        require(fields.size == 6) { "Malformed export record" }
        val decoded = fields.map { String(Base64.getUrlDecoder().decode(it), UTF_8) }
        return ActionResult(decoded[0], decoded[1], ActionStatus.valueOf(decoded[2]),
            decoded[3], decoded[4], decoded[5])
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(UTF_8)).joinToString("") { "%02x".format(it) }
}
