package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8
import java.security.MessageDigest

/** A proposed operator step. It is descriptive only and has no executable command. */
data class RecoveryReportRepairStep(
    val code: String,
    val description: String,
    val requiredInput: String,
    val risk: String,
    val destructive: Boolean = false
)

data class RecoveryReportRepairPlan(
    val reportId: String,
    val diagnosticAtMillis: Long,
    val steps: List<RecoveryReportRepairStep>,
    val planFingerprint: String
) {
    val requiresOperatorReview: Boolean get() = steps.isNotEmpty()
    val containsDestructiveAction: Boolean get() = steps.any { it.destructive }
}

data class RecoveryReportRepairReview(
    val reportId: String,
    val planFingerprint: String,
    val reviewedAtMillis: Long,
    val reviewerLabel: String,
    val approvedForFutureExecution: Boolean,
    val executionAllowed: Boolean = false,
    val note: String = "Review recorded in memory only; no repair was executed"
)

/** Step 60: turn read-only findings into a deterministic, non-executable repair proposal. */
object RecoveryReportRepairPlanner {
    fun create(diagnostic: RecoveryReportCatalogDiagnostic): RecoveryReportRepairPlan {
        require(diagnostic.checkedAtMillis >= 0 && diagnostic.reportId.isNotBlank())
        val steps = diagnostic.findings.mapNotNull { finding ->
            when (finding.code) {
                "CSV_MISSING" -> RecoveryReportRepairStep("RESTORE_CSV", "Restore the exact CSV from a trusted backup", "Original CSV and verified backup provenance", "High: wrong bytes would invalidate the package")
                "PROVENANCE_MISSING" -> RecoveryReportRepairStep("RESTORE_PROVENANCE", "Restore the matching provenance manifest", "Manifest from the same report generation", "High: mismatched provenance breaks traceability")
                "PACKAGE_MANIFEST_MISSING" -> RecoveryReportRepairStep("RESTORE_PACKAGE_SIDECAR", "Restore the matching package sidecar", "Sidecar from the same report generation", "High: do not recreate hashes from untrusted files")
                "CSV_HASH_MISMATCH" -> RecoveryReportRepairStep("RECONCILE_CSV", "Compare the CSV with trusted backups; preserve the current copy for investigation", "Trusted original CSV and custody information", "High: current CSV may contain tampering or legitimate later edits")
                "PROVENANCE_HASH_MISMATCH" -> RecoveryReportRepairStep("RECONCILE_PROVENANCE", "Compare the manifest with trusted backups", "Trusted original manifest and report generation details", "High: provenance must not be guessed or reconstructed")
                "PACKAGE_MANIFEST_INVALID" -> RecoveryReportRepairStep("REVIEW_PACKAGE_SIDECAR", "Inspect the sidecar and recover a known-good copy", "Known-good sidecar and its matching report artifacts", "High: manual hash editing can conceal corruption")
                else -> null
            }
        }.distinctBy { it.code }
        val canonical = buildString {
            append(diagnostic.reportId).append('\n').append(diagnostic.checkedAtMillis).append('\n')
            steps.forEach { append(it.code).append('|').append(it.description).append('|').append(it.requiredInput).append('|').append(it.risk).append('|').append(it.destructive).append('\n') }
        }
        return RecoveryReportRepairPlan(diagnostic.reportId, diagnostic.checkedAtMillis, steps, sha256(canonical))
    }

    /** Confirmation acknowledges a proposal only; it never grants execution authority. */
    fun review(plan: RecoveryReportRepairPlan, reviewerLabel: String, confirmed: Boolean, reviewedAtMillis: Long): RecoveryReportRepairReview {
        require(confirmed) { "Explicit operator confirmation is required to record this review" }
        require(reviewerLabel.isNotBlank() && reviewerLabel.length <= 160 && reviewedAtMillis >= plan.diagnosticAtMillis)
        require(plan.planFingerprint == fingerprint(plan.copy(planFingerprint = ""))) { "Repair plan fingerprint mismatch" }
        return RecoveryReportRepairReview(plan.reportId, plan.planFingerprint, reviewedAtMillis, reviewerLabel.trim(), true)
    }

    private fun fingerprint(plan: RecoveryReportRepairPlan): String {
        val canonical = buildString {
            append(plan.reportId).append('\n').append(plan.diagnosticAtMillis).append('\n')
            plan.steps.forEach { append(it.code).append('|').append(it.description).append('|').append(it.requiredInput).append('|').append(it.risk).append('|').append(it.destructive).append('\n') }
        }
        return sha256(canonical)
    }
    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(UTF_8)).joinToString("") { "%02x".format(it) }
}
