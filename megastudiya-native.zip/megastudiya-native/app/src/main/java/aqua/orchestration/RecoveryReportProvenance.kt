package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Base64

/** Immutable provenance manifest binding a report to its source snapshot and query. */
data class RecoveryReportManifest(
    val formatVersion: Int,
    val generatedAtMillis: Long,
    val sourceLedgerSha256: String,
    val filterCanonical: String,
    val reportSha256: String,
    val manifestSha256: String
)

/** Creates, persists, reads and verifies report provenance; never changes the source ledger. */
class RecoveryReportProvenance {
    fun create(
        report: RecoveryAuditReport,
        filter: RecoveryAuditFilter,
        sourceReceipts: List<RecoveryAuditReceipt>
    ): RecoveryReportManifest {
        require(report.generatedAtMillis >= 0)
        val sourceHash = sha256(canonicalReceipts(sourceReceipts))
        val filterText = canonicalFilter(filter)
        val reportHash = sha256(canonicalReport(report))
        val unsigned = listOf(VERSION, report.generatedAtMillis.toString(), sourceHash, filterText, reportHash)
            .joinToString("\n")
        return RecoveryReportManifest(VERSION, report.generatedAtMillis, sourceHash, filterText,
            reportHash, sha256(unsigned))
    }

    fun verify(
        manifest: RecoveryReportManifest,
        report: RecoveryAuditReport,
        filter: RecoveryAuditFilter,
        currentSourceReceipts: List<RecoveryAuditReceipt>
    ): Boolean {
        if (manifest.formatVersion != VERSION || manifest.generatedAtMillis != report.generatedAtMillis) return false
        if (manifest.sourceLedgerSha256 != sha256(canonicalReceipts(currentSourceReceipts))) return false
        if (manifest.filterCanonical != canonicalFilter(filter)) return false
        if (manifest.reportSha256 != sha256(canonicalReport(report))) return false
        val unsigned = listOf(manifest.formatVersion, manifest.generatedAtMillis, manifest.sourceLedgerSha256,
            manifest.filterCanonical, manifest.reportSha256).joinToString("\n")
        return manifest.manifestSha256 == sha256(unsigned)
    }

    fun write(manifest: RecoveryReportManifest, destination: Path) {
        require(isSelfConsistent(manifest)) { "Invalid report provenance manifest" }
        val encodedFilter = Base64.getUrlEncoder().withoutPadding()
            .encodeToString(manifest.filterCanonical.toByteArray(UTF_8))
        val content = listOf(HEADER, manifest.formatVersion, manifest.generatedAtMillis,
            manifest.sourceLedgerSha256, encodedFilter, manifest.reportSha256, manifest.manifestSha256)
            .joinToString("\n", postfix = "\n")
        atomicWrite(destination, content)
    }

    fun read(source: Path): RecoveryReportManifest {
        val fields = Files.readAllLines(source, UTF_8)
        require(fields.size == 7 && fields[0] == HEADER) { "Unsupported or corrupt report manifest" }
        val filter = String(Base64.getUrlDecoder().decode(fields[4]), UTF_8)
        val manifest = RecoveryReportManifest(fields[1].toInt(), fields[2].toLong(), fields[3],
            filter, fields[5], fields[6])
        require(isSelfConsistent(manifest)) { "Report manifest checksum mismatch" }
        return manifest
    }

    private fun isSelfConsistent(m: RecoveryReportManifest): Boolean {
        if (m.formatVersion != VERSION || m.generatedAtMillis < 0) return false
        if (!m.sourceLedgerSha256.matches(HEX) || !m.reportSha256.matches(HEX) || !m.manifestSha256.matches(HEX)) return false
        val unsigned = listOf(m.formatVersion, m.generatedAtMillis, m.sourceLedgerSha256,
            m.filterCanonical, m.reportSha256).joinToString("\n")
        return m.manifestSha256 == sha256(unsigned)
    }

    private fun canonicalFilter(f: RecoveryAuditFilter): String = listOf(
        f.fromMillis?.toString() ?: "*", f.throughMillis?.toString() ?: "*",
        f.decision?.name ?: "*", f.archiveId ?: "*", f.outcome?.name ?: "*").joinToString("\t")

    private fun canonicalReceipts(receipts: List<RecoveryAuditReceipt>): String = receipts
        .sortedWith(compareBy<RecoveryAuditReceipt> { it.createdAtMillis }.thenBy { it.receiptId })
        .joinToString("\n") { listOf(it.receiptId, it.createdAtMillis, it.archiveId, it.archiveSha256,
            it.ownerDecision.name, it.outcome.name, it.added, it.skipped, it.conflicts).joinToString("\t") }

    private fun canonicalReport(r: RecoveryAuditReport): String = listOf(
        r.generatedAtMillis, r.totalMatched, r.approved, r.rejected, r.completed, r.partial, r.failed,
        canonicalReceipts(r.receipts), r.sha256).joinToString("\n")

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(UTF_8)).joinToString("") { "%02x".format(it) }

    private fun atomicWrite(destination: Path, content: String) {
        val target = destination.toAbsolutePath()
        target.parent?.let(Files::createDirectories)
        val temp = Files.createTempFile(target.parent, target.fileName.toString(), ".manifest-pending")
        try {
            Files.write(temp, content.toByteArray(UTF_8))
            try { Files.move(temp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING) }
            catch (_: java.nio.file.AtomicMoveNotSupportedException) {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING)
            }
        } finally { Files.deleteIfExists(temp) }
    }

    companion object {
        private const val VERSION = 1
        private const val HEADER = "AQUA_RECOVERY_REPORT_MANIFEST|1"
        private val HEX = Regex("[0-9a-f]{64}")
    }
}
