package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Base64

/** Lifecycle state is metadata only: catalog operations never delete report artifacts. */
enum class RecoveryReportLifecycle { ACTIVE, ARCHIVED }

data class RecoveryReportCatalogEntry(
    val reportId: String,
    val csvPath: String,
    val provenanceManifestPath: String,
    val packageManifestPath: String,
    val registeredAtMillis: Long,
    val lifecycle: RecoveryReportLifecycle,
    val latestVerification: RecoveryReportPackageStatus?,
    val lastVerifiedAtMillis: Long?,
    val archiveOwnerLabel: String?,
    val archiveReason: String?
)

data class RecoveryReportCatalogEvent(
    val sequence: Long,
    val type: String,
    val reportId: String,
    val timestampMillis: Long,
    val payload: String,
    val previousHash: String,
    val eventHash: String
)

/** Append-only, checksummed catalogue. Caller-supplied owner labels are audit labels, not authentication. */
class RecoveryReportCatalog(private val journalPath: Path) {
    private var events: List<RecoveryReportCatalogEvent> = load()

    @Synchronized fun register(reportId: String, csvPath: Path, provenanceManifestPath: Path, nowMillis: Long): RecoveryReportCatalogEntry {
        require(reportId.isNotBlank() && reportId.length <= 160 && nowMillis >= 0)
        require(events.none { it.reportId == reportId && it.type == REGISTER }) { "Report ID already registered" }
        val csv = csvPath.toAbsolutePath().normalize()
        val manifest = provenanceManifestPath.toAbsolutePath().normalize()
        val packageManifest = manifest.resolveSibling(manifest.fileName.toString() + ".package")
        require(Files.isRegularFile(csv) && Files.isRegularFile(manifest) && Files.isRegularFile(packageManifest)) {
            "Report package files must exist before registration"
        }
        append(REGISTER, reportId, nowMillis, listOf(csv.toString(), manifest.toString(), packageManifest.toString()).joinToString("\t"))
        return get(reportId)!!
    }

    @Synchronized fun recordVerification(reportId: String, status: RecoveryReportPackageStatus, nowMillis: Long): RecoveryReportCatalogEntry {
        require(nowMillis >= 0 && get(reportId) != null) { "Unknown report ID or invalid timestamp" }
        append(VERIFY, reportId, nowMillis, status.name)
        return get(reportId)!!
    }

    @Synchronized fun archive(reportId: String, ownerLabel: String, reason: String, confirmed: Boolean, nowMillis: Long): RecoveryReportCatalogEntry {
        require(confirmed) { "Explicit owner confirmation is required" }
        require(ownerLabel.isNotBlank() && reason.isNotBlank() && nowMillis >= 0)
        val entry = get(reportId) ?: throw IllegalArgumentException("Unknown report ID")
        require(entry.lifecycle == RecoveryReportLifecycle.ACTIVE) { "Report is already archived" }
        append(ARCHIVE, reportId, nowMillis, encode(ownerLabel) + "\t" + encode(reason))
        return get(reportId)!!
    }

    @Synchronized fun get(reportId: String): RecoveryReportCatalogEntry? = entries().firstOrNull { it.reportId == reportId }

    @Synchronized fun list(includeArchived: Boolean = true, query: String = ""): List<RecoveryReportCatalogEntry> {
        val q = query.trim().lowercase()
        return entries().filter { (includeArchived || it.lifecycle == RecoveryReportLifecycle.ACTIVE) &&
            (q.isEmpty() || it.reportId.lowercase().contains(q) || it.csvPath.lowercase().contains(q)) }
    }

    @Synchronized fun verificationHistory(reportId: String): List<Pair<Long, RecoveryReportPackageStatus>> {
        require(get(reportId) != null) { "Unknown report ID" }
        return events.filter { it.reportId == reportId && it.type == VERIFY }.map { it.timestampMillis to RecoveryReportPackageStatus.valueOf(it.payload) }
    }

    @Synchronized fun verifyJournal(): Boolean = try { validate(Files.readAllLines(journalPath, UTF_8)); true } catch (_: Exception) { false }

    private fun entries(): List<RecoveryReportCatalogEntry> {
        val result = linkedMapOf<String, RecoveryReportCatalogEntry>()
        events.forEach { e ->
            when (e.type) {
                REGISTER -> {
                    val p = e.payload.split('\t'); require(p.size == 3)
                    result[e.reportId] = RecoveryReportCatalogEntry(e.reportId, p[0], p[1], p[2], e.timestampMillis,
                        RecoveryReportLifecycle.ACTIVE, null, null, null, null)
                }
                VERIFY -> result[e.reportId]?.let { result[e.reportId] = it.copy(
                    latestVerification = RecoveryReportPackageStatus.valueOf(e.payload), lastVerifiedAtMillis = e.timestampMillis) }
                ARCHIVE -> result[e.reportId]?.let { val p = e.payload.split('\t'); require(p.size == 2)
                    result[e.reportId] = it.copy(lifecycle = RecoveryReportLifecycle.ARCHIVED,
                        archiveOwnerLabel = decode(p[0]), archiveReason = decode(p[1])) }
            }
        }
        return result.values.toList()
    }

    private fun append(type: String, id: String, time: Long, payload: String) {
        val previous = events.lastOrNull()?.eventHash ?: ZERO
        val seq = events.size.toLong() + 1
        val hash = digest(listOf(seq, type, id, time, payload, previous).joinToString("\n"))
        val updated = events + RecoveryReportCatalogEvent(seq, type, id, time, payload, previous, hash)
        persist(updated)
        events = updated
    }

    private fun load(): List<RecoveryReportCatalogEvent> {
        if (!Files.exists(journalPath)) return emptyList()
        return validate(Files.readAllLines(journalPath, UTF_8))
    }

    private fun validate(lines: List<String>): List<RecoveryReportCatalogEvent> {
        if (lines.isEmpty()) return emptyList()
        require(lines.first() == HEADER) { "Unsupported catalogue journal" }
        var previous = ZERO
        val loaded = lines.drop(1).mapIndexed { index, line ->
            val p = line.split('|'); require(p.size == 7)
            val event = RecoveryReportCatalogEvent(p[0].toLong(), p[1], decode(p[2]), p[3].toLong(), decode(p[4]), p[5], p[6])
            require(event.sequence == index + 1L && event.previousHash == previous &&
                event.eventHash == digest(listOf(event.sequence, event.type, event.reportId, event.timestampMillis,
                    event.payload, event.previousHash).joinToString("\n"))) { "Catalogue hash-chain mismatch" }
            require(event.type in setOf(REGISTER, VERIFY, ARCHIVE))
            previous = event.eventHash; event
        }
        return loaded
    }

    private fun persist(snapshot: List<RecoveryReportCatalogEvent>) {
        val lines = listOf(HEADER) + snapshot.map { listOf(it.sequence, it.type, encode(it.reportId), it.timestampMillis,
            encode(it.payload), it.previousHash, it.eventHash).joinToString("|") }
        val target = journalPath.toAbsolutePath(); target.parent?.let(Files::createDirectories)
        val temp = Files.createTempFile(target.parent, target.fileName.toString(), ".pending")
        try { Files.write(temp, lines, UTF_8)
            try { Files.move(temp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING) }
            catch (_: java.nio.file.AtomicMoveNotSupportedException) { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING) }
        } finally { Files.deleteIfExists(temp) }
    }

    private fun encode(s: String) = Base64.getUrlEncoder().withoutPadding().encodeToString(s.toByteArray(UTF_8))
    private fun decode(s: String) = String(Base64.getUrlDecoder().decode(s), UTF_8)
    private fun digest(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(UTF_8)).joinToString("") { "%02x".format(it) }
    companion object { private const val HEADER = "AQUA_RECOVERY_REPORT_CATALOG|1"; private val ZERO = "0".repeat(64)
        private const val REGISTER = "REGISTER"; private const val VERIFY = "VERIFY"; private const val ARCHIVE = "ARCHIVE" }
}
