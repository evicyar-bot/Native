package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8

/** Explicit capacity policy. Reaching a limit blocks new records; it never prunes history. */
data class ActionJournalPolicy(
    val maxEntries: Int = 10_000,
    val maxEstimatedBytes: Long = 16L * 1024L * 1024L,
    val warningRatio: Double = 0.80
) {
    init {
        require(maxEntries > 0) { "maxEntries must be positive" }
        require(maxEstimatedBytes > 0) { "maxEstimatedBytes must be positive" }
        require(warningRatio in 0.1..0.99) { "warningRatio must be between 0.1 and 0.99" }
    }
}

enum class ActionJournalHealth { HEALTHY, NEAR_CAPACITY, CAPACITY_REACHED }

data class ActionJournalDiagnostics(
    val health: ActionJournalHealth,
    val entries: Int,
    val estimatedBytes: Long,
    val maxEntries: Int,
    val maxEstimatedBytes: Long,
    val entryUtilization: Double,
    val byteUtilization: Double,
    val warnings: List<String>
)

/**
 * Adds bounded-growth admission and read-only diagnostics around any journal.
 * Existing records are never deleted or compacted. If restored history already
 * exceeds a configured limit, the wrapper remains readable but refuses appends.
 */
class PolicyBoundActionResultJournal(
    private val delegate: ActionResultJournal,
    private val policy: ActionJournalPolicy = ActionJournalPolicy()
) : ActionResultJournal {
    @Synchronized override fun append(result: ActionResult) {
        val existing = delegate.snapshot().firstOrNull { it.requestId == result.requestId }
        if (existing != null) {
            require(existing == result) { "Conflicting request ID" }
            return
        }
        val current = diagnostics()
        require(current.entries < policy.maxEntries) { "Action journal entry capacity reached; archive or review history before continuing" }
        require(current.estimatedBytes + estimate(result) <= policy.maxEstimatedBytes) {
            "Action journal byte capacity reached; archive or review history before continuing"
        }
        delegate.append(result)
    }

    override fun snapshot(): List<ActionResult> = delegate.snapshot()

    @Synchronized fun diagnostics(): ActionJournalDiagnostics {
        val records = delegate.snapshot()
        val bytes = records.sumOf(::estimate)
        val entryUse = records.size.toDouble() / policy.maxEntries.toDouble()
        val byteUse = bytes.toDouble() / policy.maxEstimatedBytes.toDouble()
        val maxUse = maxOf(entryUse, byteUse)
        val warnings = buildList {
            if (records.size >= policy.maxEntries || bytes >= policy.maxEstimatedBytes)
                add("Capacity reached; new records are blocked and existing history is preserved")
            else if (maxUse >= policy.warningRatio)
                add("Journal is approaching its configured capacity")
            if (records.isEmpty()) add("Journal contains no action results")
        }
        val health = when {
            records.size >= policy.maxEntries || bytes >= policy.maxEstimatedBytes -> ActionJournalHealth.CAPACITY_REACHED
            maxUse >= policy.warningRatio -> ActionJournalHealth.NEAR_CAPACITY
            else -> ActionJournalHealth.HEALTHY
        }
        return ActionJournalDiagnostics(health, records.size, bytes, policy.maxEntries,
            policy.maxEstimatedBytes, entryUse, byteUse, warnings)
    }

    private fun estimate(result: ActionResult): Long {
        // Conservative UTF-8 payload estimate including framing, hash and base64 expansion.
        val payload = listOf(result.requestId, result.actionKey, result.status.name,
            result.code, result.message, result.resultFingerprint).sumOf { it.toByteArray(UTF_8).size.toLong() }
        return payload * 4L / 3L + 256L
    }
}
