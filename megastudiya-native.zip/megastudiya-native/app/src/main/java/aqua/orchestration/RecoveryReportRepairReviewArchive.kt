package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Base64

/** Immutable, independently verifiable copy of a review-journal export. */
data class RecoveryReportRepairReviewArchiveEntry(
    val archiveId: String,
    val label: String,
    val createdAtMillis: Long,
    val exportFile: String,
    val exportSha256: String,
    val receiptCount: Int,
    val terminalReceiptHash: String,
    val valid: Boolean,
    val error: String? = null
)

enum class RecoveryReportRepairArchiveRelation { IDENTICAL, LEFT_IS_PREFIX, RIGHT_IS_PREFIX, DIVERGENT, INVALID }

data class RecoveryReportRepairArchiveComparison(
    val relation: RecoveryReportRepairArchiveRelation,
    val leftReceiptCount: Int,
    val rightReceiptCount: Int,
    val commonPrefixCount: Int,
    val leftOnlySequences: List<Long>,
    val rightOnlySequences: List<Long>,
    val explanation: String
)

/** Step 63: explicit immutable archive; never prunes or mutates existing snapshots. */
class RecoveryReportRepairReviewArchive(private val archiveDirectory: Path) {
    @Synchronized
    fun save(archiveId: String, label: String, exportPath: Path, createdAtMillis: Long): RecoveryReportRepairReviewArchiveEntry {
        require(archiveId.matches(Regex("[A-Za-z0-9][A-Za-z0-9._-]{0,79}"))) { "Invalid archive ID" }
        require(label.isNotBlank() && label.length <= 160) { "Archive label is required" }
        require(createdAtMillis >= 0) { "Invalid archive timestamp" }
        val verified = RecoveryReportRepairReviewJournalExport.verify(exportPath)
        require(verified.valid) { verified.error ?: "Export is invalid" }
        Files.createDirectories(archiveDirectory)
        val data = archiveDirectory.resolve("$archiveId.export").toAbsolutePath().normalize()
        val meta = archiveDirectory.resolve("$archiveId.meta").toAbsolutePath().normalize()
        require(data.parent == archiveDirectory.toAbsolutePath().normalize() && meta.parent == data.parent) { "Archive path escaped directory" }
        require(!Files.exists(data) && !Files.exists(meta)) { "Archive ID already exists; snapshots are immutable" }
        val bytes = Files.readAllBytes(exportPath)
        val exportHash = sha256(bytes)
        val lines = listOf(HEADER, encode(archiveId), encode(label), createdAtMillis.toString(), data.fileName.toString(),
            exportHash, verified.receiptCount.toString(), verified.lastHash).joinToString("\n", postfix = "\n")
        atomicWrite(data, bytes)
        try { atomicWrite(meta, lines.toByteArray(UTF_8)) }
        catch (e: Exception) { Files.deleteIfExists(data); throw e }
        return inspect(archiveId)
    }

    @Synchronized
    fun list(): List<RecoveryReportRepairReviewArchiveEntry> {
        if (!Files.isDirectory(archiveDirectory)) return emptyList()
        return Files.list(archiveDirectory).use { paths -> paths.filter { it.fileName.toString().endsWith(".meta") }
            .map { it.fileName.toString().removeSuffix(".meta") }.sorted().map { inspect(it) }.toList() }
    }

    @Synchronized
    fun inspect(archiveId: String): RecoveryReportRepairReviewArchiveEntry = try {
        require(archiveId.matches(Regex("[A-Za-z0-9][A-Za-z0-9._-]{0,79}"))) { "Invalid archive ID" }
        val meta = Files.readAllLines(archiveDirectory.resolve("$archiveId.meta"), UTF_8)
        require(meta.size == 8 && meta[0] == HEADER) { "Malformed archive metadata" }
        val id = decode(meta[1]); val label = decode(meta[2]); val created = meta[3].toLong()
        require(id == archiveId && label.isNotBlank() && created >= 0) { "Archive metadata identity mismatch" }
        require(meta[4] == "$archiveId.export") { "Archive data filename mismatch" }
        require(meta[5].matches(Regex("[0-9a-f]{64}")) && meta[7].matches(Regex("[0-9a-f]{64}"))) { "Malformed archive digest" }
        val data = archiveDirectory.resolve(meta[4]); require(Files.isRegularFile(data)) { "Archived export is missing" }
        require(sha256(Files.readAllBytes(data)) == meta[5]) { "Archived export digest mismatch" }
        val status = RecoveryReportRepairReviewJournalExport.verify(data)
        require(status.valid && status.receiptCount == meta[6].toInt() && status.lastHash == meta[7]) { "Archived export verification mismatch" }
        RecoveryReportRepairReviewArchiveEntry(id, label, created, meta[4], meta[5], status.receiptCount, status.lastHash, true)
    } catch (e: Exception) {
        RecoveryReportRepairReviewArchiveEntry(archiveId, "", 0, "$archiveId.export", "", 0, ZERO, false, e.message ?: "Archive invalid")
    }

    /** Compares verified receipt hash sequences; no source or archive is modified. */
    @Synchronized
    fun compare(leftId: String, rightId: String): RecoveryReportRepairArchiveComparison {
        val left = receiptHashes(leftId); val right = receiptHashes(rightId)
        if (left == null || right == null) return RecoveryReportRepairArchiveComparison(
            RecoveryReportRepairArchiveRelation.INVALID, left?.size ?: 0, right?.size ?: 0, 0, emptyList(), emptyList(),
            "At least one archive is missing or failed integrity verification")
        val common = left.zip(right).takeWhile { it.first == it.second }.size
        val relation = when {
            left == right -> RecoveryReportRepairArchiveRelation.IDENTICAL
            common == left.size && left.size < right.size -> RecoveryReportRepairArchiveRelation.LEFT_IS_PREFIX
            common == right.size && right.size < left.size -> RecoveryReportRepairArchiveRelation.RIGHT_IS_PREFIX
            else -> RecoveryReportRepairArchiveRelation.DIVERGENT
        }
        return RecoveryReportRepairArchiveComparison(relation, left.size, right.size, common,
            (common until left.size).map { it + 1L }, (common until right.size).map { it + 1L },
            when (relation) {
                RecoveryReportRepairArchiveRelation.IDENTICAL -> "Both snapshots contain the same receipt history"
                RecoveryReportRepairArchiveRelation.LEFT_IS_PREFIX -> "Right snapshot extends left; no receipt is missing from right"
                RecoveryReportRepairArchiveRelation.RIGHT_IS_PREFIX -> "Left snapshot extends right; no receipt is missing from left"
                else -> "Histories diverge at sequence ${common + 1}; inspect both branches"
            })
    }

    private fun receiptHashes(id: String): List<String>? {
        return try {
            val entry = inspect(id)
            if (!entry.valid) null else {
                val lines = Files.readAllLines(archiveDirectory.resolve(entry.exportFile), UTF_8)
                val payload = String(Base64.getDecoder().decode(lines[4]), UTF_8).lines().filter { it.isNotEmpty() }
                payload.drop(1).map { line -> val fields = line.split('|'); require(fields.size == 10); fields[9] }
            }
        } catch (_: Exception) { null }
    }

    private fun atomicWrite(target: Path, bytes: ByteArray) {
        val temp = Files.createTempFile(target.parent, target.fileName.toString(), ".pending")
        try {
            Files.write(temp, bytes)
            try { Files.move(temp, target, StandardCopyOption.ATOMIC_MOVE) }
            catch (_: java.nio.file.AtomicMoveNotSupportedException) { Files.move(temp, target) }
        } finally { Files.deleteIfExists(temp) }
    }
    private fun encode(s: String) = Base64.getUrlEncoder().withoutPadding().encodeToString(s.toByteArray(UTF_8))
    private fun decode(s: String) = String(Base64.getUrlDecoder().decode(s), UTF_8)
    private fun sha256(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
    companion object { private const val HEADER = "AQUA_REPAIR_REVIEW_ARCHIVE|1"; private val ZERO = "0".repeat(64) }
}
