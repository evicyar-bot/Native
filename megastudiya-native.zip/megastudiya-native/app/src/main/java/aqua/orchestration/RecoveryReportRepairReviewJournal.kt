package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Base64

/** Durable receipt for a human review. It records acknowledgement, never execution authority. */
data class RecoveryReportRepairReviewReceipt(
    val sequence: Long,
    val review: RecoveryReportRepairReview,
    val previousHash: String,
    val receiptHash: String
)

data class RecoveryReportRepairReviewJournalStatus(
    val valid: Boolean,
    val receiptCount: Int,
    val lastHash: String,
    val error: String? = null
)

/**
 * Step 61: append-only, atomically persisted, tamper-evident review history.
 * Reviewer labels are caller supplied and do not establish authenticated identity.
 * No method in this class executes or authorizes a repair.
 */
class RecoveryReportRepairReviewJournal(private val journalPath: Path) {
    private var receipts: List<RecoveryReportRepairReviewReceipt> = load()

    @Synchronized
    fun record(
        plan: RecoveryReportRepairPlan,
        reviewerLabel: String,
        confirmed: Boolean,
        reviewedAtMillis: Long
    ): RecoveryReportRepairReviewReceipt {
        require(confirmed) { "Explicit operator confirmation is required to record a review" }
        require(plan.planFingerprint == fingerprint(plan)) { "Repair plan fingerprint mismatch" }
        val review = RecoveryReportRepairPlanner.review(plan, reviewerLabel, true, reviewedAtMillis)
        val previous = receipts.lastOrNull()?.receiptHash ?: ZERO
        val sequence = receipts.size.toLong() + 1
        val hash = hash(canonical(sequence, review, previous))
        val receipt = RecoveryReportRepairReviewReceipt(sequence, review, previous, hash)
        val updated = receipts + receipt
        persist(updated)
        receipts = updated
        return receipt
    }

    @Synchronized fun history(reportId: String): List<RecoveryReportRepairReviewReceipt> =
        receipts.filter { it.review.reportId == reportId }

    @Synchronized fun all(): List<RecoveryReportRepairReviewReceipt> = receipts.toList()

    @Synchronized fun verify(): RecoveryReportRepairReviewJournalStatus = try {
        val loaded = if (Files.exists(journalPath)) validate(Files.readAllLines(journalPath, UTF_8)) else emptyList()
        RecoveryReportRepairReviewJournalStatus(true, loaded.size, loaded.lastOrNull()?.receiptHash ?: ZERO)
    } catch (e: Exception) {
        RecoveryReportRepairReviewJournalStatus(false, receipts.size, receipts.lastOrNull()?.receiptHash ?: ZERO,
            e.message ?: "Journal validation failed")
    }

    private fun load(): List<RecoveryReportRepairReviewReceipt> =
        if (!Files.exists(journalPath)) emptyList() else validate(Files.readAllLines(journalPath, UTF_8))

    private fun validate(lines: List<String>): List<RecoveryReportRepairReviewReceipt> {
        if (lines.isEmpty()) return emptyList()
        require(lines.first() == HEADER) { "Unsupported repair-review journal version" }
        var previous = ZERO
        val loaded = lines.drop(1).mapIndexed { index, line ->
            val fields = line.split('|')
            require(fields.size == 10) { "Malformed repair-review receipt" }
            val sequence = fields[0].toLong()
            val review = RecoveryReportRepairReview(
                decode(fields[1]), fields[2], fields[3].toLong(), decode(fields[4]),
                fields[5].toBooleanStrict(), fields[6].toBooleanStrict(), decode(fields[7])
            )
            val receipt = RecoveryReportRepairReviewReceipt(sequence, review, fields[8], fields[9])
            require(sequence == index + 1L && receipt.previousHash == previous) { "Repair-review sequence mismatch" }
            require(!review.executionAllowed && review.approvedForFutureExecution) { "Invalid review authority flags" }
            require(review.reportId.isNotBlank() && review.planFingerprint.matches(Regex("[0-9a-f]{64}")) &&
                review.reviewerLabel.isNotBlank() && review.reviewedAtMillis >= 0) { "Invalid review receipt fields" }
            require(receipt.receiptHash == hash(canonical(sequence, review, previous))) { "Repair-review hash-chain mismatch" }
            previous = receipt.receiptHash
            receipt
        }
        return loaded
    }

    private fun persist(snapshot: List<RecoveryReportRepairReviewReceipt>) {
        val lines = listOf(HEADER) + snapshot.map { r -> listOf(
            r.sequence, encode(r.review.reportId), r.review.planFingerprint, r.review.reviewedAtMillis,
            encode(r.review.reviewerLabel), r.review.approvedForFutureExecution, r.review.executionAllowed,
            encode(r.review.note), r.previousHash, r.receiptHash
        ).joinToString("|") }
        val target = journalPath.toAbsolutePath().normalize()
        target.parent?.let(Files::createDirectories)
        val temp = Files.createTempFile(target.parent, target.fileName.toString(), ".pending")
        try {
            Files.write(temp, lines, UTF_8)
            try { Files.move(temp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING) }
            catch (_: java.nio.file.AtomicMoveNotSupportedException) { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING) }
        } finally { Files.deleteIfExists(temp) }
    }

    private fun canonical(sequence: Long, review: RecoveryReportRepairReview, previous: String): String = listOf(
        sequence, review.reportId, review.planFingerprint, review.reviewedAtMillis, review.reviewerLabel,
        review.approvedForFutureExecution, review.executionAllowed, review.note, previous
    ).joinToString("\n")

    private fun fingerprint(plan: RecoveryReportRepairPlan): String {
        val canonical = buildString {
            append(plan.reportId).append('\n').append(plan.diagnosticAtMillis).append('\n')
            plan.steps.forEach { append(it.code).append('|').append(it.description).append('|').append(it.requiredInput)
                .append('|').append(it.risk).append('|').append(it.destructive).append('\n') }
        }
        return hash(canonical)
    }

    private fun encode(value: String): String = Base64.getUrlEncoder().withoutPadding().encodeToString(value.toByteArray(UTF_8))
    private fun decode(value: String): String = String(Base64.getUrlDecoder().decode(value), UTF_8)
    private fun hash(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(UTF_8)).joinToString("") { "%02x".format(it) }

    companion object {
        private const val HEADER = "AQUA_REPAIR_REVIEW_JOURNAL|1"
        private val ZERO = "0".repeat(64)
    }
}
