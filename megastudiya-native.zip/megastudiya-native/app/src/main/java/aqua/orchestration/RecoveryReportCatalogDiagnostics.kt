package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.Files
import java.nio.file.Path
import java.security.MessageDigest

/** Read-only filesystem consistency result for one registered report. */
data class RecoveryReportCatalogFinding(
    val reportId: String,
    val code: String,
    val severity: RecoveryReportFindingSeverity,
    val detail: String,
    val proposedAction: String
)

enum class RecoveryReportFindingSeverity { INFO, WARNING, ERROR }

data class RecoveryReportCatalogDiagnostic(
    val reportId: String,
    val checkedAtMillis: Long,
    val findings: List<RecoveryReportCatalogFinding>
) {
    val isConsistent: Boolean get() = findings.none { it.severity == RecoveryReportFindingSeverity.ERROR }
}

/**
 * Step 59 filesystem diagnostics. This extension only reads registered artifacts;
 * it never rewrites the catalogue, repairs files, or removes report data.
 */
fun RecoveryReportCatalog.diagnoseFilesystem(nowMillis: Long): List<RecoveryReportCatalogDiagnostic> {
    require(nowMillis >= 0)
    return list(includeArchived = true).map { entry ->
        val findings = mutableListOf<RecoveryReportCatalogFinding>()
        val csv = Path.of(entry.csvPath)
        val provenance = Path.of(entry.provenanceManifestPath)
        val packageFile = Path.of(entry.packageManifestPath)
        fun add(code: String, severity: RecoveryReportFindingSeverity, detail: String, action: String) {
            findings += RecoveryReportCatalogFinding(entry.reportId, code, severity, detail, action)
        }
        if (!Files.isRegularFile(csv)) add("CSV_MISSING", RecoveryReportFindingSeverity.ERROR,
            "Registered CSV file is missing or not a regular file", "Restore the exact report CSV from a trusted backup, then rerun diagnostics")
        if (!Files.isRegularFile(provenance)) add("PROVENANCE_MISSING", RecoveryReportFindingSeverity.ERROR,
            "Registered provenance manifest is missing or not a regular file", "Restore the matching provenance manifest from a trusted backup")
        if (!Files.isRegularFile(packageFile)) add("PACKAGE_MANIFEST_MISSING", RecoveryReportFindingSeverity.ERROR,
            "Registered package sidecar is missing or not a regular file", "Restore the matching package sidecar from a trusted backup")
        if (Files.isRegularFile(csv) && Files.isRegularFile(provenance) && Files.isRegularFile(packageFile)) {
            try {
                val lines = Files.readAllLines(packageFile, UTF_8)
                require(lines.size == 5 && lines[0] == "AQUA_RECOVERY_REPORT_PACKAGE|1") { "Unsupported package sidecar format" }
                val version = lines[1].toInt()
                val csvHash = lines[2]
                val provenanceHash = lines[3]
                val packageHash = lines[4]
                require(version == 1 && csvHash.matches(HEX) && provenanceHash.matches(HEX) && packageHash.matches(HEX)) { "Malformed package sidecar fields" }
                require(packageHash == sha256(listOf(version, csvHash, provenanceHash).joinToString("\n").toByteArray(UTF_8))) { "Package sidecar checksum mismatch" }
                if (sha256(Files.readAllBytes(csv)) != csvHash) add("CSV_HASH_MISMATCH", RecoveryReportFindingSeverity.ERROR,
                    "CSV bytes differ from the registered package manifest", "Recover the original CSV or explicitly create and register a new report package")
                if (sha256(Files.readAllBytes(provenance)) != provenanceHash) add("PROVENANCE_HASH_MISMATCH", RecoveryReportFindingSeverity.ERROR,
                    "Provenance manifest bytes differ from the registered package manifest", "Recover the matching provenance manifest or explicitly create a new report package")
            } catch (e: Exception) {
                add("PACKAGE_MANIFEST_INVALID", RecoveryReportFindingSeverity.ERROR,
                    e.message ?: "Package sidecar is malformed", "Inspect the package from a trusted backup; do not edit hashes manually")
            }
        }
        if (findings.isEmpty()) add("FILES_PRESENT_AND_HASHED", RecoveryReportFindingSeverity.INFO,
            "All registered files exist and match the package sidecar hashes", "No catalogue-level action proposed; run full provenance verification with the source snapshot")
        RecoveryReportCatalogDiagnostic(entry.reportId, nowMillis, findings)
    }
}

private val HEX = Regex("[0-9a-f]{64}")
private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
