package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

/** Integrity state for a CSV + provenance manifest pair. */
enum class RecoveryReportPackageStatus { VALID, STALE, INVALID }

data class RecoveryReportPackageManifest(
    val version: Int,
    val csvSha256: String,
    val provenanceManifestSha256: String,
    val packageSha256: String
)

data class RecoveryReportPackageVerification(
    val status: RecoveryReportPackageStatus,
    val reason: String
)

/** Binds the exported CSV bytes to the report provenance manifest. Read/verify never mutates source receipts. */
class RecoveryReportPackage(private val provenance: RecoveryReportProvenance = RecoveryReportProvenance()) {
    fun create(
        report: RecoveryAuditReport,
        filter: RecoveryAuditFilter,
        sourceReceipts: List<RecoveryAuditReceipt>,
        csvPath: Path,
        manifestPath: Path
    ): RecoveryReportPackageManifest {
        val sourceSnapshot = sourceReceipts.toList()
        val provenanceManifest = provenance.create(report, filter, sourceSnapshot)
        val csvTemp = Files.createTempFile(csvPath.toAbsolutePath().parent ?: Path.of("."), "aqua-report", ".csv-pending")
        try {
            RecoveryAuditReceiptStore().exportCsv(report, csvTemp)
            val target = csvPath.toAbsolutePath()
            target.parent?.let(Files::createDirectories)
            moveAtomic(csvTemp, target)
        } finally { Files.deleteIfExists(csvTemp) }
        val packageUnsigned = listOf(VERSION, sha256(Files.readAllBytes(csvPath)), provenanceManifest.manifestSha256).joinToString("\n")
        val packageManifest = RecoveryReportPackageManifest(VERSION, sha256(Files.readAllBytes(csvPath)),
            provenanceManifest.manifestSha256, sha256(packageUnsigned))
        provenance.write(provenanceManifest, manifestPath)
        writePackageManifest(packageManifest, manifestPath.resolveSibling(manifestPath.fileName.toString() + ".package"))
        return packageManifest
    }

    fun verify(
        csvPath: Path,
        manifestPath: Path,
        report: RecoveryAuditReport,
        filter: RecoveryAuditFilter,
        currentSourceReceipts: List<RecoveryAuditReceipt>
    ): RecoveryReportPackageVerification {
        return try {
            val csvHash = sha256(Files.readAllBytes(csvPath))
            val provenanceManifest = provenance.read(manifestPath)
            val packageManifest = readPackageManifest(manifestPath.resolveSibling(manifestPath.fileName.toString() + ".package"))
            if (packageManifest.version != VERSION || packageManifest.csvSha256 != csvHash ||
                packageManifest.provenanceManifestSha256 != provenanceManifest.manifestSha256 ||
                packageManifest.packageSha256 != sha256(listOf(packageManifest.version, packageManifest.csvSha256,
                    packageManifest.provenanceManifestSha256).joinToString("\n"))) {
                RecoveryReportPackageVerification(RecoveryReportPackageStatus.INVALID, "CSV or package manifest integrity mismatch")
            } else if (!provenance.verify(provenanceManifest, report, filter, currentSourceReceipts)) {
                RecoveryReportPackageVerification(RecoveryReportPackageStatus.STALE, "Source snapshot, query, or report no longer matches")
            } else {
                RecoveryReportPackageVerification(RecoveryReportPackageStatus.VALID, "CSV and provenance manifest verified")
            }
        } catch (e: Exception) {
            RecoveryReportPackageVerification(RecoveryReportPackageStatus.INVALID, e.message ?: "Package is malformed or incomplete")
        }
    }

    private fun writePackageManifest(m: RecoveryReportPackageManifest, path: Path) {
        require(m.version == VERSION && m.csvSha256.matches(HEX) && m.provenanceManifestSha256.matches(HEX) && m.packageSha256.matches(HEX))
        val text = listOf(HEADER, m.version, m.csvSha256, m.provenanceManifestSha256, m.packageSha256).joinToString("\n", postfix = "\n")
        val target = path.toAbsolutePath(); target.parent?.let(Files::createDirectories)
        val temp = Files.createTempFile(target.parent, target.fileName.toString(), ".pending")
        try { Files.writeString(temp, text, UTF_8); moveAtomic(temp, target) } finally { Files.deleteIfExists(temp) }
    }

    private fun readPackageManifest(path: Path): RecoveryReportPackageManifest {
        val f = Files.readAllLines(path, UTF_8)
        require(f.size == 5 && f[0] == HEADER) { "Unsupported or corrupt package manifest" }
        val m = RecoveryReportPackageManifest(f[1].toInt(), f[2], f[3], f[4])
        require(m.version == VERSION && m.csvSha256.matches(HEX) && m.provenanceManifestSha256.matches(HEX) && m.packageSha256.matches(HEX))
        require(m.packageSha256 == sha256(listOf(m.version, m.csvSha256, m.provenanceManifestSha256).joinToString("\n")))
        return m
    }

    private fun moveAtomic(from: Path, to: Path) {
        try { Files.move(from, to, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING) }
        catch (_: java.nio.file.AtomicMoveNotSupportedException) { Files.move(from, to, StandardCopyOption.REPLACE_EXISTING) }
    }
    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
    private fun sha256(value: String): String = sha256(value.toByteArray(UTF_8))
    companion object { private const val VERSION = 1; private const val HEADER = "AQUA_RECOVERY_REPORT_PACKAGE|1"; private val HEX = Regex("[0-9a-f]{64}") }
}
