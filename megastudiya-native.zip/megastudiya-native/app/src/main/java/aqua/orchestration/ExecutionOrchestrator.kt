package aqua.orchestration

/** Dry-run orchestration only: decisions are emitted, no tools or external actions are invoked. */
enum class ActionRisk { LOW, MEDIUM, HIGH, CRITICAL }
enum class ActionDecision { SIMULATE_READY, BLOCKED_POLICY, BLOCKED_DEPENDENCY, REQUIRES_OWNER_APPROVAL, STOPPED }

data class OrchestrationStep(
    val stepId: String,
    val actionKey: String,
    val risk: ActionRisk,
    val dependsOn: List<String> = emptyList(),
    val requiresApproval: Boolean = false
) { init { require(stepId.isNotBlank() && actionKey.isNotBlank() && dependsOn.distinct().size == dependsOn.size) } }

data class OrchestrationPolicy(
    val allowedActionKeys: Set<String>,
    val maxRiskWithoutApproval: ActionRisk = ActionRisk.MEDIUM,
    val ownerApprovedActionKeys: Set<String> = emptySet(),
    val dryRun: Boolean = true
) { init { require(dryRun) { "Step 40 is dry-run only; live mode is not supported." } } }

data class OrchestrationResult(
    val decisions: Map<String, ActionDecision>,
    val orderedStepIds: List<String>,
    val stopped: Boolean,
    val reasons: List<String>
)

class ExecutionOrchestrator {
    /** Deterministic topological dry-run; stop flag prevents decisions for later steps. */
    fun simulate(steps: List<OrchestrationStep>, policy: OrchestrationPolicy, stopRequested: Boolean = false): OrchestrationResult {
        require(steps.isNotEmpty())
        require(steps.map { it.stepId }.distinct().size == steps.size) { "Step IDs must be unique" }
        val ids = steps.map { it.stepId }.toSet()
        require(steps.all { it.dependsOn.all(ids::contains) }) { "Unknown dependency" }
        require(!hasCycle(steps)) { "Dependency cycle" }
        val ordered = topological(steps)
        val decisions = linkedMapOf<String, ActionDecision>()
        val reasons = mutableListOf<String>()
        if (stopRequested) {
            ordered.forEach { decisions[it.stepId] = ActionDecision.STOPPED }
            return OrchestrationResult(decisions, ordered.map { it.stepId }, true, listOf("Stop requested before simulation."))
        }
        for (step in ordered) {
            if (step.dependsOn.any { decisions[it] != ActionDecision.SIMULATE_READY }) {
                decisions[step.stepId] = ActionDecision.BLOCKED_DEPENDENCY
                reasons += "${step.stepId}: dependency is not simulated as ready."
                continue
            }
            if (step.actionKey !in policy.allowedActionKeys) {
                decisions[step.stepId] = ActionDecision.BLOCKED_POLICY
                reasons += "${step.stepId}: action key is not allowlisted."
                continue
            }
            val needsApproval = step.requiresApproval || step.risk.ordinal > policy.maxRiskWithoutApproval.ordinal
            if (needsApproval && step.actionKey !in policy.ownerApprovedActionKeys) {
                decisions[step.stepId] = ActionDecision.REQUIRES_OWNER_APPROVAL
                reasons += "${step.stepId}: explicit owner approval required."
                continue
            }
            decisions[step.stepId] = ActionDecision.SIMULATE_READY
        }
        return OrchestrationResult(decisions, ordered.map { it.stepId }, false, reasons)
    }

    private fun topological(steps: List<OrchestrationStep>): List<OrchestrationStep> {
        val remaining = steps.toMutableList(); val result = mutableListOf<OrchestrationStep>(); val done = mutableSetOf<String>()
        while (remaining.isNotEmpty()) {
            val next = remaining.firstOrNull { it.dependsOn.all(done::contains) } ?: error("Dependency cycle")
            remaining.remove(next); result += next; done += next.stepId
        }
        return result
    }
    private fun hasCycle(steps: List<OrchestrationStep>): Boolean {
        val byId = steps.associateBy { it.stepId }; val visiting = mutableSetOf<String>(); val visited = mutableSetOf<String>()
        fun visit(id: String): Boolean {
            if (id in visiting) return true
            if (id in visited) return false
            visiting += id
            for (dep in byId[id]?.dependsOn.orEmpty()) if (visit(dep)) return true
            visiting -= id; visited += id; return false
        }
        return byId.keys.any(::visit)
    }
}
