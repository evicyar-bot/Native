package aqua.orchestration

import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Base64

/** A reproducible record of what the simulation-only preflight actually checked. */
data class PreflightReceipt(
    val sequence: Long,
    val receiptId: String,
    val createdAtMillis: Long,
    val planFingerprint: String,
    val queueFingerprint: String,
    val queueSnapshot: String,
    val requestFingerprint: String,
    val stopped: Boolean,
    val simulationOnly: Boolean,
    val approvalDecision: String,
    val approvalReviewer: String,
    val approvalTimestamp: Long,
    val permissionsSatisfied: Boolean,
    val dependenciesSatisfied: Boolean,
    val riskLevel: Int,
    val maxAllowedRisk: Int,
    val estimatedBudget: Long,
    val remainingBudget: Long,
    val outcome: PreflightOutcome,
    val passed: List<PreflightCheck>,
    val failed: List<PreflightCheck>,
    val reasons: List<String>,
    val previousHash: String,
    val hash: String
)

/** Creates receipts only; it does not grant tool access or execute external actions. */
object PreflightReceiptFactory {
    fun create(request: PreflightRequest, result: PreflightResult, sequence: Long, receiptId: String, createdAtMillis: Long): PreflightReceipt {
        require(sequence > 0 && receiptId.isNotBlank() && createdAtMillis >= 0)
        val approval = request.approval
        val approvalDecision = approval?.decision?.name ?: "NONE"
        val reviewer = approval?.reviewer ?: ""
        val approvalTime = approval?.reviewedAtEpochMs ?: 0L
        val queueSnapshot = request.queue.items.joinToString("\n") { listOf(it.stepId, it.disposition.name, it.rationale).joinToString("\u001f") }
        val requestFingerprint = sha(listOf(
            request.planFingerprint, request.queue.planFingerprint, request.queue.queueFingerprint,
            request.queue.stopped.toString(), queueSnapshot,
            request.stopped.toString(), request.simulationOnly.toString(), approvalDecision, reviewer, approvalTime.toString(),
            request.permissionsSatisfied.toString(), request.dependenciesSatisfied.toString(), request.riskLevel.toString(),
            request.maxAllowedRisk.toString(), request.estimatedBudget.toString(), request.remainingBudget.toString()
        ).joinToString("\u001f"))
        val draft = PreflightReceipt(sequence, receiptId, createdAtMillis, request.planFingerprint, request.queue.queueFingerprint,
            queueSnapshot, requestFingerprint, request.stopped || request.queue.stopped, request.simulationOnly, approvalDecision, reviewer,
            approvalTime, request.permissionsSatisfied, request.dependenciesSatisfied, request.riskLevel, request.maxAllowedRisk,
            request.estimatedBudget, request.remainingBudget, result.outcome, result.passed.sortedBy { it.name },
            result.failed.sortedBy { it.name }, result.reasons.toList(), "GENESIS", "")
        return draft.copy(hash = sha(payload(draft)))
    }

    internal fun payload(r: PreflightReceipt): String = listOf(
        r.sequence, r.receiptId, r.createdAtMillis, r.planFingerprint, r.queueFingerprint, r.queueSnapshot, r.requestFingerprint,
        r.stopped, r.simulationOnly, r.approvalDecision, r.approvalReviewer, r.approvalTimestamp,
        r.permissionsSatisfied, r.dependenciesSatisfied, r.riskLevel, r.maxAllowedRisk, r.estimatedBudget,
        r.remainingBudget, r.outcome.name, r.passed.joinToString(",") { it.name },
        r.failed.joinToString(",") { it.name }, r.reasons.joinToString("\u001e"), r.previousHash
    ).joinToString("\u001f")

    internal fun sha(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}

/** Atomic, checksummed receipt journal. A failed write never publishes the receipt in memory. */
class PreflightReceiptStore {
    private val receipts = mutableListOf<PreflightReceipt>()

    @Synchronized fun append(request: PreflightRequest, receiptId: String, createdAtMillis: Long): PreflightReceipt {
        require(receiptId.isNotBlank() && receipts.none { it.receiptId == receiptId }) { "Duplicate or blank receipt ID" }
        require(verify()) { "Existing receipt journal is invalid" }
        val previous = receipts.lastOrNull()?.hash ?: "GENESIS"
        val result = PreflightGate.evaluate(request)
        val draft = PreflightReceiptFactory.create(request, result, receipts.size.toLong() + 1, receiptId, createdAtMillis)
            .copy(previousHash = previous, hash = "")
        val receipt = draft.copy(hash = PreflightReceiptFactory.sha(PreflightReceiptFactory.payload(draft)))
        val candidate = receipts + receipt
        persist(candidate)
        receipts.add(receipt)
        return receipt
    }

    @Synchronized fun snapshot(): List<PreflightReceipt> = receipts.toList()

    @Synchronized fun verify(): Boolean = receipts.withIndex().all { (index, receipt) ->
        val previous = if (index == 0) "GENESIS" else receipts[index - 1].hash
        receipt.sequence == index + 1L && receipt.previousHash == previous &&
            receipt.receiptId.isNotBlank() && receipt.hash == PreflightReceiptFactory.sha(PreflightReceiptFactory.payload(receipt))
    } && receipts.map { it.receiptId }.toSet().size == receipts.size

    @Synchronized fun save(file: File) {
        require(verify()) { "Receipt journal integrity failure" }
        persistTo(file, receipts)
        backingFile = file
    }

    @Synchronized fun load(file: File) {
        val lines = file.readLines(Charsets.UTF_8)
        require(lines.firstOrNull() == HEADER) { "Invalid receipt journal header" }
        val parsed = lines.drop(1).filter { it.isNotBlank() }.map(::decode)
        val old = receipts.toList()
        receipts.clear(); receipts.addAll(parsed)
        if (!verify()) { receipts.clear(); receipts.addAll(old); error("Receipt journal integrity failure") }
        backingFile = file
    }

    private var backingFile: File? = null

    private fun persist(candidate: List<PreflightReceipt>) {
        require(candidate.withIndex().all { (i, r) -> r.sequence == i + 1L && r.hash == PreflightReceiptFactory.sha(PreflightReceiptFactory.payload(r)) })
        val file = backingFile ?: error("Attach a receipt file before appending")
        persistTo(file, candidate)
    }

    @Synchronized fun attach(file: File) {
        backingFile = file
        if (file.exists()) load(file) else { file.parentFile?.mkdirs(); persistTo(file, emptyList()) }
    }

    private fun persistTo(file: File, values: List<PreflightReceipt>) {
        file.parentFile?.mkdirs()
        val body = values.joinToString("\n") { encode(it) }
        val temp = File(file.parentFile ?: File("."), file.name + ".tmp")
        temp.writeText(HEADER + "\n" + body + if (body.isEmpty()) "" else "\n", Charsets.UTF_8)
        try { Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE) }
        catch (_: Exception) { Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING) }
    }

    private fun encode(r: PreflightReceipt): String {
        val fields = listOf(r.sequence.toString(), r.receiptId, r.createdAtMillis.toString(), r.planFingerprint, r.queueFingerprint,
            r.queueSnapshot, r.requestFingerprint, r.stopped.toString(), r.simulationOnly.toString(), r.approvalDecision, r.approvalReviewer,
            r.approvalTimestamp.toString(), r.permissionsSatisfied.toString(), r.dependenciesSatisfied.toString(),
            r.riskLevel.toString(), r.maxAllowedRisk.toString(), r.estimatedBudget.toString(), r.remainingBudget.toString(),
            r.outcome.name, r.passed.joinToString(",") { it.name }, r.failed.joinToString(",") { it.name },
            r.reasons.joinToString("\u001e"), r.previousHash, r.hash)
        return fields.joinToString("\t") { b64(it) }
    }

    private fun decode(line: String): PreflightReceipt {
        val p = line.split('\t').map(::unb64); require(p.size == 24) { "Invalid receipt record" }
        fun checks(value: String) = if (value.isBlank()) emptyList() else value.split(',').map(PreflightCheck::valueOf)
        return PreflightReceipt(p[0].toLong(), p[1], p[2].toLong(), p[3], p[4], p[5], p[6], p[7].toBooleanStrict(),
            p[8].toBooleanStrict(), p[9], p[10], p[11].toLong(), p[12].toBooleanStrict(), p[13].toBooleanStrict(),
            p[14].toInt(), p[15].toInt(), p[16].toLong(), p[17].toLong(), PreflightOutcome.valueOf(p[18]),
            checks(p[19]), checks(p[20]), if (p[21].isBlank()) emptyList() else p[21].split("\u001e"), p[22], p[23])
    }

    private fun b64(s: String) = Base64.getEncoder().encodeToString(s.toByteArray(Charsets.UTF_8))
    private fun unb64(s: String) = String(Base64.getDecoder().decode(s), Charsets.UTF_8)
    companion object { private const val HEADER = "AQUA_PREFLIGHT_RECEIPTS_V1" }
}
