package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8
import java.security.MessageDigest

/** Step 65: aggregate archive health without changing any archive entry. */
data class RecoveryArchiveHealthSummary(
    val scannedFiles: Int,
    val metadataEntries: Int,
    val validEntries: Int,
    val errors: Int,
    val warnings: Int,
    val infos: Int,
    val healthPercent: Int,
    val status: String
) {
    companion object {
        fun from(result: RecoveryReportRepairArchiveDiagnosticsResult): RecoveryArchiveHealthSummary {
            val errors = result.findings.count { it.severity == RecoveryReportRepairArchiveFindingSeverity.ERROR }
            val warnings = result.findings.count { it.severity == RecoveryReportRepairArchiveFindingSeverity.WARNING }
            val infos = result.findings.count { it.severity == RecoveryReportRepairArchiveFindingSeverity.INFO }
            val denominator = (result.metadataEntries + errors).coerceAtLeast(1)
            val score = ((result.validEntries.toDouble() / denominator) * 100.0).toInt().coerceIn(0, 100)
            val status = when {
                errors > 0 -> "NEEDS_REVIEW"
                warnings > 0 -> "HEALTHY_WITH_WARNINGS"
                !result.directoryPresent -> "NOT_INITIALIZED"
                else -> "HEALTHY"
            }
            return RecoveryArchiveHealthSummary(result.filesScanned, result.metadataEntries, result.validEntries,
                errors, warnings, infos, score, status)
        }
    }
}

/** A remediation item is advisory. It deliberately contains no executable command. */
data class RecoveryArchiveRemediationItem(
    val id: String,
    val findingCode: String,
    val severity: RecoveryReportRepairArchiveFindingSeverity,
    val path: String,
    val archiveId: String?,
    val title: String,
    val operatorAction: String,
    val risk: String,
    val priority: Int,
    val group: String,
    val requiresOwnerDecision: Boolean = true,
    val executable: Boolean = false
)

data class RecoveryArchiveRemediationQueue(
    val items: List<RecoveryArchiveRemediationItem>,
    val generatedAtMillis: Long,
    val fingerprint: String
) {
    val total: Int get() = items.size
    val highPriorityCount: Int get() = items.count { it.priority >= 80 }
}

/** Step 66: stable queue construction from diagnostics; no repair execution. */
object RecoveryArchiveRemediationQueueBuilder {
    fun build(findings: List<RecoveryReportRepairArchiveFinding>, generatedAtMillis: Long): RecoveryArchiveRemediationQueue {
        require(generatedAtMillis >= 0)
        val items = findings.map { finding ->
            val (group, risk) = when (finding.severity) {
                RecoveryReportRepairArchiveFindingSeverity.ERROR -> Pair("INTEGRITY", "High: preserve originals and verify trusted backups")
                RecoveryReportRepairArchiveFindingSeverity.WARNING -> Pair("REVIEW", "Moderate: inspect before making changes")
                RecoveryReportRepairArchiveFindingSeverity.INFO -> Pair("HOUSEKEEPING", "Low: informational; no action unless needed")
            }
            val title = finding.code.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }
            RecoveryArchiveRemediationItem(stableId(finding), finding.code, finding.severity, finding.path,
                finding.archiveId, title, finding.proposedAction, risk, RecoveryArchivePriorityPolicy.priority(finding.severity, finding.code), group)
        }.distinctBy { it.id }.sortedWith(compareByDescending<RecoveryArchiveRemediationItem> { it.priority }
            .thenBy { it.group }.thenBy { it.path }.thenBy { it.id }
        )
        return RecoveryArchiveRemediationQueue(items, generatedAtMillis, fingerprint(items))
    }

    private fun stableId(f: RecoveryReportRepairArchiveFinding): String =
        sha256("${f.code}|${f.archiveId.orEmpty()}|${f.path}").take(24)
    private fun fingerprint(items: List<RecoveryArchiveRemediationItem>): String =
        sha256(items.joinToString("\n") { "${it.id}|${it.findingCode}|${it.priority}|${it.group}|${it.path}|${it.operatorAction}" })
    private fun sha256(s: String): String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(UTF_8)).joinToString("") { "%02x".format(it) }
}

/** Step 67: priority policy is explicit, stable and independently testable. */
object RecoveryArchivePriorityPolicy {
    fun priority(severity: RecoveryReportRepairArchiveFindingSeverity, code: String): Int {
        val base = when (severity) {
            RecoveryReportRepairArchiveFindingSeverity.ERROR -> 80
            RecoveryReportRepairArchiveFindingSeverity.WARNING -> 50
            RecoveryReportRepairArchiveFindingSeverity.INFO -> 10
        }
        val modifier = when (code) {
            "ARCHIVE_DIRECTORY_UNSAFE", "ARCHIVE_METADATA_UNSAFE", "ARCHIVE_PAYLOAD_SYMLINK" -> 20
            "ARCHIVE_ENTRY_INVALID", "ARCHIVE_PAYLOAD_MISSING", "ARCHIVE_PAYLOAD_HASH_MISMATCH" -> 10
            "INTERRUPTED_ARCHIVE_WRITE", "ORPHAN_ARCHIVE_PAYLOAD" -> 5
            else -> 0
        }
        return (base + modifier).coerceAtMost(100)
    }
}

/** Step 68: deterministic de-duplication that preserves distinct paths and IDs. */
object RecoveryArchiveQueueDeduplicator {
    fun deduplicate(items: List<RecoveryArchiveRemediationItem>): List<RecoveryArchiveRemediationItem> =
        items.groupBy { it.id }.values.map { group ->
            group.maxWith(compareBy<RecoveryArchiveRemediationItem> { it.priority }.thenBy { it.risk })
        }.sortedWith(compareByDescending<RecoveryArchiveRemediationItem> { it.priority }.thenBy { it.id })
}

/** Step 69: grouping for operator review; items remain individually addressable. */
object RecoveryArchiveQueueGrouping {
    fun group(items: List<RecoveryArchiveRemediationItem>): Map<String, List<RecoveryArchiveRemediationItem>> =
        items.groupBy { it.group }.toSortedMap().mapValues { (_, value) ->
            value.sortedWith(compareByDescending<RecoveryArchiveRemediationItem> { it.priority }.thenBy { it.path })
        }
}

/** Step 70: a read-only suggested order; dependency links are advisory, not execution edges. */
data class RecoveryArchiveQueueDependency(val beforeId: String, val afterId: String, val rationale: String)

object RecoveryArchiveQueueDependencies {
    fun suggest(items: List<RecoveryArchiveRemediationItem>): List<RecoveryArchiveQueueDependency> {
        val ordered = items.sortedWith(compareByDescending<RecoveryArchiveRemediationItem> { it.priority }.thenBy { it.id })
        return ordered.zipWithNext().map { (before, after) ->
            RecoveryArchiveQueueDependency(before.id, after.id,
                "Review higher-priority item first; this is a suggested review order only")
        }
    }
}

/** Step 71: bounded queue pagination with stable fingerprint and input validation. */
data class RecoveryArchiveQueuePage(
    val fingerprint: String,
    val offset: Int,
    val limit: Int,
    val total: Int,
    val items: List<RecoveryArchiveRemediationItem>
)

object RecoveryArchiveQueuePaging {
    fun page(queue: RecoveryArchiveRemediationQueue, offset: Int, limit: Int): RecoveryArchiveQueuePage {
        require(offset >= 0) { "Offset must be non-negative" }
        require(limit in 1..200) { "Limit must be 1..200" }
        return RecoveryArchiveQueuePage(queue.fingerprint, offset, limit, queue.total,
            queue.items.drop(offset).take(limit))
    }
}

/** Step 72: signed-off review is not represented; snapshot is a content fingerprint only. */
data class RecoveryArchiveQueueSnapshot(
    val createdAtMillis: Long,
    val queueFingerprint: String,
    val itemIds: List<String>,
    val count: Int,
    val digest: String
)

object RecoveryArchiveQueueSnapshotter {
    fun snapshot(queue: RecoveryArchiveRemediationQueue, createdAtMillis: Long): RecoveryArchiveQueueSnapshot {
        require(createdAtMillis >= 0)
        val ids = queue.items.map { it.id }
        val digest = sha256("${queue.fingerprint}|$createdAtMillis|${ids.joinToString(",")}")
        return RecoveryArchiveQueueSnapshot(createdAtMillis, queue.fingerprint, ids, ids.size, digest)
    }
    fun verify(snapshot: RecoveryArchiveQueueSnapshot): Boolean =
        snapshot.createdAtMillis >= 0 && snapshot.count == snapshot.itemIds.size &&
            snapshot.digest == sha256("${snapshot.queueFingerprint}|${snapshot.createdAtMillis}|${snapshot.itemIds.joinToString(",")}")
    private fun sha256(s: String): String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(UTF_8)).joinToString("") { "%02x".format(it) }
}

/** Step 73: compact report serialization; escaped JSON strings and deterministic field order. */
object RecoveryArchiveQueueReportJson {
    fun render(queue: RecoveryArchiveRemediationQueue, summary: RecoveryArchiveHealthSummary): String {
        fun q(s: String): String = "\"" + s.map { c -> when (c.code) { 92 -> "\\\\"; 34 -> "\\\""; 10 -> "\\n"; 13 -> "\\r"; 9 -> "\\t"; else -> if (c.code < 0x20) "\\u%04x".format(c.code) else c.toString() } }.joinToString("") + "\""
        val entries = queue.items.joinToString(",") { item ->
            """{"id":${q(item.id)},"code":${q(item.findingCode)},"severity":${q(item.severity.name)},"path":${q(item.path)},"priority":${item.priority},"group":${q(item.group)},"action":${q(item.operatorAction)},"executable":false}"""
        }
        return """{"schema":1,"queueFingerprint":${q(queue.fingerprint)},"generatedAt":${queue.generatedAtMillis},"health":{"status":${q(summary.status)},"percent":${summary.healthPercent},"errors":${summary.errors},"warnings":${summary.warnings}},"items":[$entries]}"""
    }
}

/** Step 74: compare snapshots without merging or altering either queue. */
data class RecoveryArchiveQueueSnapshotComparison(
    val identical: Boolean,
    val leftCount: Int,
    val rightCount: Int,
    val commonIds: List<String>,
    val leftOnly: List<String>,
    val rightOnly: List<String>
)

object RecoveryArchiveQueueSnapshotComparer {
    fun compare(left: RecoveryArchiveQueueSnapshot, right: RecoveryArchiveQueueSnapshot): RecoveryArchiveQueueSnapshotComparison {
        require(RecoveryArchiveQueueSnapshotter.verify(left) && RecoveryArchiveQueueSnapshotter.verify(right)) {
            "Invalid queue snapshot"
        }
        val l = left.itemIds.toSet(); val r = right.itemIds.toSet()
        return RecoveryArchiveQueueSnapshotComparison(left.queueFingerprint == right.queueFingerprint && left.itemIds == right.itemIds,
            left.count, right.count, left.itemIds.filter { it in r }, left.itemIds.filter { it !in r }, right.itemIds.filter { it !in l })
    }
}
