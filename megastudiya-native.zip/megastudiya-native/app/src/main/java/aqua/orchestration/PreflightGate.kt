package aqua.orchestration

/** Final safety review before simulated hand-off. This gate never executes tools. */
enum class PreflightOutcome { READY_FOR_SIMULATION, REQUIRES_OWNER_CONFIRMATION, BLOCKED }
enum class PreflightCheck { STOP_FLAG, PLAN_FINGERPRINT, QUEUE_FINGERPRINT, APPROVAL, PERMISSIONS, DEPENDENCIES, RISK, BUDGET, QUEUE_STATE }
data class PreflightRequest(
    val planFingerprint: String,
    val queue: FrozenResumeQueue,
    val approval: ResumeApprovalRecord?,
    val permissionsSatisfied: Boolean,
    val dependenciesSatisfied: Boolean,
    val riskLevel: Int,
    val maxAllowedRisk: Int,
    val estimatedBudget: Long,
    val remainingBudget: Long,
    val stopped: Boolean = false,
    val simulationOnly: Boolean = true
)
data class PreflightResult(val outcome: PreflightOutcome, val passed: Set<PreflightCheck>, val failed: Set<PreflightCheck>, val reasons: List<String>)
object PreflightGate {
    fun evaluate(request: PreflightRequest): PreflightResult {
        val passed = linkedSetOf<PreflightCheck>(); val failed = linkedSetOf<PreflightCheck>(); val reasons = mutableListOf<String>()
        fun check(c: PreflightCheck, ok: Boolean, reason: String) { if (ok) passed += c else { failed += c; reasons += reason } }
        check(PreflightCheck.STOP_FLAG, !request.stopped && !request.queue.stopped, "Stop flag active: preflight denied.")
        check(PreflightCheck.PLAN_FINGERPRINT, request.planFingerprint.isNotBlank() && request.planFingerprint == request.queue.planFingerprint, "Plan fingerprint mismatch or missing.")
        check(PreflightCheck.QUEUE_FINGERPRINT, request.queue.queueFingerprint.isNotBlank(), "Queue fingerprint missing.")
        check(PreflightCheck.APPROVAL, request.approval != null && ResumeQueueApprovalService.matches(request.approval, request.queue) && request.approval.decision == ResumeApprovalDecision.APPROVE, "Current queue approval missing, rejected, or stale.")
        check(PreflightCheck.PERMISSIONS, request.permissionsSatisfied, "Required permissions are not satisfied.")
        check(PreflightCheck.DEPENDENCIES, request.dependenciesSatisfied, "Dependencies are not verified complete.")
        check(PreflightCheck.RISK, request.riskLevel >= 0 && request.maxAllowedRisk >= 0 && request.riskLevel <= request.maxAllowedRisk, "Risk exceeds policy or is invalid.")
        check(PreflightCheck.BUDGET, request.estimatedBudget >= 0 && request.remainingBudget >= 0 && request.estimatedBudget <= request.remainingBudget, "Budget is insufficient or invalid.")
        val queueClean = request.queue.items.none { it.disposition in setOf(ResumeDisposition.NEEDS_RECONCILIATION, ResumeDisposition.BLOCKED_DEPENDENCY, ResumeDisposition.NEEDS_APPROVAL, ResumeDisposition.STOPPED) }
        check(PreflightCheck.QUEUE_STATE, queueClean, "Queue contains unresolved or blocked entries.")
        val outcome = when { failed.isNotEmpty() -> PreflightOutcome.BLOCKED; !request.simulationOnly -> PreflightOutcome.REQUIRES_OWNER_CONFIRMATION; else -> PreflightOutcome.READY_FOR_SIMULATION }
        return PreflightResult(outcome, passed, failed, reasons.toList())
    }
}
