package aqua.orchestration

import java.nio.file.Files
import java.nio.file.Path
import java.security.MessageDigest

/** Severity of a finding discovered while reconciling archive metadata and payload files. */
enum class RecoveryReportRepairArchiveFindingSeverity { INFO, WARNING, ERROR }

data class RecoveryReportRepairArchiveFinding(
    val code: String,
    val severity: RecoveryReportRepairArchiveFindingSeverity,
    val archiveId: String?,
    val path: String,
    val explanation: String,
    val proposedAction: String
)

data class RecoveryReportRepairArchiveDiagnosticsResult(
    val directory: String,
    val directoryPresent: Boolean,
    val filesScanned: Int,
    val metadataEntries: Int,
    val validEntries: Int,
    val findings: List<RecoveryReportRepairArchiveFinding>
) {
    val healthy: Boolean get() = findings.none { it.severity == RecoveryReportRepairArchiveFindingSeverity.ERROR }
}

/**
 * Step 64: read-only consistency diagnostics for Step 63 review snapshots.
 * Findings are advisory; this class never repairs, renames, overwrites or deletes archive entries.
 * The delegated export verifier may create and clean a transient scratch file during validation.
 */
class RecoveryReportRepairReviewArchiveDiagnostics(private val archiveDirectory: Path) {
    @Synchronized
    fun inspect(): RecoveryReportRepairArchiveDiagnosticsResult {
        val root = archiveDirectory.toAbsolutePath().normalize()
        val findings = mutableListOf<RecoveryReportRepairArchiveFinding>()
        if (!Files.exists(root)) {
            findings += finding("ARCHIVE_DIRECTORY_MISSING", RecoveryReportRepairArchiveFindingSeverity.INFO,
                null, root, "Archive directory does not exist yet", "Create the archive directory only when the owner intentionally saves the first snapshot")
            return RecoveryReportRepairArchiveDiagnosticsResult(root.toString(), false, 0, 0, 0, findings)
        }
        if (Files.isSymbolicLink(root) || !Files.isDirectory(root)) {
            findings += finding("ARCHIVE_DIRECTORY_UNSAFE", RecoveryReportRepairArchiveFindingSeverity.ERROR,
                null, root, "Archive path is not a plain directory", "Review the configured archive path and permissions manually")
            return RecoveryReportRepairArchiveDiagnosticsResult(root.toString(), false, 0, 0, 0, findings)
        }

        val children = Files.list(root).use { stream -> stream.toList() }.sortedBy { it.fileName.toString() }
        val metadata = children.filter { it.fileName.toString().endsWith(".meta") }
        val exports = children.filter { it.fileName.toString().endsWith(".export") }
        var validEntries = 0
        val seenDigests = mutableMapOf<String, String>()
        val expectedExports = mutableSetOf<String>()

        metadata.forEach { meta ->
            val name = meta.fileName.toString()
            val id = name.removeSuffix(".meta")
            if (Files.isSymbolicLink(meta) || !Files.isRegularFile(meta)) {
                findings += finding("ARCHIVE_METADATA_UNSAFE", RecoveryReportRepairArchiveFindingSeverity.ERROR,
                    id, meta, "Metadata entry is not a regular non-symlink file", "Inspect the entry manually; do not follow or replace it automatically")
                return@forEach
            }
            val data = root.resolve("$id.export")
            expectedExports += data.fileName.toString()
            if (Files.isSymbolicLink(data)) {
                findings += finding("ARCHIVE_PAYLOAD_SYMLINK", RecoveryReportRepairArchiveFindingSeverity.ERROR,
                    id, data, "Snapshot payload is a symbolic link", "Verify the intended payload location and restore a regular file only from a trusted copy")
                return@forEach
            }
            val entry = RecoveryReportRepairReviewArchive(root).inspect(id)
            if (!entry.valid) {
                val code = when {
                    !Files.exists(data) -> "ARCHIVE_PAYLOAD_MISSING"
                    !Files.isRegularFile(data) -> "ARCHIVE_PAYLOAD_NOT_REGULAR"
                    else -> "ARCHIVE_ENTRY_INVALID"
                }
                findings += finding(code, RecoveryReportRepairArchiveFindingSeverity.ERROR, id, meta,
                    entry.error ?: "Archive entry failed integrity verification", "Compare metadata and payload with an independently retained trusted snapshot")
            } else {
                validEntries++
                val previous = seenDigests.putIfAbsent(entry.exportSha256, id)
                if (previous != null) findings += finding("DUPLICATE_SNAPSHOT_CONTENT",
                    RecoveryReportRepairArchiveFindingSeverity.WARNING, id, data,
                    "Snapshot payload is byte-identical to archive '$previous'", "Confirm whether the duplicate snapshot is intentional; retain both unless the owner decides otherwise")
            }
        }

        exports.forEach { export ->
            val name = export.fileName.toString()
            if (name !in expectedExports) findings += finding(
                if (Files.isSymbolicLink(export)) "ORPHAN_PAYLOAD_SYMLINK" else "ORPHAN_ARCHIVE_PAYLOAD",
                RecoveryReportRepairArchiveFindingSeverity.WARNING, name.removeSuffix(".export"), export,
                "Payload has no matching metadata entry", "Locate a trusted matching metadata record or preserve the payload for manual investigation")
        }

        children.filter { it.fileName.toString().endsWith(".pending") }.forEach { pending ->
            findings += finding("INTERRUPTED_ARCHIVE_WRITE", RecoveryReportRepairArchiveFindingSeverity.WARNING,
                null, pending, "A temporary file from an interrupted write may remain", "Inspect its origin and age; do not promote or delete it automatically")
        }
        children.filter { !it.fileName.toString().endsWith(".meta") && !it.fileName.toString().endsWith(".export") && !it.fileName.toString().endsWith(".pending") }
            .forEach { extra -> findings += finding("UNRECOGNIZED_ARCHIVE_ENTRY", RecoveryReportRepairArchiveFindingSeverity.WARNING,
                null, extra, "Archive directory contains an unrecognized entry", "Determine whether another process owns this file before taking action") }

        return RecoveryReportRepairArchiveDiagnosticsResult(root.toString(), true, children.size,
            metadata.size, validEntries, findings)
    }

    private fun finding(code: String, severity: RecoveryReportRepairArchiveFindingSeverity, id: String?, path: Path,
                       explanation: String, proposedAction: String) = RecoveryReportRepairArchiveFinding(
        code, severity, id, path.toString(), explanation, proposedAction)
}
