package aqua.planning.gate

import aqua.planning.PlanStatus
import aqua.planning.storage.StoredPlanStatus
import aqua.planning.storage.StoredTaskPlan

/** Explicit human-review attestations required before a plan may be handed to an executor. */
data class PlanGateReview(
    val reviewerId: String,
    val reviewedAtEpochMs: Long,
    val constraintsAcknowledged: Boolean,
    val risksAcknowledged: Boolean,
    val note: String = ""
)

enum class PlanGateStatus { BLOCKED, READY_FOR_HANDOFF }

data class PlanGateDecision(
    val status: PlanGateStatus,
    val blockers: List<String>,
    val warnings: List<String>,
    val planId: String,
    val planVersion: Int,
    val reviewerId: String? = null,
    val reviewedAtEpochMs: Long? = null
) {
    val allowed: Boolean get() = status == PlanGateStatus.READY_FOR_HANDOFF && blockers.isEmpty()
}

/**
 * Read-only safety gate. It checks readiness only; it does not execute, approve, or mutate plans.
 * An explicit repository APPROVED status and review attestations are required.
 */
class PlanExecutionGate {
    fun evaluate(stored: StoredTaskPlan, review: PlanGateReview): PlanGateDecision {
        val blockers = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        val plan = stored.plan

        if (stored.status != StoredPlanStatus.APPROVED) blockers += "Plan must be explicitly APPROVED in storage."
        if (stored.status == StoredPlanStatus.ARCHIVED) blockers += "Archived plans cannot be handed off."
        if (plan.status == PlanStatus.INVALID) blockers += "Invalid plans cannot be handed off."
        if (plan.status == PlanStatus.NEEDS_REVIEW) blockers += "Plans requiring review cannot be handed off until resolved."
        if (plan.status != PlanStatus.READY) blockers += "Plan status must be READY."
        if (plan.goal.isBlank()) blockers += "Plan goal is missing."
        if (plan.steps.isEmpty()) blockers += "Plan has no steps."
        if (plan.successCriteria.isEmpty() || plan.successCriteria.any { it.isBlank() }) blockers += "Overall success criteria are missing or incomplete."
        if (plan.steps.any { it.draft.completionCriteria.isEmpty() || it.draft.completionCriteria.any(String::isBlank) }) blockers += "One or more steps lack completion criteria."
        if (plan.steps.any { it.draft.riskNotes.isEmpty() || it.draft.riskNotes.any(String::isBlank) }) blockers += "Explicit risk notes are required for every step."
        if (review.reviewerId.isBlank()) blockers += "Reviewer identity is required."
        if (review.reviewedAtEpochMs <= 0L) blockers += "Review timestamp must be valid."
        if (!review.constraintsAcknowledged) blockers += "Task constraints must be explicitly acknowledged."
        if (!review.risksAcknowledged) blockers += "Plan risks must be explicitly acknowledged."
        if (review.note.isBlank()) warnings += "Review note is empty; rationale will not be recorded in this gate result."
        if (plan.contextWarnings.isNotEmpty()) warnings += "Plan contains context cautions that should be retained by the handoff."
        if (plan.planningWarnings.isNotEmpty()) warnings += "Plan has planning warnings; inspect before handoff."

        val status = if (blockers.isEmpty()) PlanGateStatus.READY_FOR_HANDOFF else PlanGateStatus.BLOCKED
        return PlanGateDecision(status, blockers.distinct(), warnings.distinct(), stored.planId, stored.version,
            review.reviewerId.takeIf { it.isNotBlank() }, review.reviewedAtEpochMs.takeIf { it > 0 })
    }
}
