package aqua.planning

import aqua.experience.TaskContextPackage

/** A proposed action is a plan item only; this module does not execute it. */
data class PlanStepDraft(
    val id: String,
    val description: String,
    val expectedResult: String,
    val completionCriteria: List<String>,
    val dependsOn: List<String> = emptyList(),
    val riskNotes: List<String> = emptyList()
) {
    init {
        require(id.isNotBlank() && description.isNotBlank() && expectedResult.isNotBlank())
        require(completionCriteria.isNotEmpty() && completionCriteria.all { it.isNotBlank() })
        require(dependsOn.distinct().size == dependsOn.size)
    }
}
data class TaskPlanDraft(val steps: List<PlanStepDraft>, val overallSuccessCriteria: List<String>)
data class PlannedStep(val order: Int, val draft: PlanStepDraft)
data class TaskPlan(
    val taskId: String, val goal: String, val constraints: List<String>,
    val steps: List<PlannedStep>, val successCriteria: List<String>,
    val contextMemoryIds: List<String>, val contextWarnings: List<String>,
    val planningWarnings: List<String>, val status: PlanStatus = PlanStatus.READY
)
enum class PlanStatus { READY, NEEDS_REVIEW, INVALID }
data class PlanValidation(val valid: Boolean, val errors: List<String>, val warnings: List<String>)

/** Deterministic planning and validation, with dependency order and traceability. No execution. */
class TaskPlanner {
    fun create(context: TaskContextPackage, draft: TaskPlanDraft): TaskPlan {
        val validation = validate(draft)
        val ordered = if (validation.valid) topologicalOrder(draft.steps) else draft.steps
        val planWarnings = validation.warnings + if (!validation.valid) validation.errors else emptyList()
        return TaskPlan(
            taskId=context.taskId, goal=context.goal, constraints=context.constraints.toList(),
            steps=ordered.mapIndexed { i, step -> PlannedStep(i + 1, step) },
            successCriteria=draft.overallSuccessCriteria.toList(),
            contextMemoryIds=context.memories.map { it.insightId }.distinct().sorted(),
            contextWarnings=context.warnings.toList(), planningWarnings=planWarnings,
            status=if (!validation.valid) PlanStatus.INVALID else if (planWarnings.isNotEmpty() || context.warnings.isNotEmpty()) PlanStatus.NEEDS_REVIEW else PlanStatus.READY
        )
    }

    fun validate(draft: TaskPlanDraft): PlanValidation {
        val errors = mutableListOf<String>(); val warnings = mutableListOf<String>()
        if (draft.steps.isEmpty()) errors += "Plan must contain at least one step."
        if (draft.overallSuccessCriteria.isEmpty() || draft.overallSuccessCriteria.any { it.isBlank() }) errors += "Overall success criteria must be provided."
        val ids = draft.steps.map { it.id }
        if (ids.distinct().size != ids.size) errors += "Step IDs must be unique."
        val idSet = ids.toSet()
        draft.steps.forEach { step ->
            if (step.dependsOn.any { it !in idSet }) errors += "Step ${step.id} has an unknown dependency."
            if (step.id in step.dependsOn) errors += "Step ${step.id} cannot depend on itself."
            if (step.riskNotes.isEmpty()) warnings += "Step ${step.id} has no explicit risk notes."
        }
        if (hasCycle(draft.steps)) errors += "Dependency graph contains a cycle."
        return PlanValidation(errors.isEmpty(), errors.distinct(), warnings.distinct())
    }

    private fun topologicalOrder(steps: List<PlanStepDraft>): List<PlanStepDraft> {
        val remaining = steps.toMutableList(); val result = mutableListOf<PlanStepDraft>(); val done = mutableSetOf<String>()
        while (remaining.isNotEmpty()) {
            val ready = remaining.filter { it.dependsOn.all(done::contains) }
            if (ready.isEmpty()) return steps // validation should already flag this
            val next = ready.first(); remaining.remove(next); result += next; done += next.id
        }
        return result
    }
    private fun hasCycle(steps: List<PlanStepDraft>): Boolean {
        val byId = steps.associateBy { it.id }; val visiting = mutableSetOf<String>(); val visited = mutableSetOf<String>()
        fun visit(id: String): Boolean {
            if (id in visiting) return true
            if (id in visited) return false
            visiting += id
            for (dep in byId[id]?.dependsOn.orEmpty()) if (dep in byId && visit(dep)) return true
            visiting -= id; visited += id; return false
        }
        return byId.keys.any(::visit)
    }
}
