package aqua.planning.storage

import aqua.planning.*

enum class StoredPlanStatus { SAVED, APPROVED, ARCHIVED }
data class StoredTaskPlan(val planId:String, val plan:TaskPlan, val version:Int, val status:StoredPlanStatus, val savedAtEpochMs:Long, val history:List<PlanStatusChange> = emptyList())
data class PlanStatusChange(val status:StoredPlanStatus, val changedAtEpochMs:Long, val note:String)
interface TaskPlanRepository {
 fun save(planId:String, plan:TaskPlan, nowEpochMs:Long):StoredTaskPlan
 fun get(planId:String):StoredTaskPlan?
 fun list(taskId:String?=null):List<StoredTaskPlan>
 fun changeStatus(planId:String,status:StoredPlanStatus,nowEpochMs:Long,note:String=""):StoredTaskPlan?
}
