package aqua.experience

/** Bounded, traceable context prepared before a task begins. */
data class TaskContextRequest(
    val taskId: String,
    val goal: String,
    val constraints: List<String> = emptyList(),
    val maxMemories: Int = 5,
    val maxCharacters: Int = 8_000
) {
    init { require(taskId.isNotBlank()); require(goal.isNotBlank()); require(maxMemories in 1..50); require(maxCharacters in 256..100_000) }
}
data class TaskContextMemory(
    val insightId: String, val statement: String, val kind: String, val reviewStatus: String,
    val confidenceScore: Int, val relevance: Int, val evidenceEventIds: List<String>,
    val matchedTerms: List<String>, val caution: String
)
data class TaskContextPackage(
    val taskId: String, val goal: String, val constraints: List<String>,
    val memories: List<TaskContextMemory>, val warnings: List<String>,
    val renderedText: String, val truncated: Boolean
)

/** Combines retrieval into a compact task briefing without inventing or mutating memories. */
class TaskContextAssembler(private val retrieval: ExperienceRetrievalService) {
    fun assemble(request: TaskContextRequest): TaskContextPackage {
        val retrieved = retrieval.retrieve(ExperienceQuery(request.goal + " " + request.constraints.joinToString(" "), maxResults=request.maxMemories)).retrieved
        val memories = retrieved.map { r -> TaskContextMemory(
            r.insight.id.value, r.insight.statement, r.insight.kind.name, r.insight.reviewStatus.name,
            r.insight.confidenceScore, r.relevance, r.insight.evidenceEventIds.sorted(), r.matchedTerms.sorted(), r.caution
        ) }
        val warnings = buildList {
            if (memories.any { it.reviewStatus == "UNREVIEWED" }) add("Some retrieved experience is unreviewed; treat as a hypothesis.")
            if (memories.isEmpty()) add("No relevant experience found; proceed without historical guidance.")
            if (memories.any { it.evidenceEventIds.isEmpty() }) add("At least one memory lacks event provenance.")
        }
        val full = render(request, memories, warnings)
        val bounded = if (full.length <= request.maxCharacters) full else full.take(request.maxCharacters).trimEnd() + "\n[Context truncated by character budget]"
        return TaskContextPackage(request.taskId, request.goal, request.constraints.toList(), memories, warnings, bounded, full.length > request.maxCharacters)
    }
    private fun render(req: TaskContextRequest, memories: List<TaskContextMemory>, warnings: List<String>): String = buildString {
        appendLine("TASK CONTEXT: ${req.taskId}"); appendLine("GOAL: ${req.goal}")
        if (req.constraints.isNotEmpty()) { appendLine("CONSTRAINTS:"); req.constraints.forEach { appendLine("- $it") } }
        appendLine("RELEVANT EXPERIENCE:")
        if (memories.isEmpty()) appendLine("- None retrieved")
        memories.forEach { m -> appendLine("- [${m.kind}; ${m.reviewStatus}; confidence=${m.confidenceScore}; relevance=${m.relevance}] ${m.statement}"); appendLine("  evidence=${m.evidenceEventIds.joinToString(",")}; matched=${m.matchedTerms.joinToString(",")}"); if (m.caution.isNotBlank()) appendLine("  caution=${m.caution}") }
        if (warnings.isNotEmpty()) { appendLine("WARNINGS:"); warnings.forEach { appendLine("- $it") } }
    }
}
