package aqua.experience

import aqua.analytics.EventHistoryReport
import java.security.MessageDigest

@JvmInline value class ExperienceId(val value: String) { init { require(value.isNotBlank()) } }
enum class ExperienceKind { FAILURE_PATTERN, LOW_SUCCESS_ACTION, REPEATED_TASK, HIGH_SUCCESS_SIGNAL }
enum class ExperienceReviewStatus { UNREVIEWED, CONFIRMED, REJECTED, OUTDATED }

data class ExperienceInsight(
    val id: ExperienceId,
    val kind: ExperienceKind,
    val statement: String,
    val evidenceEventIds: Set<String>,
    val evidenceCount: Int,
    /** Heuristic strength, not a calibrated probability. */
    val confidenceScore: Int,
    val reviewStatus: ExperienceReviewStatus = ExperienceReviewStatus.UNREVIEWED,
    val createdAtEpochMs: Long = 0L
) {
    init {
        require(statement.isNotBlank())
        require(evidenceEventIds.isNotEmpty())
        require(evidenceCount >= evidenceEventIds.size)
        require(confidenceScore in 0..100)
        require(createdAtEpochMs >= 0)
    }
}

interface ExperienceMemoryRepository {
    fun save(insight: ExperienceInsight): ExperienceInsight
    fun get(id: ExperienceId): ExperienceInsight?
    fun list(status: ExperienceReviewStatus? = null): List<ExperienceInsight>
    fun updateReview(id: ExperienceId, status: ExperienceReviewStatus): ExperienceInsight?
}

/** Converts observed analytics into traceable, reviewable experience records. */
class ExperienceLearningService(private val repository: ExperienceMemoryRepository) {
    fun learn(report: EventHistoryReport, nowEpochMs: Long = 0L): List<ExperienceInsight> {
        require(nowEpochMs >= 0)
        val candidates = buildList {
            report.repeatedFailures.forEach { p ->
                if (p.evidenceEventIds.isNotEmpty()) add(candidate(
                    ExperienceKind.FAILURE_PATTERN,
                    "Repeated failure for ${p.actor}/${p.action}: ${p.normalizedReason} (${p.occurrences} occurrences).",
                    p.evidenceEventIds, p.occurrences, nowEpochMs
                ))
            }
            report.actionStats.filter { it.terminalCount >= 3 && it.successRatePercent != null && it.successRatePercent < 50.0 }
                .forEach { stat -> if (stat.evidenceEventIds.isNotEmpty()) add(candidate(
                    ExperienceKind.LOW_SUCCESS_ACTION,
                    "Observed low success for ${stat.actor}/${stat.action}: ${stat.successes}/${stat.terminalCount} successful terminal events.",
                    stat.evidenceEventIds, stat.terminalCount, nowEpochMs
                )) }
            report.recurringTasks.forEach { task -> if (task.evidenceEventIds.isNotEmpty()) add(candidate(
                ExperienceKind.REPEATED_TASK,
                "Task ${task.taskId} recurred ${task.eventCount} times; failures=${task.failedCount}, successes=${task.succeededCount}.",
                task.evidenceEventIds, task.eventCount, nowEpochMs
            )) }
            report.actionStats.filter { it.terminalCount >= 5 && it.successRatePercent != null && it.successRatePercent >= 90.0 }
                .forEach { stat -> if (stat.evidenceEventIds.isNotEmpty()) add(candidate(
                    ExperienceKind.HIGH_SUCCESS_SIGNAL,
                    "Historical success signal for ${stat.actor}/${stat.action}: ${stat.successes}/${stat.terminalCount} successful terminal events; not a guarantee.",
                    stat.evidenceEventIds, stat.terminalCount, nowEpochMs
                )) }
        }
        return candidates.map(repository::save).distinctBy { it.id }
    }

    private fun candidate(kind: ExperienceKind, statement: String, evidence: Set<String>, count: Int, now: Long): ExperienceInsight {
        // Confidence is a transparent heuristic based on repetition, not a probability.
        val score = (45 + (count.coerceAtMost(10) - 1) * 5).coerceAtMost(90)
        val stableId = digest("$kind|${evidence.sorted().joinToString(",")}|$statement")
        return ExperienceInsight(ExperienceId(stableId), kind, statement, evidence, count, score, createdAtEpochMs = now)
    }

    private fun digest(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }.take(24)
}

/** Query the memory before a task; only reviewed-positive or unreviewed records are eligible by default. */
data class ExperienceQuery(
    val text: String,
    val kinds: Set<ExperienceKind> = emptySet(),
    val includeUnreviewed: Boolean = true,
    val maxResults: Int = 5,
    val minimumConfidence: Int = 0
) { init { require(maxResults in 1..50); require(minimumConfidence in 0..100) } }
data class RetrievedExperience(val insight: ExperienceInsight, val relevance: Int, val matchedTerms: Set<String>, val caution: String)
data class ExperienceContext(val query: String, val retrieved: List<RetrievedExperience>)

class ExperienceRetrievalService(private val repository: ExperienceMemoryRepository) {
    private val stopWords = setOf("the", "and", "for", "with", "from", "this", "that", "task", "about", "into", "на", "для", "это", "как", "что", "при", "или", "его", "её", "их")
    fun retrieve(query: ExperienceQuery): ExperienceContext {
        val terms = tokenize(query.text).filterNot { it in stopWords }.toSet()
        val eligible = repository.list().filter { insight ->
            insight.reviewStatus != ExperienceReviewStatus.REJECTED && insight.reviewStatus != ExperienceReviewStatus.OUTDATED &&
            (query.includeUnreviewed || insight.reviewStatus == ExperienceReviewStatus.CONFIRMED) &&
            (query.kinds.isEmpty() || insight.kind in query.kinds) && insight.confidenceScore >= query.minimumConfidence
        }
        val ranked = eligible.mapNotNull { insight ->
            val contentTerms = tokenize(insight.statement + " " + insight.kind.name.replace('_', ' '))
            val matches = terms.intersect(contentTerms)
            if (terms.isEmpty() || matches.isEmpty()) null else {
                val coverage = (matches.size * 100 / terms.size).coerceAtLeast(1)
                val relevance = (coverage * 70 / 100 + insight.confidenceScore * 30 / 100).coerceIn(1, 100)
                RetrievedExperience(insight, relevance, matches, when (insight.reviewStatus) {
                    ExperienceReviewStatus.UNREVIEWED -> "Unreviewed historical observation; verify before relying on it."
                    ExperienceReviewStatus.CONFIRMED -> "Reviewed insight; still context-specific, not a guarantee."
                    else -> ""
                })
            }
        }.sortedWith(compareByDescending<RetrievedExperience> { it.relevance }.thenByDescending { it.insight.evidenceCount }.thenBy { it.insight.id.value })
        return ExperienceContext(query.text, ranked.take(query.maxResults))
    }
    private fun tokenize(text: String): Set<String> = Regex("[\\p{L}\\p{N}]{3,}").findAll(text.lowercase())
        .map { it.value }.toSet()
}
