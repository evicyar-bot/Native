package aqua.ports

import aqua.research.*

/** Persistence ports. Implementations may be local files, databases, or host-app adapters. */
interface EvidenceRepository {
    fun list(taskId: TaskId? = null): List<EvidenceSource>
    fun find(id: SourceId): EvidenceSource?
    fun upsert(source: EvidenceSource): Boolean
    fun removeTask(taskId: TaskId): Int
}
interface ClaimRepository {
    fun list(taskId: TaskId? = null): List<Claim>
    fun find(id: ClaimId): Claim?
    fun upsert(claim: Claim): Boolean
    fun removeTask(taskId: TaskId): Int
}
interface DecisionRepository {
    fun list(taskId: TaskId? = null): List<ResearchDecision>
    fun find(id: DecisionId): ResearchDecision?
    fun upsert(decision: ResearchDecision): Boolean
    fun removeTask(taskId: TaskId): Int
}
