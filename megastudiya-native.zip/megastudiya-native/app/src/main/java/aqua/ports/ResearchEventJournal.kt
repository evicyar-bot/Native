package aqua.ports

import aqua.research.EventId
import aqua.research.EventQuery
import aqua.research.ResearchEvent

/** Append-only audit/event port. Duplicate event IDs must be idempotent. */
interface ResearchEventJournal {
    fun append(event: ResearchEvent): ResearchEvent
    fun query(query: EventQuery = EventQuery()): List<ResearchEvent>
    fun find(id: EventId): ResearchEvent?
    fun latestSequence(): Long
}
