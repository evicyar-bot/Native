package app.megastudiya.nativeapp

import java.net.URI
import java.util.Locale

// MediaHub — чистое ядро (без Android-классов, проверяется обычными JVM-тестами).
// Видео живёт отдельно от обычных публикаций: Post и Store этот модуль не трогает.

object Mk {
    const val LOCAL = "local"      // видеофайл, скопированный в закрытую папку приложения
    const val IMAGE = "image"      // изображение, скопированное так же
    const val LINK = "link"        // только ссылка на публикацию площадки (видео НЕ сохранено)

    const val OK = "ok"
    const val UNAVAILABLE = "unavailable"

    const val META_NONE = "none"
    const val META_PENDING = "pending"
    const val META_OK = "ok"
    const val META_FAILED = "failed"
    const val META_GONE = "gone"
    const val META_UNSUPPORTED = "unsupported"

    const val MAX_FILE_BYTES = 500L * 1024 * 1024

    fun sourceLabel(src: String): String = when (src) {
        "tiktok" -> "TikTok"
        "telegram" -> "Telegram"
        "youtube" -> "YouTube"
        "bsky" -> "Skylight"
        "rutube" -> "Rutube"
        "instagram" -> "Instagram"
        "device" -> "Устройство"
        "web" -> "Сайт"
        else -> src
    }
}

/** Карточка материала в каталоге «Видео». Не смешивается с Post. */
data class VideoCard(
    val id: String,
    val kind: String,                 // Mk.LOCAL | Mk.IMAGE | Mk.LINK
    val source: String,               // tiktok | telegram | youtube | instagram | web | device
    val dedupKey: String,
    val url: String = "",             // каноническая ссылка на оригинал (для link)
    val file: String = "",            // путь относительно папки mediahub (для local/image)
    val thumb: String = "",           // jpg-превью относительно папки mediahub (можно пересоздать)
    val thumbUrl: String = "",        // картинка из метаданных площадки (только для link)
    val title: String = "",
    val author: String = "",
    val desc: String = "",
    val tags: List<String> = emptyList(),
    val country: String = "",         // заполняется только если страна известна достоверно (в пакете 1 — никогда)
    val published: Long = 0L,         // 0 = неизвестно
    val added: Long = 0L,
    val durationMs: Long = 0L,
    val w: Int = 0,
    val h: Int = 0,
    val bytes: Long = 0L,
    val status: String = Mk.OK,
    val meta: String = Mk.META_NONE,
    val embedId: String = "",
    val streamUrl: String = ""            // временный CDN stream URL, если API его вернул
) {
    val hasFile: Boolean get() = kind == Mk.LOCAL || kind == Mk.IMAGE
    val playable: Boolean get() = kind == Mk.LOCAL
    /** Идентификатор ролика TikTok: из метаданных, а у старых карточек — из ключа «tiktok:<id>». Только цифры. */
    val embedVideoId: String get() {
        if (source != "tiktok") return ""
        val id = embedId.ifEmpty { if (dedupKey.startsWith("tiktok:")) dedupKey.removePrefix("tiktok:") else "" }
        return if (id.isNotEmpty() && id.length <= 24 && id.all { it.isDigit() }) id else ""
    }
    val canEmbed: Boolean get() = embedVideoId.isNotEmpty()

    fun toCand(): Cand = Cand(id, source, tags, country, published, added, playable)
}

data class LinkInfo(
    val platform: String,             // tiktok | telegram | youtube | instagram | web
    val canonical: String,
    val key: String,                  // ключ для удаления дублей
    val videoId: String = "",
    val author: String = "",
    val isPost: Boolean = true        // false: профиль, канал или иная страница
)

object LinkNorm {
    private val urlRe = Regex("""https?://[^\s<>"']+""", RegexOption.IGNORE_CASE)
    private val ytId = Regex("^[A-Za-z0-9_-]{6,15}$")
    private val tracking = setOf(
        "igshid", "igsh", "fbclid", "gclid", "si", "feature", "is_from_webapp", "sender_device", "sender_web_id",
        "_t", "_r", "share_app_id", "share_link_id", "share_item_id", "u_code", "timestamp", "user_id",
        "sec_user_id", "mc_cid", "mc_eid", "ref", "ref_src", "ref_url"
    )

    fun extractUrls(text: String): List<String> =
        urlRe.findAll(text).map { it.value.trimEnd('.', ',', ')', ']', '!', '?', ';', ':') }.toList()

    fun stripUrls(text: String): String =
        urlRe.replace(text, " ").replace(Regex("\\s+"), " ").trim()

    private fun queryOf(raw: String?): List<Pair<String, String>> {
        if (raw.isNullOrEmpty()) return emptyList()
        return raw.split('&').filter { it.isNotEmpty() }.map { kv ->
            val i = kv.indexOf('=')
            if (i < 0) kv to "" else kv.substring(0, i) to kv.substring(i + 1)
        }
    }

    /** null — это не http(s)-ссылка. */
    fun parse(raw: String): LinkInfo? {
        val u = try { URI(raw.trim()) } catch (_: Exception) { return null }
        val scheme = (u.scheme ?: return null).lowercase(Locale.ROOT)
        if (scheme != "http" && scheme != "https") return null
        var host = (u.host ?: return null).lowercase(Locale.ROOT)
        if (host.startsWith("www.")) host = host.substring(4)
        val segs = (u.rawPath ?: "").split('/').filter { it.isNotEmpty() }
        val q = queryOf(u.rawQuery)
        return when {
            host == "tiktok.com" || host.endsWith(".tiktok.com") -> tiktok(host, segs)
            host == "t.me" || host == "telegram.me" || host == "telegram.dog" -> telegram(segs)
            host == "youtu.be" || host == "youtube.com" || host.endsWith(".youtube.com") -> youtube(host, segs, q)
            host == "instagram.com" || host.endsWith(".instagram.com") || host == "instagr.am" -> instagram(segs)
            else -> web(scheme, host, u.rawPath ?: "", q)
        }
    }

    private fun tiktok(host: String, segs: List<String>): LinkInfo {
        val vi = segs.indexOf("video").takeIf { it >= 0 } ?: segs.indexOf("photo").takeIf { it >= 0 }
        if (vi != null && vi >= 1 && vi + 1 < segs.size && segs[vi - 1].startsWith("@") && segs[vi + 1].all { it.isDigit() }) {
            val user = segs[vi - 1]
            val id = segs[vi + 1]
            return LinkInfo("tiktok", "https://www.tiktok.com/$user/${segs[vi]}/$id", "tiktok:$id", id, user)
        }
        if (segs.size == 1 && segs[0].startsWith("@")) {
            return LinkInfo("tiktok", "https://www.tiktok.com/${segs[0]}", "tiktok-user:${segs[0].lowercase(Locale.ROOT)}", "", segs[0], false)
        }
        // короткие ссылки (vm./vt./…/t/xxx): без сети настоящий идентификатор неизвестен
        val path = segs.joinToString("/")
        return LinkInfo("tiktok", "https://$host/$path", "tiktok-short:$host/$path", "", "", true)
    }

    private fun telegram(segs0: List<String>): LinkInfo {
        var segs = segs0
        if (segs.size >= 2 && segs[0] == "s") segs = segs.drop(1)
        if (segs.size >= 3 && segs[0] == "c" && segs[1].all { it.isDigit() } && segs[2].all { it.isDigit() }) {
            return LinkInfo("telegram", "https://t.me/c/${segs[1]}/${segs[2]}", "tg:c/${segs[1]}/${segs[2]}", segs[2], "")
        }
        if (segs.size >= 2 && segs[1].all { it.isDigit() }) {
            val ch = segs[0]
            return LinkInfo("telegram", "https://t.me/$ch/${segs[1]}", "tg:${ch.lowercase(Locale.ROOT)}/${segs[1]}", segs[1], "@$ch")
        }
        if (segs.size == 1 && !segs[0].startsWith("+")) {
            return LinkInfo("telegram", "https://t.me/${segs[0]}", "tg-chan:${segs[0].lowercase(Locale.ROOT)}", "", "@${segs[0]}", false)
        }
        val p = segs.joinToString("/")
        return LinkInfo("telegram", "https://t.me/$p", "tg-path:${p.lowercase(Locale.ROOT)}", "", "", false)
    }

    private fun youtube(host: String, segs: List<String>, q: List<Pair<String, String>>): LinkInfo {
        var id = ""
        var shorts = false
        if (host == "youtu.be") {
            id = segs.firstOrNull() ?: ""
        } else {
            when (segs.firstOrNull()) {
                "shorts" -> { id = segs.getOrNull(1) ?: ""; shorts = true }
                "embed", "live", "v" -> id = segs.getOrNull(1) ?: ""
                "watch" -> id = q.firstOrNull { it.first == "v" }?.second ?: ""
            }
        }
        if (!ytId.matches(id)) {
            val p = segs.joinToString("/")
            return LinkInfo("youtube", "https://www.youtube.com/$p", "yt-path:${p.lowercase(Locale.ROOT)}", "", "", false)
        }
        val canon = if (shorts) "https://www.youtube.com/shorts/$id" else "https://www.youtube.com/watch?v=$id"
        return LinkInfo("youtube", canon, "yt:$id", id, "")
    }

    private fun instagram(segs: List<String>): LinkInfo {
        val t = segs.firstOrNull()
        if ((t == "reel" || t == "reels" || t == "p" || t == "tv") && segs.size >= 2) {
            val kind = if (t == "reels") "reel" else t
            return LinkInfo("instagram", "https://www.instagram.com/$kind/${segs[1]}/", "ig:${segs[1]}", segs[1], "")
        }
        val p = segs.joinToString("/")
        return LinkInfo("instagram", "https://www.instagram.com/$p/", "ig-path:${p.lowercase(Locale.ROOT)}", "", "", false)
    }

    private fun web(scheme: String, host: String, path: String, q: List<Pair<String, String>>): LinkInfo {
        val keep = q.filter { (k, _) -> !k.startsWith("utm_") && k.lowercase(Locale.ROOT) !in tracking }
        val qs = if (keep.isEmpty()) "" else "?" + keep.joinToString("&") { (k, v) -> if (v.isEmpty()) k else "$k=$v" }
        val canon = "$scheme://$host${path.trimEnd('/')}$qs"
        return LinkInfo("web", canon, "web:" + canon.lowercase(Locale.ROOT), "", "")
    }
}

/** Темы ролика берутся только из текста, который у него реально есть (хэштеги, подпись). */
object MhTags {
    private val tagRe = Regex("#([\\p{L}\\d_]{2,})")
    private val wordRe = Regex("\\p{L}{5,}")
    private val junk = setOf(
        "fyp", "foryou", "foryoupage", "fy", "viral", "tiktok", "trending", "reels", "reel", "shorts", "short",
        "рекомендации", "рекомендация", "рек", "тикток", "тренды", "тренд", "вирусное", "хочуврек", "хочувтоп"
    )
    private val stop = setOf(
        "после", "который", "которые", "которая", "также", "только", "этого", "когда", "более", "между", "через", "будет",
        "может", "своих", "почему", "очень", "чтобы", "пока", "если", "смотрите", "посмотрите", "видео", "ролик",
        "check", "video", "watch", "about", "their", "there", "which", "would", "could"
    )

    fun of(text: String, max: Int = 6): List<String> {
        val clean = LinkNorm.stripUrls(text)
        val out = LinkedHashSet<String>()
        for (m in tagRe.findAll(clean)) {
            val t = m.groupValues[1].lowercase(Locale.ROOT)
            if (t !in junk) out.add(t)
            if (out.size >= max) return out.toList()
        }
        if (out.isEmpty() && clean.length >= 20) {
            // подписи без хэштегов: самые частые содержательные слова (по основе из 6 букв)
            val cnt = LinkedHashMap<String, Int>()
            for (m in wordRe.findAll(clean.lowercase(Locale.ROOT))) {
                val w = m.value
                if (w in stop || w in junk) continue
                val stem = w.take(6)
                cnt[stem] = (cnt[stem] ?: 0) + 1
            }
            cnt.entries.sortedByDescending { it.value }.take(3).forEach { out.add(it.key) }
        }
        return out.toList()
    }
}

/** Разбор OpenGraph-тегов страницы (только метаданные, без загрузки медиа). */
object Og {
    private val metaRe = Regex("<meta\\s+[^>]*>", RegexOption.IGNORE_CASE)

    private fun attr(tag: String, name: String): String? {
        val m = Regex("""\b$name\s*=\s*("([^"]*)"|'([^']*)')""", RegexOption.IGNORE_CASE).find(tag) ?: return null
        return m.groups[2]?.value ?: m.groups[3]?.value
    }

    fun parse(html: String): Map<String, String> {
        val out = HashMap<String, String>()
        for (m in metaRe.findAll(html)) {
            val tag = m.value
            val key = (attr(tag, "property") ?: attr(tag, "name") ?: continue).lowercase(Locale.ROOT)
            val v = attr(tag, "content") ?: continue
            if (key.startsWith("og:") || key == "description") out.putIfAbsent(key, unescape(v).trim())
        }
        return out
    }

    fun unescape(s: String): String {
        var r = s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")
        r = Regex("&#x([0-9a-fA-F]{1,6});").replace(r) { mr -> cp(mr.groupValues[1].toInt(16), mr.value) }
        r = Regex("&#(\\d{1,7});").replace(r) { mr -> cp(mr.groupValues[1].toInt(), mr.value) }
        return r
    }

    private fun cp(c: Int, orig: String): String =
        if (c in 1..0x10FFFF && c !in 0xD800..0xDFFF) String(Character.toChars(c)) else orig
}
