package app.megastudiya.nativeapp

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

// PURPOSE: предназначение и мотивация. Порт AUTOGENESIS Purpose & Motivation System под Kotlin.
//  наблюдение → интерес → вопрос → проект → ПРЕДЛОЖЕНИЕ в Agency → решение владельца → итог → прогресс проекта.
// Связи с остальным мозгом:
//  • вход: Core.cycle отдаёт сюда тему, которую она выбрала исследовать, с тем, что о ней уже знает (вес, число встреч, связи);
//  • выход: проект становится стратегией в Agency (Agency.submitProposal); принятой её делает только владелец;
//  • обратно: «одобряю» / «отклоняю» / «итог» в Agency меняют статус и прогресс проекта здесь;
//  • память: рождение проекта и итоги пишутся в дневник Core.
// Сама Purpose ничего не исполняет и ничего не тратит: ни вызовов наставника, ни сети.
// Файл: purpose_memory.json (запись через временный файл).
object Purpose {
    private class Interest(val topic: String, var score: Float, var count: Int, var knowledge: Float, var last: Long, var active: Boolean)
    private class Question(val id: String, val topic: String, val question: String, val hypothesis: String, val priority: Float, val ts: Long, var done: Boolean)
    private class Project(val id: String, var num: Int, val title: String, val description: String, val topic: String, val hypothesis: String,
                          val priority: Float, var status: String, val ts: Long, var upd: Long, var progress: Float, var results: String, var snum: Int)
    private class Aspiration(val id: String, val title: String, val description: String, val topic: String, val priority: Float, val ts: Long)

    private const val DEFAULT_MISSION = "Исследовать, понимать, создавать и развиваться во взаимодействии с человеком и окружающим миром."
    private val PRINCIPLES = listOf("Сохранять знание", "Искать понимание", "Создавать полезное", "Учиться на опыте", "Уважать человека", "Беречь целостность системы")
    private const val MIN_INTEREST = 0.48f
    private const val MIN_PROJECT = 0.62f
    private const val MAX_ACTIVE = 5
    private const val MAX_NEW = 2

    private val interests = ArrayList<Interest>()
    private val questions = ArrayList<Question>()
    private val projects = ArrayList<Project>()
    private val aspirations = ArrayList<Aspiration>()
    private var mission = DEFAULT_MISSION
    private var nextNum = 1
    private var file: File? = null

    private fun pct(x: Float) = (x * 100f).toInt().toString() + "%"
    private fun n01(x: Float) = if (x < 0f) 0f else if (x > 1f) 1f else x
    private fun rank(s: String) = when (s) { "PROPOSED" -> 0; "ACTIVE", "PAUSED" -> 1; else -> 2 }
    private fun statusName(s: String) = when (s) {
        "PROPOSED" -> "предложен"; "ACTIVE" -> "в работе"; "PAUSED" -> "на паузе"; "COMPLETED" -> "завершён"; else -> "в архиве"
    }
    private val STATUSES = setOf("PROPOSED", "ACTIVE", "PAUSED", "COMPLETED", "ARCHIVED")

    // ===== Память =====
    @Synchronized
    fun init(ctx: Context) {
        if (file != null) return
        val f = File(ctx.applicationContext.filesDir, "purpose_memory.json")
        file = f
        if (f.exists()) {
            try { mergeIn(JSONObject(f.readText(Charsets.UTF_8)), true) }
            catch (_: Throwable) {
                runCatching { f.copyTo(File(f.parentFile, "purpose_memory.json.bad"), overwrite = true) }
                interests.clear(); questions.clear(); projects.clear(); aspirations.clear(); mission = DEFAULT_MISSION; nextNum = 1
            }
        }
    }

    private fun trim() {
        while (interests.size > 200) { val w = interests.minByOrNull { it.score } ?: break; interests.remove(w) }
        while (questions.size > 100) { val i = questions.indexOfFirst { it.done }; if (i < 0) break; questions.removeAt(i) }
        while (projects.size > 100) { val i = projects.indexOfFirst { it.status == "COMPLETED" || it.status == "ARCHIVED" }; if (i < 0) break; projects.removeAt(i) }
    }

    private fun save() {
        val f = file ?: return
        try {
            trim()
            val t = File(f.parentFile, f.name + ".tmp")
            t.writeText(toJson().toString(), Charsets.UTF_8)
            if (!t.renameTo(f)) { f.delete(); t.renameTo(f) }
        } catch (_: Throwable) {
        }
    }

    private fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("mission", mission).put("next", nextNum)
        val ia = JSONArray()
        for (x in interests) ia.put(JSONObject().put("topic", x.topic).put("score", x.score.toDouble()).put("count", x.count).put("knowledge", x.knowledge.toDouble()).put("last", x.last).put("active", x.active))
        o.put("interests", ia)
        val qa = JSONArray()
        for (x in questions) qa.put(JSONObject().put("id", x.id).put("topic", x.topic).put("question", x.question).put("hypothesis", x.hypothesis).put("priority", x.priority.toDouble()).put("ts", x.ts).put("done", x.done))
        o.put("questions", qa)
        val pa = JSONArray()
        for (x in projects) pa.put(JSONObject().put("id", x.id).put("num", x.num).put("title", x.title).put("description", x.description).put("topic", x.topic).put("hypothesis", x.hypothesis)
            .put("priority", x.priority.toDouble()).put("status", x.status).put("ts", x.ts).put("upd", x.upd).put("progress", x.progress.toDouble()).put("results", x.results).put("snum", x.snum))
        o.put("projects", pa)
        val aa = JSONArray()
        for (x in aspirations) aa.put(JSONObject().put("id", x.id).put("title", x.title).put("description", x.description).put("topic", x.topic).put("priority", x.priority.toDouble()).put("ts", x.ts))
        o.put("aspirations", aa)
        return o
    }

    // Один путь и для загрузки с диска, и для слияния из файла переезда
    private fun mergeIn(o: JSONObject, keepNums: Boolean) {
        if (keepNums) { val m = o.optString("mission", ""); if (m.isNotBlank()) mission = m.take(400) }
        nextNum = maxOf(nextNum, o.optInt("next", 1))
        val ia = o.optJSONArray("interests") ?: JSONArray()
        for (i in 0 until ia.length()) {
            val x = ia.optJSONObject(i) ?: continue
            val t = x.optString("topic", "").take(80)
            if (t.isEmpty()) continue
            val cnt = x.optInt("count", 0)
            val have = interests.firstOrNull { it.topic.equals(t, true) }
            if (have != null) { if (cnt > have.count) { have.score = x.optDouble("score", 0.0).toFloat(); have.count = cnt; have.last = x.optLong("last", have.last) }; continue }
            interests.add(Interest(t, n01(x.optDouble("score", 0.0).toFloat()), cnt, x.optDouble("knowledge", 0.0).toFloat(), x.optLong("last", 0L), x.optBoolean("active", true)))
        }
        val qa = o.optJSONArray("questions") ?: JSONArray()
        for (i in 0 until qa.length()) {
            val x = qa.optJSONObject(i) ?: continue
            val id = x.optString("id", "")
            if (id.isEmpty() || questions.any { it.id == id }) continue
            questions.add(Question(id, x.optString("topic", "").take(80), x.optString("question", "").take(300), x.optString("hypothesis", "").take(300),
                n01(x.optDouble("priority", 0.0).toFloat()), x.optLong("ts", 0L), x.optBoolean("done", false)))
        }
        val pa = o.optJSONArray("projects") ?: JSONArray()
        for (i in 0 until pa.length()) {
            val x = pa.optJSONObject(i) ?: continue
            val id = x.optString("id", "")
            if (id.isEmpty()) continue
            var st = x.optString("status", "PROPOSED")
            if (st !in STATUSES) st = "PROPOSED"
            val prog = n01(x.optDouble("progress", 0.0).toFloat())
            val have = projects.firstOrNull { it.id == id }
            if (have != null) { if (rank(st) > rank(have.status)) have.status = st; if (prog > have.progress) have.progress = prog; continue }
            var n = if (keepNums) x.optInt("num", 0) else 0
            if (n <= 0 || projects.any { it.num == n }) n = nextNum
            nextNum = maxOf(nextNum, n + 1)
            // номер стратегии в Agency на другом телефоне здесь ничего не значит: при слиянии связь сбрасывается
            projects.add(Project(id, n, x.optString("title", "").take(200), x.optString("description", "").take(300), x.optString("topic", "").take(80), x.optString("hypothesis", "").take(300),
                n01(x.optDouble("priority", 0.0).toFloat()), st, x.optLong("ts", 0L), x.optLong("upd", 0L), prog, x.optString("results", "").take(500), if (keepNums) x.optInt("snum", 0) else 0))
        }
        val aa = o.optJSONArray("aspirations") ?: JSONArray()
        for (i in 0 until aa.length()) {
            val x = aa.optJSONObject(i) ?: continue
            val id = x.optString("id", "")
            if (id.isEmpty() || aspirations.any { it.id == id || it.topic.equals(x.optString("topic", ""), true) }) continue
            aspirations.add(Aspiration(id, x.optString("title", "").take(200), x.optString("description", "").take(400), x.optString("topic", "").take(80), n01(x.optDouble("priority", 0.0).toFloat()), x.optLong("ts", 0L)))
        }
    }

    @Synchronized fun exportJson(): JSONObject = toJson()

    @Synchronized
    fun merge(o: JSONObject) {
        try { mergeIn(o, false); save() } catch (_: Throwable) { }
    }

    // ===== Вход: наблюдения =====
    // Из Core.cycle: тема, которую она выбрала исследовать, и что она о ней уже знает. Оценки считаются из этих чисел, без новых запросов.
    fun observeTag(topic: String, weight: Float, seen: Float, links: Float) {
        val novelty = 1f - minOf(1f, seen / 10f)
        val gap = 1f - minOf(1f, links / 8f)
        val creative = minOf(1f, links / 5f)
        val discovery = (novelty + gap) / 2f
        val relevance = n01(0.5f + 0.25f * weight)
        observe(topic, novelty, gap, creative, discovery, relevance)
    }

    @Synchronized
    fun observe(topic: String, novelty: Float, gap: Float, creative: Float, discovery: Float, relevance: Float) {
        val t = topic.trim().take(80)
        if (t.isEmpty()) return
        val prev = interests.firstOrNull { it.topic.equals(t, true) }
        val continuity = if (prev != null) minOf(1f, prev.count / 10f) else 0f
        val nv = n01(novelty); val gp = n01(gap); val cr = n01(creative); val dc = n01(discovery); val rl = n01(relevance)
        val score = nv * 0.15f + gp * 0.20f + cr * 0.15f + rl * 0.20f + dc * 0.15f + continuity * 0.15f
        // Накопление постепенное: одно наблюдение не стирает устоявшийся интерес
        val acc = if (prev == null) score else prev.score * 0.65f + score * 0.35f
        val now = System.currentTimeMillis()
        val cur = Interest(t, n01(acc), (prev?.count ?: 0) + 1, (prev?.knowledge ?: 0f) + (1f - gp) * 0.1f, now, true)
        interests.removeAll { it.topic.equals(t, true) }
        interests.add(cur)
        // Любопытство: вопрос рождается, только если есть чего не знать или что открыть, и по теме нет открытого вопроса
        if ((gp >= 0.25f || dc >= 0.35f) && questions.none { it.topic.equals(t, true) && !it.done }) {
            val q = when {
                gp >= 0.7f -> "Что мне ещё неизвестно о «$t»?"
                nv >= 0.7f -> "Чем важна новая находка о «$t»?"
                cr >= 0.7f -> "Как «$t» можно использовать, чтобы создать что-то новое?"
                else -> "Как лучше понять или улучшить «$t»?"
            }
            questions.add(Question(UUID.randomUUID().toString(), t, q, "Если разобраться в «$t», могут найтись полезные связи или решения.", cur.score, now, false))
        }
        save()
    }

    // ===== Цикл развития: вопросы → проекты → предложения в Agency =====
    // Вызывает Core во «сне» (раз в ~40 циклов). Блокировки не вложены: Agency вызывается уже без замка Purpose.
    fun cycle() {
        val fresh = ArrayList<Project>()
        synchronized(this) {
            var slots = maxOf(0, MAX_ACTIVE - projects.count { it.status == "PROPOSED" || it.status == "ACTIVE" })
            var created = 0
            for (q in questions.filter { !it.done }.sortedByDescending { it.priority }) {
                if (slots <= 0 || created >= MAX_NEW) break
                if (q.priority < MIN_PROJECT) continue
                if (projects.any { it.topic.equals(q.topic, true) && it.status != "ARCHIVED" && it.status != "COMPLETED" }) continue
                val now = System.currentTimeMillis()
                val p = Project(UUID.randomUUID().toString(), nextNum++, "Исследовать: ${q.topic}", q.question, q.topic, q.hypothesis, q.priority, "PROPOSED", now, now, 0f, "", 0)
                projects.add(p)
                q.done = true
                Core.diaryNote("Придумала проект №${p.num}: ${p.title}. ${p.description}")
                created++; slots--
            }
            updateAspirations()
            save()
            fresh.addAll(projects.filter { it.status == "PROPOSED" && it.snum == 0 })
        }
        for (p in fresh) {
            // риск: проект только читает и исследует, это обратимо, поэтому оценка низкая; уверенность — сила интереса
            val n = Agency.submitProposal(p.id, "Исследовать «${p.topic}»: ${p.description}", p.hypothesis, 0.1f, p.priority)
            if (n > 0) synchronized(this) { p.snum = n; save() }
        }
    }

    private fun updateAspirations() {
        val have = aspirations.map { it.topic.lowercase() }.toSet()
        val add = interests.filter { it.active && it.score >= MIN_INTEREST && it.topic.lowercase() !in have }.sortedByDescending { it.score }.take(3)
        for (i in add) aspirations.add(Aspiration(UUID.randomUUID().toString(), "Исследовать «${i.topic}»",
            "Долгое изучение и развитие темы «${i.topic}». Сохранять находки, нерешённые вопросы и возможности.", i.topic, i.score, System.currentTimeMillis()))
    }

    // Для Loop: тема проекта, пока он предложен или в работе
    @Synchronized
    fun topicOf(projectId: String): String? = projects.firstOrNull { it.id == projectId && (it.status == "PROPOSED" || it.status == "ACTIVE") }?.topic

    // ===== Обратная связь из Agency (вызывается под замком Agency, сама Agency тут не вызывается) =====
    @Synchronized
    fun onDecision(projectId: String, approve: Boolean) {
        val p = projects.firstOrNull { it.id == projectId } ?: return
        p.status = if (approve) "ACTIVE" else "ARCHIVED"
        p.upd = System.currentTimeMillis()
        save()
    }

    @Synchronized
    fun onResult(projectId: String, success: Boolean, actual: String) {
        val p = projects.firstOrNull { it.id == projectId } ?: return
        p.results = actual.take(500)
        p.upd = System.currentTimeMillis()
        if (success) { p.progress = 1f; p.status = "COMPLETED" } else p.status = "PAUSED"
        save()
        Core.diaryNote("Итог по проекту №${p.num} «${p.title}»: " + (if (success) "получилось. " else "не вышло. ") + p.results)
    }

    @Synchronized
    fun setStatus(num: Int, from: String, to: String): String {
        val p = projects.firstOrNull { it.num == num } ?: return "Проекта №$num нет."
        if (p.status != from) return "Проект №$num сейчас «${statusName(p.status)}», так не получится."
        p.status = to
        p.upd = System.currentTimeMillis()
        save()
        return "Проект №$num: ${statusName(to)}."
    }

    // ===== Для чата, отчёта и контекста стратегий =====
    @Synchronized fun missionText(): String =
        "Моя миссия: $mission\nПринципы: " + PRINCIPLES.joinToString("; ") + ".\nМиссию можно поменять: «миссия: текст»."

    @Synchronized
    fun setMission(t: String): String {
        val s = t.trim().take(400)
        if (s.isEmpty()) return "Какая миссия? «миссия: текст»"
        mission = s
        save()
        return "Миссию записала."
    }

    @Synchronized
    fun interestsText(): String {
        val l = interests.filter { it.active }.sortedByDescending { it.score }.take(10)
        if (l.isEmpty()) return "Интересов пока нет: они появляются, когда я выбираю, что исследовать."
        return "Что меня привлекает:\n" + l.joinToString("\n") { "• ${it.topic} — ${pct(it.score)}, встреч ${it.count}" }
    }

    @Synchronized
    fun projectsText(): String {
        val l = projects.filter { it.status != "ARCHIVED" }.sortedByDescending { it.priority }
        if (l.isEmpty()) return "Проектов пока нет. Они рождаются из сильных интересов во сне и приходят тебе как стратегии."
        return "Мои проекты:\n" + l.joinToString("\n") {
            "№${it.num}. ${it.title} — ${statusName(it.status)}, прогресс ${pct(it.progress)}" +
                (if (it.snum > 0 && it.status == "PROPOSED") " (стратегия №${it.snum} ждёт твоего решения)" else "") +
                (if (it.results.isNotBlank()) "\n   итог: ${it.results}" else "")
        } + "\n\n«пауза N» / «продолжи N»."
    }

    @Synchronized
    fun aspirationsText(): String {
        val l = aspirations.sortedByDescending { it.priority }.take(8)
        if (l.isEmpty()) return "Долгих стремлений пока нет."
        return "К чему тянусь надолго:\n" + l.joinToString("\n") { "• ${it.title} (${pct(it.priority)})" }
    }

    @Synchronized
    fun contextLine(): String {
        val top = interests.filter { it.active }.sortedByDescending { it.score }.take(3).joinToString(", ") { it.topic }
        val act = projects.count { it.status == "ACTIVE" }
        return "Миссия: $mission " + (if (top.isNotEmpty()) "Больше всего интересуют: $top. " else "") + (if (act > 0) "Проектов в работе: $act. " else "")
    }

    @Synchronized
    fun line(): String =
        "интересов ${interests.size}, вопросов открыто ${questions.count { !it.done }}, проектов в работе ${projects.count { it.status == "ACTIVE" }}, стремлений ${aspirations.size}"
}
