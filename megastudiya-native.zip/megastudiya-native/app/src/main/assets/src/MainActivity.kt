package app.megastudiya.nativeapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.derivedStateOf
import androidx.compose.ui.graphics.lerp as colorLerp
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import android.graphics.RenderEffect as AndroidRenderEffect
import android.graphics.ColorMatrix as AndroidColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Rect
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.ui.graphics.drawscope.clipRect
import kotlinx.coroutines.delay
import androidx.compose.ui.graphics.layer.*
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.runtime.DisposableEffect
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.ui.draw.blur
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.activity.compose.BackHandler
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import android.os.SystemClock
import androidx.compose.ui.unit.sp
import androidx.compose.animation.animateContentSize
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.runtime.withFrameNanos

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Разрешаем приложению рисовать в верхней области выреза дисплея.
        // На HONOR X7d это нужно, чтобы капсула могла визуально обрамлять центральную камеру,
        // а не начиналась ниже системной строки состояния.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        Store.load(this)
        Core.start(this)
        CoreJob.schedule(this)
        takeShared(intent)
        Place.load(this)
        News.load(this)
        Snd.init(this)
        Hap.init(this)
        WxFx.init(this)
        ConnectorSetup.init(this)
        ConnectorSetup.handleRedirect(this, intent?.data)
        Thread { Img.trim(applicationContext) }.start()
        setHighRefresh()
        setContent {
            val ff = FontFamily(Font(R.font.msans_regular, FontWeight.Normal), Font(R.font.msans_bold, FontWeight.Bold), Font(R.font.msans_bold, FontWeight.ExtraBold), Font(R.font.msans_bold, FontWeight.SemiBold))
            androidx.compose.runtime.CompositionLocalProvider(
                androidx.compose.material3.LocalTextStyle provides androidx.compose.ui.text.TextStyle(fontFamily = ff, color = Color(0xFFE9ECF2))
            ) { MegaApp() }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        takeShared(intent)
        ConnectorSetup.handleRedirect(this, intent.data)
    }

    // «Поделиться → МЕГАСТУДИЯ» из любого приложения (Instagram, браузер, Telegram): текст или ссылка ложатся личным постом
    private fun takeShared(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        i.action = Intent.ACTION_MAIN // чтобы поворот экрана не сохранил второй раз
        val txt = i.getStringExtra(Intent.EXTRA_TEXT)?.trim().orEmpty()
        if (txt.isEmpty()) return
        val old = Store.draft
        Store.setDraft(this, txt)
        Store.publish(this, false)
        Store.setDraft(this, old)
        android.widget.Toast.makeText(this, "Сохранено в МЕГАСТУДИЮ", android.widget.Toast.LENGTH_SHORT).show()
    }

    override fun onPause() {
        super.onPause()
        Perf.save(this)
        MediaHub.flush()
        Core.setActive(false)
        Link.pause()
        EarthGate.view?.onPause()
    }

    override fun onResume() {
        super.onResume()
        Core.setActive(true)
        Link.resume(this)
        ConnectorSetup.onAppStart(this)
        EarthGate.view?.onResume()
    }

    // просим у системы максимальную частоту экрана (90/120 Гц, если есть)
    private fun setHighRefresh() {
        try {
            @Suppress("DEPRECATION")
            val d = windowManager.defaultDisplay
            val best = d.supportedModes.maxByOrNull { it.refreshRate } ?: return
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            window.attributes = lp
        } catch (_: Throwable) {
        }
    }
}

private val Bg = Color(0xFF0B0D12)
private val Pill = RoundedCornerShape(999.dp)
private val Line = Color.White.copy(alpha = 0.14f)
private val Muted = Color(0xFF8B93A5)
private val Acc = Color(0xFF6EA8FF)

// «Жидкое стекло» как в финальном стиле v99 (body .glass::before): тёмная диагональная заливка
// rgba(14,19,34,.46)→rgba(8,11,22,.34), светлая верхняя кромка .22 и тонкое кольцо .05 по контуру.
// Без размытия фона (Земля — GLSurfaceView, её нельзя размыть изнутри Compose), поэтому дёшево.
private val GlassFill = Brush.linearGradient(listOf(Color(0x750E1322), Color(0x570B1016)))
private val GlassRim = Brush.verticalGradient(0f to Color.White.copy(alpha = 0.22f), 0.3f to Color.White.copy(alpha = 0.05f), 1f to Color.White.copy(alpha = 0.05f))
// Карточки ленты плотнее (dense), чтобы Земля не просвечивала сквозь текст; док и пилюля остаются как в v99.
private val GlassFillDense = Brush.linearGradient(listOf(Color(0xB80E1322), Color(0x9E0B1016)))
private fun Modifier.glass(shape: androidx.compose.ui.graphics.Shape, dense: Boolean = false): Modifier = this
    .clip(shape)
    .background(if (dense) GlassFillDense else GlassFill)
    .border(1.dp, GlassRim, shape)
// ===== Liquid Glass (v99): док и верхняя пилюля преломляют и размывают то, что под ними =====
// Сцена (небо, погода, лента) пишется в один слой; стекло рисует его копию с размытием, насыщенностью
// и (Android 13+) линзовым искажением у краёв, как SVG-карта смещения в v99. Ниже Android 12 — обычное стекло.
val LocalScene = compositionLocalOf<SceneRec?> { null }

// Сцена пишется прямо в RenderNode: холст на время записи подменяется на холст узла, drawContent() рисует туда же.
// Слой GraphicsLayer в Compose 1.7 оставался пустым (проверено на телефоне: пиксель #0), поэтому берём платформенный узел.
class SceneRec { val node = android.graphics.RenderNode("scene"); @Volatile var ok = false }

fun androidx.compose.ui.graphics.drawscope.ContentDrawScope.recordScene(rec: SceneRec) {
    if (Build.VERSION.SDK_INT < 29) { drawContent(); return }
    val w = size.width.toInt().coerceAtLeast(1)
    val h = size.height.toInt().coerceAtLeast(1)
    val node = rec.node
    node.setPosition(0, 0, w, h)
    val rc = node.beginRecording(w, h)
    val old = drawContext.canvas
    drawContext.canvas = androidx.compose.ui.graphics.Canvas(rc)
    try { drawContent() } finally { drawContext.canvas = old; node.endRecording() }
    rec.ok = true
    drawIntoCanvas { runCatching { it.nativeCanvas.drawRenderNode(node) } }
}

fun androidx.compose.ui.graphics.drawscope.DrawScope.drawScene(rec: SceneRec) {
    if (Build.VERSION.SDK_INT >= 29) drawIntoCanvas { runCatching { it.nativeCanvas.drawRenderNode(rec.node) } }
}
// Тонировка дока и верхней пилюли: тёмная, как в v99. Без размытия (Android ниже 12) заливка плотнее, чтобы лента не просвечивала резким текстом.
// Shared Obsidian Glass: keep the photographed scene visible only as a restrained
// refraction, never as a bright/washed-out window behind the black camera aperture.
private val GlassLiquidFill = Brush.linearGradient(
    listOf(Color(0xE811141D), Color(0xE0080B12), Color(0xE611151E))
)
private val DockFillPlain = Brush.linearGradient(listOf(Color(0xF20A0D14), Color(0xF00A0D14)))
// Near-black reflected rim; no pale silver outline around the camera.
private val GlassRimLiquid = Brush.linearGradient(
    listOf(Color(0x24FFFFFF), Color(0x0CFFFFFF), Color(0x08FFFFFF), Color(0x1CFFFFFF))
)
private const val LIQUID_BLUR = true // Liquid Glass из v99: размытие 1.5px + насыщенность 1.8 + линза у краёв
private const val LIQUID_AGSL = """
uniform shader content;
uniform float2 size;
uniform float bw;
uniform float amt;
half4 main(float2 p) {
    float2 c = size * 0.5;
    float r = min(size.x, size.y) * 0.5;
    float2 q = abs(p - c) - (c - float2(r));
    float ln = length(max(q, 0.0));
    float dep = -(ln + min(max(q.x, q.y), 0.0) - r);
    if (dep < 0.0 || dep >= bw) return content.eval(p);
    float2 s = sign(p - c);
    float2 g;
    if (ln > 0.0) g = s * max(q, 0.0) / ln;
    else if (q.x > q.y) g = float2(s.x, 0.0);
    else g = float2(0.0, s.y);
    float t = 1.0 - dep / bw;
    return content.eval(p - g * (t * t) * amt);
}
"""

// Параметры как в v99: край-линза шириной min(20, h/2) px, смещение до 17 px (scale 34), blur(1.5px) saturate(1.8).
// Сначала слой размытия+насыщенности (работает с Android 12), затем отдельно линза AGSL (Android 13+);
// если шейдер не создался, остаётся размытие, а не пустота.
@RequiresApi(31)
private fun makeLiquidEffect(w: Float, h: Float, d: Float): androidx.compose.ui.graphics.RenderEffect {
    val blur = AndroidRenderEffect.createBlurEffect(5f * d, 5f * d, Shader.TileMode.CLAMP)
    val sat = AndroidColorMatrix().apply { setSaturation(1.8f) }
    val satFx = AndroidRenderEffect.createColorFilterEffect(ColorMatrixColorFilter(sat), blur)
    var fx: android.graphics.RenderEffect = satFx
    if (Build.VERSION.SDK_INT >= 33) {
        try {
            val sh = RuntimeShader(LIQUID_AGSL)
            sh.setFloatUniform("size", w, h)
            sh.setFloatUniform("bw", minOf(20f * d, h / 2f))
            sh.setFloatUniform("amt", 22f * d)
            fx = AndroidRenderEffect.createChainEffect(AndroidRenderEffect.createRuntimeShaderEffect(sh, "content"), satFx)
            GlassInfo.lens = true
        } catch (e: Throwable) { GlassInfo.lens = false }
    }
    GlassInfo.made++
    return fx.asComposeRenderEffect()
}

object GlassInfo { @Volatile var lens = false; @Volatile var drawn = 0; @Volatile var made = 0 }

// Стеклянная поверхность: снизу слой с копией сцены (размытие + линза), поверх тонировка и рамка, сверху содержимое.
// Эффект висит на отдельном слое-соседе, поэтому иконки и текст не размываются.
@Composable
private fun LiquidSurface(
    shape: androidx.compose.ui.graphics.Shape,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val scene = LocalScene.current
    if (!LIQUID_BLUR || scene == null || Build.VERSION.SDK_INT < 31) {
        Box(
            modifier.clip(shape).graphicsLayer { this.shape = shape; clip = true }
                .background(DockFillPlain).border(1.dp, GlassRim, shape),
            content = content
        )
        return
    }
    val dens = LocalDensity.current.density
    var origin by remember { mutableStateOf(Offset.Zero) }
    var sz by remember { mutableStateOf(IntSize.Zero) }
    val effect = remember(sz) {
        if (Build.VERSION.SDK_INT >= 31 && sz.width > 0) makeLiquidEffect(sz.width.toFloat(), sz.height.toFloat(), dens) else null
    }
    Box(
        modifier.clip(shape).graphicsLayer { this.shape = shape; clip = true }
            .onGloballyPositioned { origin = it.positionInRoot() }.onSizeChanged { sz = it }
    ) {
        Box(
            Modifier.matchParentSize().graphicsLayer { clip = true; this.shape = shape; renderEffect = effect }
                .drawBehind { translate(-origin.x, -origin.y) { drawScene(scene) }; GlassInfo.drawn++ }
        )
        Box(Modifier.matchParentSize().clip(shape).background(GlassLiquidFill))
        // Тонкий внутренний блик связывает верхнюю капсулу и нижний Dock одним материалом.
        Box(
            Modifier.matchParentSize().clip(shape)
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.075f), Color.Transparent, Color.White.copy(alpha = 0.018f))))
                .border(1.dp, GlassRimLiquid, shape)
        )
        content()
    }
}

// Диагностика стекла: три способа на ярком фоне. Видно сразу, какой из них даёт размытие и преломление на этом телефоне.
@Composable
fun GlassTest(onClose: () -> Unit) {
    BackHandler { onClose() }
    val scene = remember { SceneRec() }
    val d = LocalDensity.current.density
    val shape = RoundedCornerShape(40.dp)
    Box(Modifier.fillMaxSize().background(Color.Black).clickable { onClose() }) {
        Box(
            Modifier.fillMaxSize().drawWithContent {
                recordScene(scene)
            }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                for (i in 0 until 14) drawRect(Color.hsv(i * 25f, 0.8f, 1f), Offset(i * w / 14f, 0f), androidx.compose.ui.geometry.Size(w / 14f + 1f, size.height))
                for (i in 0 until 12) drawCircle(Color.White, 10f * d, Offset(w * 0.12f + (i % 4) * w * 0.25f, size.height * (0.18f + (i / 4) * 0.3f)))
            }
        }
        CompositionLocalProvider(LocalScene provides scene) {
            Column(Modifier.align(Alignment.Center), verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                LiquidSurface(shape, Modifier.size(240.dp, 50.dp)) { Box(Modifier.matchParentSize(), contentAlignment = Alignment.Center) { Text("A", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) } }
                GlassVariant(shape, true, "B")
                GlassVariant(shape, false, "C")
                GlassControl(shape)
                GlassVariant(shape, false, "E: копия x1.6", zoom = true)
                GlassPlain(shape, scene)
                Text("Нажми, чтобы закрыть", color = Color.White, fontSize = 14.sp)
            }
        }
    }
}

// B: размытие и линза вешаются модификатором на сам слой; C: то же, но только размытие
@Composable
private fun GlassVariant(sh: androidx.compose.ui.graphics.Shape, lens: Boolean, label: String, zoom: Boolean = false) {
    val scene = LocalScene.current ?: return
    val d = LocalDensity.current.density
    var origin by remember { mutableStateOf(Offset.Zero) }
    var sz by remember { mutableStateOf(IntSize.Zero) }
    val fx = remember(sz, lens) {
        if (Build.VERSION.SDK_INT >= 31 && sz.width > 0) {
            if (lens) makeLiquidEffect(sz.width.toFloat(), sz.height.toFloat(), d)
            else AndroidRenderEffect.createBlurEffect(8f * d, 8f * d, Shader.TileMode.CLAMP).asComposeRenderEffect()
        } else null
    }
    Box(Modifier.size(240.dp, 50.dp).onGloballyPositioned { origin = it.positionInRoot() }.onSizeChanged { sz = it }) {
        Box(
            Modifier.matchParentSize().graphicsLayer { clip = true; shape = sh; renderEffect = if (zoom) null else fx }
                .drawBehind {
                    translate(-origin.x, -origin.y) {
                        if (zoom) scale(1.6f, Offset(origin.x + size.width / 2f, origin.y + size.height / 2f)) { drawScene(scene) }
                        else drawScene(scene)
                    }
                }
        )
        Box(Modifier.matchParentSize().clip(sh).background(GlassLiquidFill).border(1.dp, GlassRim, sh), contentAlignment = Alignment.Center) {
            Text(label, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// F: самый простой вариант: без вложенного слоя и эффектов, копия сцены x1.6 прямо в drawBehind под обрезкой
@Composable
private fun GlassPlain(sh: androidx.compose.ui.graphics.Shape, scene: SceneRec) {
    var origin by remember { mutableStateOf(Offset.Zero) }
    Box(
        Modifier.size(240.dp, 50.dp).onGloballyPositioned { origin = it.positionInRoot() }.clip(sh)
            .drawBehind {
                translate(-origin.x, -origin.y) {
                    scale(1.6f, Offset(origin.x + size.width / 2f, origin.y + size.height / 2f)) { drawScene(scene) }
                }
            },
        contentAlignment = Alignment.Center
    ) { Text("F: простая копия x1.6", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
}

// D: контроль без сцены: свои полоски, левая половина резкая, правая размыта обычным Modifier.blur. Если и тут нет размытия, RenderEffect на этом телефоне не работает.
@Composable
private fun GlassControl(sh: androidx.compose.ui.graphics.Shape) {
    Box(Modifier.size(240.dp, 50.dp).clip(sh)) {
        Row(Modifier.matchParentSize()) {
            for (half in 0..1) {
                Box(Modifier.weight(1f).fillMaxHeight().then(if (half == 1) Modifier.blur(8.dp) else Modifier)) {
                    Canvas(Modifier.fillMaxSize()) {
                        for (i in 0 until 6) drawRect(Color.hsv(i * 60f, 0.8f, 1f), Offset(i * size.width / 6f, 0f), androidx.compose.ui.geometry.Size(size.width / 6f + 1f, size.height))
                    }
                }
            }
        }
        Text("D: блюр справа", color = Color.White, fontSize = 12.sp, modifier = Modifier.align(Alignment.Center))
    }
}

private val fmt = SimpleDateFormat("d MMM, HH:mm", Locale("ru"))

@Composable
fun MegaApp() {
    var tab by remember { mutableIntStateOf(0) }
    var intro by remember { mutableStateOf(!IntroGate.shown) }
    var appOn by remember { mutableStateOf(IntroGate.shown) }
    var zen by remember { mutableStateOf(false) }
    var compose by remember { mutableStateOf(false) }
    var breathe by remember { mutableStateOf(false) }
    LaunchedEffect(zen) { EarthGate.contemplate = zen }
    val haptic = LocalHapticFeedback.current
    // у каждого раздела своя прокрутка: «наверх» в закладках не трогает «Сатурн» и наоборот
    val feed0 = rememberLazyListState()
    val feed1 = rememberLazyListState()
    val feedState = if (tab == 1) feed1 else feed0
    val ctx = LocalContext.current
    val scene = remember { SceneRec() }
    val scope = rememberCoroutineScope()
    val ps = remember { PullState() }
    // Состояние жеста вынесено из NestedScrollConnection: оно гарантированно сбрасывается
    // при смене вкладки/режима и не остаётся захваченным старым экземпляром обработчика.
    val rawPullPx = remember { mutableFloatStateOf(0f) }
    // Порог задаётся в dp и переводится в px текущей плотностью экрана.
    // 104 dp — достижимый жест, но достаточно длинный, чтобы не путать его с обычной прокруткой.
    val pullThresholdPx = with(LocalDensity.current) { 104.dp.toPx() }
    val pullOnState = rememberUpdatedState(!zen && tab <= 1)
    val conn = remember(pullThresholdPx) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                // Если пользователь передумал и ведёт палец вверх, сначала схлопываем pull-индикатор.
                if (pullOnState.value && rawPullPx.floatValue > 0f && available.y < 0f && !ps.spin) {
                    val consumedY = -minOf(rawPullPx.floatValue, -available.y)
                    rawPullPx.floatValue = (rawPullPx.floatValue + consumedY).coerceAtLeast(0f)
                    ps.p = (rawPullPx.floatValue / pullThresholdPx).coerceIn(0f, 1f)
                    return Offset(0f, consumedY)
                }
                return Offset.Zero
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                // Берём только неиспользованный дочерним LazyColumn delta: он появляется,
                // когда лента уже дошла до самого верха. Поэтому жест не крадёт обычный скролл.
                if (pullOnState.value && !ps.spin && source == NestedScrollSource.UserInput && available.y > 0f) {
                    rawPullPx.floatValue += available.y
                    ps.p = (rawPullPx.floatValue / pullThresholdPx).coerceIn(0f, 1f)
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                val shouldRefresh = rawPullPx.floatValue >= pullThresholdPx && pullOnState.value && !ps.spin
                rawPullPx.floatValue = 0f
                if (shouldRefresh) {
                    ps.p = 1f
                    ps.spin = true
                    scope.launch {
                        try {
                            // Запускаем обе операции и держим состояние загрузки до их завершения.
                            runCatching { News.refresh(ctx, true) }
                            runCatching { Place.loadWx(ctx) }
                        } finally {
                            ps.spin = false
                            ps.p = 0f
                        }
                    }
                } else {
                    ps.p = 0f
                }
                // Если обновление запущено, забираем остаточную скорость, чтобы лента
                // не продолжала инерционное движение под индикатором загрузки.
                return if (shouldRefresh) available else Velocity.Zero
            }
        }
    }
    // При смене раздела или входе в Space незавершённый pull не должен переноситься дальше.
    LaunchedEffect(tab, zen) {
        rawPullPx.floatValue = 0f
        ps.p = 0f
        // Уже запущенное обновление не отменяем при смене вкладки: его coroutine
        // сама завершит spinner в finally, без риска запустить второе обновление.
    }
    LaunchedEffect(feedState) {
        snapshotFlow { feedState.isScrollInProgress }.collect { sc ->
            EarthGate.scrolling = sc
            if (!sc) EarthGate.scrollEnd = SystemClock.uptimeMillis()
        }
    }
    Box(
        Modifier.fillMaxSize().pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val e = awaitPointerEvent(PointerEventPass.Initial)
                    val down = e.changes.any { it.pressed }
                    EarthGate.touching = down
                    if (!down) EarthGate.scrollEnd = SystemClock.uptimeMillis()
                }
            }
        }
    ) {
        if (appOn) {
        // Земля только в режиме созерцания; на главной её нет (экономит ~60 мс на кадр)
        if (zen) AndroidView(factory = { c -> EarthGLView(c).also { EarthGate.view = it } }, modifier = Modifier.fillMaxSize())
        Box(
            Modifier.fillMaxSize()
                .drawWithContent {
                    if (LIQUID_BLUR && Build.VERSION.SDK_INT >= 31) {
                        recordScene(scene)
                    } else drawContent()
                }
                .background(if (zen) Color.Transparent else Bg)
        ) {
        if (!zen) { Sky(); WeatherSky(); Galaxy(Store.posts.size) }
        // Лента всегда живая в памяти (не пересобирается при переключении), скрытая просто не размещается.
        Box(
            Modifier.fillMaxSize().nestedScroll(conn).graphicsLayer { alpha = if (zen) 0f else 1f }.layout { m, c ->
                if (tab <= 1) {
                    val pl = m.measure(c)
                    layout(pl.width, pl.height) { pl.placeRelative(0, 0) }
                } else {
                    layout(c.maxWidth, c.maxHeight) { }
                }
            }
        ) { Feed(feedState, tab) { compose = true } }
        if (!zen && tab == 2) MeScreen { breathe = true }
        if (!zen && tab == 3) VideoScreen()
        }
        CompositionLocalProvider(LocalScene provides scene) {
        if (!zen) TopPill(Modifier.align(Alignment.TopCenter), ps) { zen = true }
        if (!zen) Dock(
            sel = tab,
            onAdd = { compose = true },
            onTab = {
                // повторное нажатие на «Сатурн»: лента улетает наверх; если уже наверху — обновляется
                if (it == tab && it <= 1) scope.launch {
                    if (feedState.firstVisibleItemIndex == 0 && feedState.firstVisibleItemScrollOffset < 40) runCatching { News.refresh(ctx, true) }
                    else feedState.animateScrollToItem(0)
                }
                tab = it
                EarthGate.holdUntil = SystemClock.uptimeMillis() + 450
                Hap.tick()
            },
            m = Modifier.align(Alignment.BottomCenter)
        )
        }
        PerfCollector()
        AquaChat(compose) { compose = false }
        if (breathe) Breathe { breathe = false }
        if (zen) Zen { zen = false }
        }
        if (intro) StarIntro(onReveal = { appOn = true }) { IntroGate.shown = true; appOn = true; intro = false }
    }
}

// Погода в небе: реальная погода + реальное время суток по городу (рассвет, закат, сумерки).
// Взрослый «волшебный» стиль: тёплые закатные подсветки, мягкие облака без контуров. Всё статично, кроме
// дождя, снега, тумана и грозы (тикают ~15 раз в секунду и замирают на время скролла и касаний).
private class Drop(val x: Float, val y: Float, val v: Float, val l: Float)
private class Pal(val top: Color, val glow: Color, val dl: Float)

private fun sunTimes(lat: Double, lon: Double): Pair<Float, Float> {
    val cal = java.util.Calendar.getInstance()
    val doy = cal.get(java.util.Calendar.DAY_OF_YEAR)
    val decl = Math.toRadians(23.44 * Math.sin(2 * Math.PI * (doy - 81) / 365.0))
    val c = (-Math.tan(Math.toRadians(lat)) * Math.tan(decl)).coerceIn(-1.0, 1.0)
    val h0 = Math.toDegrees(Math.acos(c)) / 15.0 // полдлины дня, часы
    val tz = cal.timeZone.getOffset(cal.timeInMillis) / 3_600_000.0
    val noon = 12.0 - lon / 15.0 + tz
    return Pair((noon - h0).toFloat(), (noon + h0).toFloat())
}

private fun pal(top: Long, glow: Long, dl: Float) = Pal(Color(top), Color(glow), dl)

// Палитра по времени относительно восхода/заката, затем приглушена погодой (серость, тьма)
private fun weatherPalette(now: Float, sr: Float, ss: Float, kind: Int): Pal {
    val k = listOf(
        sr - 1.2f to pal(0xFF0A0F24, 0xFF2A1F4D, 0f),
        sr - 0.1f to pal(0xFF1B2350, 0xFFE9856B, 0.45f),
        sr + 1.3f to pal(0xFF1E4F9E, 0xFF7FB6F0, 0.95f),
        ss - 1.8f to pal(0xFF1E4F9E, 0xFF86B9EE, 0.95f),
        ss - 0.35f to pal(0xFF2B2563, 0xFFFF8A4C, 0.62f),
        ss + 0.6f to pal(0xFF151A45, 0xFF8A4FA8, 0.28f),
        ss + 1.8f to pal(0xFF0A0F24, 0xFF2A1F4D, 0f)
    )
    val night = k[0].second
    val base = if (now <= k[0].first || now >= k.last().first) night else {
        var r = night
        for (n in 0 until k.size - 1) {
            if (now >= k[n].first && now < k[n + 1].first) {
                val f = (now - k[n].first) / (k[n + 1].first - k[n].first)
                val a = k[n].second; val b = k[n + 1].second
                r = Pal(colorLerp(a.top, b.top, f), colorLerp(a.glow, b.glow, f), a.dl + (b.dl - a.dl) * f)
                break
            }
        }
        r
    }
    val gray = when (kind) { 0 -> 0f; 1 -> 0.15f; 2 -> 0.45f; 3 -> 0.40f; 4 -> 0.55f; 5 -> 0.35f; else -> 0.65f }
    val g = Color(0xFF2B3140)
    return Pal(colorLerp(base.top, g, gray), colorLerp(base.glow, g, gray * 0.9f), base.dl * (1f - 0.25f * gray))
}

@Composable
fun WeatherSky() {
    val code = Place.wcode
    if (code < 0) return
    // 0 ясно, 1 малооблачно, 2 пасмурно, 3 туман, 4 дождь, 5 снег, 6 гроза
    val kind = when {
        code >= 95 -> 6
        code in 71..77 || code == 85 || code == 86 -> 5
        code in 51..67 || code in 80..82 -> 4
        code == 45 || code == 48 -> 3
        code == 3 -> 2
        code in 1..2 -> 1
        else -> 0
    }
    var stamp by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(300_000); stamp++ } } // время суток пересчитываем раз в 5 минут
    val lat = if (Place.lat != 0.0) Place.lat else 51.5
    val lon = if (Place.lon != 0.0) Place.lon else 46.0
    val now = remember(stamp) { val c = java.util.Calendar.getInstance(); c.get(java.util.Calendar.HOUR_OF_DAY) + c.get(java.util.Calendar.MINUTE) / 60f }
    val sun = remember(stamp, lat, lon) { sunTimes(lat, lon) }
    val sr = sun.first; val ss = sun.second
    val pl = remember(now, sr, ss, kind) { weatherPalette(now, sr, ss, kind) }
    // 1) небо и светило: рисуется один раз и больше не перерисовывается
    Canvas(Modifier.fillMaxSize().graphicsLayer {}) {
        val w = size.width
        val h = size.height
        val a = 0.30f + 0.62f * pl.dl
        drawRect(
            Brush.verticalGradient(
                listOf(pl.top.copy(alpha = a), colorLerp(pl.top, pl.glow, 0.55f).copy(alpha = a), pl.glow.copy(alpha = a * 0.85f)),
                endY = h * 0.75f
            )
        )
        if (kind <= 1) {
            val k = if (kind == 1) 0.7f else 1f
            if (now in sr..ss) { // солнце: мягкое свечение, без диска; идёт по небу по часам
                val p = (now - sr) / (ss - sr)
                val c = Offset(w * (0.12f + 0.76f * p), h * (0.40f - 0.32f * kotlin.math.sin(Math.PI.toFloat() * p)))
                val warm = colorLerp(Color(0xFFFFF1CF), pl.glow, 0.45f)
                drawCircle(Brush.radialGradient(listOf(warm.copy(alpha = 0.50f * k), Color.Transparent), c, w * 0.65f), w * 0.65f, c)
                drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF8E4).copy(alpha = 0.70f * k), Color.Transparent), c, w * 0.12f), w * 0.12f, c)
            } else if (pl.dl < 0.2f) { // луна: мягкое холодное свечение
                val c = Offset(w * 0.22f, h * 0.09f)
                drawCircle(Brush.radialGradient(listOf(Color(0xFFDCE6FF).copy(alpha = 0.32f * k), Color.Transparent), c, w * 0.30f), w * 0.30f, c)
                drawCircle(Brush.radialGradient(listOf(Color(0xFFF2F6FF).copy(alpha = 0.95f * k), Color(0xFFF2F6FF).copy(alpha = 0.85f * k), Color.Transparent), c, 15.dp.toPx()), 15.dp.toPx(), c)
            }
        }
    }
    // дождь, снег и гроза: слой есть только пока они идут
    if (WxFx.on && kind == 5) SnowLayer(colorLerp(Color.White, pl.glow, 0.40f))
    else if (WxFx.on && kind >= 4 && Build.VERSION.SDK_INT >= 33) WxLayer(kind, colorLerp(Color.White, pl.glow, 0.40f))
}

// Далёкая галактика из постов (v92): чем больше постов, тем крупнее и ярче. Растр строится только при смене числа постов.
@Composable
fun Galaxy(n: Int) {
    if (n <= 0) return
    val p = (n / 5000f).coerceAtMost(1f)
    val stars = (60 + 1500 * p).toInt()
    val bmp = remember(stars) {
        val s = 256
        val bm = android.graphics.Bitmap.createBitmap(s, s, android.graphics.Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(bm)
        val pt = android.graphics.Paint()
        pt.shader = android.graphics.RadialGradient(
            s / 2f, s / 2f, s * 0.5f,
            intArrayOf(
                android.graphics.Color.argb(((0.5f + 0.4f * p) * 255).toInt(), 255, 236, 200),
                android.graphics.Color.argb(89, 255, 200, 150),
                android.graphics.Color.argb(26, 140, 150, 255),
                android.graphics.Color.argb(0, 90, 110, 255)
            ),
            floatArrayOf(0f, 0.12f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, s.toFloat(), s.toFloat(), pt)
        pt.shader = null
        val r = java.util.Random(7)
        val mid = s / 2f
        for (i in 0 until stars) {
            val t = Math.pow(r.nextDouble(), 0.75)
            val a = (i % 2) * Math.PI + t * 5.4 + (r.nextDouble() + r.nextDouble() + r.nextDouble() - 1.5) * 0.35 * (1.1 - t)
            val rad = t * s * 0.46
            val m = 1 - t
            pt.color = android.graphics.Color.argb(((0.25 + 0.5 * r.nextDouble()) * 255).toInt(), (150 + 105 * m).toInt(), (170 + 60 * m).toInt(), (255 - 60 * m).toInt())
            val x = (mid + Math.cos(a) * rad).toFloat()
            val y = (mid + Math.sin(a) * rad).toFloat()
            val z = (1 + r.nextDouble() * 1.1).toFloat()
            c.drawRect(x, y, x + z, y + z, pt)
        }
        bm.asImageBitmap()
    }
    Canvas(Modifier.fillMaxSize().graphicsLayer {}) {
        val sz = ((4f + 210f * p * p) * density).toInt().coerceAtLeast(2)
        val c = Offset(size.width * 0.72f, size.height * 0.17f)
        rotate(-24f, c) {
            scale(1f, 0.52f, c) {
                drawImage(bmp, dstOffset = IntOffset((c.x - sz / 2f).toInt(), (c.y - sz / 2f).toInt()), dstSize = IntSize(sz, sz), alpha = 0.35f + 0.65f * kotlin.math.sqrt(p))
            }
        }
    }
}

// Насколько темно сейчас по времени суток в городе: 1 ночью, 0 днём. Пересчёт раз в 5 минут.
@Composable
private fun nightFactor(): Float {
    var stamp by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(300_000); stamp++ } }
    val lat = if (Place.lat != 0.0) Place.lat else 51.5
    val lon = if (Place.lon != 0.0) Place.lon else 46.0
    return remember(stamp, lat, lon) {
        val c = java.util.Calendar.getInstance()
        val now = c.get(java.util.Calendar.HOUR_OF_DAY) + c.get(java.util.Calendar.MINUTE) / 60f
        val sun = sunTimes(lat, lon)
        (1f - weatherPalette(now, sun.first, sun.second, 0).dl * 1.25f).coerceIn(0f, 1f)
    }
}

private class Spark(val x: Float, val y: Float, val z: Float, val c: Color, val ph: Float)

// Небо из v79. Туманности и мелкие звёзды рисуются один раз и больше не перерисовываются.
// Десять искр мерцают ~8 раз в секунду и замирают на время скролла и касаний, чтобы не отнимать кадры у ленты и Земли.
@Composable
fun Sky() {
    val na = nightFactor()
    val naNow by rememberUpdatedState(na)
    val cols = remember {
        listOf(Color(0xFFFFFFFF), Color(0xFFD2E1FF), Color(0xFFFFDEBE), Color(0xFFBECDFF), Color(0xFFFFC8E6), Color(0xFFC8FFEB))
    }
    val tiny = remember {
        val r = java.util.Random(11)
        // много мелких звёзд разной яркости и размера, как на снимках телескопа: Triple(x, y, Triple(яркость, цвет, радиус))
        List(260) { i ->
            val b = r.nextFloat()
            Triple(r.nextFloat(), r.nextFloat(), Triple(0.25f + 0.65f * b * b, cols[r.nextInt(cols.size)], 0.6f + 1.1f * b * b * b))
        }
    }
    val big = remember {
        val r = java.util.Random(23)
        List(10) { Spark(0.05f + r.nextFloat() * 0.9f, 0.04f + r.nextFloat() * 0.8f, 14f + r.nextFloat() * 20f, cols[r.nextInt(cols.size)], r.nextFloat()) }
    }
    // 1) статичный слой: нет чтения состояния, поэтому не перерисовывается
    Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = na }) {
        val w = size.width
        val h = size.height
        clipRect(0f, 0f, w, h) {
            fun blob(cx: Float, cy: Float, rad: Float, c: Color) =
                drawCircle(Brush.radialGradient(listOf(c, c.copy(alpha = 0f)), Offset(cx, cy), rad), rad, Offset(cx, cy))
            blob(w * 0.12f, h * 0.05f, w * 0.7f, Color(140, 110, 255).copy(alpha = 0.22f))
            blob(w * 0.92f, h * 0.30f, w * 0.6f, Color(60, 160, 255).copy(alpha = 0.17f))
            blob(w * 0.5f, h * 0.30f, w * 0.55f, Color(255, 110, 180).copy(alpha = 0.08f))
            tiny.forEach { (x, y, p) ->
                drawCircle(p.second.copy(alpha = p.first), p.third, Offset(x * w, y * h))
            }
        }
    }
    // 2) искры: редкий тик вместо покадровой анимации
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(125)
            if (naNow > 0.05f && !EarthGate.scrolling && !EarthGate.touching) tick++
        }
    }
    Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = na }) {
        val w = size.width
        val h = size.height
        val tw = (tick % 56) / 56f
        clipRect(0f, 0f, w, h) {
            big.forEach { s ->
                val k: Float = 0.8f + 0.35f * (0.5f + 0.5f * kotlin.math.sin(2f * 3.14159265f * (tw + s.ph)))
                val z: Float = s.z * k * 1.3f
                val c = Offset(s.x * w, s.y * h)
                // как на снимках телескопа: маленькое яркое ядро и тонкие лучи, тающие к краям
                val tr = s.c.copy(alpha = 0f)
                val ray = s.c.copy(alpha = 0.55f)
                drawLine(Brush.horizontalGradient(listOf(tr, ray, tr), c.x - z * 1.5f, c.x + z * 1.5f), Offset(c.x - z * 1.5f, c.y), Offset(c.x + z * 1.5f, c.y), 1f)
                drawLine(Brush.verticalGradient(listOf(tr, ray, tr), c.y - z * 1.5f, c.y + z * 1.5f), Offset(c.x, c.y - z * 1.5f), Offset(c.x, c.y + z * 1.5f), 1f)
                drawCircle(Brush.radialGradient(listOf(Color.White, s.c.copy(alpha = 0.35f), s.c.copy(alpha = 0f)), c, z * 0.35f), z * 0.35f, c)
                drawCircle(Color.White, 1.5f, c)
            }
        }
    }
    // 3) редкий метеор: рисуется только пока летит
    val shoot = remember { Animatable(0f) }
    var sx by remember { mutableStateOf(0.2f) }
    var sy by remember { mutableStateOf(0.1f) }
    LaunchedEffect(Unit) {
        val r = java.util.Random()
        delay(6000)
        while (true) {
            sx = 0.08f + r.nextFloat() * 0.5f
            sy = 0.03f + r.nextFloat() * 0.3f
            shoot.snapTo(0f)
            if (naNow > 0.4f) shoot.animateTo(1f, tween(1300))
            shoot.snapTo(0f)
            delay(14000L + r.nextInt(16000))
        }
    }
    Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = na }) {
        val p = shoot.value
        if (p > 0f && p < 1f) {
            val w = size.width
            val h = size.height
            val hx = (sx + p * 0.35f) * w
            val hy = (sy + p * 0.18f) * h
            val tx = hx - w * 0.12f
            val ty = hy - h * 0.06f
            val a = kotlin.math.sin(Math.PI.toFloat() * p)
            drawLine(
                Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = a)), Offset(tx, ty), Offset(hx, hy)),
                Offset(tx, ty), Offset(hx, hy), 2.5f
            )
        }
    }
}

@Composable
fun Feed(state: LazyListState, ft: Int, onAqua: () -> Unit) {
    val ctx = LocalContext.current
    // 0 — общая лента: мои посты, чужие посты и источники по времени; 1 — мои и те, на кого подписан
    val scope = rememberCoroutineScope()
    var openKey by remember { mutableStateOf<String?>(null) }
    var openAt by remember { mutableLongStateOf(0L) }
    var applied by remember { mutableIntStateOf(News.rev) }
    val atTop by remember { derivedStateOf { state.firstVisibleItemIndex == 0 && state.firstVisibleItemScrollOffset == 0 } }
    // Новое подмешиваем, только пока ты наверху и ничего не читаешь: лента не уезжает из-под пальца
    LaunchedEffect(News.rev, atTop, openKey) { if (openKey == null && atTop) applied = News.rev }
    // 0 — лента под твой вкус (Taste), 1 — мои и те, на кого подписан
    val head: List<Any> = remember(ft, Store.posts.size, applied) {
        when (ft) {
            0 -> Taste.rank(ctx, Store.posts + News.visible())
            else -> Store.posts.filter { it.mine || it.aid == Store.meId || it.aid in Store.follows }.distinctBy { it.id }
        }
    }
    // Бесконечный хвост: подгружается у конца, порядок уже загруженного не меняется
    val list: List<Any> = remember(head, ft, News.moreRev, News.rev) {
        if (ft == 0) {
            val tail = News.visibleMore()
            if (tail.isEmpty()) head else { val have = head.map { Taste.keyOf(it) }.toHashSet(); head + tail.filter { have.add(Taste.keyOf(it)) } }
        } else head
    }
    val shownTiles = remember { HashSet<String>() }
    val nearEnd by remember { derivedStateOf { val li = state.layoutInfo; li.totalItemsCount > 0 && (li.visibleItemsInfo.lastOrNull()?.index ?: 0) >= li.totalItemsCount - 6 } }
    LaunchedEffect(nearEnd, ft, list.size) { if (ft == 0 && nearEnd && openKey == null) scope.launch { News.loadMore(ctx) } }
    LaunchedEffect(ft) {
        openKey = null
        if (ft == 0) News.refresh(ctx)
    }
    LaunchedEffect(Place.cityName) { Place.loadWx(ctx) }
    Box(Modifier.fillMaxSize()) {
    LazyColumn(
        state = state,
        modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { openKey = null } },
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 96.dp, bottom = 150.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (ft == 0) item(key = "aqua") { AquaStrip(onAqua) }
        if (ft == 0) item(key = "wx") {
            EmptyCard(if (Place.cityName.isEmpty()) "Укажи город во вкладке «Копия», здесь появится погода" else Place.cityName + " · " + Place.wx)
        }
        if (ft == 0 && News.status.isNotEmpty()) item(key = "st") { EmptyCard(News.status) }
        if (list.isEmpty()) {
            item(key = "empty") { if (Store.posts.isEmpty() && ft == 0) HintCard() else EmptyCard("Здесь пока пусто.") }
        } else {
            items(count = list.size, key = { i -> Taste.keyOf(list[i]) }) { i ->
                val x = list[i]
                TileIn(shownTiles, Taste.keyOf(x), if (i < 6) i * 55 else 0) {
                if (x is Post) GlassCard(x) else {
                    val n = x as NewsItem
                    NewsCard(
                        n, openKey == n.link,
                        { Taste.add(ctx, n.title + " " + n.desc.take(200), n.src, 1f); openAt = SystemClock.uptimeMillis(); openKey = n.link },
                        { if (openKey == n.link && SystemClock.uptimeMillis() - openAt > 8000) Taste.add(ctx, n.title + " " + n.desc.take(200), n.src, 1f); openKey = null }
                    )
                }
                }
            }
        }
    }
    if (applied != News.rev && !atTop && openKey == null) Box(
        Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 64.dp).glass(Pill)
            .clickable { applied = News.rev; scope.launch { state.scrollToItem(0) } }
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) { Text("Есть новое ↑", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
    }
}
// Появление карточки как плитки в Windows 8: въезжает справа с лёгким поворотом, каскадом.
// Играет один раз на карточку (повторный возврат при прокрутке не анимируется), слой снимается после конца анимации.
@Composable
fun TileIn(shown: HashSet<String>, key: String, delayMs: Int, content: @Composable () -> Unit) {
    val first = remember(key) { shown.add(key) }
    if (first) TileAnim(key, delayMs, content) else content()
}

@Composable
private fun TileAnim(key: String, delayMs: Int, content: @Composable () -> Unit) {
    val p = remember(key) { Animatable(0f) }
    var done by remember(key) { mutableStateOf(false) }
    LaunchedEffect(key) {
        delay(delayMs.toLong())
        p.animateTo(1f, tween(420, easing = FastOutSlowInEasing))
        done = true
    }
    Box(
        if (done) Modifier else Modifier.graphicsLayer {
            val v = p.value
            alpha = v
            translationX = (1f - v) * 56.dp.toPx()
            rotationY = (1f - v) * -16f
            cameraDistance = 14f * density
            transformOrigin = TransformOrigin(0f, 0.5f)
        }
    ) { content() }
}
// Карточка источника: всё читается внутри приложения. Долгое нажатие раскрывает, тап в сторону сворачивает.
@Composable
fun NewsCard(n: NewsItem, open: Boolean, onOpen: () -> Unit, onClose: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val ago = ((System.currentTimeMillis() - n.ts) / 3_600_000L).coerceAtLeast(0)
    val more = n.full.length > n.desc.length + 40
    val body = if (open && n.full.isNotEmpty()) n.full else n.desc
    val hasImg = n.img.isNotEmpty()
    var heart by remember { mutableStateOf(false) }
    LaunchedEffect(heart) { if (heart) { delay(750); heart = false } }
    val lctx = LocalContext.current
    // «Прижим» как у плиток Windows 8: карточка чуть уходит вглубь и наклоняется от точки касания
    var pressed by remember { mutableStateOf(false) }
    var pnx by remember { mutableStateOf(0.5f) }
    var pny by remember { mutableStateOf(0.5f) }
    val boxSz = remember { IntArray(2) }
    val pr = pressed && !open
    val pSpec = spring<Float>(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium)
    val psc by animateFloatAsState(if (pr) 0.975f else 1f, pSpec, label = "npress")
    val ptx by animateFloatAsState(if (pr) (pnx - 0.5f) * 2f else 0f, pSpec, label = "ntx")
    val pty by animateFloatAsState(if (pr) (pny - 0.5f) * 2f else 0f, pSpec, label = "nty")
    Column(
        Modifier.fillMaxWidth()
            .onSizeChanged { boxSz[0] = it.width; boxSz[1] = it.height }
            .graphicsLayer {
                scaleX = psc; scaleY = psc
                rotationY = ptx * 4f; rotationX = -pty * 4f
                cameraDistance = 16f * density
            }
            .animateContentSize(spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow))
            .glass(RoundedCornerShape(24.dp), dense = true)
            .pointerInput(open) {
                detectTapGestures(
                    onPress = { o -> pnx = o.x / boxSz[0].coerceAtLeast(1); pny = o.y / boxSz[1].coerceAtLeast(1); pressed = true; tryAwaitRelease(); pressed = false },
                    onLongPress = { if (!open) { Hap.click(); onOpen() } },
                    onDoubleTap = { // как в Инстаграме: двойной тап = нравится
                        Hap.click()
                        Taste.add(lctx, n.title + " " + n.desc.take(200), n.src, 2f)
                        heart = true
                    },
                    onTap = { if (open) onClose() }
                )
            }
            .padding(if (hasImg) PaddingValues(0.dp) else PaddingValues(horizontal = 18.dp, vertical = 16.dp))
    ) {
        if (hasImg) Box(contentAlignment = Alignment.Center) {
            NewsImage(n.img, if (open) 280.dp else 250.dp, edge = true)
            if (heart) Text("♥", color = Color.White, fontSize = 72.sp)
        }
        Column(Modifier.padding(horizontal = if (hasImg) 18.dp else 0.dp, vertical = if (hasImg) 14.dp else 0.dp)) {
        Text(n.src + " · " + (if (ago < 24) "$ago ч назад" else "${ago / 24} дн назад"), color = Acc, fontSize = 12.sp)
        Text(n.title, color = Color.White, fontSize = if (open) 19.sp else 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
        if (body.isNotEmpty()) Text(
            body,
            color = Color.White.copy(alpha = if (open) 0.88f else 0.65f),
            fontSize = if (open) 15.sp else 13.sp,
            lineHeight = if (open) 23.sp else 19.sp,
            maxLines = if (open) Int.MAX_VALUE else 3,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = if (open) 12.dp else 6.dp)
        )
        if (open) {
            val ctx = LocalContext.current
            val txt = n.title + " " + n.desc.take(200)
            Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Text("Нравится", color = Acc, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { Taste.add(ctx, txt, n.src, 2f); onClose() })
                Text("Не нравится", color = Acc, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { Taste.add(ctx, txt, n.src, -2f); News.hideItem(ctx, n.link); onClose() })
            }
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Text("Скрыть это", color = Muted, fontSize = 13.sp, modifier = Modifier.clickable { Taste.add(ctx, txt, n.src, -1f); News.hideItem(ctx, n.link); onClose() })
                Text("Скрыть «" + n.src + "»", color = Muted, fontSize = 13.sp, modifier = Modifier.clickable { Taste.add(ctx, "", n.src, -6f); News.hideSource(ctx, n.src); onClose() })
            }
            Text("Тапни в сторону, чтобы свернуть", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
        }
        else if (more) Text("Удержи, чтобы читать целиком", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable
fun FeedTabs(sel: Int, onSel: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("Сегодня", "Все", "Читаю", "Новости").forEachIndexed { i, n ->
            val on = i == sel
            Box(
                Modifier.glass(Pill).then(if (on) Modifier.background(Color(0x406EA8FF), Pill) else Modifier).clickable { onSel(i) }.padding(horizontal = 12.dp, vertical = 8.dp)
            ) { Text(n, color = if (on) Color.White else Color.White.copy(alpha = 0.6f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
fun EmptyCard(t: String) {
    Text(t, color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
}

@Composable
fun GlassCard(p: Post) {
    val ctx = LocalContext.current
    var pressed by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    Column(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .glass(RoundedCornerShape(24.dp), dense = true)
            .pointerInput(p.id) {
                detectTapGestures(
                    onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                    onLongPress = { if (p.mine) menu = true }
                )
            }
            .padding(horizontal = 18.dp, vertical = 20.dp)
    ) {
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(
                text = { Text(if (p.pub) "Отозвать из публичного" else "Сделать публичным") },
                onClick = { Store.setPub(ctx, p.id, !p.pub); menu = false }
            )
            DropdownMenuItem(
                text = { Text("Удалить", color = Color(0xFFFF6B6B)) },
                onClick = { Store.delete(ctx, p.id); menu = false }
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Color(0x266EA8FF)).border(1.dp, Color(0x526EA8FF), CircleShape),
                contentAlignment = Alignment.Center
            ) { Text(p.author.take(1).uppercase(), color = Acc, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold) }
            Column(Modifier.padding(start = 12.dp)) {
                Text(p.author, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(fmt.format(Date(p.ts)) + if (p.mine && !p.pub) " · 🔒 только мне" else "", color = Muted, fontSize = 13.sp)
            }
        }
        Text(p.text, color = Color(0xFFE9ECF2), fontSize = 16.sp, lineHeight = 26.sp, modifier = Modifier.padding(top = 12.dp))
    }
}
@Composable
fun NewPost(show: Boolean, onClose: () -> Unit) {
    val ctx = LocalContext.current
    if (show) Sheet(onClose) {
        Text("Новый пост", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            colors = fieldColors(),
            value = Store.draft, onValueChange = { Store.setDraft(ctx, it) },
            modifier = Modifier.fillMaxWidth().padding(top = 14.dp), minLines = 3, maxLines = 8,
            placeholder = { Text("Черновик сохраняется сам") }
        )
        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("Закрыть", Modifier.weight(1f)) { onClose() }
            Btn("Только мне", Modifier.weight(1f), enabled = Store.draft.isNotBlank()) { Store.publish(ctx, false); Snd.play(); Hap.success(); onClose() }
        }
        Btn("Опубликовать", Modifier.fillMaxWidth().padding(top = 8.dp), primary = true, enabled = Store.draft.isNotBlank()) { Store.publish(ctx, true); Snd.play(); Hap.success(); onClose() }
    }
}
@Composable
fun Simple(name: String) {
    val text = if (name == "Чаты") "Здесь будут переписки: личные и по кругу близких. Они появятся вместе с «Связью», когда устройства научатся находить друг друга напрямую."
    else "Здесь будут устройства рядом и статус каждого канала доставки. Появится вместе с «Связью»."
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(26.dp), dense = true).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(text, color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp))
            Text("Скоро", color = Color(0xFF6EA8FF), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 14.dp))
        }
    }
}

// Потяни вниз (как в v99): кромка бежит по пилюле с двух сторон, замыкается в кольцо и вращается при обновлении.
class PullState {
    var p by mutableFloatStateOf(0f)
    var spin by mutableStateOf(false)
}

private val PullColors = listOf(Color(0xFF3D8BFF), Color(0xFF9A4DFF), Color(0xFFFF3FA4), Color(0xFFFF9A2E), Color(0xFF19E0C0))

private fun DrawScope.drawPullGlow(p: Float, spin: Boolean, phase: Float) {
    // A fine, dispersed aura rather than a thick continuous neon stripe.
    val e = 0.7.dp.toPx()
    val x = -e; val y = -e; val w2 = size.width + 2 * e; val b = size.height + e
    val r = (b - y) / 2f
    val cx = size.width / 2f
    val right = Path().apply { moveTo(cx, b); lineTo(x + w2 - r, b); arcTo(Rect(x + w2 - 2 * r, y, x + w2, b), 90f, -180f, false); lineTo(cx, y) }
    val left = Path().apply { moveTo(cx, b); lineTo(x + r, b); arcTo(Rect(x, y, x + 2 * r, b), 90f, 180f, false); lineTo(cx, y) }
    val brush = Brush.horizontalGradient(PullColors, startX = 0f, endX = size.width)
    val pm = PathMeasure()
    fun seg(path: Path, a: Float, z: Float): Path {
        pm.setPath(path, false)
        val len = pm.length
        return Path().also { pm.getSegment(len * a, len * z, it, true) }
    }
    val parts = ArrayList<Path>(2)
    if (spin) {
        val ring = Path().apply {
            moveTo(cx, y); lineTo(x + w2 - r, y); arcTo(Rect(x + w2 - 2 * r, y, x + w2, b), -90f, 180f, false)
            lineTo(x + r, b); arcTo(Rect(x, y, x + 2 * r, b), 90f, 180f, false); close()
        }
        val a = phase; val z = phase + 0.30f
        if (z <= 1f) parts.add(seg(ring, a, z)) else { parts.add(seg(ring, a, 1f)); parts.add(seg(ring, 0f, z - 1f)) }
    } else {
        parts.add(seg(right, 0f, p)); parts.add(seg(left, 0f, p))
    }
    // Broken, feathered segments: broad low-alpha haze + restrained luminous hairline.
    val dash = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(5.dp.toPx(), 4.dp.toPx()), 0f)
    for (pt in parts) {
        drawPath(pt, brush, alpha = 0.055f, style = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Round, pathEffect = dash))
        drawPath(pt, brush, alpha = 0.13f, style = Stroke(width = 3.2.dp.toPx(), cap = StrokeCap.Round, pathEffect = dash))
        drawPath(pt, brush, alpha = 0.62f, style = Stroke(width = 1.05.dp.toPx(), cap = StrokeCap.Round, pathEffect = dash))
    }
}

@Composable
fun TopPill(m: Modifier, ps: PullState, onClick: () -> Unit) {
    val phase = remember { Animatable(0f) }
    var expanded by remember { mutableStateOf(false) }
    val view = LocalView.current
    val density = LocalDensity.current
    val pillInteraction = remember { MutableInteractionSource() }
    val pillPressed by pillInteraction.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        if (pillPressed) 0.975f else 1f,
        spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMedium),
        label = "pillPress"
    )

    // Системная строка скрывается только на время раскрытого состояния.
    DisposableEffect(expanded, view) {
        val root = view.rootView
        val oldSystemUiVisibility = root.systemUiVisibility
        if (expanded) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                root.windowInsetsController?.let { controller ->
                    controller.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    controller.hide(android.view.WindowInsets.Type.statusBars())
                }
            } else {
                root.systemUiVisibility = oldSystemUiVisibility or android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
            }
        }
        onDispose {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                root.windowInsetsController?.show(android.view.WindowInsets.Type.statusBars())
            } else root.systemUiVisibility = oldSystemUiVisibility
        }
    }
    BackHandler(enabled = expanded) { expanded = false }

    // Размер компактной камеры-капсулы; раскрытое состояние — единая поверхность.
    val screenWidthDpValue = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp.toFloat()
    val screenWidth = screenWidthDpValue.dp
    val deviceScale = screenWidthDpValue / 393f
    val pillWidth = (125.34f * deviceScale).dp
    val pillHeight = (36.67f * deviceScale).dp
    val islandWidth by androidx.compose.animation.core.animateDpAsState(
        if (expanded) minOf((371f * deviceScale).dp, screenWidth - 24.dp) else pillWidth,
        spring(dampingRatio = 0.78f, stiffness = Spring.StiffnessMediumLow), label = "islandWidth"
    )
    val islandHeight by androidx.compose.animation.core.animateDpAsState(
        if (expanded) 148.dp * deviceScale else pillHeight,
        spring(dampingRatio = 0.78f, stiffness = Spring.StiffnessMediumLow), label = "islandHeight"
    )
    val corner by androidx.compose.animation.core.animateDpAsState(
        if (expanded) 28.dp * deviceScale else pillHeight / 2f,
        spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMediumLow), label = "islandCorner"
    )
    val islandShape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(corner)

    // Привязка к реальному DisplayCutout, если прошивка отдаёт его координаты.
    var cameraCenterYpx by remember(view) { mutableIntStateOf(-1) }
    LaunchedEffect(view) {
        repeat(12) {
            val root = view.rootView
            val cutout = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) root.rootWindowInsets?.displayCutout else null
            val centerX = root.width / 2
            val rect = cutout?.boundingRects?.minByOrNull { kotlin.math.abs(it.centerX() - centerX) }
            if (rect != null && root.width > 0) {
                cameraCenterYpx = rect.centerY()
                return@LaunchedEffect
            }
            withFrameNanos { }
        }
    }
    val cameraTop = if (cameraCenterYpx >= 0) {
        with(density) { cameraCenterYpx.toDp() } - pillHeight / 2f + 2.dp
    } else (-1).dp

    val entrance = remember { Animatable(0.72f) }
    LaunchedEffect(Unit) {
        delay(90)
        entrance.animateTo(1.045f, spring(dampingRatio = 0.48f, stiffness = Spring.StiffnessMedium))
        entrance.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMedium))
    }
    LaunchedEffect(ps.spin) {
        if (ps.spin) phase.animateTo(1f, infiniteRepeatable(tween(1000, easing = LinearEasing))) else phase.snapTo(0f)
    }

    Column(
        modifier = m.offset(y = cameraTop).graphicsLayer {
            scaleX = entrance.value * pressScale; scaleY = entrance.value * pressScale
            alpha = (entrance.value / 0.72f).coerceIn(0f, 1f)
        },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ОДНА поверхность на оба состояния: больше нет отдельной карточки под островом.
        LiquidSurface(
            islandShape,
            Modifier
                .width(islandWidth)
                .height(islandHeight)
                .drawWithContent {
                    drawContent()
                    if (ps.p > 0.02f || ps.spin) drawPullGlow(ps.p, ps.spin, phase.value)
                }
                .clip(islandShape)
                .clickable(interactionSource = pillInteraction, indication = null) {
                    expanded = !expanded
                }
        ) {
            Box(
                Modifier.fillMaxSize().graphicsLayer { shape = islandShape; clip = true }
                    .background(Color(0xFF020203))
            ) {
                if (!expanded) {
                    // Компактное состояние — чистая чёрная капсула, без прямоугольных слоёв.
                    Box(
                        Modifier.align(Alignment.TopCenter).fillMaxWidth(0.52f).height(0.7.dp)
                            .background(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.045f), Color.Transparent)))
                    )
                } else {
                    Column(
                        Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 15.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("MEGASTUDIYA", color = Color.White.copy(alpha = 0.94f), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                            androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
                            Text("OBSIDIAN", color = Color.White.copy(alpha = 0.42f), fontSize = 9.sp, letterSpacing = 1.2.sp)
                        }
                        if (ps.spin) {
                            Text("ОБНОВЛЯЕМ ЛЕНТУ И ПОГОДУ…", color = Color(0xFF8FB8FF), fontSize = 10.sp, letterSpacing = 0.5.sp)
                        } else if (ps.p > 0f) {
                            Text(if (ps.p >= 1f) "ОТПУСТИ — ОБНОВИТЬ" else "ПОТЯНИ ЕЩЁ", color = Color.White.copy(alpha = 0.65f), fontSize = 10.sp)
                        } else {
                            Text("Твоя цифровая вселенная", color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp)
                        }
                        Box(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                                .background(Brush.horizontalGradient(listOf(Color(0xFF172033), Color(0xFF0B101B), Color(0xFF172033))))
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null
                                ) { expanded = false; onClick() }
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("✦   SPACE PLATFORM   ·   ОТКРЫТЬ", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.55.sp)
                        }
                    }
                }
            }
        }
    }
}

private val ICON_RAYS by lazy { PathParser().parsePathString("M12 3v2.2M12 18.8V21M3 12h2.2M18.8 12H21M5.6 5.6l1.6 1.6M16.8 16.8l1.6 1.6M18.4 5.6l-1.6 1.6M7.2 16.8l-1.6 1.6").toPath() }
private val ICON_MARK by lazy { PathParser().parsePathString("M7 4.5h10a1 1 0 0 1 1 1V20l-6-4-6 4V5.5a1 1 0 0 1 1-1z").toPath() }
private val ICON_PLAY by lazy { PathParser().parsePathString("M8 5l11 7-11 7z").toPath() }
private val ICON_STAR by lazy { PathParser().parsePathString("M12 2.5C12.9 8.6 15.4 11.1 21.5 12 15.4 12.9 12.9 15.4 12 21.5 11.1 15.4 8.6 12.9 2.5 12 8.6 11.1 11.1 8.6 12 2.5z").toPath() }

// Иконки из v99 (сетка 24x24): солнце, плитки, закладка, кольцо, искра
@Composable
fun DockIcon(kind: Int, color: Color, size: androidx.compose.ui.unit.Dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension / 24f
        val st = Stroke(1.9f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        withTransform({ scale(s, s, Offset.Zero) }) {
            when (kind) {
                0 -> { drawCircle(color, 4f, Offset(12f, 12f), style = st); drawPath(ICON_RAYS, color, style = st) }
                1 -> for (x in listOf(4f, 13.5f)) for (y in listOf(4f, 13.5f))
                    drawRoundRect(color, Offset(x, y), Size(6.5f, 6.5f), CornerRadius(2f, 2f), style = st)
                2 -> drawPath(ICON_MARK, color, style = st)
                3 -> { drawCircle(color, 8f, Offset(12f, 12f), style = st); drawCircle(color, 2.6f, Offset(12f, 12f), style = st) }
                6 -> drawPath(ICON_PLAY, color, style = st)
                5 -> {
                    drawCircle(color, 4.6f, Offset(12f, 12f), style = st)
                    withTransform({ rotate(-28f, Offset(12f, 12f)) }) {
                        drawOval(color, Offset(2.2f, 8.2f), Size(19.6f, 7.6f), style = st)
                    }
                }
                else -> drawPath(ICON_STAR, color)
            }
        }
    }
}

// Нижний док как в v99: стеклянная таблетка с иконками и отдельная круглая кнопка «Написать»
@Composable
fun Dock(sel: Int, onTab: (Int) -> Unit, onAdd: () -> Unit, m: Modifier) {
    val xs = remember { mutableStateListOf(0, 0, 0, 0) }
    val ws = remember { mutableStateListOf(0, 0, 0, 0) }
    var hh by remember { mutableIntStateOf(0) }
    val spec = spring<Float>(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow)
    val dens = LocalDensity.current
    val padPx = with(dens) { 8.dp.toPx() }
    val selNow by rememberUpdatedState(sel)
    val tabNow by rememberUpdatedState(onTab)
    var dragX by remember { mutableStateOf<Float?>(null) }   // палец на доке: x в координатах содержимого
    var pressed by remember { mutableIntStateOf(-1) }
    var hover by remember { mutableIntStateOf(-1) }
    val ax = remember { Animatable(0f) }
    // Плашка едет за пальцем без пружины, а после отпускания мягко доезжает до выбранной вкладки.
    LaunchedEffect(sel, xs[sel], dragX) {
        val dx = dragX
        if (dx != null) ax.snapTo((dx - ws[sel] / 2f).coerceIn(xs[0].toFloat(), xs[3].toFloat()))
        else ax.animateTo(xs[sel].toFloat(), spec)
    }
    val iw = ws[sel]
    Row(
        m.navigationBarsPadding().padding(bottom = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LiquidSurface(
            Pill,
            Modifier
                .pointerInput(Unit) {
                    val slop = viewConfiguration.touchSlop
                    fun hit(x: Float): Int {
                        val stride = (xs[1] - xs[0]).coerceAtLeast(1)
                        return ((x - xs[0]) / stride).toInt().coerceIn(0, 3)
                    }
                    awaitPointerEventScope {
                        while (true) {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val x0 = down.position.x - padPx
                            var dragging = false
                            pressed = hit(x0)
                            while (true) {
                                val ch = awaitPointerEvent().changes.firstOrNull { it.id == down.id } ?: break
                                if (!ch.pressed) {
                                    // страницы переключаются только при отпускании, пока палец ведёт каплю, лента не трогается
                                    tabNow(if (dragging) hit(ch.position.x - padPx) else hit(x0))
                                    ch.consume(); break
                                }
                                val x = ch.position.x - padPx
                                if (!dragging && kotlin.math.abs(x - x0) > slop) { dragging = true; pressed = -1 }
                                if (dragging) {
                                    dragX = x
                                    hover = hit(x)
                                    ch.consume()
                                }
                            }
                            pressed = -1; dragX = null; hover = -1
                        }
                    }
                }
        ) {
          Box(Modifier.padding(horizontal = 8.dp, vertical = 8.dp)) {
            if (iw > 0) Box(
                Modifier.offset { IntOffset(ax.value.toInt(), 0) }
                    .size(with(dens) { iw.toDp() }, with(dens) { hh.toDp() })
                    .clip(Pill).background(Color(0x336EA8FF)).border(1.dp, Color(0x4D6EA8FF), Pill)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                for (i in 0..3) {
                    val sc by animateFloatAsState(
                        targetValue = if (pressed == i) 0.9f else 1f,
                        animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
                        label = "dsc"
                    )
                    Box(
                        Modifier.size(58.dp, 50.dp)
                            .onGloballyPositioned { xs[i] = it.positionInParent().x.toInt(); ws[i] = it.size.width; hh = it.size.height }
                            .graphicsLayer { scaleX = sc; scaleY = sc }
                            .clip(Pill),
                        contentAlignment = Alignment.Center
                    ) { DockIcon(intArrayOf(5, 2, 3, 6)[i], if (i == (if (hover >= 0) hover else sel)) Color(0xFF6EA8FF) else Color.White.copy(alpha = 0.75f), 26.dp) }
                }
            }
          }
        }
        LiquidSurface(androidx.compose.foundation.shape.CircleShape, Modifier.size(66.dp).clickable { onAdd() }) {
            Box(Modifier.matchParentSize(), contentAlignment = Alignment.Center) { DockIcon(4, Color(0xFF6EA8FF), 30.dp) }
        }
    }
}

@Composable
fun HintCard() {
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape)
            .background(Color.White.copy(alpha = 0.08f)).border(BorderStroke(1.dp, Line), shape).padding(16.dp)
    ) {
        Text("Лента пока пустая", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(
            "Вкладка «Я» → «Импорт копии»: выбери файл копии из старого приложения.",
            color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
fun MeScreen(onBreathe: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var raw by remember { mutableStateOf<String?>(null) }
    var pw by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var page by remember { mutableIntStateOf(0) }
    var gt by remember { mutableStateOf(false) }
    var expDlg by remember { mutableStateOf(false) }
    var expPw by remember { mutableStateOf("") }
    var expData by remember { mutableStateOf<String?>(null) }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val d = expData
        if (uri != null && d != null) {
            note = try {
                ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(d.toByteArray(Charsets.UTF_8)) }
                "Копия сохранена. Пароль знаешь только ты."
            } catch (_: Throwable) { "Не удалось сохранить файл" }
        }
        expData = null
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                raw = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                pw = ""
                err = ""
                note = ""
            } catch (_: Throwable) {
                note = "Не удалось прочитать файл"
            }
        }
    }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Я", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            colors = fieldColors(),
            value = Store.name, onValueChange = { Store.setName(ctx, it) }, singleLine = true,
            label = { Text("Твоё имя") }, modifier = Modifier.padding(top = 12.dp)
        )
        var cin by remember { mutableStateOf("") }
        OutlinedTextField(
            colors = fieldColors(),
            value = cin, onValueChange = { cin = it }, singleLine = true,
            label = { Text(if (Place.cityName.isEmpty()) "Город" else "Город: " + Place.cityName) }, modifier = Modifier.padding(top = 8.dp)
        )
        MenuBtn("Найти город", "Для погоды и Земли") {
            val q = cin.trim()
            if (q.isNotEmpty()) scope.launch {
                note = "Ищу…"
                try {
                    val g = Place.geocode(q)
                    if (g == null) note = "Не нашёл такой город" else {
                        Place.setCity(ctx, g)
                        cin = ""
                        note = "Город: " + g.name
                        Place.loadWx(ctx)
                    }
                } catch (_: Throwable) {
                    note = "Нет интернета"
                }
            }
        }
        Text("Постов: ${Store.posts.size}", color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
        Box(
            Modifier.padding(top = 20.dp).clip(Pill).background(Color(0x407AA8FF)).border(1.dp, Line, Pill)
                .clickable { pick.launch(arrayOf("*/*")) }.padding(horizontal = 24.dp, vertical = 13.dp)
        ) { Text("Импорт копии", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
        MenuBtn("Экспорт копии", "Всё приложение одним файлом: посты, вкус ленты, настройки") { expDlg = true }
        MenuBtn("Журнал переезда", "Что, от кого и как было перенесено") { page = 4 }
        MenuBtn("Источники видео", "YouTube, Telegram и TikTok: ключи и подключение") { page = 6 }
        MenuBtn("Подышать", "Пять медленных вдохов") { onBreathe() }
        MenuBtn(if (Snd.on) "Звук: вкл" else "Звук: выкл", "Звон при публикации") { Snd.toggle(ctx) }
        MenuBtn(if (WxFx.on) "Осадки: вкл" else "Осадки: выкл", "Дождь, снег и гроза, когда они идут") { WxFx.toggle(ctx) }
        MenuBtn("Тест", "fps, лаги по запускам, Земля, стекло") { page = 3 }
        MenuBtn("$CORE_NAME: ядро", "Её состояние, связь телефонов, очистка памяти") { page = 5 }
        MenuBtn("Тест стекла", "Три варианта, скажи какой похож на стекло") { gt = true }
        MenuBtn("О проекте", "Что это и как устроено") { page = 1 }
        MenuBtn("Правила", "Коротко и честно") { page = 2 }
        if (note.isNotEmpty()) Text(note, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp))
    }
    if (gt) GlassTest { gt = false }
    if (expDlg) {
        AlertDialog(
            onDismissRequest = { if (!busy) expDlg = false },
            title = { Text("Экспорт копии") },
            text = {
                Column {
                    Text("В файле все твои посты, вкус ленты и настройки. Он закрыт паролем: без него не открыть. Придумай пароль (от 4 знаков) и запомни его.", fontSize = 14.sp)
                    OutlinedTextField(
                        colors = fieldColors(),
                        value = expPw, onValueChange = { expPw = it }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.padding(top = 10.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(enabled = !busy && expPw.length >= 4, onClick = {
                    busy = true
                    val pwd = expPw
                    scope.launch {
                        val d = withContext(Dispatchers.Default) { runCatching { Store.exportAll(ctx, pwd) } }.getOrNull()
                        busy = false
                        if (d == null) { note = "Не удалось собрать копию"; expDlg = false }
                        else {
                            expData = d; expDlg = false; expPw = ""
                            save.launch("megastudiya-copy-" + java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date()) + ".json")
                        }
                    }
                }) { Text(if (busy) "Считаю…" else "Сохранить") }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { expDlg = false }) { Text("Отмена") } }
        )
    }
    if (page != 0) {
        BackHandler { page = 0 }
        if (page == 3) PerfScreen { page = 0 }
        else if (page == 5) CoreScreen { page = 0 }
        else if (page == 6) SourceSettingsScreen { page = 0 }
        else TextPage(when (page) { 1 -> "О проекте"; 2 -> "Правила"; else -> "Журнал переезда" }, when (page) { 1 -> ABOUT; 2 -> RULES; else -> Store.importLogText(ctx) }) { page = 0 }
    }
    val r = raw
    if (r != null) {
        AlertDialog(
            onDismissRequest = { if (!busy) raw = null },
            title = { Text("Пароль копии") },
            text = {
                Column {
                    OutlinedTextField(
            colors = fieldColors(),
                        value = pw, onValueChange = { pw = it }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                    if (err.isNotEmpty()) Text(err, color = Color(0xFFFF8A80), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    busy = true
                    err = ""
                    val p = pw
                    scope.launch {
                        val res = withContext(Dispatchers.Default) { runCatching { Store.parse(r, p) } }
                        val o = res.getOrNull()
                        if (o != null) {
                            note = (if (Store.isNative(o)) runCatching { Store.restore(ctx, o) }.getOrDefault("Не удалось применить файл")
                                else runCatching { Store.importOld(ctx, o) }.getOrDefault("Не удалось применить файл")) + "\nВсего постов: ${Store.posts.size}"
                            raw = null
                        } else {
                            err = if (res.exceptionOrNull() is javax.crypto.AEADBadTagException) "Неверный пароль" else "Файл не подходит"
                        }
                        busy = false
                    }
                }) { Text(if (busy) "Считаю…" else "Открыть") }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { raw = null }) { Text("Отмена") } }
        )
    }
}

private const val ABOUT = "Канал, который живёт у тебя. Сеть без центра: каждое устройство часть сервера. Её нельзя отключить в одном месте.\n\nТри круга\nЗаметки: только у меня.\nКруг: избранным.\nВсем: публичный канал.\n\nЯдро\n1. Своя копия у каждого, без интернета.\n2. Слияние без потерь.\n3. Несколько каналов доставки.\n4. Знакомство без сервера.\n5. Честные статусы.\n6. Копия одним файлом.\n7. Любое устройство."
private const val RULES = "Здесь нет модератора: ты сам решаешь, что видеть. Нельзя публиковать незаконное, угрозы, чужие личные данные и материалы с насилием над детьми. Ты отвечаешь за то, что публикуешь.\n\nПосты нельзя подделать, но и стереть у всех нельзя. «Пожаловаться» скрывает пост у тебя и больше не пересылает его дальше; «Скрыть» убирает автора целиком.\n\nДля обмена бери копию без личного. Полная копия защищена паролем. «Личный» пост никуда не уходит. Анонимности сеть не обещает."

@Composable
fun MenuBtn(t: String, sub: String = "", onClick: () -> Unit) {
    Column(
        Modifier.padding(top = 10.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp))
            .clickable { onClick() }.padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Text(t, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        if (sub.isNotEmpty()) Text(sub, color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun Btn(t: String, modifier: Modifier = Modifier, primary: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val sh = RoundedCornerShape(14.dp)
    Box(
        modifier.clip(sh)
            .then(if (primary) Modifier.background(Brush.linearGradient(listOf(Acc, Color(0xFFB58CFF)))) else Modifier.glass(sh))
            .graphicsLayer { alpha = if (enabled) 1f else 0.4f }
            .clickable(enabled = enabled) { onClick() }
            .padding(horizontal = 16.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { Text(t, color = if (primary) Bg else Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp) }
}

// Нижняя шторка, как .sheet в v99
@Composable
fun Sheet(onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    BackHandler { onClose() }
    val top = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).pointerInput(Unit) { detectTapGestures { onClose() } }) {
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .pointerInput(Unit) { detectTapGestures { } }
                .clip(top).background(Color(0xFF10141C)).border(1.dp, Line, top)
                .navigationBarsPadding().imePadding().padding(20.dp),
            content = content
        )
    }
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
    focusedBorderColor = Acc, unfocusedBorderColor = Line, cursorColor = Acc,
    focusedLabelColor = Acc, unfocusedLabelColor = Muted,
    focusedPlaceholderColor = Muted, unfocusedPlaceholderColor = Muted
)
@Composable
fun TextPage(title: String, body: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Text("← Назад", color = Color(0xFF6EA8FF), fontSize = 15.sp, modifier = Modifier.clickable { onBack() }.padding(bottom = 16.dp))
        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(body, color = Color.White.copy(alpha = 0.8f), fontSize = 16.sp, modifier = Modifier.padding(top = 12.dp))
    }
}

private class Stop(val name: String, val lat: Double, val lon: Double)

private val WORLD = listOf(
    Stop("Москва", 55.75, 37.62), Stop("Санкт-Петербург", 59.94, 30.31), Stop("Лондон", 51.51, -0.13),
    Stop("Нью-Йорк", 40.71, -74.0), Stop("Рио-де-Жанейро", -22.91, -43.17), Stop("Кейптаун", -33.92, 18.42),
    Stop("Каир", 30.04, 31.24), Stop("Дубай", 25.2, 55.27), Stop("Мумбаи", 19.08, 72.88),
    Stop("Пекин", 39.9, 116.4), Stop("Токио", 35.68, 139.69), Stop("Сидней", -33.87, 151.21),
    Stop("Сан-Франциско", 37.77, -122.42)
)

// Режим созерцания: интерфейс гаснет, планета в центре. Щипок — зум, «Лететь» — следующий город, тап — выход.
@Composable
fun Zen(onExit: () -> Unit) {
    val stops = remember { (if (Place.cityName.isEmpty()) emptyList() else listOf(Stop(Place.cityName, Place.lat, Place.lon))) + WORLD }
    var i by remember { mutableIntStateOf(0) }
    LaunchedEffect(i) {
        EarthGate.focusLat = Math.toRadians(stops[i].lat)
        EarthGate.focusLon = Math.toRadians(stops[i].lon)
    }
    DisposableEffect(Unit) { onDispose { EarthGate.zoom = 1f } }
    BackHandler { onExit() }
    val mine = Store.posts.count { it.mine || (Store.meId.isNotEmpty() && it.aid == Store.meId) }
    val hung = Store.posts.count { (it.mine || (Store.meId.isNotEmpty() && it.aid == Store.meId)) && it.text.contains("#подвешено", ignoreCase = true) }
    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) { detectTransformGestures { _, _, z, _ -> EarthGate.zoom = (EarthGate.zoom * z).coerceIn(0.6f, 3.2f) } }
            .pointerInput(Unit) { detectTapGestures { onExit() } }
    ) {
        Text(
            if (mine == 0) "" else "$mine звёзд" + (if (hung > 0) " · $hung подвешено" else ""),
            color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp,
            modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 16.dp)
        )
        Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(stops[i].name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("щипок — зум · тап — назад", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            MenuBtn("Лететь ›") { i = (i + 1) % stops.size }
        }
    }
}

// «Подышать»: 5 циклов, вдох 4 секунды, выдох 6, как в v99
@Composable
fun Breathe(onClose: () -> Unit) {
    var say by remember { mutableStateOf("Вдох…") }
    val sc = remember { Animatable(0.45f) }
    LaunchedEffect(Unit) {
        repeat(5) {
            say = "Вдох…"
            sc.animateTo(1f, tween(4000))
            say = "Выдох…"
            sc.animateTo(0.45f, tween(6000))
        }
        say = "Хорошо. Можно возвращаться."
    }
    Sheet(onClose) {
        Text("Подышать", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(170.dp)) {
                drawCircle(Brush.radialGradient(listOf(Color(0x886EA8FF), Color(0x22B58CFF))), radius = size.minDimension / 2 * sc.value)
            }
        }
        Text(say, color = Muted, fontSize = 14.sp, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        Btn("Закрыть", Modifier.fillMaxWidth().padding(top = 14.dp)) { onClose() }
    }
}


// Раздел «Тест»: всё, что раньше висело поверх ленты. Считается само, ничего не обнуляется.
@Composable
fun PerfScreen(onBack: () -> Unit) {
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(700); tick++ } }
    val fmt = remember { java.text.SimpleDateFormat("dd.MM HH:mm", java.util.Locale.getDefault()) }
    val dim = Color.White.copy(alpha = 0.8f)
    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Text("← Назад", color = Acc, fontSize = 15.sp, modifier = Modifier.clickable { onBack() }.padding(bottom = 16.dp))
        Text("Тест · сборка " + Perf.BUILD, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        val t = tick
        Text(
            "Сейчас: ${Perf.fps} fps · ${Perf.hz} Гц · худший кадр ${Perf.worstMs} мс · лагов за 10 с: ${Perf.lags10s}" + if (t < 0) "" else "",
            color = dim, fontSize = 15.sp, modifier = Modifier.padding(top = 14.dp)
        )
        Text(
            "Земля ${EarthGate.renderMs.toInt()} мс${if (EarthGate.lite) " лайт" else ""} ×${EarthGate.scale} · осадки ${if (WxFx.on) "q" + WxFx.q else "выкл"} · стекло ${if (GlassInfo.lens) "линза" else "блюр"} э${GlassInfo.made}/к${GlassInfo.drawn} · API ${Build.VERSION.SDK_INT}",
            color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
        )
        Text("Сводка (ничего не обнуляется)", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 22.dp))
        fun r(x: Double) = String.format(java.util.Locale.US, "%.1f", x)
        Text("Последние 3 запуска: ${Perf.lagsLast(3)} лагов, ${r(Perf.rate(3))} на 1000 кадров", color = dim, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp))
        Text("Последние 10 запусков: ${Perf.lagsLast(10)} лагов, ${r(Perf.rate(10))} на 1000 кадров", color = dim, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp))
        Text("За всё время: ${Perf.totalLags} лагов в ${Perf.totalFrames} кадрах, запусков ${Perf.totalRuns}", color = dim, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp))
        Text("Ядро (эмбрион)", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 22.dp))
        Text(Core.report, color = dim, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        Text("Запуски (новые сверху)", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 22.dp))
        val list = Perf.runs.filter { it.frames > 0 }.takeLast(15).reversed()
        if (list.isEmpty()) Text("Пока нет данных", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
        for (x in list) {
            Text(
                "${fmt.format(java.util.Date(x.t))} · ${x.frames} кадров · лагов ${x.lags} (${r(x.lags * 1000.0 / x.frames)}/1000) · худший ${x.worstMs} мс",
                color = dim, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
            )
        }
        Text("Запуск = один запуск приложения. Лаг = кадр дольше 25 мс.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 18.dp))
    }
}
