package app.megastudiya.nativeapp

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

// AGENCY: слой целей и стратегий ядра. Порт модуля AgencyCore (Python) под Kotlin.
//  цель → стратегии (их предлагает наставник, если у владельца есть ключ) → ВЫБОР ЗА ВЛАДЕЛЬЦЕМ → итог → опыт.
// Главное правило оригинала сохранено: стратегия не считается принятой, пока владелец не сказал «одобряю N».
// Одобрение приходит из команды в чате. Единственное исключение (решение владельца 14.11.2026): Loop может автоодобрить
// стратегию-исследование от Purpose (R1, чтение разрешённых источников). Всё остальное только человек.
// Сама Agency ничего не исполняет: она хранит замысел, решение и результат. Исполняет человек или другие органы ядра.
// Память: файл agency_memory.json (те же ключи, что в Python-версии), запись через временный файл.
object Agency {
    private class Goal(val id: String, var title: String, var reason: String, var priority: Float, var progress: Float, var active: Boolean)
    private class Strat(val id: String, var num: Int, val goalId: String, val description: String, val expected: String, val risk: Float, var confidence: Float, var status: String, val src: String = "")
    private class Exp(val strategyId: String, val goalId: String, val expected: String, val actual: String, val success: Boolean, val ts: Long)
    private class Pos(val statement: String, val confidence: Float, val ts: Long)
    private class Begin(val msg: String?, val goalId: String = "", val prompt: String = "")

    private val goals = ArrayList<Goal>()
    private val strats = ArrayList<Strat>()
    private val exps = ArrayList<Exp>()
    private val positions = LinkedHashMap<String, Pos>()
    private val told = HashSet<String>()
    private var file: File? = null
    private var nextNum = 1
    private var seeded = false
    private var busy = false

    private val STATUSES = setOf("proposed", "authorized", "succeeded", "failed", "rejected")

    private const val SYS = "Ты компонент генерации стратегий автономного ядра по имени Аква. Ты только предлагаешь планы владельцу и сама ничего не исполняешь. Отвечай ТОЛЬКО валидным JSON, без пояснений и без markdown-ограждений."

    private fun pct(x: Float) = (x * 100f).toInt().toString() + "%"
    private fun rank(s: String) = when (s) { "proposed" -> 0; "authorized", "rejected" -> 1; else -> 2 }
    private fun statusName(s: String) = when (s) {
        "proposed" -> "ждёт решения"; "authorized" -> "одобрена"; "succeeded" -> "получилась"; "failed" -> "не вышла"; else -> "отклонена"
    }

    // ===== Память =====
    @Synchronized
    fun init(ctx: Context) {
        if (file != null) return
        val f = File(ctx.applicationContext.filesDir, "agency_memory.json")
        file = f
        if (f.exists()) {
            try {
                mergeIn(JSONObject(f.readText(Charsets.UTF_8)), true)
            } catch (_: Throwable) {
                runCatching { f.copyTo(File(f.parentFile, "agency_memory.json.bad"), overwrite = true) }
                goals.clear(); strats.clear(); exps.clear(); positions.clear(); seeded = false; nextNum = 1
            }
        }
        // Первая цель — из твоего примера. Если ты её закроешь, она не вернётся.
        if (!seeded && goals.isEmpty()) {
            goals.add(Goal(UUID.randomUUID().toString(), "Развивать собственную базу знаний", "Уменьшать зависимость от внешних источников", 0.9f, 0f, true))
        }
        seeded = true
        save()
    }

    private fun trim() {
        while (strats.size > 300) {
            val i = strats.indexOfFirst { it.status == "succeeded" || it.status == "failed" || it.status == "rejected" }
            if (i < 0) break
            strats.removeAt(i)
        }
        while (exps.size > 500) exps.removeAt(0)
    }

    private fun save() {
        val f = file ?: return
        try {
            trim()
            val t = File(f.parentFile, f.name + ".tmp")
            t.writeText(toJson().toString(), Charsets.UTF_8)
            if (!t.renameTo(f)) { f.delete(); t.renameTo(f) }
        } catch (_: Throwable) {
        }
    }

    private fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("seeded", seeded)
        o.put("next", nextNum)
        val ga = JSONArray()
        for (g in goals) ga.put(JSONObject().put("id", g.id).put("title", g.title).put("reason", g.reason).put("priority", g.priority.toDouble()).put("progress", g.progress.toDouble()).put("active", g.active))
        o.put("goals", ga)
        val sa = JSONArray()
        for (s in strats) sa.put(JSONObject().put("id", s.id).put("num", s.num).put("goal_id", s.goalId).put("description", s.description).put("expected_result", s.expected).put("risk", s.risk.toDouble()).put("confidence", s.confidence.toDouble()).put("status", s.status).put("src", s.src))
        o.put("strategies", sa)
        val ea = JSONArray()
        for (e in exps) ea.put(JSONObject().put("strategy_id", e.strategyId).put("goal_id", e.goalId).put("expected", e.expected).put("actual", e.actual).put("success", e.success).put("timestamp", e.ts / 1000.0))
        o.put("experiences", ea)
        val po = JSONObject()
        for ((k, p) in positions) po.put(k, JSONObject().put("statement", p.statement).put("confidence", p.confidence.toDouble()).put("updated_at", p.ts / 1000.0))
        o.put("positions", po)
        return o
    }

    // Один путь и для загрузки с диска, и для слияния из файла переезда: ничего не теряем, берём более продвинутое состояние
    private fun mergeIn(o: JSONObject, keepNums: Boolean) {
        seeded = seeded || o.optBoolean("seeded", false)
        nextNum = maxOf(nextNum, o.optInt("next", 1))
        val ga = o.optJSONArray("goals") ?: JSONArray()
        for (i in 0 until ga.length()) {
            val x = ga.optJSONObject(i) ?: continue
            val id = x.optString("id", "")
            val title = x.optString("title", "").trim().take(200)
            if (id.isEmpty() || title.isEmpty()) continue
            val prog = x.optDouble("progress", 0.0).toFloat().coerceIn(0f, 1f)
            val have = goals.firstOrNull { it.id == id }
            if (have != null) { if (prog > have.progress) have.progress = prog; continue }
            goals.add(Goal(id, title, x.optString("reason", "").take(300), x.optDouble("priority", 0.5).toFloat().coerceIn(0f, 1f), prog, x.optBoolean("active", true)))
        }
        val sa = o.optJSONArray("strategies") ?: JSONArray()
        for (i in 0 until sa.length()) {
            val x = sa.optJSONObject(i) ?: continue
            val id = x.optString("id", "")
            val gid = x.optString("goal_id", "")
            if (id.isEmpty() || goals.none { it.id == gid }) continue
            var st = x.optString("status", "proposed")
            if (st !in STATUSES) st = "proposed"
            val have = strats.firstOrNull { it.id == id }
            if (have != null) { if (rank(st) > rank(have.status)) have.status = st; continue }
            val desc = x.optString("description", "").trim().take(400)
            if (desc.isEmpty()) continue
            var n = if (keepNums) x.optInt("num", 0) else 0
            if (n <= 0 || strats.any { it.num == n }) n = nextNum
            nextNum = maxOf(nextNum, n + 1)
            strats.add(Strat(id, n, gid, desc, x.optString("expected_result", "").take(300),
                x.optDouble("risk", 1.0).toFloat().coerceIn(0f, 1f), x.optDouble("confidence", 0.0).toFloat().coerceIn(0f, 1f), st,
                if (keepNums) x.optString("src", "") else ""))
        }
        val ea = o.optJSONArray("experiences") ?: JSONArray()
        for (i in 0 until ea.length()) {
            val x = ea.optJSONObject(i) ?: continue
            val sid = x.optString("strategy_id", "")
            val ts = (x.optDouble("timestamp", 0.0) * 1000.0).toLong()
            if (sid.isEmpty() || exps.any { it.strategyId == sid && it.ts == ts }) continue
            val gid = x.optString("goal_id", "").ifEmpty { strats.firstOrNull { it.id == sid }?.goalId ?: "" }
            exps.add(Exp(sid, gid, x.optString("expected", "").take(300), x.optString("actual", "").take(500), x.optBoolean("success", false), ts))
        }
        val po = o.optJSONObject("positions")
        if (po != null) {
            val it = po.keys()
            while (it.hasNext()) {
                val k = it.next()
                val x = po.optJSONObject(k) ?: continue
                val ts = (x.optDouble("updated_at", 0.0) * 1000.0).toLong()
                val have = positions[k]
                if (have == null || ts > have.ts) positions[k] = Pos(x.optString("statement", "").take(400), x.optDouble("confidence", 0.5).toFloat().coerceIn(0f, 1f), ts)
            }
        }
    }

    // Для «Экспорта копии» и связи между телефонами (вызывает Core.snapshot / Core.merge)
    @Synchronized fun exportJson(): JSONObject = toJson()

    @Synchronized
    fun merge(o: JSONObject) {
        try { mergeIn(o, false); save() } catch (_: Throwable) { }
    }

    // ===== Цели =====
    private fun activeGoals() = goals.filter { it.active }.sortedByDescending { it.priority }

    @Synchronized
    fun goalsText(): String {
        val ag = activeGoals()
        if (ag.isEmpty()) return "Целей пока нет. Добавь: «цель: название | зачем»."
        val sb = StringBuilder("Мои цели:")
        for ((i, g) in ag.withIndex()) {
            val open = strats.count { it.goalId == g.id && it.status == "proposed" }
            val run = strats.count { it.goalId == g.id && it.status == "authorized" }
            sb.append("\n${i + 1}. ${g.title} · прогресс ${pct(g.progress)}, важность ${pct(g.priority)}")
            if (g.reason.isNotBlank()) sb.append("\n   зачем: ${g.reason}")
            if (open + run > 0) sb.append("\n   стратегий: ждут решения $open, в работе $run")
        }
        sb.append("\n\n«стратегии» — предложу, как двигаться к главной цели. «закрой цель N» — убрать цель.")
        return sb.toString()
    }

    @Synchronized
    fun addGoal(title: String, reason: String, priority: Float): String {
        val t = title.trim().take(200)
        if (t.isEmpty()) return "Что за цель?"
        goals.add(Goal(UUID.randomUUID().toString(), t, reason.trim().take(300), priority.coerceIn(0f, 1f), 0f, true))
        save()
        return "Цель записала: «$t», важность ${pct(priority.coerceIn(0f, 1f))}."
    }

    @Synchronized
    fun closeGoal(n: Int): String {
        val g = activeGoals().getOrNull(n - 1) ?: return "Такой цели нет. Список: «цели»."
        g.active = false
        for (s in strats) if (s.goalId == g.id && (s.status == "proposed")) { s.status = "rejected"; if (s.src.isNotEmpty()) Purpose.onDecision(s.src, false) }
        save()
        return "Цель «${g.title}» закрыла."
    }

    // ===== Стратегии =====
    private fun line(s: Strat) = "№${s.num}. ${s.description}\n   ждём: ${s.expected} · риск ${pct(s.risk)}, уверенность ${pct(s.confidence)}"

    // Прошлый опыт по цели подправляет уверенность: уверенность наставника смешивается с тем, как часто это получалось у меня
    private fun score(s: Strat): Float {
        val mine = exps.filter { it.goalId == s.goalId }
        val conf = if (mine.size >= 3) 0.7f * s.confidence + 0.3f * ((mine.count { it.success } + 1f) / (mine.size + 2f)) else s.confidence
        return conf - s.risk
    }

    private fun promptFor(g: Goal, context: String): String {
        val past = exps.filter { it.goalId == g.id }.takeLast(5)
            .joinToString("\n") { "- ждала: ${it.expected.take(150)}; вышло: ${it.actual.take(150)}; " + (if (it.success) "успех" else "неудача") }
        val goal = JSONObject().put("title", g.title).put("reason", g.reason).put("priority", g.priority.toDouble()).put("progress", g.progress.toDouble())
        return "ЦЕННОСТИ:\n" + Core.VALUES + "\n\nЦЕЛЬ:\n" + goal.toString() + "\n\nСОСТОЯНИЕ:\n" + context + "\n" +
            (if (past.isNotEmpty()) "\nПРОШЛЫЙ ОПЫТ ПО ЭТОЙ ЦЕЛИ:\n$past\n" else "") +
            "\nПредложи 3 разные стратегии. Поля description и expected_result пиши по-русски, коротко (до 250 символов).\n" +
            "Верни ТОЛЬКО валидный JSON:\n" +
            "{\"strategies\":[{\"description\":\"Стратегия\",\"expected_result\":\"Ожидаемый результат\",\"risk\":0.2,\"confidence\":0.8}]}\n" +
            "risk и confidence — числа от 0 до 1.\n\nПравила:\n" +
            "- Не выдумывай факты.\n- Честно отмечай неопределённость.\n" +
            "- Не используй обман, принуждение и манипуляции.\n- Не обходи разрешения и ограничения.\n" +
            "- Предпочитай обратимые и малорисковые действия.\n- Учитывай прошлый опыт, если он есть."
    }

    @Synchronized
    private fun begin(context: String): Begin {
        if (busy) return Begin("Уже думаю над этим, подожди ответа.")
        val g = activeGoals().firstOrNull() ?: return Begin("Целей пока нет. Добавь: «цель: название | зачем».")
        val open = strats.filter { it.goalId == g.id && it.status == "proposed" }
        if (open.isNotEmpty()) return Begin("По цели «${g.title}» уже есть стратегии на твоём решении:\n" + open.joinToString("\n") { line(it) } + "\n\n«одобряю N» или «отклоняю N».")
        busy = true
        return Begin(null, g.id, promptFor(g, context))
    }

    @Synchronized private fun release() { busy = false }

    // Стратегии для главной цели. Нужен ключ наставника: без него придумать их я не умею.
    fun propose(ctx: Context, cb: (String) -> Unit) {
        val b = begin(Core.agencyContext())
        if (b.msg != null) { cb(b.msg); return }
        Mentor.complete(ctx, SYS, b.prompt, 1500) { text, err ->
            if (text == null) { release(); cb(err ?: "Не вышло.") } else cb(finish(b.goalId, text))
        }
    }

    @Synchronized
    private fun finish(goalId: String, raw: String): String {
        busy = false
        val g = goals.firstOrNull { it.id == goalId } ?: return "Цель за это время пропала."
        val made = ArrayList<Strat>()
        try {
            val a = raw.indexOf('{')
            val z = raw.lastIndexOf('}')
            val arr = JSONObject(raw.substring(a, z + 1)).optJSONArray("strategies")
            if (arr != null) for (i in 0 until minOf(arr.length(), 3)) {
                val x = arr.optJSONObject(i) ?: continue
                val d = x.optString("description", "").trim().take(400)
                val risk = x.optDouble("risk", -1.0)
                val conf = x.optDouble("confidence", -1.0)
                if (d.isEmpty() || risk !in 0.0..1.0 || conf !in 0.0..1.0) continue
                made.add(Strat(UUID.randomUUID().toString(), 0, g.id, d, x.optString("expected_result", "").trim().take(300), risk.toFloat(), conf.toFloat(), "proposed"))
            }
        } catch (_: Throwable) {
        }
        if (made.isEmpty()) return "Наставник ответил не в том виде, как я просила, разобрать не смогла. Попробуй «стратегии» ещё раз."
        for (s in made) { s.num = nextNum++; strats.add(s); told.add(s.id) }
        save()
        val best = made.maxByOrNull { score(it) }!!
        return "Цель: «${g.title}». Предлагаю:\n" + made.joinToString("\n") { line(it) } +
            "\n\nБольше всего верю в №${best.num}.\n«одобряю N» — тогда считаю её принятой, «отклоняю N» — откладываю. Без твоего слова ничего принятым не считаю."
    }

    // Предложение от другого органа (Purpose): ложится в ту же очередь «ждёт решения». Одобрить его может только владелец.
    // Возвращает номер стратегии, 0 — если нет активной цели.
    @Synchronized
    fun submitProposal(src: String, text: String, expected: String, risk: Float, conf: Float): Int {
        strats.firstOrNull { it.src == src }?.let { return it.num }
        val g = activeGoals().firstOrNull() ?: return 0
        val s = Strat(UUID.randomUUID().toString(), nextNum++, g.id, text.trim().take(400), expected.trim().take(300), risk.coerceIn(0f, 1f), conf.coerceIn(0f, 1f), "proposed", src)
        strats.add(s)
        save()
        return s.num
    }

    class Cand(val num: Int, val projectId: String, val text: String, val expected: String, val risk: Float, val status: String)

    // Для Loop: стратегии, пришедшие от Purpose и ещё не исполненные (одобренные первыми)
    @Synchronized
    fun loopCandidates(): List<Cand> = strats.filter { it.src.isNotEmpty() && (it.status == "proposed" || it.status == "authorized") }
        .sortedBy { if (it.status == "authorized") 0 else 1 }
        .map { Cand(it.num, it.src, it.description, it.expected, it.risk, it.status) }

    // Автоодобрение только для Loop и только для стратегий от Purpose. Проверку класса R1 делает Loop.
    @Synchronized
    fun autoAuthorize(num: Int): Boolean {
        val s = strats.firstOrNull { it.num == num } ?: return false
        if (s.status != "proposed" || s.src.isEmpty()) return false
        s.status = "authorized"
        Purpose.onDecision(s.src, true)
        save()
        return true
    }

    // Решение владельца. Это основное место, где стратегия становится одобренной.
    @Synchronized
    fun decide(num: Int, approve: Boolean): String {
        val s = strats.firstOrNull { it.num == num } ?: return "Стратегии №$num нет."
        if (s.status != "proposed") return "Стратегия №$num уже в статусе «${statusName(s.status)}»."
        s.status = if (approve) "authorized" else "rejected"
        if (s.src.isNotEmpty()) Purpose.onDecision(s.src, approve)
        save()
        return if (approve) "Принято: №$num. Когда что-то выйдет, скажи: «итог $num: успех: что получилось» или «итог $num: неудача: что случилось». Можно добавить «+15%», насколько цель продвинулась."
        else "Отложила №$num."
    }

    // Итог: что вышло на самом деле. Только по одобренной стратегии.
    @Synchronized
    fun observe(num: Int, success: Boolean, actual: String, delta: Float): String {
        val s = strats.firstOrNull { it.num == num } ?: return "Стратегии №$num нет."
        if (s.status != "authorized") return if (s.status == "proposed") "№$num ещё не одобрена. Сначала «одобряю $num»." else "По №$num итог уже записан, либо она отклонена."
        val g = goals.firstOrNull { it.id == s.goalId }
        s.status = if (success) "succeeded" else "failed"
        if (g != null) g.progress = (g.progress + delta).coerceIn(0f, 1f)
        exps.add(Exp(s.id, s.goalId, s.expected, actual.take(500), success, System.currentTimeMillis()))
        s.confidence = (s.confidence + if (success) 0.05f else -0.05f).coerceIn(0f, 1f)
        save()
        if (s.src.isNotEmpty()) Purpose.onResult(s.src, success, actual)
        Core.read(listOf(actual)) // как и твои посты, итог она читает и учится на нём
        return "Записала: №$num — " + (if (success) "получилось" else "не вышло") + "." +
            (if (g != null) " Цель «${g.title}»: прогресс ${pct(g.progress)}." else "") +
            " Опыт учту при выборе следующих стратегий."
    }

    // ===== Позиции: что она считает верным и насколько уверена =====
    @Synchronized
    fun setPosition(topic: String, statement: String, conf: Float): String {
        val t = topic.trim().take(80)
        val s = statement.trim().take(400)
        if (t.isEmpty() || s.isEmpty()) return "Так: «позиция: тема = утверждение | уверенность 0–1»"
        positions[t] = Pos(s, conf.coerceIn(0f, 1f), System.currentTimeMillis())
        save()
        return "Позицию по теме «$t» записала, уверенность ${pct(conf.coerceIn(0f, 1f))}."
    }

    @Synchronized
    fun positionsText(): String =
        if (positions.isEmpty()) "Позиций пока нет. «позиция: тема = утверждение»."
        else "Мои позиции:\n" + positions.entries.joinToString("\n") { (k, p) -> "• $k: ${p.statement} (уверенность ${pct(p.confidence)})" }

    // ===== Для чата и отчёта ядра =====
    // Стратегии, которые ждут решения и о которых я ещё не говорила в этом запуске
    @Synchronized
    fun pending(): String {
        val open = strats.filter { it.status == "proposed" && it.id !in told }
        if (open.isEmpty()) return ""
        for (s in open) told.add(s.id)
        return "Стратегии ждут твоего решения:\n" + open.joinToString("\n") { line(it) } + "\n\n«одобряю N» или «отклоняю N»."
    }

    @Synchronized
    fun line(): String =
        "активных ${goals.count { it.active }} · стратегий ждут решения ${strats.count { it.status == "proposed" }}, в работе ${strats.count { it.status == "authorized" }} · опыта ${exps.size}"
}
