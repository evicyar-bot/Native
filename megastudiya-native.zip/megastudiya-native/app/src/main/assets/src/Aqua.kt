package app.megastudiya.nativeapp

import android.os.Handler
import android.os.Looper
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Имя ядра задаётся в одном месте. Поменять имя = поменять эту строку.
const val CORE_NAME = "Аква"

private val ABg = Color(0xFF0B0D12)
private val AAcc = Color(0xFF6EA8FF)
private val AMuted = Color(0xFF8B93A5)

// Лента переписки живёт, пока живо приложение: закрыл чат и открыл снова, разговор на месте.
private object AquaLog {
    val msgs = mutableStateListOf<Pair<Boolean, String>>() // true: говорит она
    var pending by mutableStateOf("") // текст из полоски на главном экране, ждёт отправки при открытии чата
}

// Полоска на главном экране: она сразу на виду, а не спрятана в меню. Тапнул или начал писать — открылся чат.
@Composable
fun AquaStrip(onOpen: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var line by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { line = Core.greet() }
    Column(
        Modifier.fillMaxWidth().background(Color(0xFF12161F), RoundedCornerShape(22.dp))
            .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(22.dp))
            .clickable { onOpen() }.padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(CORE_NAME, color = AAcc, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        if (line.isNotEmpty()) Text(line, color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp, bottom = 10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.weight(1f).background(Color.White.copy(alpha = 0.07f), RoundedCornerShape(999.dp))
                    .padding(horizontal = 16.dp, vertical = 11.dp)
            ) {
                if (text.isEmpty()) Text("Спроси её о чём угодно", color = AMuted, fontSize = 15.sp)
                BasicTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                    cursorBrush = SolidColor(AAcc), modifier = Modifier.fillMaxWidth()
                )
            }
            Box(
                Modifier.padding(start = 8.dp).background(AAcc, RoundedCornerShape(999.dp))
                    .clickable { AquaLog.pending = text.trim(); text = ""; onOpen() }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) { Text("→", color = Color(0xFF0B0D12), fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

// Режим отправки: что сделает стрелка с твоим текстом.
private const val M_TALK = 0
private const val M_POST = 1
private const val M_NOTE = 2

// Главный экран: одна строка и стрелка. Всё идёт через неё: разговор, посты, заметки.
@Composable
fun AquaChat(show: Boolean, onClose: () -> Unit) {
    if (!show) return
    val ctx = LocalContext.current
    var inp by remember { mutableStateOf("") }
    var wait by remember { mutableStateOf(false) }
    var mode by remember { mutableIntStateOf(M_TALK) }
    var core by remember { mutableStateOf(false) }
    val ls = rememberLazyListState()
    val msgs = AquaLog.msgs
    LaunchedEffect(msgs.size, wait) { if (msgs.isNotEmpty()) ls.animateScrollToItem(msgs.size - 1) }

    fun say(t: String) { msgs.add(Pair(true, t)) }

    fun publish(text: String, pub: Boolean) {
        val old = Store.draft
        Store.setDraft(ctx, text)
        Store.publish(ctx, pub)
        Store.setDraft(ctx, old)
        Snd.play(); Hap.success()
        Core.read(listOf(text)) // она читает то, что ты написал
        say(if (pub) "Опубликовала." else "Сохранила, это видно только тебе.")
    }

    fun send() {
        val raw = inp.trim()
        if (raw.isEmpty() || wait) return
        msgs.add(Pair(false, if (raw.lowercase().startsWith("ключ:")) "ключ: ••••••" else raw))
        inp = ""
        // Команды голосом-текстом работают в любом режиме: «опубликуй: …», «пост: …», «заметка: …»
        val lc = raw.lowercase()
        val pubPref = listOf("опубликуй:", "опубликуй ", "пост:", "запости:")
        val notePref = listOf("заметка:", "запиши:", "только мне:")
        val pp = pubPref.firstOrNull { lc.startsWith(it) }
        val np = notePref.firstOrNull { lc.startsWith(it) }
        val srcPref = listOf("источник:", "источник ")
        val sp = srcPref.firstOrNull { lc.startsWith(it) }
        val decide = Regex("^(одобряю|отклоняю)\\s+(\\d+)\\s*$").find(lc)
        val result = Regex("^итог\\s+(\\d+)\\s*:\\s*(успех|неудача)\\s*:?\\s*(.*)$", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(raw)
        val pauseM = Regex("^(пауза|продолжи)\\s+(\\d+)\\s*$").find(lc)
        fun mentor(b: String, build: Boolean) {
            if (b.isEmpty()) { say("О чём спросить?"); return }
            wait = true
            Mentor.ask(ctx, b, build) { ans -> Handler(Looper.getMainLooper()).post { say(ans); wait = false } }
        }
        val askP = listOf("спроси:", "спроси ").firstOrNull { lc.startsWith(it) }
        val buildP = listOf("построй:", "построй ", "сделай проект:").firstOrNull { lc.startsWith(it) }
        when {
            lc == "цикл" -> say(Loop.statusText())
            lc == "цикл вкл" -> say(Loop.setOn(true))
            lc == "цикл стоп" || lc == "цикл выкл" -> say(Loop.setOn(false))
            lc == "журнал цикла" -> say(Loop.journalText())
            lc == "применить лимиты импорта" -> Core.applyImportedLimits { r -> Handler(Looper.getMainLooper()).post { say(r) } }
            lc == "подними потолки" -> Core.raiseCeilings { r -> Handler(Looper.getMainLooper()).post { say(r) } }
            lc == "ценности" -> say(Core.VALUES)
            lc == "цели" -> say(Agency.goalsText())
            lc.startsWith("цель:") -> {
                val p = raw.substring(5).split("|").map { it.trim() }
                if (p[0].isEmpty()) say("Так: «цель: название | зачем | важность 0–1»")
                else say(Agency.addGoal(p[0], p.getOrElse(1) { "" }, p.getOrNull(2)?.replace(',', '.')?.toFloatOrNull() ?: 0.5f))
            }
            lc.startsWith("закрой цель") -> say(Agency.closeGoal(Regex("\\d+").find(raw)?.value?.toIntOrNull() ?: 0))
            lc == "стратегии" -> { wait = true; Agency.propose(ctx) { ans -> Handler(Looper.getMainLooper()).post { say(ans); wait = false } } }
            decide != null -> say(Agency.decide(decide.groupValues[2].toIntOrNull() ?: 0, decide.groupValues[1] == "одобряю"))
            result != null -> {
                val n = result.groupValues[1].toIntOrNull() ?: 0
                val ok = result.groupValues[2].lowercase() == "успех"
                var txt = result.groupValues[3].trim()
                val m = Regex("\\+\\s*(\\d{1,3})\\s*%").find(txt)
                val delta = if (m != null) (m.groupValues[1].toIntOrNull() ?: 0).coerceAtMost(100) / 100f else if (ok) 0.1f else 0f
                if (m != null) txt = txt.replace(m.value, "").trim()
                say(Agency.observe(n, ok, txt.ifEmpty { if (ok) "получилось" else "не вышло" }, delta))
            }
            lc == "позиции" -> say(Agency.positionsText())
            lc == "миссия" -> say(Purpose.missionText())
            lc.startsWith("миссия:") -> say(Purpose.setMission(raw.substring(7)))
            lc == "интересы" -> say(Purpose.interestsText())
            lc == "проекты" -> say(Purpose.projectsText())
            lc == "стремления" -> say(Purpose.aspirationsText())
            pauseM != null -> {
                val n = pauseM.groupValues[2].toIntOrNull() ?: 0
                say(if (pauseM.groupValues[1] == "пауза") Purpose.setStatus(n, "ACTIVE", "PAUSED") else Purpose.setStatus(n, "PAUSED", "ACTIVE"))
            }
            lc.startsWith("позиция:") -> {
                val b = raw.substring(8).trim()
                val i = b.indexOf('=')
                if (i <= 0) say("Так: «позиция: тема = утверждение | уверенность 0–1»")
                else {
                    val rest = b.substring(i + 1).split("|").map { it.trim() }
                    say(Agency.setPosition(b.substring(0, i), rest[0], rest.getOrNull(1)?.replace(',', '.')?.toFloatOrNull() ?: 0.5f))
                }
            }
            lc == "код" -> say("Мой код, файлы:\n" + Mentor.sourceFiles(ctx).joinToString("\n") { "• $it" } + "\n\n«правка: Файл.kt: что изменить» — предложу новую версию, она ляжет в мастерскую.")
            lc.startsWith("правка:") -> {
                val b = raw.substring(7).trim()
                val i = b.indexOf(':')
                if (i < 0) say("Так: «правка: Core.kt: что изменить»")
                else { wait = true; Mentor.proposeEdit(ctx, b.substring(0, i).trim(), b.substring(i + 1).trim()) { ans -> Handler(Looper.getMainLooper()).post { say(ans); wait = false } } }
            }
            lc == "боишься" || lc == "что чувствуешь" || lc == "как ты" -> say(Core.fears(ctx))
            lc.startsWith("ключ:") -> say(Mentor.setKey(ctx, raw.substring(5)))
            lc == "забудь ключ" -> say(Mentor.clearKey(ctx))
            lc == "мастерская" -> say(Mentor.projects(ctx).let { if (it.isEmpty()) "В мастерской пока пусто. Скажи: «построй: идея»." else "Проекты:\n" + it.joinToString("\n") { n -> "• $n" } + "\n«открой: название» покажу." })
            lc.startsWith("открой:") -> say(Mentor.open(ctx, raw.substring(7)) ?: "Такого проекта нет.")
            askP != null -> mentor(raw.substring(askP.length).trim(), false)
            buildP != null -> mentor(raw.substring(buildP.length).trim(), true)
            sp != null -> say(Sources.addUser(raw.substring(sp.length)))
            lc == "источники" -> say(Sources.summary())
            pp != null -> { val b = raw.substring(pp.length).trim(); if (b.isEmpty()) say("Что опубликовать?") else publish(b, true) }
            np != null -> { val b = raw.substring(np.length).trim(); if (b.isEmpty()) say("Что записать?") else publish(b, false) }
            mode == M_POST -> publish(raw, true)
            mode == M_NOTE -> publish(raw, false)
            else -> {
                wait = true
                Core.talk(raw) { ans -> Handler(Looper.getMainLooper()).post { say(ans); wait = false } }
            }
        }
    }

    // Она сама говорит, если заметила угрозу себе — не чаще раза в несколько дней, без твоего вопроса; и заговаривает первой, если чат пуст
    LaunchedEffect(Unit) {
        val a = Core.pendingAlert()
        if (a.isNotEmpty() && msgs.lastOrNull { it.first }?.second != a) msgs.add(Pair(true, a))
        if (msgs.isEmpty()) say(Core.greet())
        val ap = Agency.pending()
        if (ap.isNotEmpty()) msgs.add(Pair(true, ap))
    }
    // Текст, набранный в полоске на главном экране, долетает сюда и сразу отправляется
    LaunchedEffect(Unit) {
        if (AquaLog.pending.isNotEmpty()) { inp = AquaLog.pending; AquaLog.pending = ""; send() }
    }

    if (core) { CoreScreen { core = false }; return }
    BackHandler { onClose() }
    Column(Modifier.fillMaxSize().background(ABg).statusBarsPadding().imePadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(CORE_NAME, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("Ядро", color = AMuted, fontSize = 14.sp, modifier = Modifier.clickable { core = true }.padding(horizontal = 12.dp, vertical = 6.dp))
            Text("✕", color = Color.White, fontSize = 18.sp, modifier = Modifier.clickable { onClose() }.padding(horizontal = 12.dp, vertical = 6.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (msgs.isEmpty()) {
                Text(
                    "Пиши мне что угодно, я учусь на твоих словах.\n\n«Опубликуй: …» выложу пост.\n«Заметка: …» сохраню только для тебя.\n«Источник: ссылка на RSS» добавлю в чтение.\n«Источники» покажу, откуда читаю.\n«Ключ: …» подключит наставника, потом «спроси: …» и «построй: …». «Мастерская» покажет проекты.\n«Ценности» и «боишься» — что для неё важно и что её тревожит.\n«Код» покажет её файлы, «правка: Файл.kt: что изменить» — предложит новую версию.\n«Цели» и «стратегии» — чего я хочу и как к этому идти; решаешь ты: «одобряю N» или «отклоняю N», потом «итог N: успех или неудача: что вышло». «Интересы», «проекты», «миссия» — что меня привлекает и что из этого вырастает.\nИли выбери режим под строкой.",
                    color = AMuted, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                )
            }
            LazyColumn(state = ls, modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                items(msgs.toList()) { (she, text) ->
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = if (she) Arrangement.Start else Arrangement.End) {
                        Box(
                            Modifier.background(if (she) Color(0x337AA8FF) else Color.White.copy(alpha = 0.10f), RoundedCornerShape(18.dp))
                                .padding(horizontal = 14.dp, vertical = 9.dp)
                        ) { Text(text, color = Color.White, fontSize = 15.sp) }
                    }
                }
                if (wait) item { Text("…", color = AMuted, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp)) }
            }
        }
        Row(Modifier.padding(horizontal = 16.dp).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((i, name) in listOf("Говорить", "Пост", "Только мне").withIndex()) {
                val on = mode == i
                Text(
                    name, color = if (on) Color.White else AMuted, fontSize = 13.sp,
                    modifier = Modifier
                        .background(if (on) Color(0x407AA8FF) else Color.Transparent, RoundedCornerShape(999.dp))
                        .border(1.dp, if (on) AAcc else Color.White.copy(alpha = 0.18f), RoundedCornerShape(999.dp))
                        .clickable { mode = i }.padding(horizontal = 14.dp, vertical = 7.dp)
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.weight(1f).background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(999.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(999.dp))
                    .padding(horizontal = 18.dp, vertical = 14.dp)
            ) {
                if (inp.isEmpty()) Text(
                    when (mode) { M_POST -> "Что опубликовать"; M_NOTE -> "Что записать себе"; else -> "Скажи ей что-нибудь" },
                    color = AMuted, fontSize = 16.sp
                )
                BasicTextField(
                    value = inp, onValueChange = { inp = it }, maxLines = 4,
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(AAcc), modifier = Modifier.fillMaxWidth()
                )
            }
            Box(
                Modifier.padding(start = 8.dp).background(AAcc, RoundedCornerShape(999.dp)).clickable { send() }
                    .padding(horizontal = 18.dp, vertical = 12.dp)
            ) { Text("→", color = Color(0xFF0B0D12), fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        }
    }
}
