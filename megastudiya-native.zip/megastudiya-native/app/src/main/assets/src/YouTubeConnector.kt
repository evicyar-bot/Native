package app.megastudiya.nativeapp

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

// YouTube через официальные интерфейсы Google:
//  1) YouTube Data API v3 (ключ API): метаданные роликов, чарт «популярное» по региону, загрузки канала, поиск.
//  2) IFrame Player API: встроенный плеер (только для роликов с status.embeddable = true).
// Видеофайлы НЕ скачиваются. Файл автономный: зависит только от VideoSource/MetaResult/LinkInfo/MhTags/YouTubeSource.
//
// Квота (по умолчанию 10 000 единиц в сутки): videos.list / channels.list / playlistItems.list = 1, search.list = 100.
// Подключение: в VideoSources.all заменить YouTubeSource на YouTubeApiSource (id тот же — "youtube").
// Ключ задаётся при запуске: YouTubeConfig.apiKey = "...". Ограничьте ключ в Google Cloud по приложению Android
// и пропишите YouTubeConfig.androidPackage / androidCertSha1 — они уйдут заголовками X-Android-Package / X-Android-Cert.

object YouTubeConfig {
    @Volatile var apiKey: String = ""
    @Volatile var androidPackage: String = ""
    @Volatile var androidCertSha1: String = ""          // SHA-1 подписи, hex без двоеточий
    // Origin/Referer встроенного плеера. Собственного сайта нет: используется адрес, выведенный из идентификатора приложения
    // (https://<package>, см. ConnectorSetup.init). Запросов на этот адрес никто не делает — он нужен только как идентификатор клиента.
    @Volatile var embedOrigin: String = ""
    @Volatile var legacyOrigin: String = ""   // прежний выдуманный адрес: оставлен только для встроенного плеера TikTok
    val configured: Boolean get() = apiKey.isNotBlank()
}

class YtApiException(val http: Int, val reason: String) : Exception("YouTube API $http: $reason") {
    val quota: Boolean
        get() = reason == "quotaExceeded" || reason == "dailyLimitExceeded" ||
            reason == "rateLimitExceeded" || reason == "userRateLimitExceeded"
}

data class YtVideo(
    val id: String,
    val title: String,
    val channelId: String,
    val channelTitle: String,
    val description: String,
    val thumb: String,
    val publishedMs: Long,
    val durationMs: Long,
    val tags: List<String>,
    val embeddable: Boolean,
    val privacy: String,            // public | unlisted | private
    val live: String,               // none | live | upcoming
    val views: Long,
    val likes: Long,
    val region: String = ""         // регион чарта, если ролик получен из mostPopular (не страна ролика)
) {
    val url: String get() = "https://www.youtube.com/watch?v=$id"
    /** Эвристика: официального признака Shorts в API нет. */
    val shortLike: Boolean get() = durationMs in 1..180_000
    fun toMeta(): MetaResult.Ok = MetaResult.Ok(title.take(120), channelTitle, description.take(600), thumb, id, publishedMs)
}

class YtPage(val items: List<YtVideo>, val next: String)

private object YtHttp {
    class Res(val code: Int, val body: String)

    fun get(url: String, headers: Map<String, String>): Res {
        val conn = try { URL(url).openConnection() as HttpURLConnection } catch (_: Exception) { return Res(-1, "badUrl") }
        try {
            conn.requestMethod = "GET"
            conn.connectTimeout = 7000
            conn.readTimeout = 10000
            conn.instanceFollowRedirects = false
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            val code = conn.responseCode
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            val text = stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            return Res(code, text)
        } catch (e: Exception) {
            return Res(-1, e.javaClass.simpleName)
        } finally {
            try { conn.disconnect() } catch (_: Throwable) { }
        }
    }
}

/** Все методы блокирующие: вызывать только не на главном потоке. Ошибки — YtApiException. */
object YouTubeApi {
    private const val BASE = "https://www.googleapis.com/youtube/v3/"
    private const val PART = "snippet,contentDetails,statistics,status"
    private const val TTL_MS = 10 * 60 * 1000L
    private val regionRe = Regex("^[A-Za-z]{2}$")
    private val durRe = Regex("^P(?:(\\d+)D)?(?:T(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?)?$")

    private class Hit(val at: Long, val v: YtVideo)

    // Короткий кэш: после выдачи списка fetchMeta по тем же роликам не тратит квоту.
    private val cache = object : LinkedHashMap<String, Hit>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Hit>?): Boolean = size > 300
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun call(method: String, params: Map<String, String>): JSONObject {
        val key = YouTubeConfig.apiKey
        if (key.isBlank()) throw YtApiException(0, "noKey")
        val qs = params.entries.joinToString("&") { enc(it.key) + "=" + enc(it.value) }
        val h = HashMap<String, String>()
        h["X-Goog-Api-Key"] = key
        h["Accept"] = "application/json"
        if (YouTubeConfig.androidPackage.isNotBlank()) h["X-Android-Package"] = YouTubeConfig.androidPackage
        if (YouTubeConfig.androidCertSha1.isNotBlank()) h["X-Android-Cert"] = YouTubeConfig.androidCertSha1
        val r = YtHttp.get(BASE + method + "?" + qs, h)
        if (r.code < 0) throw YtApiException(-1, r.body)
        val o = try { JSONObject(r.body) } catch (_: Exception) { throw YtApiException(r.code, "badJson") }
        if (r.code !in 200..299) {
            val reason = o.optJSONObject("error")?.optJSONArray("errors")?.optJSONObject(0)?.optString("reason").orEmpty()
            throw YtApiException(r.code, reason.ifEmpty { "http${r.code}" })
        }
        return o
    }

    /** До 50 роликов за запрос. Удалённые и приватные в ответ не попадают. Порядок как во входном списке. */
    fun videos(ids: List<String>): List<YtVideo> {
        val want = ids.distinct()
        val now = System.currentTimeMillis()
        val out = HashMap<String, YtVideo>()
        val need = ArrayList<String>()
        synchronized(cache) {
            for (id in want) {
                val h = cache[id]
                if (h != null && now - h.at < TTL_MS) out[id] = h.v else need.add(id)
            }
        }
        for (chunk in need.chunked(50)) {
            val o = call("videos", mapOf("part" to PART, "id" to chunk.joinToString(",")))
            for (v in parseItems(o, "")) out[v.id] = v
        }
        return want.mapNotNull { out[it] }
    }

    /** Чарт «популярное» региона (ISO 3166-1 alpha-2). 1 единица квоты. */
    fun mostPopular(region: String, max: Int = 25, categoryId: String = "", pageToken: String = ""): YtPage {
        if (!regionRe.matches(region)) throw YtApiException(400, "badRegion")
        val reg = region.uppercase(Locale.ROOT)
        val p = linkedMapOf("part" to PART, "chart" to "mostPopular", "regionCode" to reg, "maxResults" to max.coerceIn(1, 50).toString())
        if (categoryId.isNotEmpty()) p["videoCategoryId"] = categoryId
        if (pageToken.isNotEmpty()) p["pageToken"] = pageToken
        val o = call("videos", p)
        return YtPage(parseItems(o, reg), o.optString("nextPageToken"))
    }

    /** Загрузки канала по @handle или идентификатору UC…: channels.list → playlistItems.list → videos.list (3 единицы). */
    fun channelUploads(ref: String, max: Int = 25, pageToken: String = ""): YtPage {
        val c = if (ref.startsWith("@")) call("channels", mapOf("part" to "contentDetails", "forHandle" to ref))
        else call("channels", mapOf("part" to "contentDetails", "id" to ref))
        val uploads = c.optJSONArray("items")?.optJSONObject(0)?.optJSONObject("contentDetails")
            ?.optJSONObject("relatedPlaylists")?.optString("uploads").orEmpty()
        if (uploads.isEmpty()) return YtPage(emptyList(), "")
        val p = linkedMapOf("part" to "contentDetails", "playlistId" to uploads, "maxResults" to max.coerceIn(1, 50).toString())
        if (pageToken.isNotEmpty()) p["pageToken"] = pageToken
        val o = call("playlistItems", p)
        val ids = ArrayList<String>()
        val arr = o.optJSONArray("items")
        if (arr != null) for (i in 0 until arr.length()) {
            val id = arr.optJSONObject(i)?.optJSONObject("contentDetails")?.optString("videoId").orEmpty()
            if (id.isNotEmpty()) ids.add(id)
        }
        return YtPage(videos(ids), o.optString("nextPageToken"))
    }

    /** Поиск. ДОРОГО: 100 единиц квоты за вызов (+1 на videos.list). */
    fun search(
        query: String, region: String = "", max: Int = 25, pageToken: String = "",
        order: String = "relevance", embeddableOnly: Boolean = true
    ): YtPage {
        val p = linkedMapOf("part" to "snippet", "type" to "video", "q" to query, "order" to order, "maxResults" to max.coerceIn(1, 50).toString())
        if (embeddableOnly) p["videoEmbeddable"] = "true"
        if (regionRe.matches(region)) p["regionCode"] = region.uppercase(Locale.ROOT)
        if (pageToken.isNotEmpty()) p["pageToken"] = pageToken
        val o = call("search", p)
        val ids = ArrayList<String>()
        val arr = o.optJSONArray("items")
        if (arr != null) for (i in 0 until arr.length()) {
            val id = arr.optJSONObject(i)?.optJSONObject("id")?.optString("videoId").orEmpty()
            if (id.isNotEmpty()) ids.add(id)
        }
        return YtPage(videos(ids), o.optString("nextPageToken"))
    }

    /** Ссылка на канал (@handle или /channel/UC…) из LinkNorm → ссылка для channelUploads; null — это не канал. */
    fun channelRef(link: LinkInfo): String? {
        if (link.platform != "youtube") return null
        val segs = try { URI(link.canonical).path.split('/').filter { it.isNotEmpty() } } catch (_: Exception) { return null }
        val first = segs.firstOrNull() ?: return null
        return when {
            first.startsWith("@") -> first
            first == "channel" && segs.size >= 2 && segs[1].startsWith("UC") -> segs[1]
            else -> null
        }
    }

    private fun parseItems(o: JSONObject, region: String): List<YtVideo> {
        val out = ArrayList<YtVideo>()
        val arr = o.optJSONArray("items") ?: return out
        val now = System.currentTimeMillis()
        for (i in 0 until arr.length()) {
            val v = parseVideo(arr.optJSONObject(i) ?: continue, region) ?: continue
            out.add(v)
            synchronized(cache) { cache[v.id] = Hit(now, v) }
        }
        return out
    }

    private fun parseVideo(o: JSONObject, region: String): YtVideo? {
        val id = o.optString("id")
        if (id.isEmpty()) return null
        val sn = o.optJSONObject("snippet") ?: JSONObject()
        val cd = o.optJSONObject("contentDetails") ?: JSONObject()
        val st = o.optJSONObject("status") ?: JSONObject()
        val stats = o.optJSONObject("statistics") ?: JSONObject()
        val title = sn.optString("title")
        val desc = sn.optString("description")
        val rawTags = ArrayList<String>()
        val ta = sn.optJSONArray("tags")
        if (ta != null) for (i in 0 until minOf(ta.length(), 8)) {
            val t = ta.optString(i).lowercase(Locale.ROOT).replace(" ", "")
            if (t.length >= 2) rawTags.add(t)
        }
        val tags = (rawTags + MhTags.of("$title $desc")).distinct().take(6)
        return YtVideo(
            id = id, title = title,
            channelId = sn.optString("channelId"), channelTitle = sn.optString("channelTitle"),
            description = desc, thumb = pickThumb(sn.optJSONObject("thumbnails")),
            publishedMs = isoToMs(sn.optString("publishedAt")),
            durationMs = isoDurationMs(cd.optString("duration")),
            tags = tags, embeddable = st.optBoolean("embeddable", true),
            privacy = st.optString("privacyStatus"), live = sn.optString("liveBroadcastContent", "none"),
            views = stats.optString("viewCount").toLongOrNull() ?: 0L,
            likes = stats.optString("likeCount").toLongOrNull() ?: 0L,
            region = region
        )
    }

    private fun pickThumb(th: JSONObject?): String {
        if (th == null) return ""
        for (k in listOf("maxres", "standard", "high", "medium", "default")) {
            val u = th.optJSONObject(k)?.optString("url").orEmpty()
            if (u.isNotEmpty()) return u
        }
        return ""
    }

    private fun isoToMs(s: String): Long {
        if (s.length < 19) return 0L
        return try {
            val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
            f.timeZone = TimeZone.getTimeZone("UTC")
            f.parse(s.substring(0, 19))?.time ?: 0L
        } catch (_: Exception) {
            0L
        }
    }

    private fun isoDurationMs(s: String): Long {
        val m = durRe.matchEntire(s) ?: return 0L
        fun g(i: Int): Long = m.groupValues[i].toLongOrNull() ?: 0L
        return ((g(1) * 24 + g(2)) * 3600 + g(3) * 60 + g(4)) * 1000
    }
}

/** Адаптер под контракт VideoSource. Без ключа и при исчерпанной квоте падает обратно на oEmbed (YouTubeSource). */
object YouTubeApiSource : VideoSource {
    override val id = "youtube"
    override val title = "YouTube"

    override fun status(): SourceStatus =
        if (!YouTubeConfig.configured) SourceStatus(
            SourceStatus.NEEDS_ACCESS,
            "Ключ YouTube Data API v3 не задан: работает запасной режим oEmbed (название, канал, картинка)."
        ) else SourceStatus(
            SourceStatus.WORKS,
            "YouTube Data API v3: название, канал, описание, дата, длительность, теги, признак «можно встраивать»; " +
                "чарт популярного по региону, загрузки канала, поиск. Ролики не скачиваются; играют во встроенном плеере (IFrame Player API). " +
                "Лимит квоты ключа; при исчерпании — oEmbed."
        )

    override fun handles(link: LinkInfo) = link.platform == "youtube"

    override fun fetchMeta(link: LinkInfo): MetaResult {
        if (!link.isPost || link.videoId.isEmpty()) return MetaResult.Unsupported
        if (!YouTubeConfig.configured) return YouTubeSource.fetchMeta(link)
        return try {
            val v = YouTubeApi.videos(listOf(link.videoId)).firstOrNull()
            if (v == null) MetaResult.Gone else v.toMeta()
        } catch (e: YtApiException) {
            if (e.quota || e.http < 0) YouTubeSource.fetchMeta(link) else MetaResult.Failed(e.reason)
        } catch (_: Throwable) {
            MetaResult.Failed("ошибка разбора")
        }
    }
}

class YtPlayerEvent(val type: String, val value: String)

/**
 * Встроенный плеер (официальный IFrame Player API) для WebView.
 * Использование — как у TikTok-плеера во VideoTab:
 *   loadDataWithBaseURL(YouTubeConfig.embedOrigin + "/", YouTubeEmbed.html(id), "text/html", "utf-8", null)
 *   в onConsoleMessage: YouTubeEmbed.parse(m.message()) → YtPlayerEvent
 *   команды: web.evaluateJavascript("cmd('play')" | "cmd('pause')" | "cmd('mute')" | "cmd('unmute')", null)
 * baseUrl обязателен: без Referer плеер отвечает ошибкой 153.
 */
object YouTubeEmbed {
    const val ST_ENDED = 0
    const val ST_PLAYING = 1
    const val ST_PAUSED = 2
    const val ST_BUFFERING = 3

    private val idRe = Regex("^[A-Za-z0-9_-]{6,15}$")
    private val originRe = Regex("^https://[A-Za-z0-9.-]+(:\\d+)?$")

    fun html(videoId: String, origin: String = YouTubeConfig.embedOrigin): String {
        if (!idRe.matches(videoId)) return ""
        val o = origin.trimEnd('/')
        if (!originRe.matches(o)) return ""
        return """<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}#p{position:absolute;inset:0;width:100%;height:100%;border:0}</style></head><body>
<div id="p"></div>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
var pl=null;
function log(t,v){console.log('MSYT|'+t+'|'+(v===undefined?'':JSON.stringify(v)))}
function onYouTubeIframeAPIReady(){
 pl=new YT.Player('p',{videoId:'$videoId',host:'https://www.youtube.com',
  playerVars:{autoplay:1,controls:0,playsinline:1,rel:0,modestbranding:1,fs:0,iv_load_policy:3,loop:1,playlist:'$videoId',enablejsapi:1,origin:'$o'},
  events:{onReady:function(){log('onReady')},onStateChange:function(e){log('onStateChange',e.data)},onError:function(e){log('onError',e.data)}}});
}
function cmd(t){if(!pl)return;if(t==='play')pl.playVideo();else if(t==='pause')pl.pauseVideo();else if(t==='mute')pl.mute();else if(t==='unmute')pl.unMute();}
</script></body></html>"""
    }

    /** Сообщение console.log страницы-обёртки → событие плеера; null — чужое сообщение. */
    fun parse(consoleMessage: String): YtPlayerEvent? {
        val p = consoleMessage.split('|', limit = 3)
        return if (p.size == 3 && p[0] == "MSYT") YtPlayerEvent(p[1], p[2]) else null
    }

    /** Автор запретил встраивание (101, 150, 152). */
    fun isEmbedBlocked(e: YtPlayerEvent) = e.type == "onError" && (e.value == "101" || e.value == "150" || e.value == "152")
    /** Ролик удалён или приватный. */
    fun isGone(e: YtPlayerEvent) = e.type == "onError" && e.value == "100"
    /** Плеер не получил Referer/origin: проверьте YouTubeConfig.embedOrigin и baseUrl WebView. */
    fun isConfigError(e: YtPlayerEvent) = e.type == "onError" && e.value == "153"
}
