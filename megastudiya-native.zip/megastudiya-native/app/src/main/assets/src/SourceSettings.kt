package app.megastudiya.nativeapp

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Экран «Источники видео»: шлюз владельца, ключ YouTube, бот Telegram, подключение TikTok. Секреты вводятся здесь и хранятся
// зашифрованными (SecretBox); после сохранения поле очищается и значение больше не показывается.

private val SsBg = Color(0xFF0B0D12)
private val SsAcc = Color(0xFF6EA8FF)
private val SsMuted = Color(0xFF8B93A5)

@Composable
fun SourceSettingsScreen(onBack: () -> Unit) {
    BackHandler { onBack() }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val rev = ConnectorSetup.rev   // перерисовка при смене настроек и состояния TikTok

    var note by remember { mutableStateOf("") }
    fun toast(t: String) { note = t; Toast.makeText(ctx, t, Toast.LENGTH_SHORT).show() }

    val ytSet = remember(rev) { ConnectorSetup.hasYouTubeKey(ctx) }
    val tgSet = remember(rev) { ConnectorSetup.hasTelegramToken(ctx) }
    val tgAccessSet = remember(rev) { ConnectorSetup.hasTelegramAccessKey(ctx) }
    val ytStatus = remember(rev) { YouTubeApiSource.status() }
    val tgStatus = remember(rev) { TelegramBotSource.status() }
    val ttStatus = remember(rev) { TikTokApiSource.status() }
    val ttConnected = remember(rev) { TikTokApi.connected() }

    var ytKey by remember { mutableStateOf("") }
    var tgToken by remember { mutableStateOf("") }
    var gw by remember { mutableStateOf(ConnectorSetup.gatewayBase(ctx)) }
    var tgAccess by remember { mutableStateOf("") }
    var ttKey by remember { mutableStateOf(ConnectorSetup.tikTokClientKey(ctx)) }
    var ttDiscoveryToken by remember { mutableStateOf("") }
    val ttDiscoverySet = remember(rev) { ConnectorSetup.hasTikTokDiscoveryToken(ctx) }
    var busy by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().background(SsBg).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(24.dp)
    ) {
        Text("← Назад", color = SsAcc, fontSize = 15.sp, modifier = Modifier.clickable { onBack() }.padding(bottom = 16.dp))
        Text("Источники видео", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(
            "Ключи и токены хранятся на устройстве в зашифрованном виде и не показываются после сохранения.",
            color = SsMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
        )

        // ---------- Шлюз ----------
        val gwSaved = gw.trim().trimEnd('/') == ConnectorSetup.gatewayBase(ctx)
        SsCard("Шлюз владельца", null, if (ConnectorSetup.gatewayBase(ctx).isEmpty()) "Не задан" else "Задан") {
            Text(
                "Свой сервер из папки server/gateway: хранит секрет приложения TikTok и токен бота Telegram, чтобы их не было на телефоне. " +
                    "Нужен для TikTok и для безопасной работы бота. Адрес выдаётся при развёртывании.",
                color = SsMuted, fontSize = 13.sp
            )
            OutlinedTextField(
                colors = fieldColors(), value = gw, onValueChange = { gw = it }, singleLine = true,
                label = { Text("Адрес шлюза") }, placeholder = { Text("https://…") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            SsRow {
                Btn("Сохранить", primary = true, enabled = !gwSaved) {
                    if (ConnectorSetup.saveGateway(ctx, gw)) toast("Адрес шлюза сохранён") else toast("Адрес должен начинаться с https://")
                }
            }
        }

        // ---------- YouTube ----------
        SsCard("YouTube", ytStatus, if (ytSet) "Ключ сохранён" else "Ключ не задан") {
            Text(
                "Ключ YouTube Data API v3 нужен для названий, чартов и поиска. Видео в ленте играет и без него.",
                color = SsMuted, fontSize = 13.sp
            )
            OutlinedTextField(
                colors = fieldColors(), value = ytKey, onValueChange = { ytKey = it }, singleLine = true,
                label = { Text(if (ytSet) "Новый ключ (заменит сохранённый)" else "API-ключ") },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            SsRow {
                Btn("Сохранить", primary = true, enabled = ytKey.isNotBlank()) {
                    if (ConnectorSetup.saveYouTubeKey(ctx, ytKey)) { ytKey = ""; toast("Ключ YouTube сохранён") }
                    else toast("Не удалось зашифровать ключ: хранилище устройства недоступно")
                }
                if (ytSet) Btn("Удалить") { ConnectorSetup.saveYouTubeKey(ctx, ""); toast("Ключ YouTube удалён") }
            }
        }

        // ---------- Telegram ----------
        SsCard("Telegram", tgStatus, if (TelegramBotConfig.viaGateway) "Через шлюз" else if (tgSet) "Токен на телефоне" else "Не настроен") {
            Text(
                "Бот принимает видео и фото, отправленные ему или в канал, где он администратор. Показ публичных постов в ленте бота не требует. " +
                    "Рекомендуется: токен бота хранится на шлюзе, здесь — только ключ доступа (он не даёт писать от имени бота).",
                color = SsMuted, fontSize = 13.sp
            )
            OutlinedTextField(
                colors = fieldColors(), value = tgAccess, onValueChange = { tgAccess = it }, singleLine = true,
                label = { Text(if (tgAccessSet) "Новый ключ доступа (заменит сохранённый)" else "Ключ доступа к шлюзу") },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            if (ConnectorSetup.gatewayBase(ctx).isEmpty()) {
                Text("Сначала сохраните адрес шлюза выше.", color = SsMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
            SsRow {
                Btn("Сохранить", primary = true, enabled = tgAccess.isNotBlank()) {
                    if (ConnectorSetup.saveTelegramAccessKey(ctx, tgAccess)) { tgAccess = ""; toast("Ключ доступа сохранён") }
                    else toast("Не удалось зашифровать ключ: хранилище устройства недоступно")
                }
                if (TelegramBotConfig.configured) {
                    Btn("Проверить", enabled = !busy) {
                        busy = true
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                try { "Бот @" + TelegramBotApi.getMe() } catch (e: TgApiException) { "Ошибка: " + e.desc } catch (_: Throwable) { "Ошибка" }
                            }
                            busy = false
                            toast(r)
                        }
                    }
                }
                if (tgAccessSet) Btn("Удалить") { ConnectorSetup.saveTelegramAccessKey(ctx, ""); toast("Ключ доступа удалён") }
            }
            Text(
                "Только для отладки: токен бота прямо на телефоне. При доступе к устройству с root его можно извлечь.",
                color = SsMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 14.dp)
            )
            OutlinedTextField(
                colors = fieldColors(), value = tgToken, onValueChange = { tgToken = it }, singleLine = true,
                label = { Text(if (tgSet) "Новый токен (заменит сохранённый)" else "Токен бота (прямой режим)") },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            )
            SsRow {
                Btn("Сохранить токен", enabled = tgToken.isNotBlank()) {
                    if (ConnectorSetup.saveTelegramToken(ctx, tgToken)) { tgToken = ""; toast("Токен сохранён на устройстве") }
                    else toast("Не удалось зашифровать токен: хранилище устройства недоступно")
                }
                if (tgSet) Btn("Удалить токен") { ConnectorSetup.saveTelegramToken(ctx, ""); toast("Токен Telegram удалён") }
            }
        }

        // ---------- TikTok ----------
        val ttSaved = ttKey.trim() == ConnectorSetup.tikTokClientKey(ctx)
        SsCard("TikTok", ttStatus, if (ttConnected) "Аккаунт подключён" else "Аккаунт не подключён") {
            Text(
                "Подключение через Login Kit. В настройках приложения TikTok укажите Redirect URI: «адрес шлюза»/tiktok/callback. " +
                    "Секрет приложения (client_secret) хранится только на шлюзе.",
                color = SsMuted, fontSize = 13.sp
            )
            OutlinedTextField(
                colors = fieldColors(), value = ttKey, onValueChange = { ttKey = it }, singleLine = true,
                label = { Text("Client key") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            if (ConnectorSetup.gatewayBase(ctx).isEmpty()) {
                Text("Сначала сохраните адрес шлюза выше.", color = SsMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
            SsRow {
                Btn("Сохранить", primary = !ttSaved, enabled = ttKey.isNotBlank() && !ttSaved) {
                    ConnectorSetup.saveTikTok(ctx, ttKey)
                    toast("Client key сохранён")
                }
            }
            SsRow {
                if (!ttConnected) {
                    Btn("Подключить TikTok", primary = true, enabled = TikTokConfig.configured && ttSaved) {
                        val i = ConnectorSetup.beginTikTok()
                        if (i == null) toast("Нужны адрес шлюза и client key")
                        else try { ctx.startActivity(i) } catch (_: Throwable) { toast("Не удалось открыть браузер") }
                    }
                } else {
                    Btn("Загрузить мои ролики", primary = true, enabled = !busy) {
                        busy = true
                        ConnectorSetup.importTikTokNow(ctx) { r -> busy = false; toast("TikTok: $r") }
                    }
                    Btn("Отключить") { ConnectorSetup.disconnectTikTok(); toast("TikTok отключён на этом устройстве") }
                }
            }
            if (!ttConnected && TikTokConfig.configured && ttSaved) {
                Text(
                    "После согласия в браузере TikTok вернёт в приложение, и ролики аккаунта добавятся в каталог.",
                    color = SsMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                )
            }
        }

        // ---------- TikTok public discovery feed ----------
        SsCard("Автоматическая лента TikTok", SourceStatus(SourceStatus.NEEDS_ACCESS,
            "Публичный поиск через сторонний Apify Actor. Неофициальный источник; выдача и воспроизведение могут меняться. Токен Apify хранится зашифрованно на устройстве."),
            if (ttDiscoverySet) "API подключён" else "API не подключён") {
            Text("Для автоматического поиска видео по темам нужен Apify API token. Он создаётся в Apify Console → Settings → Integrations. Поиск платный по числу результатов; начинаем с небольших партий.", color = SsMuted, fontSize = 13.sp)
            OutlinedTextField(
                colors = fieldColors(), value = ttDiscoveryToken, onValueChange = { ttDiscoveryToken = it }, singleLine = true,
                label = { Text(if (ttDiscoverySet) "Новый токен (заменит сохранённый)" else "Apify API token") },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            SsRow {
                Btn("Сохранить", primary = true, enabled = ttDiscoveryToken.isNotBlank()) {
                    if (ConnectorSetup.saveTikTokDiscoveryToken(ctx, ttDiscoveryToken)) { ttDiscoveryToken = "" ; toast("Токен поиска TikTok сохранён") }
                    else toast("Не удалось зашифровать токен на устройстве")
                }
                if (ttDiscoverySet) {
                    Btn("Проверить поиск", enabled = !busy && !MediaHub.discoveryBusy) {
                        busy = true
                        MediaHub.discoverTikTok(ctx, force = true) { result -> busy = false; toast(result) }
                    }
                    Btn("Удалить") { ConnectorSetup.saveTikTokDiscoveryToken(ctx, ""); toast("Токен автопоиска удалён") }
                }
            }
        }

        if (note.isNotEmpty()) Text(note, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp))
    }
}

@Composable
private fun SsCard(name: String, status: SourceStatus?, state: String, content: @Composable () -> Unit) {
    val sh = RoundedCornerShape(20.dp)
    Column(
        Modifier.padding(top = 16.dp).fillMaxWidth().clip(sh).background(Color.White.copy(alpha = 0.06f)).padding(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(state, color = SsAcc, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        if (status != null) Text(status.note, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
        else Text("", modifier = Modifier.padding(top = 4.dp))
        content()
    }
}

@Composable
private fun SsRow(content: @Composable () -> Unit) {
    Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) { content() }
}
