package app.megastudiya.nativeapp

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom

// TikTok через официальные интерфейсы:
//  1) Login Kit (OAuth 2.0 + PKCE) — подключение аккаунта пользователя. Адрес https://www.tiktok.com/v2/auth/authorize/.
//  2) Display API v2 — user/info, video/list, video/query: ТОЛЬКО ролики подключённого аккаунта (scopes user.info.basic, video.list;
//     scope video.list одобряется TikTok при ревью приложения).
//  3) Публичный oEmbed и Embed Player — уже в TikTokSource и VideoTab; здесь не дублируются.
// Лент по чужим авторам, странам и трендам у TikTok общедоступного API нет — здесь этого нет.
//
// ВАЖНО по секрету: client_secret в приложении хранить нельзя. TikTok рекомендует менять code на токены на сервере.
// Поэтому обмен идёт на TikTokConfig.tokenEndpoint: свой сервер принимает те же form-поля (client_key, code, grant_type, redirect_uri,
// code_verifier / refresh_token), добавляет client_secret и возвращает JSON TikTok как есть. Прямой вызов TikTok (по умолчанию)
// работает только если задан clientSecret — годится для отладки, не для релиза.
// redirectUri = <адрес шлюза>/tiktok/callback (регистрируется в Login Kit). Шлюз возвращает пользователя в приложение через
// схему megastudiya://tiktok; полученный Uri передаётся в TikTokAuth.complete() (см. ConnectorSetup.handleRedirect). Ролики не скачиваются.
// Cover-картинки из Display API живут недолго: не храните их как постоянные, при показе запрашивайте заново.

object TikTokConfig {
    @Volatile var clientKey: String = ""
    @Volatile var redirectUri: String = ""
    @Volatile var scopes: String = "user.info.basic,video.list"
    @Volatile var tokenEndpoint: String = "https://open.tiktokapis.com/v2/oauth/token/"
    @Volatile var clientSecret: String = ""     // оставьте пустым, если обмен идёт через свой сервер
    val configured: Boolean get() = clientKey.isNotBlank() && redirectUri.isNotBlank()
}

class TikTokTokens(
    val accessToken: String,
    val refreshToken: String,
    val openId: String,
    val scope: String,
    val expiresAtMs: Long,
    val refreshExpiresAtMs: Long
)

interface TikTokTokenStore {
    fun loadTokens(): TikTokTokens?
    fun saveTokens(t: TikTokTokens)
    fun clearTokens()
    fun savePending(state: String, verifier: String)
    /** Читает и стирает начатую авторизацию (state, code_verifier). */
    fun takePending(): Pair<String, String>?
}

/** Хранилище в закрытых SharedPreferences приложения. Для повышенной защиты реализуйте интерфейс поверх Keystore. */
class PrefsTikTokTokenStore(ctx: Context) : TikTokTokenStore {
    private val p = ctx.applicationContext.getSharedPreferences("mh_tiktok", Context.MODE_PRIVATE)

    // access/refresh-токены лежат зашифрованными (SecretBox, Android Keystore); старые записи открытым текстом читаются и перешифровываются.
    override fun loadTokens(): TikTokTokens? {
        val a = SecretBox.open(p.getString("access", "") ?: "")
        if (a.isEmpty()) return null
        val rawR = p.getString("refresh", "") ?: ""
        val t = TikTokTokens(
            a, SecretBox.open(rawR), p.getString("open_id", "") ?: "", p.getString("scope", "") ?: "",
            p.getLong("exp", 0L), p.getLong("rexp", 0L)
        )
        if (!SecretBox.isSealed(p.getString("access", "") ?: "")) saveTokens(t)
        return t
    }

    override fun saveTokens(t: TikTokTokens) {
        val a = SecretBox.seal(t.accessToken) ?: return
        val r = SecretBox.seal(t.refreshToken) ?: return
        p.edit().putString("access", a).putString("refresh", r).putString("open_id", t.openId)
            .putString("scope", t.scope).putLong("exp", t.expiresAtMs).putLong("rexp", t.refreshExpiresAtMs).apply()
    }

    override fun clearTokens() {
        p.edit().remove("access").remove("refresh").remove("open_id").remove("scope").remove("exp").remove("rexp").apply()
    }

    override fun savePending(state: String, verifier: String) {
        p.edit().putString("p_state", state).putString("p_verifier", verifier).apply()
    }

    override fun takePending(): Pair<String, String>? {
        val s = p.getString("p_state", "") ?: ""
        val v = p.getString("p_verifier", "") ?: ""
        p.edit().remove("p_state").remove("p_verifier").apply()
        return if (s.isEmpty() || v.isEmpty()) null else s to v
    }
}

sealed class TikTokAuthResult {
    class Ok(val tokens: TikTokTokens) : TikTokAuthResult()
    class Denied(val reason: String) : TikTokAuthResult()
    class Failed(val why: String) : TikTokAuthResult()
}

class TtApiException(val code: String, val msg: String) : Exception("TikTok $code: $msg") {
    val notConnected: Boolean get() = code == "not_connected"
    val scopeMissing: Boolean get() = code == "scope_not_authorized" || code == "scope_permission_missed"
    val rateLimited: Boolean get() = code == "rate_limit_exceeded"
}

private object TtHttp {
    class Res(val code: Int, val body: String)

    fun request(method: String, url: String, headers: Map<String, String>, body: String?): Res {
        val conn = try { URL(url).openConnection() as HttpURLConnection } catch (_: Exception) { return Res(-1, "badUrl") }
        try {
            conn.requestMethod = method
            conn.connectTimeout = 8000
            conn.readTimeout = 12000
            conn.instanceFollowRedirects = false
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            return Res(code, stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: "")
        } catch (e: Exception) {
            return Res(-1, e.javaClass.simpleName)
        } finally {
            try { conn.disconnect() } catch (_: Throwable) { }
        }
    }

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}

/** Login Kit: PKCE (code_challenge = hex SHA-256 от code_verifier, как требует TikTok), обмен кода, обновление токена. */
object TikTokAuth {
    private const val AUTH_URL = "https://www.tiktok.com/v2/auth/authorize/"
    private const val ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~"
    private val rnd = SecureRandom()

    private fun random(n: Int): String {
        val sb = StringBuilder(n)
        repeat(n) { sb.append(ALPHABET[rnd.nextInt(ALPHABET.length)]) }
        return sb.toString()
    }

    private fun sha256Hex(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.US_ASCII)).joinToString("") { "%02x".format(it) }

    /** Начать подключение: intent открывает страницу согласия TikTok в браузере (ctx.startActivity). null — Login Kit не настроен. */
    fun begin(store: TikTokTokenStore): Intent? {
        if (!TikTokConfig.configured) return null
        val state = random(24)
        val verifier = random(64)
        store.savePending(state, verifier)
        val url = AUTH_URL +
            "?client_key=" + TtHttp.enc(TikTokConfig.clientKey) +
            "&scope=" + TtHttp.enc(TikTokConfig.scopes) +
            "&response_type=code" +
            "&redirect_uri=" + TtHttp.enc(TikTokConfig.redirectUri) +
            "&state=" + TtHttp.enc(state) +
            "&code_challenge=" + sha256Hex(verifier) +
            "&code_challenge_method=S256"
        return Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /** Завершить подключение по адресу возврата (redirectUri + code/state). Сетевой вызов: не на главном потоке. */
    fun complete(store: TikTokTokenStore, redirect: Uri): TikTokAuthResult {
        val pending = store.takePending() ?: return TikTokAuthResult.Failed("авторизация не была начата")
        val err = redirect.getQueryParameter("error")
        if (!err.isNullOrEmpty()) return TikTokAuthResult.Denied(redirect.getQueryParameter("error_description") ?: err)
        if (redirect.getQueryParameter("state") != pending.first) return TikTokAuthResult.Failed("state не совпал")
        val code = redirect.getQueryParameter("code") ?: return TikTokAuthResult.Failed("в ответе нет code")
        return exchange(
            store, linkedMapOf(
                "client_key" to TikTokConfig.clientKey, "code" to code, "grant_type" to "authorization_code",
                "redirect_uri" to TikTokConfig.redirectUri, "code_verifier" to pending.second
            )
        )
    }

    /** Обновить токен доступа по refresh-токену. Failed — нужно подключить аккаунт заново. */
    fun refresh(store: TikTokTokenStore): TikTokAuthResult {
        val t = store.loadTokens() ?: return TikTokAuthResult.Failed("аккаунт не подключён")
        if (t.refreshToken.isEmpty() || (t.refreshExpiresAtMs in 1 until System.currentTimeMillis())) {
            return TikTokAuthResult.Failed("срок подключения истёк")
        }
        return exchange(
            store, linkedMapOf("client_key" to TikTokConfig.clientKey, "grant_type" to "refresh_token", "refresh_token" to t.refreshToken)
        )
    }

    private fun exchange(store: TikTokTokenStore, form: LinkedHashMap<String, String>): TikTokAuthResult {
        if (TikTokConfig.clientSecret.isNotEmpty()) form["client_secret"] = TikTokConfig.clientSecret
        val body = form.entries.joinToString("&") { TtHttp.enc(it.key) + "=" + TtHttp.enc(it.value) }
        val r = TtHttp.request(
            "POST", TikTokConfig.tokenEndpoint,
            mapOf("Content-Type" to "application/x-www-form-urlencoded", "Cache-Control" to "no-cache"), body
        )
        if (r.code < 0) return TikTokAuthResult.Failed("сеть: " + r.body)
        val o = try { JSONObject(r.body) } catch (_: Exception) { return TikTokAuthResult.Failed("ответ не разобран (HTTP ${r.code})") }
        val access = o.optString("access_token")
        if (r.code !in 200..299 || access.isEmpty()) {
            return TikTokAuthResult.Failed(o.optString("error_description").ifEmpty { o.optString("error").ifEmpty { "HTTP ${r.code}" } })
        }
        val now = System.currentTimeMillis()
        val old = store.loadTokens()
        val t = TikTokTokens(
            accessToken = access,
            refreshToken = o.optString("refresh_token").ifEmpty { old?.refreshToken.orEmpty() },
            openId = o.optString("open_id").ifEmpty { old?.openId.orEmpty() },
            scope = o.optString("scope").ifEmpty { old?.scope.orEmpty() },
            expiresAtMs = now + o.optLong("expires_in", 86400L) * 1000L,
            refreshExpiresAtMs = now + o.optLong("refresh_expires_in", 0L) * 1000L
        )
        store.saveTokens(t)
        return TikTokAuthResult.Ok(t)
    }
}

data class TtVideo(
    val id: String,
    val title: String,
    val description: String,
    val durationSec: Int,
    val cover: String,
    val embedLink: String,
    val shareUrl: String,
    val createdMs: Long,
    val w: Int,
    val h: Int,
    val views: Long,
    val likes: Long,
    val comments: Long,
    val shares: Long
) {
    /** Ссылка вида tiktok.com/@автор/video/id для MediaHub.ingestBatch; пусто — формат ссылки не подошёл. */
    val linkUrl: String
        get() = if (LinkNorm.parse(shareUrl)?.videoId?.isNotEmpty() == true) shareUrl else ""

    fun toMeta(author: String): MetaResult.Ok {
        val t = title.ifEmpty { description.trim().lineSequence().firstOrNull().orEmpty() }
        return MetaResult.Ok(t.take(90), author, description.take(600), cover, id, createdMs)
    }
}

class TtPage(val items: List<TtVideo>, val cursor: Long, val hasMore: Boolean)
class TtUser(val openId: String, val displayName: String, val avatarUrl: String)

/** Display API v2. Блокирующие вызовы: не на главном потоке. Токен обновляется сам. */
object TikTokApi {
    private const val BASE = "https://open.tiktokapis.com/v2/"
    private const val VIDEO_FIELDS =
        "id,title,video_description,duration,cover_image_url,embed_link,share_url,create_time,width,height,view_count,like_count,comment_count,share_count"

    @Volatile private var store: TikTokTokenStore? = null
    @Volatile private var account: String = ""
    private val lock = Any()
    private val own = LinkedHashMap<String, TtVideo>()

    fun attach(s: TikTokTokenStore) { store = s }
    fun attach(ctx: Context) { store = PrefsTikTokTokenStore(ctx) }

    val tokenStore: TikTokTokenStore? get() = store
    fun connected(): Boolean = store?.loadTokens() != null
    val accountName: String get() = account

    /** Отключить аккаунт на устройстве. Отзыв токена на стороне TikTok делайте на своём сервере. */
    fun disconnect() {
        store?.clearTokens()
        account = ""
        synchronized(own) { own.clear() }
    }

    /** Ролик из уже загруженного списка своих роликов (без сети). */
    fun ownVideo(id: String): TtVideo? = if (id.isEmpty()) null else synchronized(own) { own[id] }

    private fun accessToken(force: Boolean = false): String = synchronized(lock) {
        val s = store ?: throw TtApiException("not_connected", "аккаунт TikTok не подключён")
        var t = s.loadTokens() ?: throw TtApiException("not_connected", "аккаунт TikTok не подключён")
        if (force || t.expiresAtMs - System.currentTimeMillis() < 60_000) {
            when (val r = TikTokAuth.refresh(s)) {
                is TikTokAuthResult.Ok -> t = r.tokens
                is TikTokAuthResult.Denied -> throw TtApiException("not_connected", r.reason)
                is TikTokAuthResult.Failed -> throw TtApiException("not_connected", r.why)
            }
        }
        t.accessToken
    }

    private fun send(method: String, path: String, fields: String, body: JSONObject?): JSONObject {
        var retried = false
        while (true) {
            val tok = accessToken()
            val headers = linkedMapOf("Authorization" to "Bearer $tok")
            if (body != null) headers["Content-Type"] = "application/json; charset=UTF-8"
            val r = TtHttp.request(method, BASE + path + "?fields=" + TtHttp.enc(fields), headers, body?.toString())
            if (r.code < 0) throw TtApiException("network", r.body)
            val o = try { JSONObject(r.body) } catch (_: Exception) { throw TtApiException("bad_json", "HTTP ${r.code}") }
            val err = o.optJSONObject("error")
            val code = err?.optString("code").orEmpty()
            if (r.code in 200..299 && (code.isEmpty() || code == "ok")) return o
            if (!retried && code == "access_token_invalid") {
                retried = true
                accessToken(force = true)
                continue
            }
            throw TtApiException(code.ifEmpty { "http${r.code}" }, err?.optString("message").orEmpty())
        }
    }

    /** Профиль подключённого аккаунта (scope user.info.basic). */
    fun userInfo(): TtUser {
        val o = send("GET", "user/info/", "open_id,union_id,avatar_url,display_name", null)
        val u = o.optJSONObject("data")?.optJSONObject("user") ?: JSONObject()
        val me = TtUser(u.optString("open_id"), u.optString("display_name"), u.optString("avatar_url"))
        account = me.displayName
        return me
    }

    /** Свои ролики, новые первыми (scope video.list). cursor = 0 для первой страницы, дальше — TtPage.cursor. До 20 за запрос. */
    fun listVideos(cursor: Long = 0L, max: Int = 20): TtPage {
        val body = JSONObject().put("max_count", max.coerceIn(1, 20))
        if (cursor > 0) body.put("cursor", cursor)
        val d = send("POST", "video/list/", VIDEO_FIELDS, body).optJSONObject("data") ?: JSONObject()
        val items = parse(d.optJSONArray("videos"))
        return TtPage(items, d.optLong("cursor", 0L), d.optBoolean("has_more", false))
    }

    /** Свои ролики по идентификаторам (до 20). Чужие идентификаторы TikTok отвергает или не возвращает. */
    fun queryVideos(ids: List<String>): List<TtVideo> {
        if (ids.isEmpty()) return emptyList()
        val arr = JSONArray()
        for (id in ids.distinct().take(20)) arr.put(id)
        val body = JSONObject().put("filters", JSONObject().put("video_ids", arr))
        val d = send("POST", "video/query/", VIDEO_FIELDS, body).optJSONObject("data") ?: JSONObject()
        return parse(d.optJSONArray("videos"))
    }

    /**
     * Добавить свои ролики в каталог MediaHub карточками-ссылками (до maxPages×20 штук). Блокирующая.
     * Карточки создаёт обычный конвейер ingestBatch; fetchMeta берёт данные из кэша списка, без повторных запросов.
     */
    fun importOwn(ctx: Context, maxPages: Int = 3, done: (IngestSummary) -> Unit) {
        try { if (account.isEmpty()) userInfo() } catch (_: TtApiException) { }
        val urls = ArrayList<String>()
        var cursor = 0L
        var skipped = 0
        for (page in 0 until maxPages.coerceIn(1, 10)) {
            val p = listVideos(cursor)
            for (v in p.items) { val u = v.linkUrl; if (u.isEmpty()) skipped++ else urls.add(u) }
            if (!p.hasMore) break
            cursor = p.cursor
        }
        MediaHub.ingestBatch(ctx, emptyList(), null, "tiktok", urls, "", false) { s ->
            if (skipped > 0) s.rejected.add("$skipped: нет ссылки на ролик")
            done(s)
        }
    }

    private fun parse(arr: JSONArray?): List<TtVideo> {
        val out = ArrayList<TtVideo>()
        if (arr == null) return out
        for (i in 0 until arr.length()) {
            val v = arr.optJSONObject(i) ?: continue
            val id = v.optString("id")
            if (id.isEmpty()) continue
            val t = TtVideo(
                id = id, title = v.optString("title"), description = v.optString("video_description"),
                durationSec = v.optInt("duration"), cover = v.optString("cover_image_url"),
                embedLink = v.optString("embed_link"), shareUrl = v.optString("share_url"),
                createdMs = v.optLong("create_time") * 1000L, w = v.optInt("width"), h = v.optInt("height"),
                views = v.optLong("view_count"), likes = v.optLong("like_count"),
                comments = v.optLong("comment_count"), shares = v.optLong("share_count")
            )
            out.add(t)
            synchronized(own) { own[id] = t }
        }
        return out
    }
}

/** Адаптер под контракт VideoSource. Подставляется вместо TikTokSource (id "tiktok" тот же); для чужих роликов остаётся oEmbed. */
object TikTokApiSource : VideoSource {
    override val id = "tiktok"
    override val title = "TikTok"

    override fun status(): SourceStatus {
        if (!TikTokConfig.configured) return TikTokSource.status()
        if (!TikTokApi.connected()) return SourceStatus(
            SourceStatus.NEEDS_ACCESS,
            "Login Kit настроен, аккаунт не подключён. До подключения — oEmbed и встроенный плеер для ссылок из «Поделиться»."
        )
        val who = TikTokApi.accountName.ifEmpty { "аккаунт" }
        return SourceStatus(
            SourceStatus.LIMITED,
            "Подключён: $who. Display API отдаёт только ваши ролики (описание, дата, обложка, счётчики). " +
                "Чужие ролики — oEmbed и встроенный плеер. Ленты по авторам, странам и трендам у TikTok нет в общедоступном API."
        )
    }

    override fun handles(link: LinkInfo) = link.platform == "tiktok"

    override fun fetchMeta(link: LinkInfo): MetaResult {
        val mine = TikTokApi.ownVideo(link.videoId)
        if (mine != null) return mine.toMeta(TikTokApi.accountName)
        return TikTokSource.fetchMeta(link)
    }
}
