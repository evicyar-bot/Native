package app.megastudiya.nativeapp

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt
import kotlin.math.tanh

// ForYouEngine — первая собственная рекомендательная система вкладки «Видео».
// Не зависит от Taste, от площадки и от Android: принимает общие карточки каталога и сигналы пользователя.
// Принципы:
//  • интерес к теме/источнику/стране копится из сигналов и забывается (период полураспада 14 суток);
//  • один просмотр ничего не доказывает: вклад ключа умножается на уверенность n/(n+3),
//    где n — число РАЗНЫХ роликов, давших свидетельство;
//  • лента разнообразна (штраф за повтор темы/источника подряд, каждый 5-й слот — на изучение нового);
//  • повторы ограничены (окно последних показов и пауза 20 минут после показа);
//  • профиль можно сбросить целиком или забыть отдельную тему.

enum class Sig { VIEW, LIKE, UNLIKE, SAVE, UNSAVE, HIDE, OPEN, SHARE }

data class Signal(
    val t: Long,
    val id: String,
    val sig: Sig,
    val dwellMs: Long = 0L,   // сколько времени ролик реально смотрели (не на паузе, приложение на экране)
    val durMs: Long = 0L,     // длительность ролика, 0 = неизвестна
    val loops: Int = 0        // сколько раз ролик доигран до конца и пошёл заново
)

data class Cand(
    val id: String,
    val source: String,
    val tags: List<String>,
    val country: String,
    val published: Long,
    val added: Long,
    val playable: Boolean
)

class Interest(var w: Double = 0.0, var n: Int = 0, var ts: Long = 0L)

class Profile {
    val tags = HashMap<String, Interest>()
    val sources = HashMap<String, Interest>()
    val countries = HashMap<String, Interest>()
    val counted = HashSet<String>()          // ролики, уже давшие свидетельство (каждый считается один раз)
    val seen = HashMap<String, Int>()        // реальные просмотры (дольше порога пропуска)
    val shown = HashMap<String, Long>()      // когда ролик последний раз покидали
    var events = 0
}

/** Всё, что система знает о пользователе в рамках вкладки «Видео». Хранится отдельным файлом. */
class UserState {
    var profile = Profile()
    val liked = LinkedHashSet<String>()
    val saved = LinkedHashSet<String>()
    val hidden = LinkedHashSet<String>()
    var lastId = ""
    val events = ArrayList<Signal>()
}

object ForYouEngine {
    const val SKIP_MS = 1500L
    const val HALF_LIFE_MS = 14L * 24 * 3600 * 1000
    const val COOLDOWN_MS = 20L * 60 * 1000
    const val WINDOW = 4
    private const val DAY_MS = 24.0 * 3600 * 1000

    /** Вклад просмотра: быстрый пропуск минус, досмотр плюс, пересмотр сильнее. */
    fun viewDelta(dwellMs: Long, durMs: Long, loops: Int, playable: Boolean): Double {
        if (dwellMs < SKIP_MS) return -0.6
        val d: Double = if (playable && durMs > 0) {
            val r = min(1.0, dwellMs.toDouble() / durMs)
            when {
                loops >= 2 -> 1.8
                loops >= 1 || r >= 0.9 -> 1.0
                r >= 0.5 -> 0.4
                r >= 0.25 -> 0.1
                else -> -0.1
            }
        } else {
            // ссылка или фото: время на странице — слабый признак интереса
            when {
                dwellMs >= 8000 -> 0.4
                dwellMs >= 3000 -> 0.15
                else -> 0.0
            }
        }
        return if (playable) d else d * 0.5
    }

    private fun decayed(i: Interest, now: Long): Double {
        val dt = max(0L, now - i.ts).toDouble()
        return i.w * 0.5.pow(dt / HALF_LIFE_MS)
    }

    private fun bump(m: MutableMap<String, Interest>, key: String, d: Double, now: Long, first: Boolean) {
        if (key.isEmpty()) return
        val i = m.getOrPut(key) { Interest(0.0, 0, now) }
        i.w = (decayed(i, now) + d).coerceIn(-8.0, 12.0)
        i.ts = now
        if (first) i.n += 1
    }

    /** Учесть сигнал в профиле. Лайки, сохранения и скрытия отражаются в UserState отдельно (в MediaHub). */
    fun apply(p: Profile, c: Cand, s: Signal) {
        val delta = when (s.sig) {
            Sig.VIEW -> viewDelta(s.dwellMs, s.durMs, s.loops, c.playable)
            Sig.LIKE -> 2.5
            Sig.UNLIKE -> -2.5
            Sig.SAVE -> 3.0
            Sig.UNSAVE -> -3.0
            Sig.HIDE -> -4.0
            Sig.OPEN -> 1.0
            Sig.SHARE -> 1.5
        }
        if (s.sig == Sig.VIEW) {
            p.shown[c.id] = s.t
            if (s.dwellMs >= SKIP_MS) p.seen[c.id] = (p.seen[c.id] ?: 0) + 1
        }
        p.events++
        if (abs(delta) < 0.05) return                         // нейтральный сигнал ничего не доказывает
        val first = abs(delta) >= 0.3 && p.counted.add(c.id)  // свидетельство от ролика засчитывается один раз
        val share = delta / sqrt(max(1, c.tags.size).toDouble())
        for (t in c.tags) bump(p.tags, t, share, s.t, first)
        bump(p.sources, c.source, delta * 0.5, s.t, first)
        if (c.country.isNotEmpty()) bump(p.countries, c.country, delta * 0.5, s.t, first)
    }

    /** Выученная симпатия в диапазоне (-1..1), приглушённая малым числом свидетельств. */
    fun affinity(i: Interest?, now: Long): Double {
        if (i == null) return 0.0
        return tanh(decayed(i, now) / 3.0) * (i.n / (i.n + 3.0))
    }

    /** Насколько мало мы знаем о ролике: 1 — совсем новое, к 0 — знакомое. */
    fun uncertainty(p: Profile, c: Cand): Double {
        val u = ArrayList<Double>()
        for (t in c.tags) u.add(1.0 / (1 + (p.tags[t]?.n ?: 0)))
        u.add(1.0 / (1 + (p.sources[c.source]?.n ?: 0)))
        return u.average()
    }

    fun score(p: Profile, c: Cand, now: Long): Double {
        var s = 0.0
        if (c.tags.isNotEmpty()) s += c.tags.sumOf { affinity(p.tags[it], now) } / c.tags.size
        s += 0.4 * affinity(p.sources[c.source], now)
        if (c.country.isNotEmpty()) s += 0.3 * affinity(p.countries[c.country], now)
        val ageDays = max(0.0, (now - (if (c.published > 0) c.published else c.added)).toDouble() / DAY_MS)
        s += if (c.published > 0) 0.3 * 0.5.pow(ageDays / 7.0) else 0.15 * 0.5.pow(ageDays / 3.0)
        s -= 1.0 * (p.seen[c.id] ?: 0)
        return s
    }

    private fun sameTopic(a: Cand, b: Cand): Boolean =
        a.tags.isNotEmpty() && b.tags.isNotEmpty() && a.tags.take(2).any { it in b.tags.take(2) }

    /** Допустимые к показу: не показывались последние 20 минут. */
    fun eligible(p: Profile, all: List<Cand>, now: Long): List<Cand> = all.filter { c ->
        val last = p.shown[c.id]
        last == null || now - last >= COOLDOWN_MS
    }

    /** Жадная сборка с разнообразием; каждый 5-й слот отдан изучению малознакомого. Порядок детерминирован seed. */
    fun rank(p: Profile, cands: List<Cand>, now: Long, recent: List<Cand>, seed: Long, limit: Int): List<String> {
        if (cands.isEmpty() || limit <= 0) return emptyList()
        val rnd = java.util.Random(seed)
        val base = HashMap<String, Double>()
        for (c in cands) base[c.id] = score(p, c, now) + 0.3 * uncertainty(p, c) + rnd.nextDouble() * 0.05
        val pool = ArrayList(cands)
        val window = ArrayList<Cand>(recent.takeLast(3))
        val out = ArrayList<String>()
        var slot = recent.size
        while (out.size < limit && pool.isNotEmpty()) {
            val exploreSlot = slot % 5 == 4
            var best: Cand? = null
            var bestV = Double.NEGATIVE_INFINITY
            for (c in pool) {
                var v = base.getValue(c.id)
                if (exploreSlot) v = 0.3 * v + 2.0 * uncertainty(p, c)
                v -= 0.6 * window.takeLast(3).count { sameTopic(it, c) }
                v -= 0.4 * window.takeLast(2).count { it.source == c.source }
                if (v > bestV) { bestV = v; best = c }
            }
            val b = best ?: break
            out.add(b.id)
            pool.remove(b)
            window.add(b)
            slot++
        }
        return out
    }

    /** Следующая порция ленты: без недавних, без «на паузе после показа», с разнообразием. */
    fun plan(p: Profile, visible: List<Cand>, history: List<Cand>, now: Long, seed: Long, count: Int): List<String> {
        val win = min(WINDOW, max(0, visible.size - 1))
        val recentIds = history.takeLast(win).map { it.id }.toSet()
        val el = eligible(p, visible, now).filter { it.id !in recentIds }
        return rank(p, el, now, history, seed, count)
    }

    class Line(val key: String, val affinity: Double, val n: Int)

    /** Что система поняла: темы с уверенностью. Меньше 3 роликов — только гипотеза. */
    fun topInterests(p: Profile, now: Long, k: Int = 6): List<Line> =
        p.tags.entries.map { Line(it.key, affinity(it.value, now), it.value.n) }
            .filter { it.n > 0 && it.affinity > 0.0 }
            .sortedByDescending { it.affinity }
            .take(k)
}
