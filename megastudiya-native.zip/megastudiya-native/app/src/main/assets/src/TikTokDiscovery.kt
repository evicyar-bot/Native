package app.megastudiya.nativeapp

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Public TikTok search through a configured Apify Actor. Returns public links and metadata only. */
object TikTokDiscovery {
    /** Вставь сюда токен Apify между кавычками (только для ПРИВАТНОГО репозитория). Если пусто — токен берётся из настроек. */
    const val EMBEDDED_TOKEN = "apify_api_D7732sSd08QvgbHcwKTYlBrNcEVeGd2AQwrq"
    private const val ACTOR = "scrapysocial~tiktok-scraper"
    private const val API = "https://api.apify.com/v2/acts/$ACTOR/run-sync-get-dataset-items"
    val defaultQueries = listOf("funny videos", "street food", "travel", "animals", "technology", "fashion", "music", "interesting facts")
    data class Item(val videoId: String, val url: String, val title: String, val author: String, val thumb: String, val streamUrl: String, val tags: List<String>)
    data class Result(val items: List<Item>, val message: String)

    fun discover(token: String, queries: List<String> = defaultQueries, maxPerQuery: Int = 8): Result {
        if (token.isBlank()) return Result(emptyList(), "Для автопоиска нужен Apify API token в настройках источников")
        val found = LinkedHashMap<String, Item>()
        val qlist = queries.filter { it.isNotBlank() }.distinct().take(3)
        if (qlist.isEmpty()) return Result(emptyList(), "Нет поисковых тем")
        var error = ""
        // Формат из документации актора: endpoint + keyword + maxItems. Один запуск на тему, по очереди.
        for (q in qlist) {
            val input = JSONObject().put("endpoint", "search-videos").put("keyword", q).put("maxItems", maxPerQuery)
            val conn = (URL(API + "?timeout=60&limit=" + maxPerQuery).openConnection() as HttpURLConnection)
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 20000
                conn.readTimeout = 75000
                conn.doOutput = true
                conn.setRequestProperty("Authorization", "Bearer $token")
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("Accept", "application/json")
                conn.outputStream.use { it.write(input.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val body = (if (code in 200..299) conn.inputStream else conn.errorStream)?.use { it.readBytes().toString(Charsets.UTF_8) }.orEmpty()
                if (code !in 200..299) { error = "Apify HTTP $code: ${body.take(350)}"; if (code == 401 || code == 402 || code == 403) break else continue }
                parse(JSONArray(body), found)
            } catch (t: Throwable) {
                error = "Ошибка Apify: ${t.javaClass.simpleName}: ${t.message.orEmpty().take(180)}"
            } finally { conn.disconnect() }
        }
        if (found.isEmpty() && error.isNotEmpty()) return Result(emptyList(), error)
        return Result(found.values.toList(), if (found.isEmpty()) "Поисковик не вернул публичные ролики" else "Найдено ${found.size} роликов")
    }

    private fun parse(arr: JSONArray, found: LinkedHashMap<String, Item>) {
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = first(o, "id", "videoId", "awemeId")
            val authorObj = o.optJSONObject("author") ?: o.optJSONObject("authorMeta") ?: o.optJSONObject("user")
            val author = authorObj?.let { first(it, "username", "uniqueId", "name", "nickname", "handle") }.orEmpty()
            var rawUrl = first(o, "webVideoUrl", "videoUrl", "url", "shareUrl")
            var parsedId = id
            if (parsedId.isBlank() && rawUrl.isNotBlank()) {
                parsedId = Regex("/video/(\\d+)").find(rawUrl)?.groupValues?.getOrNull(1).orEmpty()
            }
            if (rawUrl.isBlank() && parsedId.isNotBlank() && author.isNotBlank()) rawUrl = "https://www.tiktok.com/@$author/video/$parsedId"
            if (parsedId.isBlank() || rawUrl.isBlank() || !rawUrl.contains("tiktok.com")) continue
            val canonical = LinkNorm.parse(rawUrl)?.canonical ?: rawUrl
            val title = first(o, "description", "text", "title", "desc", "caption").take(300)
            val meta = o.optJSONObject("video") ?: o.optJSONObject("videoMeta") ?: o.optJSONObject("videoData")
            val thumb = first(o, "coverUrl", "thumbnail", "thumbnailUrl", "cover").ifEmpty { meta?.let { first(it, "cover", "coverUrl", "originCover", "thumbnail") }.orEmpty() }
            val stream = first(o, "playUrl", "playURL", "downloadUrl", "downloadURL").ifEmpty { meta?.let { first(it, "playUrl", "playAddr", "downloadUrl", "downloadAddr", "url") }.orEmpty() }
            val hashtagList = o.optJSONArray("hashtags")
            val tags = if (hashtagList != null) (0 until hashtagList.length()).map { idx ->
                val value = hashtagList.opt(idx)
                (if (value is JSONObject) first(value, "name", "title", "tag") else value?.toString().orEmpty()).removePrefix("#")
            }.filter { it.isNotBlank() } else MhTags.of(title)
            found.putIfAbsent("tiktok:$parsedId", Item(parsedId, canonical, title, author, thumb, stream, tags))
        }
    }

    private fun first(o: JSONObject, vararg keys: String): String {
        for (k in keys) {
            val v = o.opt(k)
            if (v is String && v.isNotBlank()) return v
            if (v is Number) return v.toString()
        }
        return ""
    }
}
