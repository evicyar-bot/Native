package app.megastudiya.nativeapp

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Бесплатный поиск коротких роликов Rutube без токенов: публичный поиск сайта, работает из России без VPN. Играет встроенный плеер Rutube. */
object RutubeDiscovery {
    val defaultQueries = listOf("смешные видео", "еда", "путешествия", "животные", "технологии", "музыка", "авто", "спорт")
    data class Item(val videoId: String, val url: String, val title: String, val author: String, val thumb: String, val tags: List<String>)
    data class Result(val items: List<Item>, val message: String)

    private const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
    private val idRe = Regex("^[0-9a-f]{32}$")

    fun discover(queries: List<String> = defaultQueries): Result {
        val found = LinkedHashMap<String, Item>()
        var error = ""
        for (q in queries.filter { it.isNotBlank() }.distinct().take(2)) {
            val conn = (URL("https://rutube.ru/api/search/video/?format=json&query=" + URLEncoder.encode(q, "UTF-8")).openConnection() as HttpURLConnection)
            try {
                conn.connectTimeout = 15000
                conn.readTimeout = 20000
                conn.setRequestProperty("User-Agent", UA)
                conn.setRequestProperty("Accept", "application/json")
                val code = conn.responseCode
                if (code !in 200..299) { error = "Rutube HTTP $code"; continue }
                val body = conn.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
                val arr = JSONObject(body).optJSONArray("results") ?: continue
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val id = o.optString("id")
                    if (!idRe.matches(id)) continue
                    // лента вертикальных коротких роликов: берём только короткие (до 3 минут)
                    val dur = o.optInt("duration", 0)
                    if (dur <= 0 || dur > 180) continue
                    val title = o.optString("title").take(300)
                    val author = o.optJSONObject("author")?.optString("name").orEmpty()
                    val thumb = o.optString("thumbnail_url")
                    found.putIfAbsent("rt:$id", Item(id, "https://rutube.ru/video/$id/", title, author, thumb, MhTags.of(title)))
                }
            } catch (t: Throwable) {
                error = "Ошибка Rutube: ${t.javaClass.simpleName}: ${t.message.orEmpty().take(120)}"
            } finally { conn.disconnect() }
        }
        if (found.isEmpty() && error.isNotEmpty()) return Result(emptyList(), error)
        return Result(found.values.toList(), if (found.isEmpty()) "Rutube не вернул коротких роликов" else "Найдено ${found.size} роликов Rutube")
    }

    fun embedHtml(id: String): String {
        if (!idRe.matches(id)) return ""
        return """<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;height:100%;background:#000}iframe{border:0;width:100%;height:100%}</style></head><body>
<iframe src="https://rutube.ru/play/embed/$id?autoStart=true" allow="autoplay; fullscreen; encrypted-media" allowfullscreen></iframe>
</body></html>"""
    }
}
