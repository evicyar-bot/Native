package app.megastudiya.nativeapp

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption

// Хранилище вкладки «Видео»: отдельные файлы, не связанные с Store (посты) и памятью AQUA.
//   filesDir/mediahub/cards.json     — карточки каталога (+ .bak)
//   filesDir/mediahub/signals.json   — сигналы и профиль интересов ForYouEngine (+ .bak)
//   filesDir/mediahub/videos|images  — скопированные локальные файлы
//   filesDir/mediahub/thumbs         — превью (можно удалить: пересоздаются)
object MediaRepository {
    fun root(ctx: Context): File = File(ctx.filesDir, "mediahub").also { it.mkdirs() }
    fun dir(ctx: Context, name: String): File = File(root(ctx), name).also { it.mkdirs() }
    fun fileOf(ctx: Context, rel: String): File = File(root(ctx), rel)
    fun thumbFile(ctx: Context, c: VideoCard): File? =
        c.thumb.takeIf { it.isNotEmpty() }?.let { File(root(ctx), it) }?.takeIf { it.exists() }

    // Запись «всё или ничего»: во временный файл, на диск, затем подмена; прошлая версия остаётся в .bak.
    fun writeAtomic(f: File, text: String) {
        try {
            val tmp = File(f.parentFile, f.name + ".tmp")
            FileOutputStream(tmp).use { it.write(text.toByteArray(Charsets.UTF_8)); it.fd.sync() }
            val bak = File(f.parentFile, f.name + ".bak")
            try {
                if (f.exists()) Files.move(f.toPath(), bak.toPath(), StandardCopyOption.REPLACE_EXISTING)
            } catch (_: Throwable) {
            }
            try {
                Files.move(tmp.toPath(), f.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
            } catch (_: Throwable) {
                if (!tmp.renameTo(f)) f.writeText(text)
            }
        } catch (_: Throwable) {
        }
    }

    // Читаем основной файл; если он битый или пропал, берём прошлую копию.
    private fun <T> readSafe(f: File, parse: (String) -> T): T? {
        for (c in listOf(f, File(f.parentFile, f.name + ".bak"))) {
            try {
                if (c.exists()) return parse(c.readText())
            } catch (_: Throwable) {
            }
        }
        return null
    }

    // ---------- карточки ----------

    fun cardToJson(c: VideoCard): JSONObject = JSONObject()
        .put("id", c.id).put("kind", c.kind).put("source", c.source).put("key", c.dedupKey)
        .put("url", c.url).put("file", c.file).put("thumb", c.thumb).put("thumbUrl", c.thumbUrl)
        .put("title", c.title).put("author", c.author).put("desc", c.desc)
        .put("tags", JSONArray(c.tags)).put("country", c.country)
        .put("published", c.published).put("added", c.added).put("dur", c.durationMs)
        .put("w", c.w).put("h", c.h).put("bytes", c.bytes)
        .put("status", c.status).put("meta", c.meta).put("embedId", c.embedId).put("streamUrl", c.streamUrl)

    fun cardFromJson(o: JSONObject): VideoCard? = try {
        val tags = ArrayList<String>()
        o.optJSONArray("tags")?.let { a -> for (i in 0 until a.length()) tags.add(a.getString(i)) }
        VideoCard(
            id = o.getString("id"), kind = o.getString("kind"), source = o.optString("source", "device"),
            dedupKey = o.getString("key"), url = o.optString("url"), file = o.optString("file"),
            thumb = o.optString("thumb"), thumbUrl = o.optString("thumbUrl"), title = o.optString("title"),
            author = o.optString("author"), desc = o.optString("desc"), tags = tags,
            country = o.optString("country"), published = o.optLong("published"), added = o.optLong("added"),
            durationMs = o.optLong("dur"), w = o.optInt("w"), h = o.optInt("h"), bytes = o.optLong("bytes"),
            status = o.optString("status", Mk.OK), meta = o.optString("meta", Mk.META_NONE), embedId = o.optString("embedId"), streamUrl = o.optString("streamUrl")
        )
    } catch (_: Throwable) {
        null
    }

    fun cardsJson(list: List<VideoCard>): String {
        val a = JSONArray()
        list.forEach { a.put(cardToJson(it)) }
        return a.toString()
    }

    fun saveCards(ctx: Context, json: String) = writeAtomic(File(root(ctx), "cards.json"), json)

    /** null — файла нет вовсе (первый запуск или потеря); пустой список — каталог действительно пуст. */
    fun loadCards(ctx: Context): List<VideoCard>? = readSafe(File(root(ctx), "cards.json")) { raw ->
        val a = JSONArray(raw)
        (0 until a.length()).mapNotNull { cardFromJson(a.getJSONObject(it)) }
    }

    // ---------- сигналы и профиль ----------

    private fun interestMap(m: Map<String, Interest>): JSONObject {
        val o = JSONObject()
        for ((k, v) in m) o.put(k, JSONArray().put(v.w).put(v.n).put(v.ts))
        return o
    }

    private fun readInterests(o: JSONObject?, into: MutableMap<String, Interest>) {
        if (o == null) return
        for (k in o.keys()) {
            val a = o.optJSONArray(k) ?: continue
            into[k] = Interest(a.optDouble(0, 0.0), a.optInt(1, 0), a.optLong(2, 0L))
        }
    }

    fun stateJson(s: UserState): String {
        val o = JSONObject().put("v", 1).put("lastId", s.lastId)
        o.put("liked", JSONArray(s.liked.toList()))
        o.put("saved", JSONArray(s.saved.toList()))
        o.put("hidden", JSONArray(s.hidden.toList()))
        val p = s.profile
        val po = JSONObject()
            .put("tags", interestMap(p.tags)).put("sources", interestMap(p.sources)).put("countries", interestMap(p.countries))
            .put("counted", JSONArray(p.counted.toList())).put("events", p.events)
        val seen = JSONObject(); for ((k, v) in p.seen) seen.put(k, v)
        val shown = JSONObject(); for ((k, v) in p.shown) shown.put(k, v)
        po.put("seen", seen).put("shown", shown)
        o.put("profile", po)
        val ev = JSONArray()
        for (e in s.events) ev.put(JSONArray().put(e.t).put(e.id).put(e.sig.name).put(e.dwellMs).put(e.durMs).put(e.loops))
        o.put("events", ev)
        return o.toString()
    }

    fun saveState(ctx: Context, json: String) = writeAtomic(File(root(ctx), "signals.json"), json)

    fun loadState(ctx: Context): UserState = readSafe(File(root(ctx), "signals.json")) { raw ->
        val o = JSONObject(raw)
        val s = UserState()
        s.lastId = o.optString("lastId")
        fun strs(name: String, into: MutableCollection<String>) {
            val a = o.optJSONArray(name) ?: return
            for (i in 0 until a.length()) into.add(a.getString(i))
        }
        strs("liked", s.liked); strs("saved", s.saved); strs("hidden", s.hidden)
        val p = Profile()
        o.optJSONObject("profile")?.let { po ->
            readInterests(po.optJSONObject("tags"), p.tags)
            readInterests(po.optJSONObject("sources"), p.sources)
            readInterests(po.optJSONObject("countries"), p.countries)
            po.optJSONArray("counted")?.let { a -> for (i in 0 until a.length()) p.counted.add(a.getString(i)) }
            p.events = po.optInt("events")
            po.optJSONObject("seen")?.let { so -> for (k in so.keys()) p.seen[k] = so.optInt(k) }
            po.optJSONObject("shown")?.let { so -> for (k in so.keys()) p.shown[k] = so.optLong(k) }
        }
        s.profile = p
        o.optJSONArray("events")?.let { a ->
            for (i in 0 until a.length()) {
                val e = a.optJSONArray(i) ?: continue
                val sig = try { Sig.valueOf(e.getString(2)) } catch (_: Throwable) { continue }
                s.events.add(Signal(e.optLong(0), e.optString(1), sig, e.optLong(3), e.optLong(4), e.optInt(5)))
            }
        }
        s
    } ?: UserState()
}
