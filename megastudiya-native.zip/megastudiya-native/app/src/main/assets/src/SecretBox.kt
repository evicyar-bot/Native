package app.megastudiya.nativeapp

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

// Шифрование секретов на устройстве ключом из Android Keystore (AES-256-GCM). Ключ не покидает хранилище системы.
// Значения вводятся владельцем в приложении и в APK / репозиторий не попадают. Если Keystore недоступен,
// секрет НЕ сохраняется открытым текстом: seal() возвращает null. Резервная копия Android не переносит ключ Keystore,
// поэтому на другом устройстве такие значения не расшифруются (open() вернёт пустую строку) — секрет вводится заново.
object SecretBox {
    private const val ALIAS = "mh_secret_v1"
    private const val PREFIX = "v1:"

    private fun key(): SecretKey? = try {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey) ?: KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").run {
            init(
                KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
            )
            generateKey()
        }
    } catch (_: Throwable) {
        null
    }

    /** Зашифровать для хранения в SharedPreferences. null — шифрование недоступно (сохранять нельзя). Пустая строка остаётся пустой. */
    fun seal(plain: String): String? {
        if (plain.isEmpty()) return ""
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key() ?: return null)
            val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
            PREFIX + Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
        } catch (_: Throwable) {
            null
        }
    }

    /** Расшифровать. Значение без префикса — старая запись открытым текстом: возвращается как есть (вызывающий перешифровывает). */
    fun open(stored: String): String {
        if (stored.isEmpty()) return ""
        if (!stored.startsWith(PREFIX)) return stored
        return try {
            val raw = Base64.decode(stored.removePrefix(PREFIX), Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key() ?: return "", GCMParameterSpec(128, raw, 0, 12))
            String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
        } catch (_: Throwable) {
            ""
        }
    }

    fun isSealed(stored: String) = stored.startsWith(PREFIX)
}
