package app.megastudiya.nativeapp

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Короткие видео открытой сети AT Protocol (Bluesky и Skylight) через публичный API без токенов и ключей. Играет HLS-поток прямо в приложении. */
object BlueskyDiscovery {
    val defaultQueries = listOf("skytok", "skylight", "funny", "cats", "travel", "food", "music", "art")
    data class Item(val postId: String, val url: String, val title: String, val author: String, val thumb: String, val stream: String, val tags: List<String>)
    data class Result(val items: List<Item>, val message: String)

    private const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36"

    fun discover(queries: List<String> = defaultQueries): Result {
        val found = LinkedHashMap<String, Item>()
        var error = ""
        for (q in queries.filter { it.isNotBlank() }.distinct().take(2)) {
            val enc = URLEncoder.encode(q, "UTF-8")
            val conn = (URL("https://public.api.bsky.app/xrpc/app.bsky.feed.searchPosts?q=$enc&tag=$enc&limit=40&sort=latest").openConnection() as HttpURLConnection)
            try {
                conn.connectTimeout = 15000
                conn.readTimeout = 20000
                conn.setRequestProperty("User-Agent", UA)
                conn.setRequestProperty("Accept", "application/json")
                val code = conn.responseCode
                if (code !in 200..299) { error = "Bluesky HTTP $code"; continue }
                val body = conn.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
                val posts = JSONObject(body).optJSONArray("posts") ?: continue
                for (i in 0 until posts.length()) {
                    val p = posts.optJSONObject(i) ?: continue
                    val emb = p.optJSONObject("embed") ?: continue
                    if (!emb.optString("\$type").startsWith("app.bsky.embed.video")) continue
                    val playlist = emb.optString("playlist")
                    if (!playlist.startsWith("https://")) continue
                    val uri = p.optString("uri")
                    val rkey = uri.substringAfterLast('/')
                    if (rkey.isBlank()) continue
                    val author = p.optJSONObject("author")
                    val handle = author?.optString("handle").orEmpty()
                    val name = author?.optString("displayName").orEmpty().ifEmpty { handle }
                    val text = p.optJSONObject("record")?.optString("text").orEmpty().take(300)
                    val id = "$handle/$rkey"
                    found.putIfAbsent("bsky:$id", Item(id, "https://bsky.app/profile/$handle/post/$rkey", text, name, emb.optString("thumbnail"), playlist, MhTags.of(text)))
                }
            } catch (t: Throwable) {
                error = "Ошибка Bluesky: ${t.javaClass.simpleName}: ${t.message.orEmpty().take(120)}"
            } finally { conn.disconnect() }
        }
        if (found.isEmpty() && error.isNotEmpty()) return Result(emptyList(), error)
        return Result(found.values.toList(), if (found.isEmpty()) "Bluesky не вернул видео" else "Найдено ${found.size} видео")
    }
}
