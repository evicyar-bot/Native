package app.megastudiya.nativeapp

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

// Telegram через официальные интерфейсы:
//  1) Bot API (токен от @BotFather): бот получает видео и фото, которые пользователь пересылает ему в личку,
//     а также посты каналов, где бот назначен администратором. Файлы скачиваются через getFile и передаются в MediaHub.
//  2) Виджет постов Telegram (telegram-widget.js) для показа публичного поста во встроенном WebView.
// Чужие каналы и закрытые чаты через Bot API прочитать нельзя — только то, что отправлено боту или в его канал.
//
// Ограничения облачного Bot API: скачивание файла до 20 МБ (больше — getFile отвечает «file is too big»).
// Лимит снимается собственным сервером Bot API (telegram-bot-api, режим --local): тогда задайте TelegramBotConfig.apiBase;
// в этом режиме getFile возвращает локальный путь, и скачивание через HTTP здесь не используется.
// Безопасная схема (по умолчанию в настройках): токен бота хранится ТОЛЬКО на шлюзе владельца (server/gateway), в приложении —
// лишь ключ доступа, который пропускает getMe/getUpdates/getFile/getChat и скачивание файлов. Прямой режим с токеном на телефоне — для отладки.
// getUpdates не работает при установленном вебхуке и при втором потребителе (ошибка 409): deleteWebhook() это снимает.
// Токен — секрет: задавайте при запуске из настроек пользователя, в код не вшивайте.

object TelegramBotConfig {
    @Volatile var token: String = ""
    @Volatile var apiBase: String = "https://api.telegram.org"
    @Volatile var gatewayBase: String = ""      // https-адрес шлюза владельца без хвостового «/»
    @Volatile var accessKey: String = ""        // ключ доступа к шлюзу (не токен бота)
    val viaGateway: Boolean get() = gatewayBase.isNotBlank() && accessKey.isNotBlank()
    val configured: Boolean get() = viaGateway || token.isNotBlank()
    const val CLOUD_DOWNLOAD_LIMIT = 20L * 1024 * 1024
}

class TgApiException(val code: Int, val desc: String, val retryAfterSec: Int = 0) : Exception("Telegram $code: $desc")

data class TgMedia(
    val updateId: Long,
    val chatId: Long,
    val chatTitle: String,
    val messageId: Long,
    val dateMs: Long,
    val isVideo: Boolean,
    val fileId: String,
    val fileUniqueId: String,
    val size: Long,
    val durationMs: Long,
    val w: Int,
    val h: Int,
    val mime: String,
    val fileName: String,
    val caption: String,
    val author: String,
    val link: String,              // публичная ссылка на оригинал, если известна («t.me/канал/номер»)
    val fromChannel: Boolean
) {
    val ext: String
        get() {
            val e = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
            if (e.length in 2..5 && e.all { it.isLetterOrDigit() }) return e
            return when (mime.lowercase(Locale.ROOT)) {
                "video/quicktime" -> "mov"
                "video/webm" -> "webm"
                "image/png" -> "png"
                "image/webp" -> "webp"
                "image/gif" -> "gif"
                "image/jpeg" -> "jpg"
                else -> if (isVideo) "mp4" else "jpg"
            }
        }
}

class TgBatch(val media: List<TgMedia>, val nextOffset: Long, val updates: Int)

class TgFile(val path: String, val size: Long)

private object TgHttp {
    class Res(val code: Int, val body: String)

    fun postJson(url: String, json: String, readTimeoutMs: Int, auth: String = ""): Res {
        val conn = try { URL(url).openConnection() as HttpURLConnection } catch (_: Exception) { return Res(-1, "badUrl") }
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 8000
            conn.readTimeout = readTimeoutMs
            conn.instanceFollowRedirects = false
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            if (auth.isNotEmpty()) conn.setRequestProperty("Authorization", "Bearer $auth")
            conn.outputStream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            return Res(code, stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: "")
        } catch (e: Exception) {
            return Res(-1, e.javaClass.simpleName)
        } finally {
            try { conn.disconnect() } catch (_: Throwable) { }
        }
    }

    /** Потоковая загрузка в файл с жёстким лимитом. При любой ошибке частичный файл удаляется. */
    fun download(url: String, dest: File, maxBytes: Long, auth: String = ""): Long {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            if (auth.isNotEmpty()) conn.setRequestProperty("Authorization", "Bearer $auth")
            conn.connectTimeout = 8000
            conn.readTimeout = 20000
            val code = conn.responseCode
            if (code != 200) throw IOException("HTTP $code")
            if (conn.contentLengthLong > maxBytes) throw IOException("too big")
            var total = 0L
            conn.inputStream.use { ins ->
                dest.outputStream().use { out ->
                    val buf = ByteArray(65536)
                    while (true) {
                        val r = ins.read(buf)
                        if (r < 0) break
                        total += r
                        if (total > maxBytes) throw IOException("too big")
                        out.write(buf, 0, r)
                    }
                }
            }
            return total
        } catch (e: IOException) {
            dest.delete()
            throw e
        } finally {
            try { conn.disconnect() } catch (_: Throwable) { }
        }
    }
}

/** Блокирующие вызовы Bot API: только не на главном потоке. Ошибки — TgApiException (текст без токена). */
object TelegramBotApi {

    private fun call(method: String, params: JSONObject = JSONObject(), readTimeoutMs: Int = 15000): Any? {
        if (!TelegramBotConfig.configured) throw TgApiException(0, "бот не настроен")
        val r = if (TelegramBotConfig.viaGateway)
            TgHttp.postJson("${TelegramBotConfig.gatewayBase}/tg/$method", params.toString(), readTimeoutMs, TelegramBotConfig.accessKey)
        else
            TgHttp.postJson("${TelegramBotConfig.apiBase}/bot${TelegramBotConfig.token}/$method", params.toString(), readTimeoutMs)
        if (r.code < 0) throw TgApiException(-1, r.body)
        val o = try { JSONObject(r.body) } catch (_: Exception) { throw TgApiException(r.code, "ответ не разобран") }
        if (!o.optBoolean("ok", false)) {
            val retry = o.optJSONObject("parameters")?.optInt("retry_after", 0) ?: 0
            throw TgApiException(o.optInt("error_code", r.code), o.optString("description"), retry)
        }
        return o.opt("result")
    }

    /** Имя бота (без @) — проверка токена. */
    fun getMe(): String = (call("getMe") as? JSONObject)?.optString("username").orEmpty()

    /** Нужно один раз, если на боте стоял вебхук: иначе getUpdates отвечает 409. */
    fun deleteWebhook(dropPending: Boolean = false) {
        call("deleteWebhook", JSONObject().put("drop_pending_updates", dropPending))
    }

    /** Новые сообщения и посты каналов с видео/фото. timeoutSec > 0 — длинный опрос (до 50 с). */
    fun getUpdates(offset: Long, limit: Int = 50, timeoutSec: Int = 0): TgBatch {
        val t = timeoutSec.coerceIn(0, 50)
        val p = JSONObject()
        if (offset > 0) p.put("offset", offset)
        p.put("limit", limit.coerceIn(1, 100))
        p.put("timeout", t)
        p.put("allowed_updates", JSONArray().put("message").put("channel_post"))
        val arr = call("getUpdates", p, (t + 10) * 1000) as? JSONArray ?: JSONArray()
        var next = offset
        val media = ArrayList<TgMedia>()
        for (i in 0 until arr.length()) {
            val u = arr.optJSONObject(i) ?: continue
            val uid = u.optLong("update_id")
            if (uid + 1 > next) next = uid + 1
            val channel = u.has("channel_post")
            val m = u.optJSONObject("message") ?: u.optJSONObject("channel_post") ?: continue
            parseMedia(uid, m, channel)?.let { media.add(it) }
        }
        return TgBatch(media, next, arr.length())
    }

    fun getFile(fileId: String): TgFile {
        val r = call("getFile", JSONObject().put("file_id", fileId)) as? JSONObject ?: throw TgApiException(-1, "getFile: пустой ответ")
        val path = r.optString("file_path")
        if (path.isEmpty()) throw TgApiException(-1, "getFile: нет file_path")
        return TgFile(path, r.optLong("file_size", 0L))
    }

    /** Скачивает файл (до 20 МБ в облачном Bot API). IOException при ошибке сети или превышении лимита. */
    fun download(file: TgFile, dest: File): Long =
        if (TelegramBotConfig.viaGateway)
            TgHttp.download("${TelegramBotConfig.gatewayBase}/tg/file/${file.path}", dest, TelegramBotConfig.CLOUD_DOWNLOAD_LIMIT, TelegramBotConfig.accessKey)
        else
            TgHttp.download("${TelegramBotConfig.apiBase}/file/bot${TelegramBotConfig.token}/${file.path}", dest, TelegramBotConfig.CLOUD_DOWNLOAD_LIMIT)

    /** Публичный канал или группа по @имени: название и описание. Приватные и несуществующие → TgApiException (400). */
    fun getChatInfo(username: String): JSONObject? =
        call("getChat", JSONObject().put("chat_id", "@" + username.removePrefix("@"))) as? JSONObject

    private fun nameOf(c: JSONObject?): String {
        if (c == null) return ""
        val t = c.optString("title")
        return if (t.isNotEmpty()) t else (c.optString("first_name") + " " + c.optString("last_name")).trim()
    }

    private fun authorOf(m: JSONObject, chat: JSONObject): String {
        val fo = m.optJSONObject("forward_origin")
        if (fo != null) {
            val n = when (fo.optString("type")) {
                "channel" -> nameOf(fo.optJSONObject("chat"))
                "chat" -> nameOf(fo.optJSONObject("sender_chat"))
                "user" -> nameOf(fo.optJSONObject("sender_user"))
                "hidden_user" -> fo.optString("sender_user_name")
                else -> ""
            }
            if (n.isNotEmpty()) return n
        }
        val sc = nameOf(m.optJSONObject("sender_chat"))
        if (sc.isNotEmpty()) return sc
        val sig = m.optString("author_signature")
        if (sig.isNotEmpty()) return sig
        return nameOf(chat)
    }

    private fun linkOf(m: JSONObject, chat: JSONObject): String {
        val fo = m.optJSONObject("forward_origin")
        if (fo != null && fo.optString("type") == "channel") {
            val u = fo.optJSONObject("chat")?.optString("username").orEmpty()
            val mid = fo.optLong("message_id")
            if (u.isNotEmpty() && mid > 0) return "https://t.me/$u/$mid"
        }
        val u = chat.optString("username")
        if (u.isNotEmpty() && chat.optString("type") != "private") return "https://t.me/$u/${m.optLong("message_id")}"
        return ""
    }

    private fun parseMedia(updateId: Long, m: JSONObject, channel: Boolean): TgMedia? {
        val chat = m.optJSONObject("chat") ?: return null
        var node: JSONObject? = null
        var isVideo = true
        var mime = ""
        when {
            m.has("video") -> node = m.optJSONObject("video")
            m.has("animation") -> node = m.optJSONObject("animation")
            m.has("video_note") -> { node = m.optJSONObject("video_note"); mime = "video/mp4" }
            m.has("photo") -> {
                var best: JSONObject? = null
                val a = m.optJSONArray("photo")
                if (a != null) for (i in 0 until a.length()) {
                    val p = a.optJSONObject(i) ?: continue
                    if (best == null || p.optInt("width") * p.optInt("height") >= best.optInt("width") * best.optInt("height")) best = p
                }
                node = best; isVideo = false; mime = "image/jpeg"
            }
            m.has("document") -> {
                node = m.optJSONObject("document")
                val dm = node?.optString("mime_type").orEmpty()
                if (dm.startsWith("video/")) isVideo = true
                else if (dm.startsWith("image/")) isVideo = false
                else return null
            }
            else -> return null
        }
        val n = node ?: return null
        val fileId = n.optString("file_id")
        if (fileId.isEmpty()) return null
        if (mime.isEmpty()) mime = n.optString("mime_type")
        val side = n.optInt("length")                       // video_note: диаметр кружка
        val caption = m.optString("caption").ifEmpty { m.optString("text") }
        return TgMedia(
            updateId = updateId, chatId = chat.optLong("id"), chatTitle = nameOf(chat),
            messageId = m.optLong("message_id"), dateMs = m.optLong("date") * 1000L,
            isVideo = isVideo, fileId = fileId, fileUniqueId = n.optString("file_unique_id"),
            size = n.optLong("file_size", 0L), durationMs = n.optLong("duration") * 1000L,
            w = n.optInt("width", side), h = n.optInt("height", side), mime = mime,
            fileName = n.optString("file_name"), caption = caption.take(1024),
            author = authorOf(m, chat), link = linkOf(m, chat), fromChannel = channel
        )
    }
}

/**
 * Приём из бота в каталог: один опрос = скачать новые видео/фото и отдать их в MediaHub.ingestBatch (источник "telegram").
 * Дубли отсекает сам MediaHub (по SHA-256). Блокирующая — вызывать из фонового потока (например, раз в N минут или по кнопке).
 * Смещение getUpdates хранится в SharedPreferences; при сетевой ошибке подтверждается только обработанное, остальное придёт снова
 * (Telegram хранит неподтверждённые обновления 24 часа).
 */
object TelegramInbox {
    class PollResult(val ok: Boolean, val fetched: Int, val queued: Int, val skipped: List<String>, val error: String = "")

    private const val PREFS = "mh_telegram"

    fun resetOffset(ctx: Context) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove("offset").apply()
    }

    /** allowedChats — белый список chat_id (пусто = любые чаты, где бот получает сообщения). */
    fun pollOnce(ctx: Context, allowedChats: Set<Long> = emptySet(), onIngested: (IngestSummary) -> Unit = {}): PollResult {
        if (!TelegramBotConfig.configured) return PollResult(false, 0, 0, emptyList(), "бот не настроен")
        val app = ctx.applicationContext
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val skipped = ArrayList<String>()
        var queued = 0
        val batch = try {
            TelegramBotApi.getUpdates(prefs.getLong("offset", 0L), 50, 0)
        } catch (e: TgApiException) {
            val why = if (e.code == 409) "конфликт getUpdates: на боте вебхук или второй потребитель (см. deleteWebhook)" else e.desc
            return PollResult(false, 0, 0, skipped, why)
        }
        val dir = File(app.cacheDir, "tgin")
        dir.mkdirs()
        var commit = batch.nextOffset
        var error = ""
        for (m in batch.media) {
            if (allowedChats.isNotEmpty() && m.chatId !in allowedChats) continue
            if (m.size > TelegramBotConfig.CLOUD_DOWNLOAD_LIMIT) { skipped.add("файл больше 20 МБ (лимит Bot API)"); continue }
            val tmp = File(dir, (m.fileUniqueId.ifEmpty { m.updateId.toString() }) + "." + m.ext)
            try {
                TelegramBotApi.download(TelegramBotApi.getFile(m.fileId), tmp)
            } catch (e: TgApiException) {
                if (e.desc.contains("too big", ignoreCase = true)) { skipped.add("файл больше 20 МБ (лимит Bot API)"); continue }
                commit = m.updateId; error = e.desc; break
            } catch (e: IOException) {
                if (e.message == "too big") { skipped.add("файл больше 20 МБ (лимит Bot API)"); continue }
                commit = m.updateId; error = "сеть: " + (e.message ?: e.javaClass.simpleName); break
            }
            queued++
            val mime = m.mime.ifEmpty { if (m.isVideo) "video/mp4" else "image/jpeg" }
            MediaHub.ingestBatch(app, listOf(Uri.fromFile(tmp)), mime, "telegram", emptyList(), m.caption, false) { s ->
                tmp.delete()
                onIngested(s)
            }
        }
        prefs.edit().putLong("offset", commit).apply()
        return PollResult(error.isEmpty(), batch.media.size, queued, skipped, error)
    }
}

/** Адаптер под контракт VideoSource. Под текущий TelegramSource подставляется в VideoSources.all (id "telegram" тот же). */
object TelegramBotSource : VideoSource {
    override val id = "telegram"
    override val title = "Telegram"

    override fun status(): SourceStatus =
        if (!TelegramBotConfig.configured) SourceStatus(
            SourceStatus.NEEDS_ACCESS,
            "Бот не настроен: работает только «Поделиться» и превью публичных постов."
        ) else SourceStatus(
            SourceStatus.LIMITED,
            "Bot API: видео и фото, отправленные боту или в канал, где он администратор, скачиваются в приложение (до 20 МБ). " +
                "Чужие каналы и закрытые чаты бот не читает. Посты по ссылке — превью OpenGraph и виджет Telegram."
        )

    override fun handles(link: LinkInfo) = link.platform == "telegram"

    override fun fetchMeta(link: LinkInfo): MetaResult {
        if (link.canonical.startsWith("https://t.me/c/")) return MetaResult.Unsupported
        // Bot API не читает посты по номеру: для постов остаётся публичное превью.
        if (link.isPost) return TelegramSource.fetchMeta(link)
        if (!TelegramBotConfig.configured) return MetaResult.Unsupported
        val name = link.author.removePrefix("@")
        if (name.isEmpty()) return MetaResult.Unsupported
        return try {
            val c = TelegramBotApi.getChatInfo(name) ?: return MetaResult.Failed("пустой ответ")
            val t = c.optString("title")
            MetaResult.Ok(t.take(90), t, c.optString("description").take(600), "")
        } catch (e: TgApiException) {
            if (e.code == 400) MetaResult.Gone else MetaResult.Failed(e.desc)
        } catch (_: Throwable) {
            MetaResult.Failed("ошибка разбора")
        }
    }
}

/** Официальный виджет поста для WebView (только публичные каналы): loadDataWithBaseURL("https://t.me/", html, "text/html", "utf-8", null). */
object TelegramEmbed {
    private val chanRe = Regex("^[A-Za-z0-9_]{4,32}$")

    fun html(channel: String, postId: Long): String {
        if (!chanRe.matches(channel) || postId <= 0) return ""
        return """<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;background:#000}</style></head><body>
<script async src="https://telegram.org/js/telegram-widget.js?22" data-telegram-post="$channel/$postId" data-width="100%" data-dark="1" data-userpic="false"></script>
</body></html>"""
    }
}
