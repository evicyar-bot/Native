package app.megastudiya.nativeapp

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean

// Единая точка настройки и запуска коннекторов YouTube, Telegram и TikTok.
// Ключей, токенов и адресов в коде нет: значения лежат в закрытых настройках приложения (SharedPreferences "mh_connectors")
// и задаются владельцем через save…() — например, из экрана настроек. Пока значение не задано, коннектор не включается,
// а источник работает в прежнем режиме (oEmbed / превью OpenGraph).
//
// Что должен предоставить владелец:
//  • YouTube: ключ YouTube Data API v3 (Google Cloud), желательно с ограничением по приложению Android (package + SHA-1 подписи).
//    Для встроенного плеера YouTube ключ не нужен — он нужен только для метаданных, чартов и поиска.
//  • Шлюз владельца (server/gateway, один Cloudflare Worker): хранит client_secret TikTok и токен бота Telegram.
//    В приложении задаются только его https-адрес, client_key TikTok и ключ доступа Telegram (шифруется в Keystore).
//    Адрес шлюза владелец получает при развёртывании — в коде его нет.
//  • TikTok: client_key; Redirect URI в Login Kit = <адрес шлюза>/tiktok/callback. Шлюз возвращает пользователя в приложение
//    через схему megastudiya://tiktok (intent-filter в манифесте), поэтому сайт, домен и assetlinks.json не нужны.
//  • Telegram: рекомендуется через шлюз (ключ доступа вместо токена). Прямой режим с токеном бота на телефоне — только для отладки.
object ConnectorSetup {
    private const val PREFS = "mh_connectors"
    private const val K_YT_KEY = "yt_api_key"
    private const val K_TG_TOKEN = "tg_bot_token"
    private const val K_TT_KEY = "tt_client_key"
    private const val K_TG_ACCESS = "tg_access_key"
    private const val K_GATEWAY = "gateway_base"
    private const val K_TT_DISCOVERY = "tt_discovery_apify_token"
    private const val POLL_GAP_MS = 60_000L

    private val polling = AtomicBoolean(false)
    @Volatile private var lastPoll = 0L
    private val ui = Handler(Looper.getMainLooper())

    /** Растёт при каждом изменении настроек и состояния TikTok: экран настроек подписан на него и перерисовывается. */
    var rev by mutableIntStateOf(0)
        private set

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // Секреты (ключ YouTube, токен бота) лежат зашифрованными. Старая запись открытым текстом читается и тут же перешифровывается.
    private fun secret(ctx: Context, key: String): String {
        val p = prefs(ctx)
        val raw = p.getString(key, "").orEmpty()
        val plain = SecretBox.open(raw).trim()
        if (raw.isNotEmpty() && !SecretBox.isSealed(raw)) SecretBox.seal(plain)?.let { p.edit().putString(key, it).apply() }
        return plain
    }

    private fun putSecret(ctx: Context, key: String, value: String): Boolean {
        val v = value.trim()
        if (v.isEmpty()) { prefs(ctx).edit().remove(key).apply(); return true }
        val sealed = SecretBox.seal(v) ?: return false
        prefs(ctx).edit().putString(key, sealed).apply()
        return true
    }

    fun hasYouTubeKey(ctx: Context) = secret(ctx, K_YT_KEY).isNotEmpty()
    fun hasTelegramToken(ctx: Context) = secret(ctx, K_TG_TOKEN).isNotEmpty()
    fun hasTelegramAccessKey(ctx: Context) = secret(ctx, K_TG_ACCESS).isNotEmpty()
    fun gatewayBase(ctx: Context): String = prefs(ctx).getString(K_GATEWAY, "").orEmpty()
    fun tikTokClientKey(ctx: Context): String = prefs(ctx).getString(K_TT_KEY, "").orEmpty()
    fun hasTikTokDiscoveryToken(ctx: Context): Boolean = tikTokDiscoveryToken(ctx).isNotEmpty()
    fun tikTokDiscoveryToken(ctx: Context): String = secret(ctx, K_TT_DISCOVERY).ifEmpty { TikTokDiscovery.EMBEDDED_TOKEN.trim() }

    /** Применить сохранённые настройки. Вызывается при запуске приложения и после каждого save…(). */
    fun init(ctx: Context) {
        val app = ctx.applicationContext
        val p = prefs(app)

        YouTubeConfig.apiKey = secret(app, K_YT_KEY)
        if (YouTubeConfig.apiKey.isNotEmpty()) {
            YouTubeConfig.androidPackage = app.packageName
            YouTubeConfig.androidCertSha1 = certSha1(app)
        }

        // Origin встроенных плееров выводится из идентификатора приложения; своего сайта нет.
        // Выдуманный адрес вида https://<package> YouTube отвергает (ошибка 153, чёрный экран). Берём origin самого youtube.com — так встроенный плеер принимает страницу.
        YouTubeConfig.legacyOrigin = "https://" + app.packageName.lowercase().replace('_', '-')
        YouTubeConfig.embedOrigin = "https://www.youtube.com"

        val gw = p.getString(K_GATEWAY, "").orEmpty().trim().trimEnd('/')
        TelegramBotConfig.token = secret(app, K_TG_TOKEN)
        TelegramBotConfig.gatewayBase = gw
        TelegramBotConfig.accessKey = secret(app, K_TG_ACCESS)

        // TikTok включается, когда заданы client_key и адрес шлюза; client_secret в приложении не бывает.
        val key = p.getString(K_TT_KEY, "").orEmpty().trim()
        if (key.isNotEmpty() && gw.isNotEmpty()) {
            TikTokConfig.clientKey = key
            TikTokConfig.redirectUri = "$gw/tiktok/callback"
            TikTokConfig.tokenEndpoint = "$gw/tiktok/token"
        } else {
            TikTokConfig.clientKey = ""
            TikTokConfig.redirectUri = ""
        }
        TikTokApi.attach(app)
        rev++
    }

    /** false — шифрование Keystore недоступно, ключ не сохранён. Пустое значение удаляет ключ. */
    fun saveYouTubeKey(ctx: Context, apiKey: String): Boolean {
        val ok = putSecret(ctx, K_YT_KEY, apiKey)
        init(ctx)
        return ok
    }

    /** false — шифрование Keystore недоступно, токен не сохранён. Пустое значение удаляет токен. */
    fun saveTelegramToken(ctx: Context, token: String): Boolean {
        val ok = putSecret(ctx, K_TG_TOKEN, token)
        init(ctx)
        return ok
    }

    /** Ключ доступа к шлюзу (не токен бота). false — шифрование Keystore недоступно. Пустое значение удаляет ключ. */
    fun saveTelegramAccessKey(ctx: Context, key: String): Boolean {
        val ok = putSecret(ctx, K_TG_ACCESS, key)
        init(ctx)
        return ok
    }

    /** Адрес шлюза владельца (только https) или пусто. false — адрес не принят. */
    fun saveGateway(ctx: Context, base: String): Boolean {
        val b = base.trim().trimEnd('/')
        if (b.isNotEmpty() && (!b.startsWith("https://") || b.length < 12 || b.contains(' '))) return false
        prefs(ctx).edit().putString(K_GATEWAY, b).apply()
        init(ctx)
        return true
    }

    /** Токен Apify для автопоиска публичных TikTok. false — шифрование Keystore недоступно. Пустое значение удаляет токен. */
    fun saveTikTokDiscoveryToken(ctx: Context, token: String): Boolean {
        val ok = putSecret(ctx, K_TT_DISCOVERY, token)
        init(ctx)
        return ok
    }

    fun saveTikTok(ctx: Context, clientKey: String) {
        prefs(ctx).edit().putString(K_TT_KEY, clientKey.trim()).apply()
        init(ctx)
    }

    // ---------- Telegram: приём из бота ----------

    /** Вызывается при возврате в приложение: не чаще раза в минуту забирает новые файлы бота в каталог. Без токена ничего не делает. */
    fun onAppStart(ctx: Context) {
        if (!TelegramBotConfig.configured) return
        val now = SystemClock.elapsedRealtime()
        if (lastPoll != 0L && now - lastPoll < POLL_GAP_MS) return
        if (!polling.compareAndSet(false, true)) return
        lastPoll = now
        val app = ctx.applicationContext
        Thread({
            try {
                TelegramInbox.pollOnce(app)
            } catch (_: Throwable) {
            } finally {
                polling.set(false)
            }
        }, "mh-telegram-poll").also { it.isDaemon = true }.start()
    }

    // ---------- TikTok: подключение аккаунта ----------

    /** Intent страницы согласия TikTok (ctx.startActivity). null — Login Kit не настроен. Кнопку/экран для вызова добавляет владелец. */
    fun beginTikTok(): Intent? = TikTokApi.tokenStore?.let { TikTokAuth.begin(it) }

    /**
     * Возврат из TikTok по redirect URI. true — адрес распознан и обрабатывается.
     * Адрес возврата — схема megastudiya://tiktok, её принимает intent-filter MainActivity.
     */
    fun handleRedirect(ctx: Context, data: Uri?): Boolean {
        if (data == null || !TikTokConfig.configured) return false
        // Возврат приходит со шлюза как megastudiya://tiktok?code=…&state=…; чужой code не пройдёт проверку state/PKCE.
        if (data.scheme != "megastudiya" || data.host != "tiktok") return false
        val store = TikTokApi.tokenStore ?: return false
        val app = ctx.applicationContext
        Thread({
            var msg: String
            when (val r = TikTokAuth.complete(store, data)) {
                is TikTokAuthResult.Ok -> {
                    try { TikTokApi.userInfo() } catch (_: Throwable) { }
                    ui.post { rev++ }
                    msg = "TikTok подключён"
                    // После успешной авторизации — свои ролики в каталог (карточки-ссылки через обычный конвейер ingestBatch).
                    try {
                        TikTokApi.importOwn(app) { s -> ui.post { Toast.makeText(app, "TikTok: " + s.text(), Toast.LENGTH_LONG).show() } }
                    } catch (e: TtApiException) {
                        msg = if (e.scopeMissing) "TikTok подключён, но доступ к списку роликов (video.list) не одобрен"
                        else "TikTok подключён, ролики не загружены: " + e.msg.ifEmpty { e.code }
                    } catch (_: Throwable) {
                        msg = "TikTok подключён, ролики не загружены"
                    }
                }
                is TikTokAuthResult.Denied -> msg = "TikTok: доступ не выдан"
                is TikTokAuthResult.Failed -> msg = "TikTok: " + r.why
            }
            ui.post { Toast.makeText(app, msg, Toast.LENGTH_SHORT).show() }
        }, "mh-tiktok-auth").also { it.isDaemon = true }.start()
        return true
    }

    /** Повторный импорт своих роликов вручную (кнопка в настройках). Сеть: поток создаётся внутри, результат — через onDone в главном потоке. */
    fun importTikTokNow(ctx: Context, onDone: (String) -> Unit) {
        val app = ctx.applicationContext
        Thread({
            try {
                TikTokApi.importOwn(app) { s -> ui.post { onDone(s.text()) } }
            } catch (e: TtApiException) {
                ui.post { onDone(if (e.notConnected) "Аккаунт не подключён" else if (e.scopeMissing) "Доступ video.list не одобрен TikTok" else e.msg.ifEmpty { e.code }) }
            } catch (_: Throwable) {
                ui.post { onDone("Не удалось загрузить ролики") }
            }
        }, "mh-tiktok-import").also { it.isDaemon = true }.start()
    }

    fun disconnectTikTok() {
        TikTokApi.disconnect()
        rev++
    }

    // ---------- служебное ----------

    /** SHA-1 подписи приложения (hex, верхний регистр) — для ключей Google, ограниченных приложением Android. */
    @Suppress("DEPRECATION")
    private fun certSha1(ctx: Context): String = try {
        val pm = ctx.packageManager
        val sigs = if (Build.VERSION.SDK_INT >= 28) {
            pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo?.apkContentsSigners
        } else {
            pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES).signatures
        }
        val s = sigs?.firstOrNull()
        if (s == null) "" else MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02X".format(it) }
    } catch (_: Throwable) {
        ""
    }
}
