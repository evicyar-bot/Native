package app.megastudiya.nativeapp

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** Итог одной операции приёма. */
class IngestSummary {
    var added = 0
    var duplicates = 0
    val rejected = ArrayList<String>()
    val addedIds = ArrayList<String>()

    fun text(): String {
        val parts = ArrayList<String>()
        if (added > 0) parts.add("добавлено: $added")
        if (duplicates > 0) parts.add("уже было: $duplicates")
        if (rejected.isNotEmpty()) parts.add("не принято: ${rejected.size} (${rejected.first()})")
        return if (parts.isEmpty()) "Ничего не добавлено" else parts.joinToString(" · ").replaceFirstChar { it.uppercase() }
    }
}

class ProfileView(
    val events: Int, val lines: List<ForYouEngine.Line>,
    val liked: Int, val saved: Int, val hidden: Int
)

class HubStats(val local: Int, val images: Int, val links: Int, val bytes: Long, val thumbBytes: Long)

/** Открыть вкладку «Видео» из любого места (например, после «Поделиться»). */
object VideoGate {
    var openRequest by mutableIntStateOf(0)
    fun open() { openRequest++ }
}

// MediaHub = MediaReceiver (приём) + MediaRepository (файлы) + VideoCatalog (каталог) + UserSignals (сигналы) + ForYouEngine.
// Единый конвейер приёма: проверка доступности → нормализация → удаление дублей → сохранение карточки → каталог.
object MediaHub {
    private val lock = Any()
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "mediahub-io").also { it.isDaemon = true } }
    private val net = Executors.newFixedThreadPool(2) { r -> Thread(r, "mediahub-net").also { it.isDaemon = true } }
    private val ui = Handler(Looper.getMainLooper())
    private val counter = AtomicInteger(0)
    private val thumbBusy = HashSet<String>()
    private val seed = System.currentTimeMillis()

    private var appCtx: Context? = null
    private var data: List<VideoCard> = emptyList()      // источник истины (под lock)
    private var state = UserState()                       // под lock
    @Volatile private var pendingFocus = ""

    // Состояние для интерфейса (меняется только на главном потоке).
    val cards = mutableStateListOf<VideoCard>()
    var loaded by mutableStateOf(false)
        private set
    var busy by mutableIntStateOf(0)
        private set
    var likedIds by mutableStateOf<Set<String>>(emptySet())
        private set
    var savedIds by mutableStateOf<Set<String>>(emptySet())
        private set
    var hiddenIds by mutableStateOf<Set<String>>(emptySet())
        private set
    var discoveryBusy by mutableStateOf(false)
    var discoveryMessage by mutableStateOf("")
    /** Итог последнего поиска по каждому источнику: показывается в строке диагностики на карточке. */
    var lastReport by mutableStateOf("поиск ещё не выполнялся")
        private set
    @Volatile private var lastDiscoveryAt = 0L
    private val discoveryRound = AtomicInteger(0)

    private fun main(f: () -> Unit) {
        if (Looper.myLooper() === Looper.getMainLooper()) f() else ui.post { f() }
    }

    // ---------- загрузка ----------

    fun load(ctx: Context) {
        if (appCtx != null) return
        val app = ctx.applicationContext
        appCtx = app
        val list = MediaRepository.loadCards(app) ?: emptyList()
        val st = MediaRepository.loadState(app)
        synchronized(lock) { data = list; state = st }
        publish()
        loaded = true
        io.execute { housekeeping(app) }
    }

    /** Фоновая уборка и восстановление после перезапуска. */
    private fun housekeeping(app: Context) {
        try {
            MediaRepository.dir(app, "tmp").listFiles()?.forEach { it.delete() }
            val known = synchronized(lock) { data.map { it.file }.toSet() }
            // 1. карточки, у которых пропал файл, помечаются недоступными (и возвращаются, если файл вернулся)
            var cur = synchronized(lock) { data }
            val fixed = cur.map { c ->
                if (!c.hasFile) c else {
                    val ex = MediaRepository.fileOf(app, c.file).exists()
                    if (!ex && c.status == Mk.OK) c.copy(status = Mk.UNAVAILABLE)
                    else if (ex && c.status == Mk.UNAVAILABLE) c.copy(status = Mk.OK) else c
                }
            }
            if (fixed != cur) commit(app, fixed)
            // 2. файлы без карточки (потерян cards.json) принимаются обратно
            for (sub in listOf("videos", "images")) {
                MediaRepository.dir(app, sub).listFiles()?.forEach { f ->
                    if (f.isFile && "$sub/${f.name}" !in known) adoptOrphan(app, f, sub == "videos")
                }
            }
            // 3. ссылки без описания: ещё раз спросить площадку (не больше 10 за запуск)
            cur = synchronized(lock) { data }
            cur.filter { it.kind == Mk.LINK && it.status == Mk.OK && (it.meta == Mk.META_PENDING || it.meta == Mk.META_FAILED) }
                .take(10).forEach { fetchMetaAsync(app, it.id) }
        } catch (_: Throwable) {
        }
    }

    private fun publish() {
        val snap: List<VideoCard>
        val l: Set<String>; val s: Set<String>; val h: Set<String>
        synchronized(lock) {
            snap = data
            l = state.liked.toSet(); s = state.saved.toSet(); h = state.hidden.toSet()
        }
        main {
            cards.clear(); cards.addAll(snap)
            likedIds = l; savedIds = s; hiddenIds = h
        }
    }

    /** Только поток io. */
    private fun commit(app: Context, list: List<VideoCard>) {
        val json: String
        synchronized(lock) { data = list; json = MediaRepository.cardsJson(list) }
        MediaRepository.saveCards(app, json)
        publish()
    }

    private fun find(id: String): VideoCard? = synchronized(lock) { data.firstOrNull { it.id == id } }

    fun card(id: String): VideoCard? = cards.firstOrNull { it.id == id }

    fun isVisible(c: VideoCard): Boolean = c.status == Mk.OK && c.id !in hiddenIds

    fun visibleIds(): List<String> = cards.filter { isVisible(it) }.map { it.id }

    fun takeFocus(): String? {
        val f = pendingFocus
        pendingFocus = ""
        return f.ifEmpty { null }
    }

    val lastId: String get() = synchronized(lock) { state.lastId }

    fun setLast(id: String) = synchronized(lock) { state.lastId = id }

    // ---------- автоматическое обнаружение публичных TikTok ----------

    /** Заполняет каталог публичными TikTok результатами. Секрет хранится зашифрованно в настройках. */
    fun discoverTikTok(ctx: Context, force: Boolean = false, done: ((String) -> Unit)? = null) {
        load(ctx)
        val app = ctx.applicationContext
        val now = System.currentTimeMillis()
        if (discoveryBusy) { done?.let { main { it("Поиск уже выполняется") } }; return }
        if (!force && now - lastDiscoveryAt < 4 * 60 * 1000L) { done?.let { main { it(discoveryMessage.ifEmpty { "Автопоиск недавно выполнялся" }) } }; return }
        val token = ConnectorSetup.tikTokDiscoveryToken(app)   // нужен только для TikTok; YouTube работает без токена
        discoveryBusy = true
        busy++
        lastDiscoveryAt = now
        val round = discoveryRound.getAndIncrement()
        val qs = TikTokDiscovery.defaultQueries
        val queries = listOf(qs[round % qs.size], qs[(round + 3) % qs.size], qs[(round + 5) % qs.size]).distinct()
        val bq = BlueskyDiscovery.defaultQueries
        val bskyQueries = listOf(bq[round % bq.size], bq[(round + 3) % bq.size]).distinct()
        val yq = YouTubeDiscovery.defaultQueries
        val ytQueries = listOf(yq[round % yq.size], yq[(round + 3) % yq.size]).distinct()
        net.execute {
            // Skylight/Bluesky: открытый API без токена. Ошибка не мешает остальным источникам.
            val bs = try { BlueskyDiscovery.discover(bskyQueries) } catch (t: Throwable) { BlueskyDiscovery.Result(emptyList(), "Ошибка Bluesky: ${t.javaClass.simpleName}") }
            var bsAdded = 0
            io.execute {
                val existing = synchronized(lock) { data.map { it.dedupKey }.toHashSet() }
                val bsCards = bs.items.filter { "bsky:${it.postId}" !in existing }.map { item ->
                    VideoCard(
                        id = newId("bs"), kind = Mk.LINK, source = "bsky", dedupKey = "bsky:${item.postId}",
                        url = item.url, title = item.title, author = item.author, desc = item.title,
                        tags = item.tags, thumbUrl = item.thumb, added = System.currentTimeMillis(),
                        streamUrl = item.stream, meta = Mk.META_OK
                    )
                }
                if (bsCards.isNotEmpty()) {
                    val cur = synchronized(lock) { data }
                    commit(app, cur + bsCards)
                }
                bsAdded = bsCards.size
            }
            val tt = if (token.isBlank()) TikTokDiscovery.Result(emptyList(), "") else try { TikTokDiscovery.discover(token, queries, 5) } catch (t: Throwable) { TikTokDiscovery.Result(emptyList(), "Ошибка поиска: ${t.javaClass.simpleName}") }
            var ttAdded = 0
            io.execute {
                val existing = synchronized(lock) { data.map { it.dedupKey }.toHashSet() }
                val cardsToAdd = tt.items.filter { it.videoId.isNotBlank() && "tiktok:${it.videoId}" !in existing }.map { item ->
                    VideoCard(
                        id = newId("tt"), kind = Mk.LINK, source = "tiktok", dedupKey = "tiktok:${item.videoId}",
                        url = item.url, title = item.title, author = item.author, desc = item.title,
                        tags = item.tags, thumbUrl = item.thumb, added = System.currentTimeMillis(),
                        embedId = item.videoId, streamUrl = item.streamUrl, meta = Mk.META_OK
                    )
                }
                if (cardsToAdd.isNotEmpty()) {
                    val cur = synchronized(lock) { data }
                    commit(app, cur + cardsToAdd)
                }
                ttAdded = cardsToAdd.size
            }
            // YouTube идёт после TikTok и не зависит от него: ошибка одного источника не мешает другому
            val yt = try { YouTubeDiscovery.discover(ytQueries) } catch (t: Throwable) { YouTubeDiscovery.Result(emptyList(), "Ошибка поиска YouTube: ${t.javaClass.simpleName}") }
            io.execute {
                val existing = synchronized(lock) { data.map { it.dedupKey }.toHashSet() }
                val ytCards = yt.items.filter { "yt:${it.videoId}" !in existing }.map { item ->
                    VideoCard(
                        id = newId("yt"), kind = Mk.LINK, source = "youtube", dedupKey = "yt:${item.videoId}",
                        url = item.url, title = item.title, author = item.author, desc = item.title,
                        tags = item.tags, thumbUrl = item.thumb, added = System.currentTimeMillis(),
                        embedId = item.videoId, meta = Mk.META_OK
                    )
                }
                if (ytCards.isNotEmpty()) {
                    val cur = synchronized(lock) { data }
                    commit(app, cur + ytCards)
                }
                val parts = ArrayList<String>()
                if (bsAdded > 0) parts.add("Skylight +$bsAdded")
                if (ttAdded > 0) parts.add("TikTok +$ttAdded")
                if (ytCards.isNotEmpty()) parts.add("YouTube +${ytCards.size}")
                val errs = listOf(bs.message, tt.message, yt.message).filter { it.startsWith("Apify HTTP") || it.startsWith("Ошибка") }
                val msg = when {
                    parts.isNotEmpty() -> "Добавлено: " + parts.joinToString(", ") + (if (errs.isNotEmpty()) ". " + errs.first() else "")
                    errs.isNotEmpty() -> errs.joinToString(" | ")
                    else -> "Новых видео нет (дубли или пустой поиск)"
                }
                val report = "Skylight: ${bs.message} | TikTok: ${if (token.isBlank()) "нет токена Apify" else tt.message} | YouTube: ${yt.message}"
                main { discoveryBusy = false; busy = (busy - 1).coerceAtLeast(0); discoveryMessage = msg; lastReport = report; done?.invoke(msg) }
            }
        }
    }

    // ---------- приём ----------

    /**
     * Единая точка приёма: локальные файлы (content://, из галереи или «Поделиться») и ссылки.
     * done вызывается на главном потоке.
     */
    fun ingestBatch(
        ctx: Context, uris: List<Uri>, mimeHint: String?, source: String,
        urls: List<String>, caption: String, allowWeb: Boolean, done: (IngestSummary) -> Unit
    ) {
        load(ctx)
        val app = ctx.applicationContext
        main { busy += 1 }
        io.execute {
            val sum = IngestSummary()
            try {
                for (u in uris) ingestUri(app, u, mimeHint, source, caption, sum)
                for (u in urls) ingestLink(app, u, caption, allowWeb, sum)
            } catch (t: Throwable) {
                sum.rejected.add("ошибка: ${t.javaClass.simpleName}")
            }
            main { busy -= 1; done(sum) }
        }
    }

    private fun newId(prefix: String): String =
        prefix + System.currentTimeMillis().toString(36) + counter.incrementAndGet().toString(36)

    private fun hasKey(key: String): Boolean = synchronized(lock) { data.any { it.dedupKey == key } }

    private fun addCard(app: Context, c: VideoCard, sum: IngestSummary) {
        val list = synchronized(lock) { data } + c
        pendingFocus = c.id
        commit(app, list)
        sum.added++
        sum.addedIds.add(c.id)
    }

    private fun ingestLink(app: Context, raw: String, caption: String, allowWeb: Boolean, sum: IngestSummary) {
        val info = LinkNorm.parse(raw)
        if (info == null) { sum.rejected.add("некорректная ссылка"); return }
        if (info.platform == "web" && !allowWeb) { sum.rejected.add("это не ссылка на поддерживаемую площадку"); return }
        if (hasKey(info.key)) { sum.duplicates++; return }
        val src = VideoSources.forLink(info)
        val c = VideoCard(
            id = newId("l"), kind = Mk.LINK, source = info.platform, dedupKey = info.key, url = info.canonical,
            title = "", author = info.author, desc = caption.take(600), tags = MhTags.of(caption),
            added = System.currentTimeMillis(), embedId = if (info.platform == "tiktok") info.videoId else "",
            meta = if (src == null || src is InstagramSource || !info.isPost) Mk.META_UNSUPPORTED else Mk.META_PENDING
        )
        addCard(app, c, sum)
        if (c.meta == Mk.META_PENDING) fetchMetaAsync(app, c.id)
    }

    private fun fetchMetaAsync(app: Context, id: String) {
        net.execute {
            val c = find(id) ?: return@execute
            val info = LinkNorm.parse(c.url)
            val src = info?.let { VideoSources.forLink(it) }
            val res: MetaResult = if (info == null || src == null) MetaResult.Unsupported
            else try { src.fetchMeta(info) } catch (t: Throwable) { MetaResult.Failed(t.javaClass.simpleName) }
            io.execute { applyMeta(app, id, res) }
        }
    }

    private fun applyMeta(app: Context, id: String, r: MetaResult) {
        val c = find(id) ?: return
        val n: VideoCard = when (r) {
            is MetaResult.Ok -> {
                var key = c.dedupKey
                if (c.source == "tiktok" && key.startsWith("tiktok-short:") && r.videoId.isNotEmpty()) key = "tiktok:" + r.videoId
                if (key != c.dedupKey && synchronized(lock) { data.any { it.id != c.id && it.dedupKey == key } }) {
                    // короткая ссылка оказалась роликом, который уже есть в каталоге
                    removeLocked(app, id)
                    return
                }
                val text = r.title + " " + r.desc
                c.copy(
                    dedupKey = key, title = r.title, author = r.author.ifEmpty { c.author },
                    desc = c.desc.ifEmpty { r.desc }, thumbUrl = r.thumb,
                    tags = if (c.tags.isEmpty()) MhTags.of(text) else c.tags,
                    published = if (r.published > 0) r.published else c.published,
                    embedId = if (c.source == "tiktok") r.videoId.ifEmpty { c.embedId } else c.embedId,
                    meta = Mk.META_OK
                )
            }
            is MetaResult.Gone -> c.copy(status = Mk.UNAVAILABLE, meta = Mk.META_GONE)
            is MetaResult.Unsupported -> c.copy(meta = Mk.META_UNSUPPORTED)
            is MetaResult.Failed -> c.copy(meta = Mk.META_FAILED)
        }
        val list = synchronized(lock) { data.map { if (it.id == id) n else it } }
        commit(app, list)
    }

    // ----- локальные файлы -----

    private val videoExt = setOf("mp4", "mov", "m4v", "webm", "3gp", "mkv")
    private val imageExt = setOf("jpg", "jpeg", "png", "webp", "gif", "heic", "heif", "bmp")

    private fun ingestUri(app: Context, uri: Uri, mimeHint: String?, source: String, caption: String, sum: IngestSummary) {
        val cr = app.contentResolver
        var name = ""
        var size = -1L
        try {
            cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni) ?: ""
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (_: Throwable) {
        }
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = (try { cr.getType(uri) } catch (_: Throwable) { null }) ?: mimeHint ?: ""
        val isVideo = mime.startsWith("video/") || (!mime.startsWith("image/") && ext in videoExt)
        val isImage = !isVideo && (mime.startsWith("image/") || ext in imageExt)
        if (!isVideo && !isImage) { sum.rejected.add("формат не поддерживается"); return }
        if (size > Mk.MAX_FILE_BYTES) { sum.rejected.add("файл больше ${Mk.MAX_FILE_BYTES / 1048576} МБ"); return }
        if (size > 0 && app.filesDir.usableSpace < size + size / 5 + 50L * 1048576) { sum.rejected.add("не хватает места"); return }

        val fext = when {
            ext.isNotEmpty() && ext.length <= 5 && (ext in videoExt || ext in imageExt) -> ext
            isVideo -> "mp4"
            else -> "jpg"
        }
        val tmp = File(MediaRepository.dir(app, "tmp"), "in" + counter.incrementAndGet() + "." + fext)
        val sha: String
        val bytes: Long
        try {
            val ins = cr.openInputStream(uri)
            if (ins == null) { sum.rejected.add("нет доступа к файлу"); return }
            val md = MessageDigest.getInstance("SHA-256")
            var total = 0L
            ins.use { input ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(65536)
                    while (true) {
                        val r = input.read(buf)
                        if (r < 0) break
                        total += r
                        if (total > Mk.MAX_FILE_BYTES) throw java.io.IOException("too big")
                        md.update(buf, 0, r)
                        out.write(buf, 0, r)
                    }
                }
            }
            sha = md.digest().joinToString("") { "%02x".format(it) }
            bytes = total
        } catch (e: SecurityException) {
            tmp.delete(); sum.rejected.add("разрешение на файл истекло"); return
        } catch (e: java.io.IOException) {
            tmp.delete(); sum.rejected.add(if (e.message == "too big") "файл слишком большой" else "файл не прочитан"); return
        }
        if (bytes <= 0) { tmp.delete(); sum.rejected.add("пустой файл"); return }
        if (hasKey("f:$sha")) { tmp.delete(); sum.duplicates++; return }

        val id = newId(if (isVideo) "v" else "i")
        val sub = if (isVideo) "videos" else "images"
        val dest = File(MediaRepository.dir(app, sub), "$id.$fext")
        if (!tmp.renameTo(dest)) { tmp.delete(); sum.rejected.add("не удалось сохранить"); return }
        val title = name.substringBeforeLast('.').replace('_', ' ').trim()
        val card = finalizeLocal(app, dest, "$sub/${dest.name}", id, isVideo, title, source, caption, sha, bytes)
        if (card == null) { dest.delete(); sum.rejected.add(if (isVideo) "видео повреждено или не читается" else "изображение повреждено"); return }
        addCard(app, card, sum)
    }

    private class Probe(val durMs: Long, val w: Int, val h: Int, val frame: Bitmap?)

    private fun probeVideo(f: File): Probe? {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(f.absolutePath)
            if (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) != "yes") return null
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            val frame = try { r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) } catch (_: Throwable) { null }
            if ((w <= 0 || h <= 0) && frame != null) { w = frame.width; h = frame.height }
            if (w <= 0 || h <= 0) return null
            if (dur <= 0 && frame == null) return null
            return Probe(dur, w, h, frame)
        } catch (_: Throwable) {
            return null
        } finally {
            try { r.release() } catch (_: Throwable) { }
        }
    }

    private fun saveThumb(app: Context, id: String, frame: Bitmap): String {
        return try {
            val maxSide = 720
            val k = maxSide.toFloat() / maxOf(frame.width, frame.height)
            val bmp = if (k < 1f) Bitmap.createScaledBitmap(frame, (frame.width * k).toInt().coerceAtLeast(1), (frame.height * k).toInt().coerceAtLeast(1), true) else frame
            val f = File(MediaRepository.dir(app, "thumbs"), "$id.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            "thumbs/$id.jpg"
        } catch (_: Throwable) {
            ""
        }
    }

    /** Проверка файла и сборка карточки. null — файл повреждён. */
    private fun finalizeLocal(
        app: Context, f: File, rel: String, id: String, isVideo: Boolean,
        title: String, source: String, caption: String, sha: String, bytes: Long
    ): VideoCard? {
        val now = System.currentTimeMillis()
        if (isVideo) {
            val p = probeVideo(f) ?: return null
            val thumb = p.frame?.let { saveThumb(app, id, it) } ?: ""
            return VideoCard(
                id = id, kind = Mk.LOCAL, source = source, dedupKey = "f:$sha", file = rel, thumb = thumb,
                title = title, desc = caption.take(600), tags = MhTags.of(caption), added = now,
                durationMs = p.durMs, w = p.w, h = p.h, bytes = bytes
            )
        }
        val o = BitmapFactory.Options().also { it.inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        return VideoCard(
            id = id, kind = Mk.IMAGE, source = source, dedupKey = "f:$sha", file = rel,
            title = title, desc = caption.take(600), tags = MhTags.of(caption), added = now,
            w = o.outWidth, h = o.outHeight, bytes = bytes
        )
    }

    private fun sha256Of(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { ins ->
            val buf = ByteArray(65536)
            while (true) { val r = ins.read(buf); if (r < 0) break; md.update(buf, 0, r) }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** Файл в папке без карточки (cards.json потерян или не успел записаться): вернуть в каталог. */
    private fun adoptOrphan(app: Context, f: File, isVideo: Boolean) {
        try {
            val sha = sha256Of(f)
            if (hasKey("f:$sha")) { f.delete(); return }
            val id = f.nameWithoutExtension
            val rel = (if (isVideo) "videos/" else "images/") + f.name
            val c = finalizeLocal(app, f, rel, id, isVideo, "Восстановленный файл", "device", "", sha, f.length()) ?: return
            commit(app, synchronized(lock) { data } + c)
        } catch (_: Throwable) {
        }
    }

    /** Превью можно удалять для освобождения места; для видео оно пересоздаётся при показе. */
    fun ensureThumb(ctx: Context, id: String) {
        val app = ctx.applicationContext
        synchronized(thumbBusy) { if (!thumbBusy.add(id)) return }
        io.execute {
            try {
                val c = find(id) ?: return@execute
                if (c.kind != Mk.LOCAL || c.status != Mk.OK) return@execute
                if (MediaRepository.thumbFile(app, c) != null) return@execute
                val f = MediaRepository.fileOf(app, c.file)
                if (!f.exists()) return@execute
                val p = probeVideo(f) ?: return@execute
                val rel = p.frame?.let { saveThumb(app, id, it) } ?: return@execute
                commit(app, synchronized(lock) { data.map { if (it.id == id) it.copy(thumb = rel) else it } })
            } finally {
                synchronized(thumbBusy) { thumbBusy.remove(id) }
            }
        }
    }

    // ---------- удаление и кэш ----------

    private fun removeLocked(app: Context, id: String) {
        val c = find(id) ?: return
        try {
            if (c.file.isNotEmpty()) MediaRepository.fileOf(app, c.file).delete()
            if (c.thumb.isNotEmpty()) MediaRepository.fileOf(app, c.thumb).delete()
        } catch (_: Throwable) {
        }
        synchronized(lock) {
            state.liked.remove(id); state.saved.remove(id); state.hidden.remove(id)
            state.profile.counted.remove(id); state.profile.seen.remove(id); state.profile.shown.remove(id)
            if (state.lastId == id) state.lastId = ""
        }
        commit(app, synchronized(lock) { data.filter { it.id != id } })
        scheduleSave()
    }

    /** Удаляет карточку вместе с локальным файлом и превью. */
    fun delete(ctx: Context, id: String) {
        val app = ctx.applicationContext
        io.execute { removeLocked(app, id) }
    }

    /** Очистка кэша: превью (пересоздаются). Видеофайлы и карточки не затрагиваются. */
    fun clearCache(ctx: Context, done: (Long) -> Unit) {
        val app = ctx.applicationContext
        io.execute {
            var freed = 0L
            try {
                MediaRepository.dir(app, "thumbs").listFiles()?.forEach { freed += it.length(); it.delete() }
                MediaRepository.dir(app, "tmp").listFiles()?.forEach { freed += it.length(); it.delete() }
            } catch (_: Throwable) {
            }
            main { done(freed) }
        }
    }

    fun stats(ctx: Context): HubStats {
        val app = ctx.applicationContext
        val snap = synchronized(lock) { data }
        var tb = 0L
        try { MediaRepository.dir(app, "thumbs").listFiles()?.forEach { tb += it.length() } } catch (_: Throwable) { }
        return HubStats(
            snap.count { it.kind == Mk.LOCAL }, snap.count { it.kind == Mk.IMAGE }, snap.count { it.kind == Mk.LINK },
            snap.filter { it.hasFile }.sumOf { it.bytes }, tb
        )
    }

    // ---------- сигналы пользователя (UserSignals) ----------

    private var saveQueued = false

    private fun scheduleSave() {
        val app = appCtx ?: return
        synchronized(lock) { if (saveQueued) return; saveQueued = true }
        ui.postDelayed({ io.execute { saveStateNow(app) } }, 1500)
    }

    private fun saveStateNow(app: Context) {
        val json: String
        synchronized(lock) { saveQueued = false; json = MediaRepository.stateJson(state) }
        MediaRepository.saveState(app, json)
    }

    /** Сброс на диск при уходе приложения на задний план. */
    fun flush() {
        val app = appCtx ?: return
        io.execute { saveStateNow(app) }
    }

    private fun applyLocked(c: VideoCard, s: Signal) {
        ForYouEngine.apply(state.profile, c.toCand(), s)
        state.events.add(s)
        while (state.events.size > 800) state.events.removeAt(0)
    }

    private fun record(id: String, make: (Long) -> Signal, mutate: (UserState) -> Unit = {}) {
        synchronized(lock) {
            val c = data.firstOrNull { it.id == id } ?: return
            mutate(state)
            applyLocked(c, make(System.currentTimeMillis()))
        }
        publish()
        scheduleSave()
    }

    fun signalView(id: String, dwellMs: Long, durMs: Long, loops: Int) =
        record(id, { t -> Signal(t, id, Sig.VIEW, dwellMs, durMs, loops) })

    fun toggleLike(id: String) {
        val liked = id in likedIds
        record(id, { t -> Signal(t, id, if (liked) Sig.UNLIKE else Sig.LIKE) }) { s -> if (liked) s.liked.remove(id) else s.liked.add(id) }
    }

    fun toggleSave(id: String) {
        val saved = id in savedIds
        record(id, { t -> Signal(t, id, if (saved) Sig.UNSAVE else Sig.SAVE) }) { s -> if (saved) s.saved.remove(id) else s.saved.add(id) }
    }

    fun signalShare(id: String) = record(id, { t -> Signal(t, id, Sig.SHARE) })
    fun signalOpen(id: String) = record(id, { t -> Signal(t, id, Sig.OPEN) })
    fun hide(id: String) = record(id, { t -> Signal(t, id, Sig.HIDE) }) { s -> s.hidden.add(id) }

    // ---------- рекомендации ----------

    /** Следующая порция ленты для истории показа history (id в порядке показа). Сохранённые и лайкнутые не имеют особых прав. */
    fun plan(history: List<String>, count: Int): List<String> {
        return synchronized(lock) {
            val now = System.currentTimeMillis()
            val cands = data.filter { it.status == Mk.OK && it.id !in state.hidden }.map { it.toCand() }
            val byId = cands.associateBy { it.id }
            val hist = history.mapNotNull { byId[it] }
            ForYouEngine.plan(state.profile, cands, hist, now, seed, count)
        }
    }

    /** «Смотреть сначала»: снять паузу после показа. Накопленные интересы не трогаем. */
    fun restartSession() {
        synchronized(lock) { state.profile.shown.clear() }
        scheduleSave()
    }

    fun profileView(): ProfileView = synchronized(lock) {
        val now = System.currentTimeMillis()
        ProfileView(
            state.profile.events, ForYouEngine.topInterests(state.profile, now),
            state.liked.size, state.saved.size, state.hidden.size
        )
    }

    /** Сбросить профиль интересов целиком (лайки, сохранённое и скрытое остаются отметками пользователя). */
    fun resetProfile() {
        synchronized(lock) { state.profile = Profile(); state.events.clear() }
        scheduleSave()
    }

    fun forgetTag(tag: String) {
        synchronized(lock) { state.profile.tags.remove(tag) }
        scheduleSave()
    }

    fun unhideAll() {
        synchronized(lock) { state.hidden.clear() }
        publish()
        scheduleSave()
    }
}
