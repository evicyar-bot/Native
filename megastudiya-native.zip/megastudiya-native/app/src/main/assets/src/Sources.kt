package app.megastudiya.nativeapp

import android.content.Context

// Реестр «акведуков»: открытые источники текста без паролей и ключей. Читает ядро (в потоке чтения).
// Каждому источнику ведётся счёт: сколько раз тянули, сколько вышло полезного текста. Удачные берутся чаще.
// Свои RSS/Atom добавляются в чате: «источник: https://...». Только открытые адреса, без обхода входов и платных стен.
object Sources {
    private class Src(val id: String, val title: String, val url: () -> String, val kind: Int) // kind: 0 вики-JSON, 1 RSS/Atom

    private val rnd = java.util.Random()
    private val arxivCats = listOf("cs.AI", "cs.CL", "cs.LG", "cs.NE", "q-bio.NC", "physics.soc-ph", "stat.ML", "cs.SE")
    private val builtin = listOf(
        Src("wiki_ru", "Википедия (рус)", { wiki("ru") }, 0),
        Src("wiki_en", "Википедия (англ)", { wiki("en") }, 0),
        Src("arxiv", "arXiv: статьи", {
            "https://export.arxiv.org/api/query?search_query=cat:" + arxivCats[rnd.nextInt(arxivCats.size)] +
                "&start=" + rnd.nextInt(400) + "&max_results=5"
        }, 1),
        Src("habr", "Хабр", { "https://habr.com/ru/rss/articles/" }, 1)
    )

    private fun wiki(l: String) = "https://$l.wikipedia.org/w/api.php?action=query&format=json&generator=random&grnnamespace=0&grnlimit=3" +
        "&prop=extracts&exintro=1&explaintext=1&exlimit=3&exchars=2500"

    // Букварь читается без сети, пока словаря мало: 70 раз, этого хватает, чтобы падежи, лица и
    // союзы примелькались, а дальше её учат обычные источники.
    private const val PRIMER_TARGET = 70
    private fun primerReads() = ctxApp?.getSharedPreferences("ms", Context.MODE_PRIVATE)?.getInt("primerReads", 0) ?: PRIMER_TARGET

    private var ctxApp: Context? = null
    private fun prefs() = ctxApp?.getSharedPreferences("ms", Context.MODE_PRIVATE)

    fun init(ctx: Context) { ctxApp = ctx.applicationContext }

    // свои источники владельца: по адресу в строке
    fun user(): List<String> = prefs()?.getString("srcUser", "")?.split("\n")?.map { it.trim() }?.filter { it.startsWith("http") } ?: emptyList()

    fun addUser(url: String): String {
        val u = url.trim()
        if (!(u.startsWith("https://") || u.startsWith("http://")) || u.length > 300 || u.contains(" ")) return "Нужен адрес вида https://..."
        val cur = user()
        if (u in cur) return "Этот источник уже есть."
        if (cur.size >= 50) return "Источников уже 50, это потолок пока."
        prefs()?.edit()?.putString("srcUser", (cur + u).joinToString("\n"))?.apply()
        return "Добавила. Буду читать наравне с остальными."
    }

    private fun stat(id: String): Pair<Int, Int> { // попыток, удачных
        val s = prefs()?.getString("srcSt:$id", "0,0")?.split(",") ?: return Pair(0, 0)
        return Pair(s.getOrNull(0)?.toIntOrNull() ?: 0, s.getOrNull(1)?.toIntOrNull() ?: 0)
    }

    private fun mark(id: String, ok: Boolean) {
        val (n, g) = stat(id)
        prefs()?.edit()?.putString("srcSt:$id", "${n + 1},${g + if (ok) 1 else 0}")?.apply()
    }

    // «сводка для чата»: кто как кормит
    fun summary(): String {
        val sb = StringBuilder("Мои источники:\n")
        for (s in builtin) { val (n, g) = stat(s.id); sb.append("• ${s.title}: $g из $n\n") }
        for (u in user()) { val (n, g) = stat("u:$u"); sb.append("• ${u.take(60)}: $g из $n\n") }
        return sb.toString().trim()
    }

    // Один заход за текстом: выбрать источник по весу, скачать, вернуть (текст, байт). null: не вышло.
    fun fetch(): Pair<String, Int>? {
        if (primerReads() < PRIMER_TARGET) {
            prefs()?.edit()?.putInt("primerReads", primerReads() + 1)?.apply()
            val t = Primer.chunk()
            return Pair(t, t.toByteArray(Charsets.UTF_8).size)
        }
        val all = ArrayList<Triple<String, () -> String, Int>>()
        for (s in builtin) all.add(Triple(s.id, s.url, s.kind))
        for (u in user()) all.add(Triple("u:$u", { u }, 1))
        if (all.isEmpty()) return null
        // 25%: наугад (исследование), иначе по доле удачных чтений
        val pick = if (rnd.nextInt(4) == 0) all[rnd.nextInt(all.size)] else {
            val w = all.map { val (n, g) = stat(it.first); (g + 1f) / (n + 2f) }
            var r = rnd.nextFloat() * w.sum()
            var i = 0
            while (i < all.size - 1 && r >= w[i]) { r -= w[i]; i++ }
            all[i]
        }
        val res = try { load(pick.second(), pick.third) } catch (_: Throwable) { null }?.takeIf { gate(it.first) }
        mark(pick.first, res != null)
        return res
    }

    // Желудок: пропускает только текст, где в основном буквы, и то, чего она ещё не читала (по отпечатку начала и конца)
    private fun gate(t: String): Boolean {
        val letters = t.count { it.isLetter() }
        if (letters < t.length * 0.6f) return false
        val h = (t.take(200) + t.takeLast(200)).hashCode().toString()
        val seen = prefs()?.getString("srcSeen", "")?.split(",")?.filter { it.isNotEmpty() } ?: emptyList()
        if (h in seen) return false
        prefs()?.edit()?.putString("srcSeen", (seen + h).takeLast(300).joinToString(","))?.apply()
        return true
    }

    private fun load(u: String, kind: Int): Pair<String, Int>? {
        var c: java.net.HttpURLConnection? = null
        try {
            c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "MegastudiyaCore/0.2 (Android app; learning)")
            val raw = c.inputStream.use { it.readBytes().let { b -> if (b.size > 600_000) b.copyOf(600_000) else b } }
            val body = String(raw, Charsets.UTF_8)
            val text = if (kind == 0) {
                val pages = org.json.JSONObject(body).optJSONObject("query")?.optJSONObject("pages") ?: return null
                val sb = StringBuilder()
                val k = pages.keys()
                while (k.hasNext()) sb.append(pages.getJSONObject(k.next()).optString("extract", "")).append("\n\n")
                sb.toString()
            } else feedText(body)
            return if (text.length < 80) null else Pair(text.take(6000), raw.size)
        } catch (_: Throwable) {
            return null
        } finally {
            c?.disconnect()
        }
    }

    // Из RSS/Atom берём заголовки и описания, без разметки
    private fun feedText(x: String): String {
        val sb = StringBuilder()
        val items = Regex("<(item|entry)[\\s>].*?</\\1>", RegexOption.DOT_MATCHES_ALL).findAll(x).take(12)
        for (m in items) {
            for (tag in listOf("title", "description", "summary", "content")) {
                val g = Regex("<$tag[^>]*>(.*?)</$tag>", RegexOption.DOT_MATCHES_ALL).find(m.value)?.groupValues?.get(1) ?: continue
                sb.append(clean(g)).append(". ")
            }
            sb.append("\n")
        }
        return sb.toString()
    }

    private fun clean(s: String): String = s
        .replace(Regex("<!\\[CDATA\\[|\\]\\]>"), "")
        .replace(Regex("<[^>]+>"), " ")
        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").replace("&nbsp;", " ")
        .replace(Regex("\\s+"), " ").trim().take(900)
}
