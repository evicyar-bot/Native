package app.megastudiya.nativeapp

import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Бесплатный поиск YouTube Shorts без токенов и ключей: обычная страница поиска youtube.com, как в браузере. Играет встроенный плеер. */
object YouTubeDiscovery {
    val defaultQueries = listOf("funny shorts", "street food shorts", "travel shorts", "animals shorts", "technology shorts", "music shorts", "interesting facts shorts", "sports shorts")
    data class Item(val videoId: String, val url: String, val title: String, val author: String, val thumb: String, val tags: List<String>)
    data class Result(val items: List<Item>, val message: String)

    private const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
    private val idRe = Regex("^[A-Za-z0-9_-]{6,15}$")

    fun discover(queries: List<String> = defaultQueries): Result {
        val found = LinkedHashMap<String, Item>()
        var error = ""
        for (q in queries.filter { it.isNotBlank() }.distinct().take(2)) {
            val conn = (URL("https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8") + "&hl=en").openConnection() as HttpURLConnection)
            try {
                conn.connectTimeout = 15000
                conn.readTimeout = 20000
                conn.setRequestProperty("User-Agent", UA)
                conn.setRequestProperty("Accept-Language", "en-US,en;q=0.8")
                conn.setRequestProperty("Cookie", "CONSENT=YES+1; SOCS=CAI")
                val code = conn.responseCode
                if (code !in 200..299) { error = "YouTube HTTP $code"; continue }
                val html = conn.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
                val mark = html.indexOf("ytInitialData")
                val brace = if (mark >= 0) html.indexOf('{', mark) else -1
                if (brace < 0) { error = "Ошибка YouTube: страница поиска без данных"; continue }
                val root = JSONTokener(html.substring(brace)).nextValue()
                walk(root, found)
            } catch (t: Throwable) {
                error = "Ошибка YouTube: ${t.javaClass.simpleName}: ${t.message.orEmpty().take(120)}"
            } finally { conn.disconnect() }
        }
        if (found.isEmpty() && error.isNotEmpty()) return Result(emptyList(), error)
        return Result(found.values.toList(), if (found.isEmpty()) "YouTube не вернул Shorts" else "Найдено ${found.size} Shorts")
    }

    private fun walk(n: Any?, found: LinkedHashMap<String, Item>) {
        when (n) {
            is JSONObject -> {
                n.optJSONObject("videoRenderer")?.let { video(it, found) }
                n.optJSONObject("shortsLockupViewModel")?.let { shorts(it, found) }
                val keys = n.keys()
                while (keys.hasNext()) walk(n.opt(keys.next()), found)
            }
            is JSONArray -> for (i in 0 until n.length()) walk(n.opt(i), found)
        }
    }

    /** Обычный результат поиска: берём только короткие (до 90 секунд). */
    private fun video(o: JSONObject, found: LinkedHashMap<String, Item>) {
        val id = o.optString("videoId")
        if (!idRe.matches(id)) return
        val len = o.optJSONObject("lengthText")?.optString("simpleText").orEmpty()
        val sec = len.split(':').mapNotNull { it.toIntOrNull() }.fold(0) { a, b -> a * 60 + b }
        if (len.isEmpty() || sec > 90) return
        val title = o.optJSONObject("title")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text").orEmpty()
        val author = o.optJSONObject("ownerText")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text").orEmpty()
        add(found, id, title, author)
    }

    /** Полка Shorts в выдаче. */
    private fun shorts(o: JSONObject, found: LinkedHashMap<String, Item>) {
        val id = o.optString("entityId").removePrefix("shorts-shelf-item-").ifEmpty {
            o.optJSONObject("onTap")?.optJSONObject("innertubeCommand")?.optJSONObject("reelWatchEndpoint")?.optString("videoId").orEmpty()
        }
        if (!idRe.matches(id)) return
        val title = o.optJSONObject("overlayMetadata")?.optJSONObject("primaryText")?.optString("content").orEmpty()
        add(found, id, title, "")
    }

    private fun add(found: LinkedHashMap<String, Item>, id: String, title: String, author: String) {
        val t = title.take(300)
        found.putIfAbsent("yt:$id", Item(id, "https://www.youtube.com/shorts/$id", t, author, "https://i.ytimg.com/vi/$id/hqdefault.jpg", MhTags.of(t)))
    }
}
