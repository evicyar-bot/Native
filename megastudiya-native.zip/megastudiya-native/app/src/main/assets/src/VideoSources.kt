package app.megastudiya.nativeapp

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

// Единый контракт источников. Лента и ForYouEngine про площадки ничего не знают:
// адаптер умеет только (1) узнать свою ссылку и (2) честно сказать, что может дать по ней без обхода ограничений.
// Видеофайлы площадок адаптеры НЕ скачивают: чужие ролики не сохраняются без разрешения.

class SourceStatus(val level: Int, val note: String) {
    companion object {
        const val WORKS = 0       // работает как описано
        const val LIMITED = 1     // работает частично (описано в note)
        const val NEEDS_ACCESS = 2 // нужны права, ключ или регистрация
        const val OFF = 3         // не подключено
    }
}

sealed class MetaResult {
    class Ok(
        val title: String, val author: String, val desc: String, val thumb: String,
        val videoId: String = "", val published: Long = 0L
    ) : MetaResult()

    object Gone : MetaResult()
    object Unsupported : MetaResult()
    class Failed(val why: String) : MetaResult()
}

interface VideoSource {
    val id: String
    val title: String
    fun status(): SourceStatus
    fun handles(link: LinkInfo): Boolean
    /** Сетевой вызов: вызывать только не на главном потоке. */
    fun fetchMeta(link: LinkInfo): MetaResult
}

object MhHttp {
    class Res(val code: Int, val body: String, val err: String = "")

    fun get(url: String, maxBytes: Int = 131072): Res {
        var cur = url
        for (hop in 0..5) {
            val u = try { URL(cur) } catch (_: Exception) { return Res(-1, "", "bad url") }
            if (u.protocol != "http" && u.protocol != "https") return Res(-1, "", "scheme")
            var c: HttpURLConnection? = null
            try {
                c = u.openConnection() as HttpURLConnection
                c.connectTimeout = 7000
                c.readTimeout = 9000
                c.instanceFollowRedirects = false
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Megastudiya")
                c.setRequestProperty("Accept-Language", "ru,en;q=0.8")
                val code = c.responseCode
                if (code in 300..399) {
                    val loc = c.getHeaderField("Location") ?: return Res(code, "", "no location")
                    cur = URL(u, loc).toString()
                    continue
                }
                val stream = if (code >= 400) c.errorStream else c.inputStream
                val body = stream?.use { readLimited(it, maxBytes) } ?: ""
                return Res(code, body)
            } catch (e: Exception) {
                return Res(-1, "", e.javaClass.simpleName)
            } finally {
                try { c?.disconnect() } catch (_: Throwable) { }
            }
        }
        return Res(-1, "", "too many redirects")
    }

    private fun readLimited(ins: java.io.InputStream, max: Int): String {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (out.size() < max) {
            val r = ins.read(buf)
            if (r < 0) break
            out.write(buf, 0, r)
        }
        return out.toString("UTF-8")
    }

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}

private fun firstLine(s: String, n: Int): String = s.trim().lineSequence().firstOrNull().orEmpty().take(n)

/** TikTok: публичный oEmbed (без ключа) даёт подпись, автора, картинку и идентификатор. Видео не отдаёт. */
object TikTokSource : VideoSource {
    override val id = "tiktok"
    override val title = "TikTok"
    override fun status() = SourceStatus(
        SourceStatus.LIMITED,
        "Ссылки из «Поделиться» сохраняются карточкой; подпись, автор и картинка берутся из публичного oEmbed. " +
            "Ролик не скачивается: он играет во встроенном плеере TikTok (официальный Embed Player) внутри вкладки «Видео», а если автор или TikTok " +
            "не разрешают встраивание, остаётся открыть оригинал. " +
            "Каталог авторов и лента требуют одобренных прав (Display API) — не подключено."
    )
    override fun handles(link: LinkInfo) = link.platform == "tiktok"
    override fun fetchMeta(link: LinkInfo): MetaResult {
        if (!link.isPost) return MetaResult.Unsupported
        val r = MhHttp.get("https://www.tiktok.com/oembed?url=" + MhHttp.enc(link.canonical), 65536)
        return when {
            r.code == 404 || r.code == 410 -> MetaResult.Gone
            r.code in 200..299 -> try {
                val o = JSONObject(r.body)
                val cap = o.optString("title")
                val author = o.optString("author_name")
                if (cap.isEmpty() && author.isEmpty()) MetaResult.Failed("пустой ответ oEmbed")
                else MetaResult.Ok(firstLine(cap, 90), author, cap.take(600), o.optString("thumbnail_url"), o.optString("embed_product_id").ifEmpty { link.videoId })
            } catch (_: Throwable) {
                MetaResult.Failed("ответ не разобран")
            }
            else -> MetaResult.Failed(if (r.code < 0) r.err else "HTTP ${r.code}")
        }
    }
}

/** Telegram: файлы приходят через «Поделиться» (локально, с временным разрешением); публичные посты — превью OpenGraph. */
object TelegramSource : VideoSource {
    override val id = "telegram"
    override val title = "Telegram"
    override fun status() = SourceStatus(
        SourceStatus.LIMITED,
        "Видеофайлы и фото из «Поделиться» копируются в приложение и играют локально. Ссылки на публичные посты сохраняются " +
            "карточкой с превью. Закрытые каналы превью не дают, видео по ссылке не скачивается."
    )
    override fun handles(link: LinkInfo) = link.platform == "telegram"
    override fun fetchMeta(link: LinkInfo): MetaResult {
        if (!link.isPost || link.canonical.startsWith("https://t.me/c/")) return MetaResult.Unsupported
        val r = MhHttp.get(link.canonical, 200000)
        if (r.code == 404 || r.code == 410) return MetaResult.Gone
        if (r.code !in 200..299) return MetaResult.Failed(if (r.code < 0) r.err else "HTTP ${r.code}")
        val og = Og.parse(r.body)
        val text = og["og:description"].orEmpty()
        val author = og["og:title"].orEmpty()
        if (text.isEmpty() && author.isEmpty()) return MetaResult.Unsupported
        return MetaResult.Ok(firstLine(text, 90), author, text.take(600), og["og:image"].orEmpty())
    }
}

/** YouTube: публичный oEmbed (без ключа). Встроенный плеер и лента Shorts — отдельный адаптер позже. */
object YouTubeSource : VideoSource {
    override val id = "youtube"
    override val title = "YouTube"
    override fun status() = SourceStatus(
        SourceStatus.LIMITED,
        "Ссылки сохраняются карточкой; название, канал и картинка — из публичного oEmbed. Воспроизведения внутри приложения пока нет."
    )
    override fun handles(link: LinkInfo) = link.platform == "youtube"
    override fun fetchMeta(link: LinkInfo): MetaResult {
        if (!link.isPost) return MetaResult.Unsupported
        val r = MhHttp.get("https://www.youtube.com/oembed?format=json&url=" + MhHttp.enc(link.canonical), 65536)
        return when {
            r.code == 404 -> MetaResult.Gone
            r.code in 200..299 -> try {
                val o = JSONObject(r.body)
                MetaResult.Ok(o.optString("title").take(120), o.optString("author_name"), "", o.optString("thumbnail_url"), link.videoId)
            } catch (_: Throwable) {
                MetaResult.Failed("ответ не разобран")
            }
            else -> MetaResult.Failed(if (r.code < 0) r.err else "HTTP ${r.code}")
        }
    }
}

/** Instagram: ссылки принимаются, но описание без разрешений Meta получить нельзя. */
object InstagramSource : VideoSource {
    override val id = "instagram"
    override val title = "Instagram"
    override fun status() = SourceStatus(
        SourceStatus.NEEDS_ACCESS,
        "Ссылки сохраняются карточкой без описания и картинки: метаданные Instagram требуют приложения Meta и токена — не подключено. " +
            "Файлы, присланные через «Поделиться», играют локально."
    )
    override fun handles(link: LinkInfo) = link.platform == "instagram"
    override fun fetchMeta(link: LinkInfo): MetaResult = MetaResult.Unsupported
}

/** Любой другой сайт: только OpenGraph страницы (заголовок, описание, картинка). Принимается из буфера, не из «Поделиться». */
object WebSource : VideoSource {
    override val id = "web"
    override val title = "Сайты"
    override fun status() = SourceStatus(SourceStatus.LIMITED, "Ссылка из буфера сохраняется карточкой; заголовок и картинка — из OpenGraph, если страница их отдаёт.")
    override fun handles(link: LinkInfo) = link.platform == "web"
    override fun fetchMeta(link: LinkInfo): MetaResult {
        val r = MhHttp.get(link.canonical, 200000)
        if (r.code == 404 || r.code == 410) return MetaResult.Gone
        if (r.code !in 200..299) return MetaResult.Failed(if (r.code < 0) r.err else "HTTP ${r.code}")
        val og = Og.parse(r.body)
        val t = og["og:title"].orEmpty()
        val d = og["og:description"] ?: og["description"].orEmpty()
        if (t.isEmpty() && d.isEmpty()) return MetaResult.Unsupported
        return MetaResult.Ok(t.take(120), og["og:site_name"].orEmpty(), d.take(600), og["og:image"].orEmpty())
    }
}

object VideoSources {
    // TikTokApiSource / TelegramBotSource / YouTubeApiSource заменяют TikTokSource / TelegramSource / YouTubeSource (те же id).
    // Старые объекты остаются в файле: новые адаптеры используют их как запасной режим (oEmbed, превью OpenGraph),
    // пока ключи не заданы в ConnectorSetup.
    val all: List<VideoSource> = listOf(TikTokApiSource, TelegramBotSource, YouTubeApiSource, InstagramSource, WebSource)

    fun forLink(l: LinkInfo): VideoSource? = all.firstOrNull { it.handles(l) }

    /** Планируемое на пакет 2: показывается честно как «не подключено». */
    class Planned(val title: String, val level: Int, val note: String)

    val planned: List<Planned> = listOf(
        Planned("Свежие ролики по странам", SourceStatus.OFF, "Пакет 2. Не подключено: пока лента наполняется только тем, что вы добавили сами."),
        Planned("TikTok Display API (каталог авторов)", SourceStatus.NEEDS_ACCESS, "Нужны регистрация приложения и одобрение прав; не подключено."),
        Planned("TikTok Creative Center / Research API", SourceStatus.NEEDS_ACCESS, "Не общедоступные API для загрузки роликов; в пакете 1 не используются.")
    )
}
