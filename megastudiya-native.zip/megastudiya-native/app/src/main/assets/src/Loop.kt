package app.megastudiya.nativeapp

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

// LOOP RUNNER: первый замкнутый цикл самостоятельной работы. Испытание: ОДНА задача.
//   проект-исследование (Purpose) → стратегия (Agency) → выполнение (Core.loopRead) → проверка ОБЪЁМА → запись в дневник/опыт.
// Границы (решение владельца 14.11.2026):
//  • R0/R1: выполняется само; чтение только из разрешённых источников (сейчас только ru.wikipedia.org).
//  • R2 (запись в Workspace) здесь НЕ реализована и остаётся ручной: нет версионирования, журнала файлов и отката.
//  • R3, R4, ядро, защитные механизмы, лимиты безопасности и права цикл менять не может и не умеет: такого кода тут нет.
//  • У задачи: потолок шагов, чтений и времени; контрольная точка до каждого действия; журнал; рубильник.
//  • Внешняя модель (Mentor) в этом цикле не вызывается, расход токенов задачи равен нулю.
// Проверка здесь только ОБЪЁМНАЯ: сколько прочитано и легло в память. Это не проверка качества исследования и не проверка
// достижения цели. Достижение цели цикл не оценивает: итог по цели остаётся за владельцем («итог N: успех/неудача»).
// Состояние: loop_state.json. Контрольная точка пишется во временный файл, перечитывается и проверяется, предыдущий
// рабочий файл сохраняется как .bak и никогда не удаляется до успешной замены. При старте берётся самая свежая годная копия.
// По умолчанию цикл ВЫКЛЮЧЕН: включает только владелец.
object Loop {
    private const val FMT = 1
    private const val MAX_STEPS = 6
    private const val MAX_READS = 2
    private const val MAX_MS = 15 * 60_000L
    private const val WAIT_MS = 3 * 60_000L
    private const val MAX_ATTEMPTS = 3
    private const val TEST_TASKS = 1
    private const val MIN_WORDS = 120
    private const val MIN_ABSORBED = 100
    private const val MAX_RISK = 0.2f
    private const val IDLE_LOG_MS = 6 * 3_600_000L
    private val ALLOWED_SOURCES = listOf("ru.wikipedia.org")

    private class Task(val id: String, val num: Int, val projectId: String, val topic: String, val expected: String, val started: Long) {
        var step = "execute"
        var steps = 0
        var reads = 0
        var stepTs = 0L
        var waiting = false
        var readId = ""
        var words = 0
        var absorbed = 0
    }

    private class Entry(val ts: Long, val text: String)

    private var file: File? = null
    private var on = false
    private var completed = 0      // задач доведено до конца цикла (с любым исходом проверки объёма)
    private var volumePassed = 0   // из них с подтверждённым объёмом; достижение цели автоматически не проверяется
    private var attempts = 0
    private var seq = 0L
    private var saveOk = true
    private var task: Task? = null
    private var idleAt = 0L
    private val journal = ArrayList<Entry>()
    private val ran = HashSet<Int>()      // номера стратегий, которые цикл уже исполнял
    private val skipped = HashSet<Int>()

    // ===== Память: контрольная точка =====
    private fun parse(f: File): JSONObject? = try {
        if (f.exists()) JSONObject(f.readText(Charsets.UTF_8)) else null
    } catch (_: Throwable) {
        null
    }

    @Synchronized
    fun init(ctx: Context) {
        if (file != null) return
        val dir = ctx.applicationContext.filesDir
        val f = File(dir, "loop_state.json")
        file = f
        val files = listOf(f, File(dir, "loop_state.json.tmp"), File(dir, "loop_state.json.bak"))
        val cands = files.mapNotNull { x -> parse(x)?.let { o -> Pair(x, o) } }
        val best = cands.maxByOrNull { it.second.optLong("seq", 0L) }
        if (best == null) {
            if (files.any { it.exists() }) runCatching { f.copyTo(File(dir, "loop_state.json.bad"), overwrite = true) }
            return
        }
        try {
            val o = best.second
            on = o.optBoolean("on", false)
            completed = o.optInt("completed", o.optInt("done", 0))
            volumePassed = o.optInt("volumePassed", 0)
            attempts = o.optInt("attempts", 0)
            seq = o.optLong("seq", 0L)
            o.optJSONArray("ran")?.let { a -> for (i in 0 until a.length()) ran.add(a.optInt(i)) }
            val ja = o.optJSONArray("journal")
            if (ja != null) for (i in 0 until ja.length()) {
                val e = ja.optJSONObject(i) ?: continue
                journal.add(Entry(e.optLong("ts"), e.optString("text")))
            }
            val t = o.optJSONObject("task")
            if (t != null) {
                val x = Task(t.optString("id"), t.optInt("num"), t.optString("projectId"), t.optString("topic"), t.optString("expected"), t.optLong("started"))
                x.step = t.optString("step", "execute")
                x.steps = t.optInt("steps")
                x.reads = t.optInt("reads")
                x.stepTs = t.optLong("stepTs")
                x.waiting = t.optBoolean("waiting")
                x.readId = t.optString("readId")
                x.words = t.optInt("words")
                x.absorbed = t.optInt("absorbed")
                task = x
            }
            if (best.first != f) log("Состояние восстановлено из " + (if (best.first.name.endsWith(".bak")) "резервной копии" else "непереименованной контрольной точки") + ".")
        } catch (_: Throwable) {
            // состояние нечитаемо: цикл остаётся выключенным, копия сохраняется
            runCatching { best.first.copyTo(File(dir, "loop_state.json.bad"), overwrite = true) }
            on = false; completed = 0; volumePassed = 0; attempts = 0; task = null; journal.clear(); ran.clear()
        }
    }

    private fun build(): JSONObject {
        val o = JSONObject().put("fmt", FMT).put("seq", seq).put("on", on).put("completed", completed)
            .put("volumePassed", volumePassed).put("attempts", attempts)
        o.put("ran", JSONArray().also { a -> for (n in ran) a.put(n) })
        o.put("journal", JSONArray().also { ja -> for (e in journal) ja.put(JSONObject().put("ts", e.ts).put("text", e.text)) })
        val t = task
        if (t != null) o.put("task", JSONObject().put("id", t.id).put("num", t.num).put("projectId", t.projectId).put("topic", t.topic)
            .put("expected", t.expected).put("started", t.started).put("step", t.step).put("steps", t.steps).put("reads", t.reads)
            .put("stepTs", t.stepTs).put("waiting", t.waiting).put("readId", t.readId).put("words", t.words).put("absorbed", t.absorbed))
        return o
    }

    // Возвращает true только если новая контрольная точка записана, перечитана и проверена.
    // Рабочий файл не удаляется: сначала он копируется в .bak, затем атомарно заменяется (rename поверх файла).
    private fun save(): Boolean {
        val f = file ?: return false
        val tmp = File(f.parentFile, f.name + ".tmp")
        val bak = File(f.parentFile, f.name + ".bak")
        var stage = 0
        return try {
            seq++
            tmp.writeText(build().toString(), Charsets.UTF_8)
            val back = JSONObject(tmp.readText(Charsets.UTF_8))
            if (back.optLong("seq") != seq || back.optInt("fmt") != FMT) throw IllegalStateException("verify")
            stage = 1
            if (parse(f) != null) f.copyTo(bak, overwrite = true)
            if (!tmp.renameTo(f)) throw IllegalStateException("rename")
            saveOk = true
            true
        } catch (_: Throwable) {
            if (stage == 0) runCatching { tmp.delete() } // непроверенный временный файл не оставляем
            saveOk = false
            false
        }
    }

    private fun log(text: String) {
        journal.add(Entry(System.currentTimeMillis(), text))
        while (journal.size > 200) journal.removeAt(0)
    }

    // ===== Рубильник и отчёты =====
    @Synchronized
    fun setOn(v: Boolean): String {
        if (v && completed >= TEST_TASKS) return "Испытательная задача уже доведена до конца. Расширять цикл можно только по твоему решению, новой сборкой."
        on = v
        if (v) attempts = 0
        log(if (v) "Цикл включён владельцем." else "Цикл остановлен владельцем.")
        save()
        return if (v) "Цикл включён. Испытание: одна задача, чтение только из разрешённых источников. Остановить: «цикл стоп»."
        else "Цикл остановлен. Контрольная точка сохранена."
    }

    @Synchronized
    fun statusText(): String {
        val t = task
        return "Цикл: " + (if (on) "включён" else "выключен") + " · задач доведено до конца $completed из $TEST_TASKS, объём подтверждён $volumePassed. Достижение цели автоматически не проверяется." +
            (if (t != null) "\nЗадача №${t.num} «${t.topic}»: шаг «${t.step}», шагов ${t.steps} из $MAX_STEPS, чтений ${t.reads} из $MAX_READS" else "\nЗадачи сейчас нет") +
            (if (!saveOk) "\nВнимание: последнюю контрольную точку сохранить не удалось." else "") +
            "\nЖурнал: «журнал цикла». Остановить: «цикл стоп»."
    }

    @Synchronized
    fun journalText(): String {
        if (journal.isEmpty()) return "Журнал цикла пуст."
        val fmt = java.text.SimpleDateFormat("dd.MM HH:mm", java.util.Locale.getDefault())
        return journal.takeLast(15).joinToString("\n") { fmt.format(java.util.Date(it.ts)) + " · " + it.text }
    }

    // ===== Один маленький шаг за вызов; вызывает ядро (поток ядра) =====
    @Synchronized
    fun tick() {
        if (!on || file == null || !Core.enabled) return
        val now = System.currentTimeMillis()
        val t = task
        if (t == null) { start(now); return }
        if (t.steps >= MAX_STEPS || now - t.started > MAX_MS) { abort(t, "исчерпан потолок шагов или времени"); return }
        when (t.step) {
            "execute" -> execute(t, now)
            "verify" -> verifyVolume(t)
            else -> abort(t, "неизвестный шаг")
        }
    }

    private fun idle(now: Long, text: String) {
        if (now - idleAt < IDLE_LOG_MS) return
        idleAt = now
        log(text)
        save()
    }

    // Класс R1: только исследование темы по проекту Purpose, риск не выше порога. Всё остальное цикл не автоодобряет.
    private fun isR1(c: Agency.Cand, topic: String?): Boolean =
        topic != null && topic.length >= 3 && c.risk <= MAX_RISK && c.text.startsWith("Исследовать «")

    private fun start(now: Long) {
        if (completed >= TEST_TASKS) {
            on = false
            log("Испытательная задача доведена до конца. Цикл остановлен: расширять самостоятельность можно только по решению владельца.")
            save()
            return
        }
        if (attempts >= MAX_ATTEMPTS) {
            on = false
            log("Три попытки без результата. Цикл остановлен, нужен взгляд владельца.")
            save()
            return
        }
        var pick: Agency.Cand? = null
        var topic = ""
        for (c in Agency.loopCandidates()) {
            if (c.num in ran) continue
            val tp = Purpose.topicOf(c.projectId)
            if (isR1(c, tp)) { pick = c; topic = tp ?: ""; break }
            if (skipped.add(c.num)) log("Не беру стратегию №${c.num}: это не чтение разрешённого источника (не R0/R1), решает владелец.")
        }
        val c = pick
        if (c == null) {
            idle(now, "Нет проекта-исследования от Purpose, ждать нечего. Ничего не делаю.")
            return
        }
        if (c.status == "proposed") {
            if (!Agency.autoAuthorize(c.num)) { log("Не удалось автоодобрить стратегию №${c.num}."); save(); return }
            log("Автоодобрено по решению владельца (R1, чтение разрешённых источников): №${c.num} «$topic».")
        }
        task = Task(UUID.randomUUID().toString(), c.num, c.projectId, topic, c.expected, now)
        log("Задача начата: №${c.num} «$topic». Потолки: шагов $MAX_STEPS, чтений $MAX_READS, ${MAX_MS / 60_000} мин, токенов 0.")
        save()
    }

    private fun execute(t: Task, now: Long) {
        if (t.waiting && now - t.stepTs < WAIT_MS) return
        if (t.reads >= MAX_READS) { abort(t, "исчерпан потолок чтений"); return }
        t.steps++
        t.reads++
        t.waiting = true
        t.stepTs = now
        t.readId = UUID.randomUUID().toString() // у каждого чтения свой номер: ответ предыдущего чтения принят не будет
        log("Шаг ${t.steps}: читаю «${t.topic}» (${ALLOWED_SOURCES.joinToString()}).")
        if (!save()) { // контрольная точка до действия: нет точки, нет действия
            t.waiting = false
            abort(t, "контрольную точку сохранить не удалось, действие не выполнял")
            return
        }
        val id = t.id
        val rid = t.readId
        Core.loopRead(t.topic) { words, absorbed -> onRead(id, rid, words, absorbed) }
    }

    @Synchronized
    private fun onRead(id: String, readId: String, words: Int, absorbed: Int) {
        val t = task
        if (t == null || t.id != id || t.readId != readId || !t.waiting || t.step != "execute") {
            log("Устаревший ответ чтения проигнорирован: результат нового чтения он не заменяет.")
            save()
            return
        }
        t.waiting = false
        if (words < 0) {
            log("Чтение не вышло: нет Wi‑Fi, исчерпан трафик или нет сети.")
            save()
            return
        }
        t.words = words
        t.absorbed = absorbed
        t.step = "verify"
        log("Прочитано слов: $words, лёгло в память: $absorbed.")
        save()
    }

    // Проверка ОБЪЁМА: сколько текста прочитано и легло в память (замер внутри потока ядра по счётчику памяти).
    // Качество исследования и достижение цели она не проверяет: цель остаётся без автоматического вердикта.
    private fun verifyVolume(t: Task) {
        t.steps++
        val volOk = t.words >= MIN_WORDS && t.absorbed >= MIN_ABSORBED
        completed++
        ran.add(t.num)
        attempts = 0
        task = null
        if (volOk) {
            volumePassed++
            Core.diaryNote("Цикл: по теме «${t.topic}» прочитано ${t.words} слов, в память легло ${t.absorbed}. Объём подтверждён, достижение цели не проверено: жду итога владельца (итог ${t.num}: успех или неудача).")
            log("Проверка объёма: подтверждена (слов ${t.words} из $MIN_WORDS, в память ${t.absorbed} из $MIN_ABSORBED). Проверка цели: НЕ выполнена, критерия качества пока нет. Стратегия №${t.num} остаётся одобренной до итога владельца: «итог ${t.num}: успех» или «итог ${t.num}: неудача».")
        } else {
            Agency.observe(t.num, false, "Объём не достигнут: прочитано ${t.words} слов, в память легло ${t.absorbed} (нужно от $MIN_WORDS и от $MIN_ABSORBED).", 0f)
            log("Проверка объёма: НЕ пройдена (слов ${t.words}, в память ${t.absorbed}). Неудача записана в Agency.")
        }
        if (completed >= TEST_TASKS) {
            on = false
            log("Испытание доведено до конца. Цикл остановлен, жду решения владельца.")
        }
        save()
    }

    // Прерывание не пишет «неудачу» в опыт: стратегия остаётся как была, попытки ограничены
    private fun abort(t: Task, why: String) {
        log("Задача №${t.num} прервана: $why. Итог не записан.")
        attempts++
        task = null
        save()
    }
}
