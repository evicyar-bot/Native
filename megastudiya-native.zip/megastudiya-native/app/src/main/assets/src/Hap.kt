package app.megastudiya.nativeapp

import android.content.Context
import android.os.Build
import android.os.VibrationAttributes
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

// Вибро-язык приложения: композиции из примитивов (чёткие «тики» и «удары», как у хороших флагманов).
// Если телефон примитивы не умеет — та же раскладка играется волной с амплитудами. Всё собирается один раз.
object Hap {
    private var vib: Vibrator? = null
    private class Ev(val at: Int, val prim: Int, val sc: Float)

    // значения VibrationEffect.Composition.PRIMITIVE_*
    private const val TICK = 7
    private const val CLICK = 1
    private const val THUD = 3
    private const val RISE = 4
    private const val SLOW = 5

    private var introEv: List<Ev>? = null

    fun init(ctx: Context) {
        vib = runCatching {
            if (Build.VERSION.SDK_INT >= 31) (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            else @Suppress("DEPRECATION") (ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
        }.getOrNull()
    }

    private fun play(evs: List<Ev>, touch: Boolean) {
        val v = vib ?: return
        if (!v.hasVibrator()) return
        runCatching {
            val effect = runCatching {
                if (Build.VERSION.SDK_INT < 30) null
                else if (!v.areAllPrimitivesSupported(*evs.map { it.prim }.distinct().toIntArray())) null
                else {
                    val c = VibrationEffect.startComposition()
                    var prev = 0
                    for (e in evs) { c.addPrimitive(e.prim, e.sc, (e.at - prev - 12).coerceAtLeast(0)); prev = e.at }
                    c.compose()
                }
            }.getOrNull() ?: wave(evs, v.hasAmplitudeControl())
            if (Build.VERSION.SDK_INT >= 33) v.vibrate(effect, VibrationAttributes.createForUsage(if (touch) VibrationAttributes.USAGE_TOUCH else VibrationAttributes.USAGE_MEDIA))
            else v.vibrate(effect)
        }
    }

    private fun wave(evs: List<Ev>, amp: Boolean): VibrationEffect {
        val tm = ArrayList<Long>(); val am = ArrayList<Int>()
        var prev = 0
        for (e in evs) {
            val dur = if (e.prim == THUD) 45 else if (e.prim == CLICK || e.prim == RISE) 26 else 14
            tm.add((e.at - prev).coerceAtLeast(1).toLong()); am.add(0)
            tm.add(dur.toLong()); am.add((40 + 215 * e.sc).toInt().coerceIn(1, 255))
            prev = e.at + dur
        }
        return if (amp) VibrationEffect.createWaveform(tm.toLongArray(), am.toIntArray(), -1)
        else VibrationEffect.createWaveform(tm.toLongArray(), -1)
    }

    fun cancel() { runCatching { vib?.cancel() } }

    // Dynamic Island / Obsidian Capsule: short, low-intensity transient feedback.
    // The patterns use device-supported primitives where available and the existing waveform fallback otherwise.
    fun islandTap() = play(listOf(Ev(0, CLICK, 0.24f)), true)
    fun islandSnap() = play(listOf(Ev(0, RISE, 0.20f), Ev(58, TICK, 0.28f)), true)
    fun islandLaunch() = play(listOf(Ev(0, RISE, 0.30f), Ev(72, CLICK, 0.34f)), true)
    fun islandThreshold() = play(listOf(Ev(0, TICK, 0.24f)), true)
    fun islandRefreshDone() = play(listOf(Ev(0, RISE, 0.22f), Ev(64, TICK, 0.28f)), true)

    // коротко и чётко: переключение разделов
    fun tick() = play(listOf(Ev(0, TICK, 0.7f)), true)
    // удержание, двойной тап
    fun click() = play(listOf(Ev(0, CLICK, 0.85f)), true)
    // публикация: подъём и щелчок
    fun success() = play(listOf(Ev(0, RISE, 0.55f), Ev(90, CLICK, 1f), Ev(170, TICK, 0.5f)), true)

    // Заставка: зажигание → ускоряющиеся тики тоннеля → тик на каждом узле кольца (раскладка из IntroPlan,
    // то есть строго в такт вспышкам) → удар в момент замыкания кольца → два лёгких касания при посадке в пилюлю.
    fun intro() {
        val ev = introEv ?: run {
            val l = ArrayList<Ev>()
            l += Ev(0, RISE, 0.3f)
            l += Ev(300, SLOW, 0.35f)
            l += Ev(900, TICK, 0.25f); l += Ev(1250, TICK, 0.35f); l += Ev(1550, TICK, 0.5f)
            val hs = IntroPlan.hits
            for (i in hs.indices) l += Ev(hs[i].toInt().coerceAtLeast(1600 + i), TICK, 0.45f + 0.55f * i / (hs.size - 1).coerceAtLeast(1))
            l += Ev(3540, THUD, 1f); l += Ev(3600, CLICK, 0.7f)
            l += Ev(4140, TICK, 0.6f); l += Ev(4210, TICK, 0.35f)
            l.sortedBy { it.at }.also { introEv = it }
        }
        play(ev, false)
    }
}
