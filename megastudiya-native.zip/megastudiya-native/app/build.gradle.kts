plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "app.megastudiya.nativeapp"
    compileSdk = 35
    defaultConfig {
        applicationId = "app.megastudiya.nativeapp"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "n0.1"
    }
    // Ключ подписи берётся только из секретов сборки (GitHub Secrets). В коде его нет.
    // Без секретов (чужая копия) приложение подписывается отладочным ключом и обновлять твоё не сможет.
    val msKey = System.getenv("MS_KEYSTORE_PATH")
    signingConfigs {
        if (msKey != null) {
            create("ms") {
                storeFile = file(msKey)
                storePassword = System.getenv("MS_STORE_PASS")
                keyAlias = "ms"
                keyPassword = System.getenv("MS_STORE_PASS")
                storeType = "pkcs12"
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (msKey != null) signingConfigs.getByName("ms") else signingConfigs.getByName("debug")
        }
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
}
