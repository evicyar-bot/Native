# GitHub build and install verification

This repository includes `.github/workflows/android-build.yml`.

1. Upload/push this project folder to a GitHub repository (the default branch can be `main` or `master`).
2. Open **Actions** → **Android build and APK artifacts**. The workflow runs on push, pull request, or manual dispatch.
3. Wait for the workflow to finish. A green run means Gradle successfully compiled both debug and release APK variants in GitHub's Android build environment. It does **not** by itself prove runtime TikTok playback or API discovery.
4. Open the successful run and download the `megastudiya-apks` artifact. Install `app-debug.apk` on Android for testing. The release APK in this workflow is also debug-signed unless a signing keystore is separately configured.
5. For TikTok discovery, add the Apify token in the app's Sources settings. Keep API tokens out of GitHub and source code.

The workflow currently uses Gradle 8.9 with Android Gradle Plugin 8.7.2, Java 17, and Android SDK setup.
