# Megastudiya — Obsidian Glass refinement (V5)

## Changes after HONOR X7d device screenshot
- Darkened the shared Liquid Glass tint substantially. The feed image should read as a subtle refraction, not show through as a bright brown/white patch.
- Reused the same near-black material for the top capsule, expanded panel, Dock and compose button.
- Removed the additional flat capsule overlay so the capsule is rendered by the shared LiquidSurface material only.
- Reduced the bright rim to a very subtle dark-glass reflection.
- Shifted the cutout-centred capsule down by 2 dp to provide a small visual breathing margin from the top edge while preserving camera-centre anchoring.
- Preserved the existing tap-to-expand then Space Platform action, existing Zen renderer, feed nested-scroll pull-to-refresh state and Dock tab/add handlers.

## Verification
Source archive is structurally checked. A new Android build and device test are still required; the screenshot confirms the prior build's material was too transparent.

## Pull to Refresh — reliability pass (2026-11-25)

- The pull gesture is driven only by unconsumed downward scroll at the top of the feed (`NestedScrollConnection.onPostScroll`), so normal scrolling is not intercepted.
- Pull progress is measured in pixels using a 104 dp threshold converted with the current display density.
- Dragging upward before release retracts the pull indicator before the list resumes scrolling.
- Releasing below threshold cancels cleanly; releasing at/above threshold starts forced news refresh and weather refresh.
- The capsule displays progress guidance and an explicit loading label while both refresh operations run; the animated edge is reset in `finally`, including failure paths.
- Switching tabs or entering Space resets any incomplete pull state.
