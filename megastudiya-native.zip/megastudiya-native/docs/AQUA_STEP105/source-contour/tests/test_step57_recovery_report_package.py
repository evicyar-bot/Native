from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_package_statuses_and_csv_binding_exist():
    source = (ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportPackage.kt").read_text()
    assert "VALID, STALE, INVALID" in source
    assert "csvSha256" in source
    assert "provenanceManifestSha256" in source
    assert "STEP57_RECOVERY_REPORT_PACKAGE_PASS" in (ROOT / "tests/kotlin/Step57RecoveryReportPackageTest.kt").read_text()


def test_package_checks_source_provenance_and_csv_integrity():
    source = (ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportPackage.kt").read_text()
    assert "provenance.verify" in source
    assert "Files.readAllBytes(csvPath)" in source
    assert "CSV or package manifest integrity mismatch" in source
