from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/DurableRecoveryAuditReporting.kt").read_text()


def test_reports_are_built_from_verified_durable_snapshot():
    assert "durable.verifyIntegrity()" in SOURCE
    assert "durable.snapshot()" in SOURCE
    assert "RecoveryAuditReceiptStore()" in SOURCE


def test_reporting_is_read_only_and_supports_csv_export():
    assert "fun exportCsv(" in SOURCE
    assert "exporter.exportCsv(report, destination)" in SOURCE
    assert "durable.append" not in SOURCE
    assert "durable.clear" not in SOURCE
