from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryArchiveQueueGovernance.kt"
def test_change_detector_tracks_added_removed_changed_unchanged():
    t = SOURCE.read_text()
    assert all(x in t for x in ("addedIds", "removedIds", "changedIds", "unchangedIds"))
