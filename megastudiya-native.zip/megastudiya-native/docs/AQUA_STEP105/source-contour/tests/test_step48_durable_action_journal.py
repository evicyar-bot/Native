from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JOURNAL = (ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/ActionResultJournal.kt").read_text()
API = (ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/ActionApi.kt").read_text()


def test_versioned_hash_chained_journal():
    assert 'AQUA_ACTION_JOURNAL_V1' in JOURNAL
    assert 'hashLine(parent, payload(result))' in JOURNAL
    assert 'Action journal integrity failure' in JOURNAL


def test_atomic_persist_before_publish():
    assert 'StandardCopyOption.ATOMIC_MOVE' in JOURNAL
    assert API.index('journal.append(result)') < API.index('completed[request.requestId] = result')


def test_restart_restore_and_idempotent_replay_contract():
    assert 'journal.snapshot().forEach' in API
    assert 'REQUEST_ID_CONFLICT' in API
    assert 'Only dry-run mode is supported' in API


def test_no_live_execution_or_replay():
    assert 'never replays or executes an action' in JOURNAL
    assert 'DRY_RUN_ACCEPTED' in API
