from pathlib import Path
p=Path(__file__).resolve().parents[1]/'modules/aqua-execution-ledger/src/main/kotlin/aqua/execution/ExecutionLedger.kt'
s=p.read_text()
def test_ledger_models_status_and_events():
    assert 'enum class StepExecutionStatus' in s and 'enum class ExecutionEventType' in s
def test_create_requires_unique_steps():
    assert 'stepIds.distinct().size == stepIds.size' in s
def test_transition_validates_allowed_state():
    assert 'require(allowed(old.status, target))' in s
def test_retry_attempts_increment():
    assert 'old.attempts + 1' in s and 'ExecutionEventType.RETRY' in s
def test_checkpoint_only_while_running():
    assert 'require(step.status==StepExecutionStatus.RUNNING)' in s
def test_event_ids_are_unique():
    assert 'Duplicate event ID' in s and 'ledger.events.none' in s
def test_no_action_executor_in_ledger():
    assert 'does not invoke tools or perform external actions' in s
