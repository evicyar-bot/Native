from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/ActionJournalDiagnostics.kt").read_text()


def test_diagnostics_expose_health_and_capacity_metrics():
    assert "enum class ActionJournalHealth" in SOURCE
    assert "entryUtilization" in SOURCE and "byteUtilization" in SOURCE
    assert "fun diagnostics()" in SOURCE


def test_capacity_blocks_growth_without_pruning_history():
    assert "Capacity reached; new records are blocked" in SOURCE
    assert "existing history is preserved" in SOURCE
    assert "delegate.append(result)" in SOURCE
    assert "remove(" not in SOURCE and "clear()" not in SOURCE


def test_policy_rejects_invalid_limits():
    assert "maxEntries > 0" in SOURCE
    assert "maxEstimatedBytes > 0" in SOURCE
    assert "warningRatio in 0.1..0.99" in SOURCE
