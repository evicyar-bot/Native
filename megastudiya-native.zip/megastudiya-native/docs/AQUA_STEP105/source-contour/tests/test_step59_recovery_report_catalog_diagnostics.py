from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportCatalogDiagnostics.kt"
TEST = ROOT / "tests/kotlin/Step59RecoveryReportCatalogDiagnosticsTest.kt"


def test_diagnostics_are_read_only_and_offer_explicit_proposals():
    source = SOURCE.read_text()
    assert "diagnoseFilesystem" in source
    assert "Files.readAllLines" in source
    assert "Files.readAllBytes" in source
    assert "proposedAction" in source
    assert "Files.delete" not in source
    assert "Files.write" not in source


def test_missing_and_hash_mismatch_are_distinguished():
    source = SOURCE.read_text()
    assert '"CSV_MISSING"' in source
    assert '"PROVENANCE_MISSING"' in source
    assert '"PACKAGE_MANIFEST_MISSING"' in source
    assert '"CSV_HASH_MISMATCH"' in source
    assert '"PROVENANCE_HASH_MISMATCH"' in source
    assert '"PACKAGE_MANIFEST_INVALID"' in source


def test_executable_regression_covers_clean_tampered_and_missing_files():
    test = TEST.read_text()
    assert "FILES_PRESENT_AND_HASHED" in test
    assert "CSV_HASH_MISMATCH" in test
    assert "CSV_MISSING" in test
    assert "did not repair" in test
