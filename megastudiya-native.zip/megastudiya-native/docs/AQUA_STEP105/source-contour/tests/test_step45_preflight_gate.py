from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/PreflightGate.kt"

def test_gate_is_non_executing_and_checks_all_safety_dimensions():
    text = SRC.read_text()
    for check in ["STOP_FLAG", "PLAN_FINGERPRINT", "QUEUE_FINGERPRINT", "APPROVAL", "PERMISSIONS", "DEPENDENCIES", "RISK", "BUDGET", "QUEUE_STATE"]:
        assert check in text
    assert "READY_FOR_SIMULATION" in text and "BLOCKED" in text
    assert "never executes tools" in text

def test_stale_approval_and_stop_flag_block():
    text = SRC.read_text()
    assert "ResumeQueueApprovalService.matches" in text
    assert "request.stopped" in text and "request.queue.stopped" in text

def test_budget_and_risk_limits_are_enforced():
    text = SRC.read_text()
    assert "estimatedBudget <= request.remainingBudget" in text
    assert "request.riskLevel <= request.maxAllowedRisk" in text

def test_unresolved_queue_entries_block():
    text = SRC.read_text()
    assert "NEEDS_RECONCILIATION" in text and "BLOCKED_DEPENDENCY" in text and "NEEDS_APPROVAL" in text
