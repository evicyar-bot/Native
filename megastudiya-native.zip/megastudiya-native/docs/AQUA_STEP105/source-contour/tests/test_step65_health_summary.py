from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairArchiveHealthAndQueue.kt"


def test_health_summary_aggregates_counts_and_state():
    text = SOURCE.read_text()
    assert 'healthPercent' in text
    assert 'NEEDS_REVIEW' in text
    assert 'NOT_INITIALIZED' in text

