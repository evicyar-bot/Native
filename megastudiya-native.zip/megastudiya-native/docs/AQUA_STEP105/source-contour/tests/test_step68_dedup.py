from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairArchiveHealthAndQueue.kt"


def test_deduplication_uses_stable_item_id():
    text = SOURCE.read_text()
    assert 'distinctBy { it.id }' in text
    assert 'maxWith' in text
    assert 'sortedWith' in text

