from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/PreflightReceipt.kt"


def test_receipt_captures_preflight_inputs_and_all_check_results():
    text = SRC.read_text()
    for field in ["planFingerprint", "queueFingerprint", "queueSnapshot", "requestFingerprint", "permissionsSatisfied", "dependenciesSatisfied", "riskLevel", "estimatedBudget", "outcome", "passed", "failed", "reasons"]:
        assert field in text
    assert "PreflightReceiptFactory.create" in text
    assert "PreflightGate.evaluate(request)" in text


def test_receipts_are_checksummed_and_chained():
    text = SRC.read_text()
    assert "previousHash" in text and "SHA-256" in text
    assert "receipt journal integrity failure" in text.lower()
    assert "AQUA_PREFLIGHT_RECEIPTS_V1" in text


def test_store_persists_before_publishing_and_rejects_duplicate_ids():
    text = SRC.read_text()
    assert "persist(candidate)" in text
    assert "receipts.add(receipt)" in text
    assert "Duplicate or blank receipt ID" in text
    assert "ATOMIC_MOVE" in text


def test_receipt_does_not_execute_external_actions():
    text = SRC.read_text()
    assert "does not grant tool access or execute" in text
    assert "PreflightOutcome" in text
