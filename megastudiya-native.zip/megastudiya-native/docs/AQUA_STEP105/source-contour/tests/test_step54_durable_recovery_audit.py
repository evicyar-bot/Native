from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/DurableRecoveryAuditStore.kt").read_text()


def test_versioned_durable_chain_and_restart_verification():
    assert 'AQUA_RECOVERY_AUDIT|1' in SOURCE
    assert 'loadAndVerify()' in SOURCE
    assert 'verifyIntegrity()' in SOURCE
    assert 'SHA-256' in SOURCE


def test_duplicate_ids_are_idempotent_and_conflicts_rejected():
    assert 'Conflicting recovery receipt ID' in SOURCE
    assert 'if (existing != null)' in SOURCE
    assert 'seen.add(receipt.receiptId)' in SOURCE


def test_atomic_persistence_and_no_silent_reset():
    assert 'ATOMIC_MOVE' in SOURCE
    assert 'Unsupported or corrupt recovery audit journal' in SOURCE
    assert 'deleteIfExists(temp)' in SOURCE
