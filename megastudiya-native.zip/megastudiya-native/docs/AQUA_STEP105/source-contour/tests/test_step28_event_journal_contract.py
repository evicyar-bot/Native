from pathlib import Path
ROOT = Path(__file__).parents[1]
CORE = ROOT / 'modules/aqua-research-core/src/main/kotlin/aqua/research/ResearchEvents.kt'
PORT = ROOT / 'modules/aqua-ports/src/main/kotlin/aqua/ports/ResearchEventJournal.kt'
MEMORY = ROOT / 'modules/aqua-adapters/in-memory/src/main/kotlin/aqua/adapters/memory/InMemoryResearchEventJournal.kt'

def test_event_captures_traceability_fields_and_outcome():
    s = CORE.read_text()
    for field in ('occurredAtEpochMs', 'actor', 'action', 'subjectId', 'outcome', 'taskId', 'reason', 'details', 'sequence'):
        assert field in s
    assert 'enum class EventOutcome' in s

def test_journal_port_is_append_query_find_and_sequence():
    s = PORT.read_text()
    for signature in ('fun append(', 'fun query(', 'fun find(', 'fun latestSequence()'):
        assert signature in s

def test_append_is_idempotent_by_event_id():
    s = MEMORY.read_text()
    assert 'byId[event.id]?.let' in s
    assert 'byId[stored.id] = stored' in s

def test_events_are_sequence_numbered_and_append_only():
    s = MEMORY.read_text()
    assert 'event.copy(sequence = ++sequence)' in s
    assert 'events += stored' in s
    assert 'synchronized(lock)' in s

def test_queries_support_filters_and_cursor():
    s = MEMORY.read_text()
    for token in ('afterSequence', 'query.taskId', 'query.actor', 'query.action', 'query.outcome', 'query.limit'):
        assert token in s

def test_event_record_validates_minimum_fields():
    s = CORE.read_text()
    assert 'require(actor.isNotBlank())' in s
    assert 'require(action.isNotBlank())' in s
    assert 'require(sequence >= 0)' in s
