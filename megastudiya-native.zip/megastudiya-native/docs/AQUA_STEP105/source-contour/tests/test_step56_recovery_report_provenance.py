from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_step56_manifest_contract_exists():
    source = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportProvenance.kt"
    text = source.read_text(encoding="utf-8")
    for token in ("RecoveryReportManifest", "sourceLedgerSha256", "filterCanonical",
                  "reportSha256", "manifestSha256", "fun verify", "fun write", "fun read"):
        assert token in text


def test_step56_manifest_is_versioned_and_atomic():
    text = (ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportProvenance.kt").read_text(encoding="utf-8")
    assert 'AQUA_RECOVERY_REPORT_MANIFEST|1' in text
    assert "ATOMIC_MOVE" in text
    assert "manifest checksum mismatch" in text
