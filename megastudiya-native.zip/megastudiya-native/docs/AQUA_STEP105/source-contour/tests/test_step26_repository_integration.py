from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
def test_step26_compile_and_behavior():
    src=[str(p) for p in ROOT.rglob('*.kt')]
    jar=ROOT/'tests'/'step26-integration.jar'
    subprocess.run(['kotlinc',*src,'-include-runtime','-d',str(jar)],check=True,capture_output=True,text=True,timeout=180)
    result=subprocess.run(['java','-cp',str(jar),'Step26RepositoryIntegrationTestKt'],check=True,capture_output=True,text=True,timeout=30)
    assert 'Step26: 6 checks PASS' in result.stdout
    jar.unlink(missing_ok=True)
def test_step26_integration_contract():
    f=ROOT/'modules/aqua-adapters/file/src/main/kotlin/aqua/adapters/file/DurableResearchRepositories.kt'
    s=f.read_text()
    for token in ['DurableResearchRepositories','store.save','initialize','recover','removeTask','evidenceSourceIds']:
        assert token in s
    assert 'android.' not in s and 'app.megastudiya' not in s
