from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/ResumeQueuePlanner.kt"
def test_resume_queue_is_planning_only():
    s = SRC.read_text(); assert "not executed" in s.lower(); assert "ResumeQueuePlanner" in s

def test_completed_steps_not_requeued():
    s = SRC.read_text(); assert "ALREADY_COMPLETED" in s and "SUCCEEDED" in s

def test_interrupted_and_failed_need_review():
    s = SRC.read_text(); assert "NEEDS_RECONCILIATION" in s and "NEEDS_APPROVAL" in s

def test_fingerprint_and_dependency_guards():
    s = SRC.read_text(); assert "fingerprint mismatch" in s.lower() and "Unknown dependency" in s
