from pathlib import Path
import subprocess
ROOT = Path(__file__).resolve().parents[1]


def test_step23_compiles_and_runs():
    sources = [str(p) for p in ROOT.rglob('*.kt')]
    jar = ROOT / 'tests' / 'step23-tests.jar'
    subprocess.run(['kotlinc', *sources, '-include-runtime', '-d', str(jar)], check=True, capture_output=True, text=True)
    result = subprocess.run(['java', '-cp', str(jar), 'Step23DataFormatTestKt'], check=True, capture_output=True, text=True)
    assert 'Step23: 9 checks PASS' in result.stdout
    jar.unlink(missing_ok=True)


def test_format_has_version_migration_and_checksum():
    source = ROOT / 'modules/aqua-data-format/src/main/kotlin/aqua/dataformat/ResearchBundle.kt'
    text = source.read_text()
    for term in ['CURRENT_SCHEMA', 'checksumSha256', 'Unsupported schema version', 'schemaVersion == 0', 'Checksum mismatch']:
        assert term in text
    assert 'android.' not in text and 'app.megastudiya' not in text


def test_adapter_boundary_is_documented():
    docs = ROOT / 'modules/aqua-data-format/README.md'
    assert docs.exists()
    assert 'JSON' in docs.read_text() and 'codec' in docs.read_text().lower()
