from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairArchiveHealthAndQueue.kt"


def test_queue_builder_is_advisory_and_deterministic():
    text = SOURCE.read_text()
    assert 'requiresOwnerDecision' in text
    assert 'executable: Boolean = false' in text
    assert 'fingerprint' in text

