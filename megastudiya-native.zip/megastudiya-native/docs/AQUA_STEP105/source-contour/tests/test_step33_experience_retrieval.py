from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'modules/aqua-experience-memory/src/main/kotlin/aqua/experience/ExperienceMemory.kt'
TEST=ROOT/'tests/kotlin/Step33ExperienceRetrievalTest.kt'
def test_query_model_has_limits():
 s=SRC.read_text(); assert 'maxResults in 1..50' in s and 'minimumConfidence in 0..100' in s
def test_excludes_rejected_and_outdated():
 s=SRC.read_text(); assert 'ExperienceReviewStatus.REJECTED' in s and 'ExperienceReviewStatus.OUTDATED' in s
def test_ranked_retrieval_is_deterministic():
 s=SRC.read_text(); assert 'sortedWith(compareByDescending' in s and 'thenBy { it.insight.id.value }' in s
def test_provides_cautions():
 s=SRC.read_text(); assert 'Unreviewed historical observation' in s and 'not a guarantee' in s
def test_filter_support():
 s=SRC.read_text(); assert 'query.kinds.isEmpty() || insight.kind in query.kinds' in s and 'minimumConfidence' in s
def test_runtime_test_present():
 assert TEST.exists() and 'STEP33_EXPERIENCE_RETRIEVAL_PASS' in TEST.read_text()
