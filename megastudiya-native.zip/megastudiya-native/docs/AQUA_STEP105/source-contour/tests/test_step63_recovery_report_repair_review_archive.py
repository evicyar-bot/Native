from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairReviewArchive.kt"


def test_archive_supports_immutable_snapshots_and_comparison():
    text = SOURCE.read_text()
    assert "fun save(" in text
    assert "fun list()" in text
    assert "fun inspect(" in text
    assert "fun compare(" in text
    assert "IDENTICAL" in text and "LEFT_IS_PREFIX" in text and "RIGHT_IS_PREFIX" in text
    assert "DIVERGENT" in text and "INVALID" in text


def test_archive_has_integrity_checks_and_no_pruning_api():
    text = SOURCE.read_text()
    assert "sha256(Files.readAllBytes(data))" in text
    assert "RecoveryReportRepairReviewJournalExport.verify(data)" in text
    assert "Archive ID already exists" in text
    assert "delete(" not in text and "prune(" not in text
