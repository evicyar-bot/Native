from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryArchiveQueueImportBoundary.kt"

def test_preview_does_not_persist_or_execute():
    text = SOURCE.read_text()
    assert "persisted: Boolean" in text
    assert "executable: Boolean" in text
    assert "RecoveryArchiveQueueImportResultBuilder" in text

def test_import_boundary_has_full_validation_chain():
    text = SOURCE.read_text()
    for marker in ("validateVersion", "withinLimits", "safe(normalized)",
                   "unique(normalized)", "FieldValidation.issues",
                   "manifest.itemCount", "manifest.contentDigest"):
        assert marker in text
