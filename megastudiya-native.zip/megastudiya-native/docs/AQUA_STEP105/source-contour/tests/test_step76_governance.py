from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryArchiveQueueGovernance.kt"
def test_summary_tracks_checked_count_and_issue_codes():
    t = SOURCE.read_text()
    assert "checkedItems" in t and "issueCodes" in t and "distinct().sorted()" in t
