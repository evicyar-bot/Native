from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryArchiveQueueGovernance.kt"
def test_filter_validates_priority_and_applies_criteria():
    t = SOURCE.read_text()
    assert "minimumPriority in 0..100" in t and "severity == null" in t and "group == null" in t
