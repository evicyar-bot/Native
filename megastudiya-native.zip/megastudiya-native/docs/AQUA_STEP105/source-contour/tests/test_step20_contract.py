from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
CORE = ROOT / 'modules/aqua-knowledge-graph/src/main/kotlin/aqua/knowledge/KnowledgeGraph.kt'
class Step20Contracts(unittest.TestCase):
    def test_standalone_docs(self): self.assertTrue((ROOT/'docs/AGENT_HANDOFF.md').exists())
    def test_core_exists(self): self.assertTrue(CORE.exists())
    def test_no_android_import(self): self.assertNotIn('android.', CORE.read_text())
    def test_task_scoped_nodes(self): self.assertIn('taskId: String', CORE.read_text())
    def test_cross_task_edge_guard(self): self.assertIn('from.taskId != edge.taskId || to.taskId != edge.taskId', CORE.read_text())
    def test_inferred_edges_labeled(self): self.assertIn('INFERRED', CORE.read_text())
    def test_edge_does_not_assert_truth(self): self.assertIn('does not infer truth', CORE.read_text())
    def test_adapter_is_separate(self): self.assertTrue((ROOT/'modules/aqua-adapters/megastudio/README.md').exists())
if __name__ == '__main__': unittest.main()
