from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairArchiveHealthAndQueue.kt"


def test_paging_is_bounded_and_validated():
    text = SOURCE.read_text()
    assert 'limit in 1..200' in text
    assert 'offset >= 0' in text
    assert 'fingerprint' in text

