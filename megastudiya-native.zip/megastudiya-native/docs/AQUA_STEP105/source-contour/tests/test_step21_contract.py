from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
CORE = ROOT / 'modules/aqua-research-core/src/main/kotlin/aqua/research'
PORTS = ROOT / 'modules/aqua-ports/src/main/kotlin/aqua/ports'

def test_core_has_no_host_or_android_imports():
    files = list(CORE.rglob('*.kt')) + list(PORTS.rglob('*.kt'))
    text = '\n'.join(p.read_text() for p in files)
    assert 'android.' not in text and 'app.megastudiya' not in text

def test_models_cover_evidence_claim_decision():
    t = (CORE / 'ResearchModels.kt').read_text()
    for token in ['EvidenceSource', 'Claim', 'ResearchDecision', 'DecisionRevision', 'TaskId']:
        assert token in t

def test_claim_service_validates_task_scoped_evidence():
    t = (CORE / 'ResearchServices.kt').read_text()
    assert 'evidence.find(id)?.taskId == claim.taskId' in t
    assert 'if (!validRefs) return false' in t

def test_decision_claim_link_is_task_scoped():
    t = (CORE / 'ResearchServices.kt').read_text()
    assert 'claims.find(it)?.taskId == decision.taskId' in t
    assert 'if (!claimValid) return false' in t

def test_decision_revision_preserves_previous_state():
    t = (CORE / 'ResearchServices.kt').read_text()
    assert 'DecisionRevision(existing.decision, existing.rationale' in t
    assert 'history = existing.history + revision' in t

def test_ports_are_storage_agnostic():
    t = (PORTS / 'ResearchRepositories.kt').read_text()
    assert 'interface EvidenceRepository' in t and 'interface ClaimRepository' in t and 'interface DecisionRepository' in t
    assert 'Context' not in t and 'File' not in t and 'JSONObject' not in t
