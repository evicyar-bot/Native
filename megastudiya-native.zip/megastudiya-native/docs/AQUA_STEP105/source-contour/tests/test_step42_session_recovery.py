from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def test_session_recovery_module_exists():
 p=ROOT/'modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/OrchestrationSessionStore.kt'
 assert p.exists() and 'class OrchestrationSessionStore' in p.read_text()
def test_recovery_never_executes_live_actions():
 t=(ROOT/'modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/OrchestrationSessionStore.kt').read_text()
 assert 'no actions executed' in t and 'PLAN_MISMATCH' in t and 'STOPPED' in t
def test_corruption_is_checked():
 t=(ROOT/'modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/OrchestrationSessionStore.kt').read_text()
 assert 'Session integrity failure' in t and 'sha(payload)' in t
