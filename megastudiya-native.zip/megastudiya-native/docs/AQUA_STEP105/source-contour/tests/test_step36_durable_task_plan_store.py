from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def test_repository_and_lifecycle():
 s=(ROOT/'modules/aqua-task-planning/src/main/kotlin/aqua/planning/storage/TaskPlanStore.kt').read_text();assert 'TaskPlanRepository' in s and 'APPROVED' in s and 'ARCHIVED' in s and 'PlanStatusChange' in s
def test_durable_integrity_and_recovery():
 s=(ROOT/'modules/aqua-adapters/file/src/main/kotlin/aqua/adapters/file/DurableTaskPlanRepository.kt').read_text();assert 'SHA-256' in s and 'checksum mismatch' in s.lower() and 'renameTo' in s and 'load()' in s
def test_plan_fields_roundtrip():
 s=(ROOT/'modules/aqua-adapters/file/src/main/kotlin/aqua/adapters/file/DurableTaskPlanRepository.kt').read_text()
 for field in ['constraints','successCriteria','contextMemoryIds','contextWarnings','planningWarnings','completionCriteria','dependsOn','riskNotes']: assert field in s
