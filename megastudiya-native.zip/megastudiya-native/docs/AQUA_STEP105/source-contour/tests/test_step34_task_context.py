from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'modules/aqua-experience-memory/src/main/kotlin/aqua/experience/TaskContextAssembler.kt'
TEST=ROOT/'tests/kotlin/Step34TaskContextAssemblerTest.kt'
def test_structured_task_context_and_provenance():
 s=SRC.read_text(); assert 'evidenceEventIds' in s and 'matchedTerms' in s and 'TaskContextPackage' in s
def test_warnings_for_unreviewed_and_empty_memory():
 s=SRC.read_text(); assert 'unreviewed' in s.lower() and 'No relevant experience found' in s
def test_bounded_context():
 s=SRC.read_text(); assert 'maxCharacters in 256..100_000' in s and 'Context truncated by character budget' in s
def test_preserves_constraints():
 s=SRC.read_text(); assert 'constraints' in s and 'CONSTRAINTS:' in s
def test_runtime_test_exists():
 assert TEST.exists() and 'STEP34_TASK_CONTEXT_ASSEMBLER_PASS' in TEST.read_text()
def test_read_only_assembly():
 s=SRC.read_text(); assert 'repository.save' not in s and 'updateReview' not in s
