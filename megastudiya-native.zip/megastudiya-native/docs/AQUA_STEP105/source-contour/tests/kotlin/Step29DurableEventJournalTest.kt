import aqua.adapters.file.DurableResearchEventJournal
import aqua.research.*
import java.nio.file.Files

fun main() {
    val dir = Files.createTempDirectory("aqua-journal-step29")
    val path = dir.resolve("events.log")
    val journal = DurableResearchEventJournal(path)
    val event = ResearchEvent(EventId("evt-1"), 123L, "planner", "plan-created", "plan-7", EventOutcome.SUCCEEDED, TaskId("task-a"), details="durable ✓")
    check(journal.append(event).sequence == 1L)
    check(journal.append(event).sequence == 1L) // idempotent
    check(journal.latestSequence() == 1L)
    val restarted = DurableResearchEventJournal(path)
    check(restarted.find(EventId("evt-1"))?.details == "durable ✓")
    check(restarted.query(EventQuery(taskId=TaskId("task-a"))).size == 1)
    Files.write(path, "incomplete-tail".toByteArray(), java.nio.file.StandardOpenOption.APPEND)
    val repaired = DurableResearchEventJournal(path)
    check(repaired.latestSequence() == 1L)
    check(!String(Files.readAllBytes(path)).endsWith("incomplete-tail"))
    check(repaired.append(event.copy(id=EventId("evt-2"), action="retry")).sequence == 2L)
    check(DurableResearchEventJournal(path).latestSequence() == 2L)
    println("STEP29_DURABLE_EVENT_JOURNAL_PASS")
}
