package aqua.orchestration

fun main() {
    val diagnostic = RecoveryReportCatalogDiagnostic("report-60", 100, listOf(
        RecoveryReportCatalogFinding("report-60", "CSV_MISSING", RecoveryReportFindingSeverity.ERROR,
            "CSV missing", "Restore from trusted backup"),
        RecoveryReportCatalogFinding("report-60", "PROVENANCE_HASH_MISMATCH", RecoveryReportFindingSeverity.ERROR,
            "Manifest changed", "Recover matching manifest")
    ))
    val plan = RecoveryReportRepairPlanner.create(diagnostic)
    check(plan.steps.map { it.code } == listOf("RESTORE_CSV", "RECONCILE_PROVENANCE"))
    check(plan.planFingerprint.matches(Regex("[0-9a-f]{64}")))
    check(!plan.containsDestructiveAction)
    check(runCatching { RecoveryReportRepairPlanner.review(plan, "operator", false, 110) }.isFailure)
    val review = RecoveryReportRepairPlanner.review(plan, "operator", true, 110)
    check(review.approvedForFutureExecution && !review.executionAllowed)
    check(review.planFingerprint == plan.planFingerprint)
    check(review.note.contains("no repair was executed"))
    check(runCatching { RecoveryReportRepairPlanner.review(plan.copy(planFingerprint = "0".repeat(64)), "operator", true, 110) }.isFailure)
    check(runCatching { RecoveryReportRepairPlanner.review(plan, "", true, 110) }.isFailure)
    val clean = RecoveryReportRepairPlanner.create(RecoveryReportCatalogDiagnostic("report-60", 120, listOf(
        RecoveryReportCatalogFinding("report-60", "FILES_PRESENT_AND_HASHED", RecoveryReportFindingSeverity.INFO,
            "Clean", "No action")
    )))
    check(clean.steps.isEmpty() && !clean.requiresOperatorReview)
    println("STEP60_RECOVERY_REPORT_REPAIR_PLAN_PASS")
}
