package aqua.tests
import aqua.adapters.memory.InMemoryExperienceMemory
import aqua.experience.*
object Step34TaskContextAssemblerTest {
 @JvmStatic fun main(args: Array<String>) {
  val repo=InMemoryExperienceMemory()
  repo.save(ExperienceInsight(ExperienceId("mem1"),ExperienceKind.FAILURE_PATTERN,"Repeated timeout in web research",setOf("evt1","evt2"),2,65,createdAtEpochMs=1))
  repo.save(ExperienceInsight(ExperienceId("mem2"),ExperienceKind.HIGH_SUCCESS_SIGNAL,"Successful file analysis process",setOf("evt3"),5,90,ExperienceReviewStatus.CONFIRMED,2))
  val assembler=TaskContextAssembler(ExperienceRetrievalService(repo))
  val pack=assembler.assemble(TaskContextRequest("task-7","web research timeout",listOf("cite sources"),maxCharacters=2000))
  check(pack.taskId=="task-7" && pack.memories.isNotEmpty())
  check(pack.renderedText.contains("GOAL: web research timeout") && pack.renderedText.contains("evt1"))
  check(pack.warnings.any { it.contains("unreviewed") })
  val empty=assembler.assemble(TaskContextRequest("task-8","unrelated astronomy",maxCharacters=300))
  check(empty.memories.isEmpty() && empty.warnings.any { it.contains("No relevant") })
  val short=assembler.assemble(TaskContextRequest("task-9","web research timeout",maxCharacters=256))
  check(short.truncated && short.renderedText.length <= 300 && short.renderedText.contains("truncated"))
  println("STEP34_TASK_CONTEXT_ASSEMBLER_PASS")
 }
}
