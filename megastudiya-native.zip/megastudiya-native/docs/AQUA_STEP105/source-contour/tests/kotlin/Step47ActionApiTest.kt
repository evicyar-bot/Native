import aqua.orchestration.*

fun main() {
    val catalog = ActionCatalog(listOf(ActionDefinition("research.read", "Read an allowed public resource",
        listOf(ActionArgument("url", true, 2048)), "research.read", ActionRisk.LOW)))
    val api = ActionApi(catalog)
    val valid = ActionRequest("r1", "research.read", mapOf("url" to "https://example.org"), setOf("research.read"))
    check(api.submit(valid).status == ActionStatus.ACCEPTED_FOR_SIMULATION)
    check(api.submit(valid).status == ActionStatus.ACCEPTED_FOR_SIMULATION) // idempotent replay
    check(api.submit(valid.copy(requestId = "r2", grantedPermissions = emptySet())).code == "PERMISSION_REQUIRED")
    check(api.submit(valid.copy(requestId = "r3", arguments = emptyMap())).code == "MISSING_ARGUMENT")
    check(api.submit(valid.copy(requestId = "r4", arguments = mapOf("url" to "x", "extra" to "y"))).code == "UNKNOWN_ARGUMENT")
    check(api.submit(valid.copy(requestId = "r1", arguments = mapOf("url" to "https://different.org"))).code == "REQUEST_ID_CONFLICT")
    check(api.submit(valid.copy(requestId = "r5", mode = ActionMode.valueOf("DRY_RUN"))).status == ActionStatus.ACCEPTED_FOR_SIMULATION)
    check(api.auditSnapshot().size == 5)
    println("STEP47_ACTION_API_PASS")
}
