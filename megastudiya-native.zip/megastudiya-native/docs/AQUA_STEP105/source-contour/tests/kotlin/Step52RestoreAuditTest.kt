import aqua.orchestration.*
import java.nio.file.Files

fun main() {
    val dir = Files.createTempDirectory("aqua-step52")
    val archive = dir.resolve("actions.export")
    val source = InMemoryActionResultJournal()
    val sample = ActionResult("restore-1", "research.read", ActionStatus.ACCEPTED_FOR_SIMULATION,
        "DRY_RUN_ACCEPTED", "Validated only", "a".repeat(64))
    source.append(sample)
    ActionJournalExport.export(source, archive)
    val target = InMemoryActionResultJournal()
    val plan = ActionJournalRestore.preview(archive, target)
    val storeFile = dir.resolve("restore-audit.log")
    val store = DurableRestoreAuditStore(storeFile)
    val audited = AuditedActionJournalRestore(target, store) { 123456L }
    val denied = audited.apply(plan, false, "receipt-denied")
    check(!denied.applied && target.snapshot().isEmpty())
    val approvedPlan = ActionJournalRestore.preview(archive, target)
    val accepted = audited.apply(approvedPlan, true, "receipt-approved")
    check(accepted.applied && accepted.imported == 1)
    check(store.snapshot().size == 2)
    val reopened = DurableRestoreAuditStore(storeFile)
    check(reopened.snapshot() == store.snapshot())
    check(reopened.snapshot()[0].ownerApproved.not())
    check(reopened.snapshot()[1].ownerApproved && reopened.snapshot()[1].imported == 1)
    // Tampering with durable evidence must be detected on reopen.
    val original = Files.readString(storeFile)
    val tampered = original.dropLast(2) + (if (original[original.lastIndex - 1] == '0') "1" else "0") + "\n"
    Files.writeString(storeFile, tampered)
    var rejected = false
    try { DurableRestoreAuditStore(storeFile) } catch (_: IllegalArgumentException) { rejected = true }
    check(rejected)
    println("STEP52_RESTORE_AUDIT_PASS")
}
