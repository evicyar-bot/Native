import aqua.orchestration.*
import java.io.File
fun main() {
 val q=ResumeQueue("plan",listOf(ResumeQueueItem("one",ResumeDisposition.QUEUED,"ready")),false,false)
 val frozen=ResumeQueueApprovalService.freeze(q)
 val record=ResumeQueueApprovalService.record(frozen,"owner",ResumeApprovalDecision.APPROVE,100,"reviewed")
 check(ResumeQueueApprovalService.matches(record,frozen))
 val changed=ResumeQueueApprovalService.freeze(q.copy(items=q.items+ResumeQueueItem("two",ResumeDisposition.QUEUED,"ready")))
 check(!ResumeQueueApprovalService.matches(record,changed))
 val f=File("/tmp/aqua-step44-approval.dat"); ResumeQueueApprovalService.save(f,record)
 check(ResumeQueueApprovalService.load(f)==record)
 f.writeText(f.readText().replace("reviewed","tampered")); var rejected=false
 try { ResumeQueueApprovalService.load(f) } catch (_: IllegalArgumentException) { rejected=true }
 check(rejected); f.delete()
 println("STEP44_RESUME_APPROVAL_PASS")
}
