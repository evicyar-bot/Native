import aqua.orchestration.*
import java.io.File
fun main() {
 val f=File.createTempFile("aqua-session", ".dat"); f.delete()
 val store=OrchestrationSessionStore()
 val original=OrchestrationSessionState("session-A","plan-abc",mapOf("s1" to ActionDecision.SIMULATE_READY,"s2" to ActionDecision.REQUIRES_OWNER_APPROVAL),false,"audit-hash",1234)
 store.save(f,original)
 check(store.recover(f,"plan-abc").status==SessionRecoveryStatus.RESTORED)
 check(store.recover(f,"changed-plan").status==SessionRecoveryStatus.PLAN_MISMATCH)
 val stopped=original.copy(stopRequested=true); store.save(f,stopped)
 check(store.recover(f,"plan-abc").status==SessionRecoveryStatus.STOPPED)
 val lines=f.readText().lines().toMutableList(); lines[2] = if (lines[2].startsWith("0")) "1" + lines[2].drop(1) else "0" + lines[2].drop(1); val text=lines.joinToString("\n")
 f.writeText(text)
 var detected=false; try { store.recover(f,"plan-abc") } catch (_: IllegalArgumentException) { detected=true }
 check(detected)
 f.delete(); println("STEP42_SESSION_RECOVERY_PASS")
}
