package aqua.orchestration

import java.nio.file.Files

fun main() {
    val root = Files.createTempDirectory("aqua-step64-")
    val absent = RecoveryReportRepairReviewArchiveDiagnostics(root.resolve("not-created")).inspect()
    check(!absent.directoryPresent && absent.findings.single().code == "ARCHIVE_DIRECTORY_MISSING")

    val journalPath = root.resolve("reviews.log")
    val journal = RecoveryReportRepairReviewJournal(journalPath)
    val diagnostic = RecoveryReportCatalogDiagnostic("report-64", 100, listOf(
        RecoveryReportCatalogFinding("report-64", "CSV_MISSING", RecoveryReportFindingSeverity.ERROR,
            "CSV missing", "Restore from trusted backup")
    ))
    val plan = RecoveryReportRepairPlanner.create(diagnostic)
    journal.record(plan, "operator", true, 110)
    val exportPath = root.resolve("review.export")
    RecoveryReportRepairReviewJournalExport.export(journalPath, exportPath)

    val archiveDir = root.resolve("archive")
    val archive = RecoveryReportRepairReviewArchive(archiveDir)
    archive.save("snapshot-a", "Snapshot A", exportPath, 120)
    val clean = RecoveryReportRepairReviewArchiveDiagnostics(archiveDir).inspect()
    check(clean.healthy && clean.metadataEntries == 1 && clean.validEntries == 1 && clean.findings.isEmpty())

    // Unmatched payloads, duplicate content and interrupted writes are reported, never changed.
    Files.copy(archiveDir.resolve("snapshot-a.export"), archiveDir.resolve("orphan.export"))
    Files.copy(archiveDir.resolve("snapshot-a.export"), root.resolve("duplicate.export"))
    archive.save("snapshot-b", "Snapshot B", root.resolve("duplicate.export"), 130)
    Files.writeString(archiveDir.resolve("unfinished.pending"), "partial")
    val before = Files.list(archiveDir).use { it.map { p -> p.fileName.toString() }.sorted().toList() }
    val result = RecoveryReportRepairReviewArchiveDiagnostics(archiveDir).inspect()
    check(result.findings.any { it.code == "ORPHAN_ARCHIVE_PAYLOAD" })
    check(result.findings.any { it.code == "DUPLICATE_SNAPSHOT_CONTENT" })
    check(result.findings.any { it.code == "INTERRUPTED_ARCHIVE_WRITE" })
    val after = Files.list(archiveDir).use { it.map { p -> p.fileName.toString() }.sorted().toList() }
    check(before == after)

    // Corrupt a stored payload and verify the diagnostic points to the affected entry.
    Files.writeString(archiveDir.resolve("snapshot-a.export"), "tampered")
    val corrupted = RecoveryReportRepairReviewArchiveDiagnostics(archiveDir).inspect()
    check(corrupted.findings.any { it.archiveId == "snapshot-a" && it.severity == RecoveryReportRepairArchiveFindingSeverity.ERROR })
    check(Files.readString(archiveDir.resolve("snapshot-a.export")) == "tampered")
    println("STEP64_RECOVERY_REPORT_REPAIR_REVIEW_ARCHIVE_DIAGNOSTICS_PASS")
}
