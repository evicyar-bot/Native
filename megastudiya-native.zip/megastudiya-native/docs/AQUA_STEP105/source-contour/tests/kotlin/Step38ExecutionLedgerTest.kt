import aqua.execution.*
fun main() {
 val svc=ExecutionLedgerService(); var l=svc.create("plan-a",1,listOf("s1","s2"),100)
 l=svc.transition(l,"s1",StepExecutionStatus.READY,110,"e1")
 l=svc.transition(l,"s1",StepExecutionStatus.RUNNING,120,"e2")
 l=svc.checkpoint(l,"s1","checkpoint-1",130,"e3")
 l=svc.transition(l,"s1",StepExecutionStatus.FAILED,140,"e4","network timeout")
 l=svc.transition(l,"s1",StepExecutionStatus.READY,150,"e5")
 l=svc.transition(l,"s1",StepExecutionStatus.RUNNING,160,"e6")
 check(l.steps.first().attempts==2)
 l=svc.transition(l,"s1",StepExecutionStatus.SUCCEEDED,170,"e7")
 check(l.steps.first().status==StepExecutionStatus.SUCCEEDED)
 check(l.steps.first().checkpoint=="checkpoint-1")
 check(l.events.size==7)
 check(svc.summary(l)[StepExecutionStatus.SUCCEEDED]==1)
 try { svc.transition(l,"s1",StepExecutionStatus.RUNNING,180,"e8"); error("terminal transition allowed") } catch(_:IllegalArgumentException) {}
 println("STEP38_EXECUTION_LEDGER_PASS")
}
