import aqua.dataformat.*
import aqua.research.*
import java.nio.file.Files

fun main() {
    val root=Files.createTempDirectory("aqua-store-test")
    val store=FileDurableBundleStore(root)
    val task=TaskId("durable-task")
    val source=EvidenceSource(SourceId("s1"),task,"Source title","https://example.org","test",100,SourceReview.UNREVIEWED)
    val claim=Claim(ClaimId("c1"),task,"Claim text",ClaimType.FACT,setOf(source.id),"",101,ClaimReview.UNREVIEWED,"")
    val raw=ResearchBundle(1,102,listOf(source),listOf(claim), emptyList(),"")
    val saved=store.save(raw,"research-1")
    check(saved is StoreSaveResult.Saved && saved.generation==1L)
    check(store.load("research-1") is StoreLoadResult.Loaded)
    check(store.keys()==listOf("research-1"))
    val saved2=store.save(raw.copy(exportedAtEpochMs=103),"research-1")
    check(saved2 is StoreSaveResult.Saved && saved2.generation==2L)
    check((store.load("research-1") as StoreLoadResult.Loaded).generation==2L)
    // corrupt current payload; recovery should return the prior committed generation
    val payload=root.resolve("research-1/generation-2/bundle.json")
    Files.write(payload,"corrupt".toByteArray())
    check(store.load("research-1") is StoreLoadResult.Failed)
    check((store.recover("research-1") as StoreLoadResult.Loaded).generation==1L)
    check(store.load("missing") is StoreLoadResult.Missing)
    check(store.save(raw,"../bad") is StoreSaveResult.Failed)
    root.toFile().deleteRecursively()
    println("Step25: 7 checks PASS")
}
