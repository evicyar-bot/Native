import aqua.orchestration.*
import java.io.File

fun main() {
    val frozen = FrozenResumeQueue("plan-46", "queue-46", listOf(ResumeQueueItem("s1", ResumeDisposition.QUEUED, "eligible")), false)
    val approval = ResumeApprovalRecord("plan-46", "queue-46", "owner", ResumeApprovalDecision.APPROVE, 100L, "reviewed")
    val request = PreflightRequest("plan-46", frozen, approval, true, true, 1, 2, 5, 10, false, true)
    check(PreflightGate.evaluate(request).outcome == PreflightOutcome.READY_FOR_SIMULATION)

    val file = File.createTempFile("aqua-preflight", ".journal")
    file.delete()
    val store = PreflightReceiptStore()
    store.attach(file)
    val first = store.append(request, "receipt-1", 200L)
    check(first.outcome == PreflightOutcome.READY_FOR_SIMULATION && first.failed.isEmpty())
    check(first.passed.size == PreflightCheck.entries.size)
    val second = store.append(request.copy(stopped = true), "receipt-2", 201L)
    check(second.failed.contains(PreflightCheck.STOP_FLAG))
    check(store.verify() && store.snapshot().size == 2)

    val restored = PreflightReceiptStore()
    restored.attach(file)
    check(restored.verify() && restored.snapshot() == store.snapshot())
    val lines = file.readLines().toMutableList()
    val fields = lines.last().split('\t').toMutableList()
    fields[fields.lastIndex] = fields.last().dropLast(1) + if (fields.last().last() == 'A') "B" else "A"
    lines[lines.lastIndex] = fields.joinToString("\t")
    file.writeText(lines.joinToString("\n") + "\n")
    val tampered = PreflightReceiptStore()
    var rejected = false
    try { tampered.attach(file) } catch (_: IllegalArgumentException) { rejected = true }
    check(rejected)
    file.delete()
    println("STEP46_PREFLIGHT_RECEIPT_PASS")
}
