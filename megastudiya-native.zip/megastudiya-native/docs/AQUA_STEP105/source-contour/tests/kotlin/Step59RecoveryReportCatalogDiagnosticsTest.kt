package aqua.orchestration

import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.Files
import java.security.MessageDigest

private fun hash59(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

fun main() {
    val root = Files.createTempDirectory("aqua-step59")
    val csv = root.resolve("report.csv")
    val provenance = root.resolve("report.manifest")
    val sidecar = root.resolve("report.manifest.package")
    val csvBytes = "id,value\n1,ok\n".toByteArray(UTF_8)
    val provenanceBytes = "provenance-v1".toByteArray(UTF_8)
    Files.write(csv, csvBytes); Files.write(provenance, provenanceBytes)
    val csvHash = hash59(csvBytes); val provenanceHash = hash59(provenanceBytes)
    val unsigned = listOf(1, csvHash, provenanceHash).joinToString("\n").toByteArray(UTF_8)
    val packageHash = hash59(unsigned)
    Files.writeString(sidecar, listOf("AQUA_RECOVERY_REPORT_PACKAGE|1", "1", csvHash, provenanceHash, packageHash).joinToString("\n", postfix = "\n"))
    val catalog = RecoveryReportCatalog(root.resolve("catalog.log"))
    catalog.register("report-59", csv, provenance, 100)
    val clean = catalog.diagnoseFilesystem(110).single()
    check(clean.isConsistent && clean.findings.single().code == "FILES_PRESENT_AND_HASHED")

    Files.writeString(csv, "tampered")
    val tampered = catalog.diagnoseFilesystem(120).single()
    check(!tampered.isConsistent && tampered.findings.any { it.code == "CSV_HASH_MISMATCH" })
    check(Files.readString(csv) == "tampered") // diagnostics did not repair or rewrite it

    Files.delete(csv)
    val missing = catalog.diagnoseFilesystem(130).single()
    check(missing.findings.any { it.code == "CSV_MISSING" })
    check(Files.exists(provenance) && Files.exists(sidecar) && catalog.verifyJournal())
    println("STEP59_RECOVERY_REPORT_CATALOG_DIAGNOSTICS_PASS")
}
