import aqua.dataformat.*
import aqua.research.*

fun main() {
    val t = TaskId("task-A")
    val src = EvidenceSource(SourceId("src-1"), t, "Source", "https://example.org", capturedAtEpochMs = 10)
    val claim = Claim(ClaimId("claim-1"), t, "A testable claim", ClaimType.FACT, setOf(src.id), createdAtEpochMs = 11)
    val decision = ResearchDecision(DecisionId("decision-1"), t, "Choose", "Choice", "Reason", claimId = claim.id, createdAtEpochMs = 12, updatedAtEpochMs = 12)
    val raw = ResearchBundle(1, 100, listOf(src), listOf(claim), listOf(decision))
    val sealed = ResearchBundleFormat.seal(raw)
    check(ResearchBundleFormat.validate(sealed).valid)
    check(ResearchBundleFormat.import(sealed) is BundleImportResult.Accepted)
    check(!ResearchBundleFormat.validate(sealed.copy(checksumSha256 = "bad")).valid)
    check(ResearchBundleFormat.import(raw.copy(schemaVersion = 0)) is BundleImportResult.Accepted)
    check(ResearchBundleFormat.import(raw.copy(schemaVersion = 99)) is BundleImportResult.Rejected)
    val orphan = raw.copy(claims = listOf(claim.copy(evidenceSourceIds = setOf(SourceId("missing")))))
    check(!ResearchBundleFormat.validate(ResearchBundleFormat.seal(orphan)).valid)
    val foreignSource = src.copy(taskId = TaskId("task-B"))
    val crossTask = raw.copy(sources = listOf(foreignSource))
    check(!ResearchBundleFormat.validate(ResearchBundleFormat.seal(crossTask)).valid)
    val duplicate = raw.copy(sources = listOf(src, src.copy(title = "duplicate")))
    check(!ResearchBundleFormat.validate(ResearchBundleFormat.seal(duplicate)).valid)
    val changed = sealed.copy(claims = listOf(claim.copy(statement = "tampered")))
    check(!ResearchBundleFormat.validate(changed).valid)
    println("Step23: 9 checks PASS")
}
