package aqua.tests

import aqua.adapters.memory.InMemoryExperienceMemory
import aqua.adapters.memory.InMemoryResearchEventJournal
import aqua.analytics.EventHistoryAnalytics
import aqua.experience.*
import aqua.research.*

object Step31ExperienceMemoryTest {
 @JvmStatic fun main(args: Array<String>) {
  val journal = InMemoryResearchEventJournal()
  fun event(id: String, action: String, outcome: EventOutcome, reason: String = "") {
   journal.append(ResearchEvent(EventId(id), id.removePrefix("e").toLong(), "worker", action, outcome=outcome, taskId=TaskId("task-a"), reason=reason))
  }
  event("e1", "sync", EventOutcome.FAILED, "offline")
  event("e2", "sync", EventOutcome.FAILED, "offline")
  event("e3", "sync", EventOutcome.FAILED, "offline")
  event("e4", "sync", EventOutcome.SUCCEEDED)
  event("e5", "sync", EventOutcome.SUCCEEDED)
  val report = EventHistoryAnalytics(journal).analyze()
  val memory = InMemoryExperienceMemory()
  val service = ExperienceLearningService(memory)
  val learned = service.learn(report, 123L)
  check(learned.isNotEmpty())
  check(learned.all { it.evidenceEventIds.isNotEmpty() && it.reviewStatus == ExperienceReviewStatus.UNREVIEWED })
  check(learned.any { it.kind == ExperienceKind.FAILURE_PATTERN && it.evidenceEventIds.size == 3 })
  check(learned.any { it.kind == ExperienceKind.LOW_SUCCESS_ACTION })
  check(learned.all { it.confidenceScore in 45..90 })
  check(service.learn(report, 999L).size == learned.size) // deterministic IDs; no duplicate insights
  val first = learned.first()
  check(memory.updateReview(first.id, ExperienceReviewStatus.CONFIRMED)?.reviewStatus == ExperienceReviewStatus.CONFIRMED)
  check(memory.list(ExperienceReviewStatus.CONFIRMED).size == 1)
  check(memory.get(first.id)?.createdAtEpochMs == 123L)
  println("STEP31_EXPERIENCE_MEMORY_PASS")
 }
}
