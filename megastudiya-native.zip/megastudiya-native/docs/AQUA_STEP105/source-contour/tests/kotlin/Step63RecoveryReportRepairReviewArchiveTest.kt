package aqua.orchestration

import java.nio.file.Files

fun main() {
    val dir = Files.createTempDirectory("aqua-step63-")
    val journalPath = dir.resolve("reviews.log")
    val journal = RecoveryReportRepairReviewJournal(journalPath)
    val diagnostic = RecoveryReportCatalogDiagnostic("report-63", 100, listOf(
        RecoveryReportCatalogFinding("report-63", "CSV_MISSING", RecoveryReportFindingSeverity.ERROR,
            "CSV missing", "Restore from trusted backup")
    ))
    val plan = RecoveryReportRepairPlanner.create(diagnostic)
    journal.record(plan, "operator", true, 110)
    val firstExport = dir.resolve("first.export")
    RecoveryReportRepairReviewJournalExport.export(journalPath, firstExport)
    val archive = RecoveryReportRepairReviewArchive(dir.resolve("archive"))
    val first = archive.save("snapshot-1", "Initial review", firstExport, 120)
    check(first.valid && first.receiptCount == 1)
    journal.record(plan, "operator", true, 130)
    val secondExport = dir.resolve("second.export")
    RecoveryReportRepairReviewJournalExport.export(journalPath, secondExport)
    val second = archive.save("snapshot-2", "Extended review", secondExport, 140)
    check(second.valid && second.receiptCount == 2)
    check(archive.list().size == 2)
    val comparison = archive.compare("snapshot-1", "snapshot-2")
    check(comparison.relation == RecoveryReportRepairArchiveRelation.LEFT_IS_PREFIX)
    check(comparison.commonPrefixCount == 1 && comparison.rightOnlySequences == listOf(2L))
    check(runCatching { archive.save("snapshot-1", "Overwrite", secondExport, 150) }.isFailure)
    val stored = dir.resolve("archive/snapshot-2.export")
    Files.writeString(stored, "tampered")
    check(!archive.inspect("snapshot-2").valid)
    check(archive.compare("snapshot-1", "snapshot-2").relation == RecoveryReportRepairArchiveRelation.INVALID)
    check(journal.verify().valid && journal.all().size == 2)
    println("STEP63_RECOVERY_REPORT_REPAIR_REVIEW_ARCHIVE_PASS")
}
