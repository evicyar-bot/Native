package aqua.tests

import aqua.adapters.memory.InMemoryResearchEventJournal
import aqua.research.*

object Step28EventJournalTest {
    @JvmStatic fun main(args: Array<String>) {
        val journal = InMemoryResearchEventJournal()
        val taskA = TaskId("task-a")
        val taskB = TaskId("task-b")
        val e1 = ResearchEvent(EventId("e1"), 100, "planner", "plan", outcome = EventOutcome.STARTED, taskId = taskA)
        val e2 = ResearchEvent(EventId("e2"), 110, "researcher", "fetch", outcome = EventOutcome.SUCCEEDED, taskId = taskA)
        val e3 = ResearchEvent(EventId("e3"), 120, "researcher", "fetch", outcome = EventOutcome.FAILED, taskId = taskB, reason = "network")
        check(journal.append(e1).sequence == 1L)
        check(journal.append(e2).sequence == 2L)
        check(journal.append(e3).sequence == 3L)
        check(journal.append(e1).sequence == 1L) // duplicate is idempotent
        check(journal.latestSequence() == 3L)
        check(journal.query(EventQuery(taskId = taskA)).map { it.id.value } == listOf("e1", "e2"))
        check(journal.query(EventQuery(outcome = EventOutcome.FAILED)).single().id == EventId("e3"))
        check(journal.query(EventQuery(afterSequence = 1)).map { it.sequence } == listOf(2L, 3L))
        check(journal.find(EventId("e2"))?.action == "fetch")
        println("STEP28_EVENT_JOURNAL_PASS")
    }
}
