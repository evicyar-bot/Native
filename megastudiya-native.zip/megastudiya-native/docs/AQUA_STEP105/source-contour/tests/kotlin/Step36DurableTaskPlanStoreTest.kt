package aqua.tests
import aqua.planning.*
import aqua.planning.storage.*
import aqua.adapters.file.DurableTaskPlanRepository
import aqua.adapters.memory.InMemoryTaskPlanRepository
import java.io.File
object Step36DurableTaskPlanStoreTest {
 @JvmStatic fun main(args:Array<String>){
  val plan=TaskPlan("task36","Build test plan",listOf("no execution"),listOf(PlannedStep(1,PlanStepDraft("a","Inspect","Inspection report",listOf("report saved"),riskNotes=listOf("missing data")))),listOf("plan is complete"),listOf("mem1"),listOf("warning"),emptyList(),PlanStatus.NEEDS_REVIEW)
  val mem=InMemoryTaskPlanRepository();val saved=mem.save("p1",plan,100);check(saved.version==1&&saved.status==StoredPlanStatus.SAVED);check(mem.save("p1",plan,200)==saved);check(mem.changeStatus("p1",StoredPlanStatus.APPROVED,300,"reviewed")!!.version==2);check(mem.list("task36").size==1)
  val f=File("/tmp/aqua-step36-plan-store-test.tsv");f.delete();val repo=DurableTaskPlanRepository(f);repo.save("p1",plan,100);repo.changeStatus("p1",StoredPlanStatus.APPROVED,300,"reviewed");val reload=DurableTaskPlanRepository(f);val got=reload.get("p1")!!;check(got.plan==plan&&got.version==2&&got.status==StoredPlanStatus.APPROVED&&got.history.single().note=="reviewed");check(reload.save("p1",plan,999)==got);check(reload.list().size==1);f.delete()
  println("STEP36_DURABLE_TASK_PLAN_STORE_PASS")
 }
}
