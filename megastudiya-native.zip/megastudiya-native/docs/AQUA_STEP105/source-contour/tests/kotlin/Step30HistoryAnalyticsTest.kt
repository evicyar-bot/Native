package aqua.tests

import aqua.adapters.memory.InMemoryResearchEventJournal
import aqua.analytics.EventHistoryAnalytics
import aqua.research.*

object Step30HistoryAnalyticsTest {
    @JvmStatic fun main(args: Array<String>) {
        val journal = InMemoryResearchEventJournal()
        val task = TaskId("task-repeat")
        fun add(id: String, action: String, outcome: EventOutcome, reason: String = "", taskId: TaskId? = task) {
            journal.append(ResearchEvent(EventId(id), id.removePrefix("e").toLong(), "researcher", action, outcome = outcome, taskId = taskId, reason = reason))
        }
        add("e1", "fetch", EventOutcome.STARTED)
        add("e2", "fetch", EventOutcome.FAILED, "Timeout  network")
        add("e3", "fetch", EventOutcome.FAILED, "timeout network")
        add("e4", "fetch", EventOutcome.SUCCEEDED)
        add("e5", "parse", EventOutcome.BLOCKED, "bad format")
        val report = EventHistoryAnalytics(journal).analyze()
        check(report.totalEvents == 5)
        check(report.outcomeCounts[EventOutcome.FAILED] == 2)
        check(report.terminalEvents == 4)
        check(report.successRatePercent == 25.0)
        check(report.actionStats.first { it.action == "fetch" }.successRatePercent == 33.333333333333336)
        check(report.repeatedFailures.single().occurrences == 2)
        check(report.recurringTasks.single().taskId == "task-repeat")
        check(report.observations.any { it.contains("Repeated failure") })
        check(EventHistoryAnalytics(journal).analyze(taskId = TaskId("absent")).totalEvents == 0)
        check(EventHistoryAnalytics(InMemoryResearchEventJournal()).analyze().successRatePercent == null)
        println("STEP30_HISTORY_ANALYTICS_PASS")
    }
}
