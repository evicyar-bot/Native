package aqua.tests

import aqua.adapters.file.DurableExperienceMemory
import aqua.experience.*
import java.io.File

object Step32DurableExperienceMemoryTest {
 @JvmStatic fun main(args: Array<String>) {
  val file = File("/tmp/aqua-step32-experience-memory-test.db")
  file.delete()
  val memory = DurableExperienceMemory(file)
  val insight = ExperienceInsight(ExperienceId("insight-1"), ExperienceKind.FAILURE_PATTERN,
   "Repeated timeout", setOf("evt-1", "evt-2"), 2, 55, createdAtEpochMs = 77)
  check(memory.save(insight) == insight)
  check(memory.save(insight.copy(statement = "duplicate changed")) == insight)
  check(memory.updateReview(insight.id, ExperienceReviewStatus.CONFIRMED)?.reviewStatus == ExperienceReviewStatus.CONFIRMED)
  val restored = DurableExperienceMemory(file)
  check(restored.get(insight.id)?.statement == "Repeated timeout")
  check(restored.get(insight.id)?.evidenceEventIds == setOf("evt-1", "evt-2"))
  check(restored.list(ExperienceReviewStatus.CONFIRMED).size == 1)
  val bytes = file.readText()
  file.writeText(bytes.replaceFirst("|", "|bad"))
  var rejected = false
  try { DurableExperienceMemory(file) } catch (_: IllegalArgumentException) { rejected = true }
  check(rejected)
  file.delete()
  println("STEP32_DURABLE_EXPERIENCE_MEMORY_PASS")
 }
}
