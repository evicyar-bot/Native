package aqua.orchestration

import java.nio.file.Files

fun main() {
    val dir = Files.createTempDirectory("aqua-step62-")
    val source = dir.resolve("reviews.log")
    val export = dir.resolve("reviews.aqua-export")
    val diagnostic = RecoveryReportCatalogDiagnostic("report-62", 100, listOf(
        RecoveryReportCatalogFinding("report-62", "CSV_MISSING", RecoveryReportFindingSeverity.ERROR,
            "CSV missing", "Restore from trusted backup")
    ))
    val plan = RecoveryReportRepairPlanner.create(diagnostic)
    val journal = RecoveryReportRepairReviewJournal(source)
    journal.record(plan, "operator", true, 110)
    val original = Files.readAllBytes(source)
    val exported = RecoveryReportRepairReviewJournalExport.export(source, export)
    check(exported.valid && exported.receiptCount == 1)
    check(Files.readAllBytes(source).contentEquals(original))
    val verified = RecoveryReportRepairReviewJournalExport.verify(export)
    check(verified.valid && verified.lastHash == journal.all().last().receiptHash)
    Files.delete(source)
    check(RecoveryReportRepairReviewJournalExport.verify(export).valid)
    val tampered = Files.readAllLines(export).toMutableList()
    tampered[4] = tampered[4].dropLast(2) + "AA"
    Files.write(export, tampered)
    check(!RecoveryReportRepairReviewJournalExport.verify(export).valid)
    check(runCatching { RecoveryReportRepairReviewJournalExport.export(source, export) }.isFailure)
    println("STEP62_RECOVERY_REPORT_REPAIR_REVIEW_EXPORT_PASS")
}
