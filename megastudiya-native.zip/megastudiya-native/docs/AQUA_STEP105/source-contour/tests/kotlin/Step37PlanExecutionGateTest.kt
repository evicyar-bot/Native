import aqua.planning.*
import aqua.planning.storage.*
import aqua.planning.gate.*

fun main() {
    val draft = PlanStepDraft("s1", "Inspect", "Inspection report", listOf("Report exists"), riskNotes=listOf("May miss issues"))
    val plan = TaskPlan("task-1", "Review system", listOf("No network"), listOf(PlannedStep(1,draft)), listOf("Report accepted"), emptyList(), emptyList(), emptyList(), PlanStatus.READY)
    val saved = StoredTaskPlan("plan-1", plan, 2, StoredPlanStatus.APPROVED, 1000, listOf(PlanStatusChange(StoredPlanStatus.APPROVED,1500,"Owner approved")))
    val gate = PlanExecutionGate()
    val good = PlanGateReview("owner", 2000, true, true, "Reviewed scope and risks")
    check(gate.evaluate(saved, good).allowed)
    check(!gate.evaluate(saved, good.copy(constraintsAcknowledged=false)).allowed)
    check(!gate.evaluate(saved.copy(status=StoredPlanStatus.SAVED), good).allowed)
    check(!gate.evaluate(saved.copy(plan=plan.copy(status=PlanStatus.NEEDS_REVIEW)), good).allowed)
    check(!gate.evaluate(saved.copy(status=StoredPlanStatus.ARCHIVED), good).allowed)
    check(gate.evaluate(saved, good).status == PlanGateStatus.READY_FOR_HANDOFF)
    println("STEP37_PLAN_EXECUTION_GATE_PASS")
}
