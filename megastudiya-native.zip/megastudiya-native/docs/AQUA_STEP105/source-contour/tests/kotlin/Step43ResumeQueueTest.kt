import aqua.orchestration.*
import aqua.execution.*
fun main() {
 val ledger = ExecutionLedger("p",1,listOf(StepExecution("a",StepExecutionStatus.SUCCEEDED),StepExecution("b",StepExecutionStatus.PENDING),StepExecution("c",StepExecutionStatus.INTERRUPTED)),createdAtEpochMs=10)
 val session=OrchestrationSessionState("s","fp",emptyMap(),false,"head",20)
 val plan=listOf(OrchestrationStep("a","read",ActionRisk.LOW),OrchestrationStep("b","read",ActionRisk.LOW, listOf("a")),OrchestrationStep("c","write",ActionRisk.HIGH))
 val queue=ResumeQueuePlanner().build("fp",plan,ledger,session)
 check(queue.items[0].disposition==ResumeDisposition.ALREADY_COMPLETED)
 check(queue.items[1].disposition==ResumeDisposition.QUEUED)
 check(queue.items[2].disposition==ResumeDisposition.NEEDS_RECONCILIATION)
 check(queue.requiresOwnerReview)
 val stopped=ResumeQueuePlanner().build("fp",plan,ledger,session.copy(stopRequested=true))
 check(stopped.items.all{it.disposition==ResumeDisposition.STOPPED})
 println("STEP43_RESUME_QUEUE_PASS")
}
