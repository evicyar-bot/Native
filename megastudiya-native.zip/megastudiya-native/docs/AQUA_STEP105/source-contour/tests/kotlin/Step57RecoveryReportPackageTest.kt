package aqua.orchestration

import java.nio.file.Files

fun main() {
    val root = Files.createTempDirectory("aqua-step57")
    val receipts = listOf(RecoveryAuditReceipt("r-57", 570, "archive-57", "b".repeat(64),
        OwnerRecoveryDecision.APPROVED, RecoveryOutcome.COMPLETED, 3, 0, 0))
    val store = RecoveryAuditReceiptStore(); receipts.forEach(store::append)
    val filter = RecoveryAuditFilter(decision = OwnerRecoveryDecision.APPROVED)
    val report = store.query(filter, 600)
    val csv = root.resolve("report.csv"); val manifest = root.resolve("report.manifest")
    val pack = RecoveryReportPackage()
    pack.create(report, filter, receipts, csv, manifest)
    check(pack.verify(csv, manifest, report, filter, receipts).status == RecoveryReportPackageStatus.VALID)
    check(pack.verify(csv, manifest, report, filter, emptyList()).status == RecoveryReportPackageStatus.STALE)
    Files.writeString(csv, Files.readString(csv) + "tampered\n")
    check(pack.verify(csv, manifest, report, filter, receipts).status == RecoveryReportPackageStatus.INVALID)
    Files.delete(csv)
    check(pack.verify(csv, manifest, report, filter, receipts).status == RecoveryReportPackageStatus.INVALID)
    println("STEP57_RECOVERY_REPORT_PACKAGE_PASS")
}
