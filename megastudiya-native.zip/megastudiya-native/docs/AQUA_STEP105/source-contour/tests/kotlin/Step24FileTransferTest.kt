import aqua.dataformat.*
import aqua.research.*
import java.nio.file.Files

fun main() {
    val dir=Files.createTempDirectory("aqua-step24")
    val file=dir.resolve("research.aqua.json")
    val source=EvidenceSource(SourceId("s"),TaskId("t"),"Title","https://example.net", "q", 1, SourceReview.REVIEWED)
    val claim=Claim(ClaimId("c"),TaskId("t"),"Claim with \"quotes\" and newline\n",ClaimType.HYPOTHESIS,setOf(source.id),"key",2,ClaimReview.INCONCLUSIVE,"review")
    val decision=ResearchDecision(DecisionId("d"),TaskId("t"),"Decision","Pick","Because",CriterionId("criterion"),claim.id,"Other",3,4,listOf(DecisionRevision("Old","Old rationale","revised",3)),DecisionStatus.ACTIVE)
    val bundle=ResearchBundle(1,99,listOf(source),listOf(claim),listOf(decision))
    val exported=ResearchBundleFileTransfer.export(bundle,file)
    check(Files.exists(file)); check(exported.bytes>0); check(!exported.backupCreated)
    val imported=ResearchBundleFileTransfer.import(file) as BundleImportResult.Accepted
    check(imported.bundle.sources==listOf(source)); check(imported.bundle.claims==listOf(claim)); check(imported.bundle.decisions==listOf(decision))
    ResearchBundleFileTransfer.export(bundle.copy(exportedAtEpochMs=100),file)
    check(Files.exists(file.resolveSibling("research.aqua.json.bak")))
    Files.write(file,"{broken".toByteArray()); check(ResearchBundleFileTransfer.import(file) is BundleImportResult.Rejected)
    check(ResearchBundleFileTransfer.restoreBackup(file)); check(ResearchBundleFileTransfer.import(file) is BundleImportResult.Accepted)
    Files.write(file,"{} trailing".toByteArray()); check(ResearchBundleFileTransfer.import(file) is BundleImportResult.Rejected)
    check(runCatching { ResearchBundleJsonCodec.decode(ByteArray(ResearchBundleJsonCodec.MAX_BYTES+1)) }.isFailure)
    println("Step24: 7 checks PASS")
}
