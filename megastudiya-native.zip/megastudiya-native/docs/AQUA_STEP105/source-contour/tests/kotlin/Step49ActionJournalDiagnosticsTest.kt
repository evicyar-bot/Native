import aqua.orchestration.*

fun main() {
    val memory = InMemoryActionResultJournal()
    val bounded = PolicyBoundActionResultJournal(memory, ActionJournalPolicy(maxEntries = 2, maxEstimatedBytes = 4096, warningRatio = 0.5))
    val empty = bounded.diagnostics()
    check(empty.health == ActionJournalHealth.HEALTHY)
    check(empty.entries == 0 && empty.warnings.any { it.contains("no action results") })

    fun result(id: String) = ActionResult(id, "research.read", ActionStatus.ACCEPTED_FOR_SIMULATION,
        "DRY_RUN_ACCEPTED", "Validated; no action was executed", id.padEnd(64, '0'))
    bounded.append(result("one"))
    check(bounded.diagnostics().health == ActionJournalHealth.NEAR_CAPACITY)
    bounded.append(result("two"))
    val full = bounded.diagnostics()
    check(full.health == ActionJournalHealth.CAPACITY_REACHED)
    check(full.entries == 2)
    var blocked = false
    try { bounded.append(result("three")) } catch (_: IllegalArgumentException) { blocked = true }
    check(blocked)
    check(bounded.snapshot().map { it.requestId } == listOf("one", "two"))
    bounded.append(result("two"))
    check(bounded.snapshot().size == 2)
    println("STEP49_ACTION_JOURNAL_DIAGNOSTICS_PASS")
}
