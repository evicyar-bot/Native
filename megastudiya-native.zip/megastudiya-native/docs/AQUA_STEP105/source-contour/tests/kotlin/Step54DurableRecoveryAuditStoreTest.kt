import aqua.orchestration.*
import java.nio.file.Files

fun main() {
    val dir = Files.createTempDirectory("aqua-step54")
    val file = dir.resolve("recovery-audit.log")
    val receipt = RecoveryAuditReceipt("receipt-1", 1730000000000, "archive-1", "a".repeat(64),
        OwnerRecoveryDecision.APPROVED, RecoveryOutcome.COMPLETED, 3, 1, 0)
    val first = DurableRecoveryAuditStore(file)
    first.append(receipt)
    first.append(receipt)
    check(first.snapshot() == listOf(receipt) && first.verifyIntegrity())
    val restored = DurableRecoveryAuditStore(file)
    check(restored.snapshot() == listOf(receipt) && restored.verifyIntegrity())
    var conflict = false
    try { restored.append(receipt.copy(outcome = RecoveryOutcome.PARTIAL)) }
    catch (_: IllegalArgumentException) { conflict = true }
    check(conflict)
    Files.writeString(file, Files.readString(file).replace("|COMPLETED|", "|PARTIAL|"))
    var corruptRejected = false
    try { DurableRecoveryAuditStore(file) } catch (_: IllegalArgumentException) { corruptRejected = true }
    check(corruptRejected)
    println("STEP54_DURABLE_RECOVERY_AUDIT_PASS")
}
