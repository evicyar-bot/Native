import aqua.orchestration.*
import java.nio.file.Files

fun main() {
    val source = InMemoryActionResultJournal()
    val first = ActionResult("export-1", "research.read", ActionStatus.ACCEPTED_FOR_SIMULATION,
        "DRY_RUN_ACCEPTED", "Simulation only", "a".repeat(64))
    val second = ActionResult("export-2", "research.read", ActionStatus.DENIED,
        "ACTION_DISABLED", "Not executed", "b".repeat(64))
    source.append(first)
    source.append(second)
    val before = source.snapshot()
    val dir = Files.createTempDirectory("aqua-step50-")
    val archive = dir.resolve("actions.export")
    val exported = ActionJournalExport.export(source, archive)
    check(exported.valid && exported.recordCount == 2)
    check(source.snapshot() == before) { "Export must not mutate source journal" }
    val verified = ActionJournalExport.verify(archive)
    check(verified.valid && verified.records == before && verified.sha256 == exported.sha256)

    val originalArchive = Files.readString(archive)
    val mutationIndex = originalArchive.indexOf('\n') + 2
    val changedChar = if (originalArchive[mutationIndex] == 'A') 'B' else 'A'
    Files.writeString(archive, originalArchive.substring(0, mutationIndex) + changedChar + originalArchive.substring(mutationIndex + 1))
    val tampered = ActionJournalExport.verify(archive)
    check(!tampered.valid && tampered.records.isEmpty())

    val emptyArchive = dir.resolve("empty.export")
    val emptyExport = ActionJournalExport.export(InMemoryActionResultJournal(), emptyArchive)
    check(emptyExport.recordCount == 0 && ActionJournalExport.verify(emptyArchive).valid)
    println("STEP50_ACTION_JOURNAL_EXPORT_PASS")
}
