import aqua.orchestration.*

fun main() {
    val orchestrator = ExecutionOrchestrator()
    val plan = listOf(
        OrchestrationStep("a", "read", ActionRisk.LOW),
        OrchestrationStep("b", "write", ActionRisk.HIGH, listOf("a")),
        OrchestrationStep("c", "unknown", ActionRisk.LOW, listOf("a"))
    )
    val policy = OrchestrationPolicy(setOf("read", "write"), ownerApprovedActionKeys = emptySet())
    val result = orchestrator.simulate(plan, policy)
    check(result.decisions["a"] == ActionDecision.SIMULATE_READY)
    check(result.decisions["b"] == ActionDecision.REQUIRES_OWNER_APPROVAL)
    check(result.decisions["c"] == ActionDecision.BLOCKED_POLICY)
    val stopped = orchestrator.simulate(plan, policy, stopRequested = true)
    check(stopped.stopped && stopped.decisions.values.all { it == ActionDecision.STOPPED })
    check(runCatching { OrchestrationPolicy(setOf("x"), dryRun = false) }.isFailure)
    check(runCatching { orchestrator.simulate(listOf(OrchestrationStep("x", "a", ActionRisk.LOW, listOf("y"))), policy) }.isFailure)
    println("STEP40_ORCHESTRATOR_PASS")
}
