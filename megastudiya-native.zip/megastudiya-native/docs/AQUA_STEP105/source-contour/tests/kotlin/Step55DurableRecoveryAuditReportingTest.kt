import aqua.orchestration.*
import java.nio.file.Files

fun main() {
    val dir = Files.createTempDirectory("aqua-step55-")
    val journal = dir.resolve("recovery-audit.log")
    val csv = dir.resolve("report.csv")
    val hash = "a".repeat(64)
    val first = RecoveryAuditReceipt("r1", 100L, "archive-A", hash,
        OwnerRecoveryDecision.APPROVED, RecoveryOutcome.COMPLETED, 3, 0, 0)
    val second = RecoveryAuditReceipt("r2", 200L, "archive-B", hash,
        OwnerRecoveryDecision.REJECTED, RecoveryOutcome.REJECTED, 0, 2, 1)

    DurableRecoveryAuditStore(journal).also { it.append(first); it.append(second) }
    // A fresh instance simulates process restart; reporting reads the durable source.
    val restored = DurableRecoveryAuditStore(journal)
    check(restored.verifyIntegrity())
    val reporting = DurableRecoveryAuditReporting(restored)
    val all = reporting.query(generatedAtMillis = 500L)
    check(all.totalMatched == 2 && all.approved == 1 && all.rejected == 1)
    check(all.receipts.map { it.receiptId } == listOf("r1", "r2"))

    val filtered = reporting.query(RecoveryAuditFilter(archiveId = "archive-A"), 501L)
    check(filtered.totalMatched == 1 && filtered.receipts.single() == first)
    val repeat = reporting.query(RecoveryAuditFilter(archiveId = "archive-A"), 501L)
    check(filtered.sha256 == repeat.sha256)
    check(reporting.exportCsv(RecoveryAuditFilter(outcome = RecoveryOutcome.COMPLETED), 502L, csv).totalMatched == 1)
    check(Files.readString(csv).contains("r1"))
    check(restored.snapshot().size == 2) // Reporting/export did not mutate the source.
    println("STEP55_DURABLE_RECOVERY_AUDIT_REPORTING_PASS")
}
