package aqua.orchestration

import java.nio.file.Files

fun main() {
    val directory = Files.createTempDirectory("aqua-step61-")
    val journalPath = directory.resolve("repair-reviews.log")
    val diagnostic = RecoveryReportCatalogDiagnostic("report-61", 100, listOf(
        RecoveryReportCatalogFinding("report-61", "CSV_MISSING", RecoveryReportFindingSeverity.ERROR,
            "CSV missing", "Restore from trusted backup")
    ))
    val plan = RecoveryReportRepairPlanner.create(diagnostic)
    val journal = RecoveryReportRepairReviewJournal(journalPath)
    check(runCatching { journal.record(plan, "operator", false, 110) }.isFailure)
    val first = journal.record(plan, "operator A", true, 110)
    check(first.sequence == 1L && !first.review.executionAllowed)
    check(journal.history("report-61").size == 1)
    check(journal.verify().valid && journal.verify().receiptCount == 1)

    val reopened = RecoveryReportRepairReviewJournal(journalPath)
    check(reopened.all() == listOf(first))
    val second = reopened.record(plan, "operator B", true, 120)
    check(second.sequence == 2L && second.previousHash == first.receiptHash)
    check(RecoveryReportRepairReviewJournal(journalPath).all().size == 2)

    val original = Files.readAllLines(journalPath)
    val tampered = original.toMutableList()
    tampered[1] = tampered[1].dropLast(1) + (if (tampered[1].last() == '0') "1" else "0")
    Files.write(journalPath, tampered)
    check(runCatching { RecoveryReportRepairReviewJournal(journalPath) }.isFailure)
    println("STEP61_RECOVERY_REPORT_REPAIR_REVIEW_JOURNAL_PASS")
}
