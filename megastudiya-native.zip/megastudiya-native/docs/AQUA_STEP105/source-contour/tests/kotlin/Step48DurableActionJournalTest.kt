import aqua.orchestration.*
import java.nio.file.Files

fun main() {
    val dir = Files.createTempDirectory("aqua-step48-")
    val journalPath = dir.resolve("actions.journal")
    val catalog = ActionCatalog(listOf(ActionDefinition("research.read", "Read an allowed public resource",
        listOf(ActionArgument("url", true, 2048)), "research.read", ActionRisk.LOW)))
    val request = ActionRequest("persist-1", "research.read", mapOf("url" to "https://example.org"), setOf("research.read"))
    val first = ActionApi(catalog, journal = DurableActionResultJournal(journalPath))
    val original = first.submit(request)
    check(original.status == ActionStatus.ACCEPTED_FOR_SIMULATION)
    check(Files.exists(journalPath))

    val restarted = ActionApi(catalog, journal = DurableActionResultJournal(journalPath))
    check(restarted.resultFor("persist-1") == original)
    check(restarted.submit(request) == original)
    check(restarted.submit(request.copy(arguments = mapOf("url" to "https://other.example"))).code == "REQUEST_ID_CONFLICT")
    check(restarted.auditSnapshot().size == 1)

    val validJournal = Files.readString(journalPath)
    val tampered = validJournal.dropLast(2) + (if (validJournal[validJournal.length - 2] == 'a') "b" else "a") + "\n"
    Files.writeString(journalPath, tampered)
    var rejected = false
    try { DurableActionResultJournal(journalPath) } catch (_: IllegalArgumentException) { rejected = true }
    check(rejected) { "Tampered journal must fail closed" }

    val emptyPath = dir.resolve("nested/empty.journal")
    val empty = DurableActionResultJournal(emptyPath)
    check(empty.snapshot().isEmpty())
    println("STEP48_DURABLE_ACTION_JOURNAL_PASS")
}
