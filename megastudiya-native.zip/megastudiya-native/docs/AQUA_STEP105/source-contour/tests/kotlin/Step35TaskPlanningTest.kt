package aqua.tests
import aqua.experience.*
import aqua.planning.*
object Step35TaskPlanningTest {
 @JvmStatic fun main(args:Array<String>) {
  val context=TaskContextPackage("t35","Prepare a research report",listOf("cite sources"),listOf(TaskContextMemory("m1","prior source validation","HIGH_SUCCESS","CONFIRMED",90,80,listOf("ev1"),listOf("source"),"")),emptyList(),"context",false)
  val draft=TaskPlanDraft(listOf(
   PlanStepDraft("write","Draft report","Draft exists",listOf("sections complete"),listOf("research"),listOf("citation quality")),
   PlanStepDraft("research","Collect sources","Source list",listOf("3 reliable sources"),riskNotes=listOf("source availability"))),listOf("Report is complete","Claims are cited"))
  val planner=TaskPlanner(); check(planner.validate(draft).valid)
  val plan=planner.create(context,draft)
  check(plan.steps.map{it.draft.id}==listOf("research","write")); check(plan.status==PlanStatus.READY); check(plan.contextMemoryIds==listOf("m1"))
  val cyclic=TaskPlanDraft(listOf(PlanStepDraft("a","A","A",listOf("done"),listOf("b")),PlanStepDraft("b","B","B",listOf("done"),listOf("a"))),listOf("done"))
  check(!planner.validate(cyclic).valid && planner.create(context,cyclic).status==PlanStatus.INVALID)
  val incomplete=TaskPlanDraft(listOf(PlanStepDraft("only","Do","Done",listOf("check"))),listOf("done"))
  check(planner.validate(incomplete).warnings.isNotEmpty())
  println("STEP35_TASK_PLANNING_PASS")
 }
}
