package aqua.orchestration

import java.nio.file.Files

fun main() {
    val root = Files.createTempDirectory("aqua-step56")
    val source = listOf(RecoveryAuditReceipt("r-1", 100, "archive-A", "a".repeat(64),
        OwnerRecoveryDecision.APPROVED, RecoveryOutcome.COMPLETED, 2, 0, 0))
    val store = RecoveryAuditReceiptStore()
    source.forEach(store::append)
    val filter = RecoveryAuditFilter(decision = OwnerRecoveryDecision.APPROVED)
    val report = store.query(filter, 200)
    val provenance = RecoveryReportProvenance()
    val manifest = provenance.create(report, filter, source)
    check(provenance.verify(manifest, report, filter, source))
    val path = root.resolve("report.manifest")
    provenance.write(manifest, path)
    val reopened = provenance.read(path)
    check(provenance.verify(reopened, report, filter, source))
    check(!provenance.verify(reopened, report, RecoveryAuditFilter(), source))
    check(!provenance.verify(reopened, report, filter, emptyList()))
    val alteredReport = report.copy(totalMatched = 9)
    check(!provenance.verify(reopened, alteredReport, filter, source))
    val alteredLines = Files.readAllLines(path).toMutableList()
    alteredLines[6] = alteredLines[6].dropLast(1) + if (alteredLines[6].last() == '0') "1" else "0"
    Files.write(path, alteredLines)
    // Tampering with any persisted field must make the manifest unreadable or unverifiable.
    check(runCatching { provenance.read(path) }.isFailure)
    println("STEP56_RECOVERY_REPORT_PROVENANCE_PASS")
}
