import aqua.orchestration.*
import java.io.File
fun main() {
 val audit=OrchestrationAudit(); audit.append("s1","stepA","research",ActionDecision.SIMULATE_READY,"dry run")
 audit.append("s1","stepB","send",ActionDecision.REQUIRES_OWNER_APPROVAL,"approval needed")
 check(audit.verify()); check(audit.snapshot().size==2)
 val f=File("/tmp/aqua-step41-audit.txt"); audit.save(f)
 val restored=OrchestrationAudit(); restored.load(f); check(restored.verify()); check(restored.snapshot()==audit.snapshot())
 f.writeText("AQUA_AUDIT_V1\ncorrupt\n"); var rejected=false; try { restored.load(f) } catch (_:Exception) { rejected=true }; check(rejected)
 println("STEP41_AUDIT_PASS")
}
