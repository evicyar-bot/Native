import aqua.orchestration.*
import java.nio.file.Files

fun main() {
    val source = InMemoryActionResultJournal()
    fun result(id: String, message: String = "Simulation only") = ActionResult(id, "research.read",
        ActionStatus.ACCEPTED_FOR_SIMULATION, "DRY_RUN_ACCEPTED", message, id.padEnd(64, '0'))
    source.append(result("restore-a")); source.append(result("restore-b"))
    val archive = Files.createTempDirectory("aqua-step51-").resolve("source.export")
    ActionJournalExport.export(source, archive)

    val target = InMemoryActionResultJournal()
    target.append(result("restore-a")) // identical duplicate
    val plan = ActionJournalRestore.preview(archive, target)
    check(plan.valid && plan.importableCount == 1 && plan.conflictCount == 0)
    check(plan.items.count { it.disposition == RestoreDisposition.IDENTICAL_DUPLICATE } == 1)
    check(target.snapshot().size == 1) { "Preview must be read-only" }
    val denied = ActionJournalRestore.apply(plan, target, ownerApproved = false)
    check(!denied.applied && target.snapshot().size == 1)
    val applied = ActionJournalRestore.apply(plan, target, ownerApproved = true)
    check(applied.applied && applied.imported == 1 && applied.skippedDuplicates == 1)
    check(target.snapshot().size == 2)

    val conflictTarget = InMemoryActionResultJournal()
    conflictTarget.append(result("restore-a", "Different payload"))
    val conflictPlan = ActionJournalRestore.preview(archive, conflictTarget)
    check(conflictPlan.conflictCount == 1)
    val conflictResult = ActionJournalRestore.apply(conflictPlan, conflictTarget, true)
    check(!conflictResult.applied && conflictTarget.snapshot().size == 1)

    val staleTarget = InMemoryActionResultJournal()
    val stalePlan = ActionJournalRestore.preview(archive, staleTarget)
    staleTarget.append(result("concurrent-change"))
    check(!ActionJournalRestore.apply(stalePlan, staleTarget, true).applied)
    println("STEP51_ACTION_JOURNAL_RESTORE_PASS")
}
