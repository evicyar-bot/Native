import aqua.orchestration.*
import java.nio.file.Files

fun main() {
    val store = RecoveryAuditReceiptStore()
    val hash = "a".repeat(64)
    store.append(RecoveryAuditReceipt("r1", 100, "archive-A", hash, OwnerRecoveryDecision.APPROVED, RecoveryOutcome.COMPLETED, 3, 1, 0))
    store.append(RecoveryAuditReceipt("r2", 200, "archive-B", hash, OwnerRecoveryDecision.REJECTED, RecoveryOutcome.REJECTED, 0, 0, 0))
    store.append(RecoveryAuditReceipt("r3", 300, "archive-A", hash, OwnerRecoveryDecision.APPROVED, RecoveryOutcome.PARTIAL, 1, 1, 1))
    val filtered = store.query(RecoveryAuditFilter(fromMillis = 150, throughMillis = 350, archiveId = "archive-A"), 400)
    check(filtered.totalMatched == 1 && filtered.receipts.single().receiptId == "r3")
    check(filtered.approved == 1 && filtered.partial == 1 && filtered.sha256.length == 64)
    val rejected = store.query(RecoveryAuditFilter(decision = OwnerRecoveryDecision.REJECTED), 401)
    check(rejected.totalMatched == 1 && rejected.rejected == 1)
    val before = store.snapshot()
    val file = Files.createTempFile("aqua-step53", ".csv")
    store.exportCsv(filtered, file)
    val csv = Files.readString(file)
    check(csv.contains("receipt_id") && csv.contains("r3"))
    check(store.snapshot() == before)
    Files.deleteIfExists(file)
    println("STEP53_RECOVERY_AUDIT_QUERY_PASS")
}
