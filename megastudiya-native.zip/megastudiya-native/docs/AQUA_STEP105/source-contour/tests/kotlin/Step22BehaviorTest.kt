import aqua.adapters.memory.*
import aqua.research.*

fun main() {
    val taskA = TaskId("A"); val taskB = TaskId("B")
    val evidenceRepo = InMemoryEvidenceRepository()
    val claimRepo = InMemoryClaimRepository()
    val decisionRepo = InMemoryDecisionRepository()
    val evidence = EvidenceService(evidenceRepo)
    val claims = ClaimService(claimRepo, evidenceRepo)
    val decisions = DecisionService(decisionRepo, claimRepo)

    val sourceA = EvidenceSource(SourceId("S1"), taskA, "source", "https://example.org", capturedAtEpochMs = 1)
    val sourceB = EvidenceSource(SourceId("S2"), taskB, "source", "https://example.org", capturedAtEpochMs = 2)
    check(evidence.register(sourceA)); check(evidence.register(sourceB))
    check(evidence.sources(taskA).size == 1 && evidence.sources(taskB).size == 1)
    check(!evidenceRepo.upsert(sourceA.copy(taskId = taskB))) // same ID cannot migrate task

    val claimA = Claim(ClaimId("C1"), taskA, "claim", ClaimType.FACT, setOf(SourceId("S1")), createdAtEpochMs = 3)
    check(claims.register(claimA))
    val foreignClaim = claimA.copy(id = ClaimId("C2"), evidenceSourceIds = setOf(SourceId("S2")))
    check(!claims.register(foreignClaim)) // foreign evidence rejected
    check(claims.review(ClaimId("C1"), ClaimReview.SUPPORTED, "checked"))
    check(claims.claims(taskA).single().review == ClaimReview.SUPPORTED)
    check(!claimRepo.upsert(claimA.copy(taskId = taskB))) // ID cannot migrate task

    val decision = ResearchDecision(DecisionId("D1"), taskA, "title", "initial", "reason", claimId = ClaimId("C1"), createdAtEpochMs = 4, updatedAtEpochMs = 4)
    check(decisions.register(decision))
    val crossTaskDecision = decision.copy(id = DecisionId("D2"), taskId = taskB, claimId = ClaimId("C1"))
    check(!decisions.register(crossTaskDecision))
    check(decisions.revise(DecisionId("D1"), "updated", "new rationale", "why changed", 5))
    val revised = decisionRepo.find(DecisionId("D1"))!!
    check(revised.decision == "updated" && revised.history.size == 1)
    check(revised.history.single().decision == "initial" && revised.history.single().rationale == "reason")
    check(!decisions.revise(DecisionId("D1"), " ", "bad", "", 6))
    check(decisions.setStatus(DecisionId("D1"), DecisionStatus.REVERSED, 7))
    check(decisionRepo.find(DecisionId("D1"))!!.status == DecisionStatus.REVERSED)

    check(evidence.removeTask(taskA) == 1)
    check(claims.removeTask(taskA) == 1)
    check(decisions.removeTask(taskA) == 1)
    check(evidence.sources(taskA).isEmpty() && evidence.sources(taskB).size == 1)
    check(claims.claims(taskA).isEmpty() && decisions.decisions(taskA).isEmpty())
    println("Step22 behavior: PASS (CRUD, task isolation, reference guards, review, revisions, cleanup)")
}
