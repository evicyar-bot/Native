package aqua.tests
import aqua.adapters.memory.InMemoryExperienceMemory
import aqua.experience.*
object Step33ExperienceRetrievalTest {
 @JvmStatic fun main(args: Array<String>) {
  val repo = InMemoryExperienceMemory()
  val fail = ExperienceInsight(ExperienceId("f"), ExperienceKind.FAILURE_PATTERN, "Repeated timeout on network research", setOf("e1","e2"),2,60, createdAtEpochMs=1)
  val good = ExperienceInsight(ExperienceId("g"), ExperienceKind.HIGH_SUCCESS_SIGNAL, "Successful file analysis workflow", setOf("e3"),5,80, ExperienceReviewStatus.CONFIRMED,2)
  val rejected = fail.copy(id=ExperienceId("r"), statement="timeout network research", reviewStatus=ExperienceReviewStatus.REJECTED)
  repo.save(fail); repo.save(good); repo.save(rejected)
  val svc = ExperienceRetrievalService(repo)
  val ctx=svc.retrieve(ExperienceQuery("network research timeout",maxResults=4))
  check(ctx.retrieved.first().insight.id==fail.id)
  check(ctx.retrieved.none { it.insight.id==rejected.id })
  check(ctx.retrieved.first().matchedTerms.containsAll(setOf("network","research","timeout")))
  check(ctx.retrieved.first().caution.contains("Unreviewed"))
  check(svc.retrieve(ExperienceQuery("network research",includeUnreviewed=false)).retrieved.isEmpty())
  check(svc.retrieve(ExperienceQuery("file analysis", kinds=setOf(ExperienceKind.HIGH_SUCCESS_SIGNAL))).retrieved.single().insight.id==good.id)
  check(svc.retrieve(ExperienceQuery("timeout",minimumConfidence=70)).retrieved.isEmpty())
  check(svc.retrieve(ExperienceQuery("irrelevant words",maxResults=1)).retrieved.isEmpty())
  println("STEP33_EXPERIENCE_RETRIEVAL_PASS")
 }
}
