import aqua.execution.*
import java.io.File

fun main() {
    val dir = File(System.getProperty("java.io.tmpdir"), "aqua-step39-${System.nanoTime()}").apply { mkdirs() }
    val store = DurableExecutionLedgerStore(File(dir, "ledger.dat"))
    val service = ExecutionLedgerService()
    var ledger = service.create("plan-1", 1, listOf("step-a", "step-b"), 100)
    ledger = service.transition(ledger, "step-a", StepExecutionStatus.READY, 110, "e1")
    ledger = service.transition(ledger, "step-a", StepExecutionStatus.RUNNING, 120, "e2")
    ledger = service.checkpoint(ledger, "step-a", "checkpoint-1", 130, "e3")
    store.save(ledger)
    val loaded = store.load() ?: error("missing saved ledger")
    check(loaded == ledger) { "restart load must exactly preserve ledger" }
    val recovered = store.recoverAfterRestart(200) ?: error("recovery failed")
    check(recovered.steps.first().status == StepExecutionStatus.INTERRUPTED)
    check(recovered.steps.first().checkpoint == "checkpoint-1")
    check(recovered.events.last().type == ExecutionEventType.INTERRUPTED)
    check(recovered.steps.first().attempts == 1) { "must not auto-retry" }
    val approved = store.resolveInterrupted("step-a", StepExecutionStatus.READY, 210, "e4", "Reviewed and approved to resume")
    check(approved.steps.first().status == StepExecutionStatus.READY)
    check(store.load() == approved) { "resolution must persist" }
    val bytes = File(dir, "ledger.dat").readText()
    File(dir, "ledger.dat").writeText(bytes.replaceFirst(Regex("(?<=\\t)[0-9a-f]"), "0"))
    var checksumRejected = false
    try { store.load() } catch (_: IllegalArgumentException) { checksumRejected = true }
    check(checksumRejected) { "corruption must be rejected" }
    dir.deleteRecursively()
    println("STEP39_DURABLE_EXECUTION_LEDGER_PASS")
}
