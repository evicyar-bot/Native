import aqua.orchestration.*

fun main() {
    val queue = FrozenResumeQueue("plan-A", "queue-A", listOf(ResumeQueueItem("s1", ResumeDisposition.QUEUED, "eligible")), false)
    val approval = ResumeApprovalRecord("plan-A", "queue-A", "owner", ResumeApprovalDecision.APPROVE, 123L, "reviewed")
    fun req() = PreflightRequest("plan-A", queue, approval, true, true, 1, 2, 10, 20, false, true)
    val good = PreflightGate.evaluate(req())
    check(good.outcome == PreflightOutcome.READY_FOR_SIMULATION && good.failed.isEmpty())
    check(PreflightGate.evaluate(req().copy(stopped = true)).outcome == PreflightOutcome.BLOCKED)
    check(PreflightGate.evaluate(req().copy(permissionsSatisfied = false)).outcome == PreflightOutcome.BLOCKED)
    check(PreflightGate.evaluate(req().copy(estimatedBudget = 21)).outcome == PreflightOutcome.BLOCKED)
    check(PreflightGate.evaluate(req().copy(riskLevel = 3)).outcome == PreflightOutcome.BLOCKED)
    check(PreflightGate.evaluate(req().copy(approval = null)).outcome == PreflightOutcome.BLOCKED)
    check(PreflightGate.evaluate(req().copy(simulationOnly = false)).outcome == PreflightOutcome.REQUIRES_OWNER_CONFIRMATION)
    println("STEP45_PREFLIGHT_GATE_PASS")
}
