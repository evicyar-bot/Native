package aqua.orchestration

import java.nio.file.Files

fun main() {
    val root = Files.createTempDirectory("aqua-step58")
    val csv = root.resolve("r.csv"); val manifest = root.resolve("r.manifest")
    Files.writeString(csv, "id,value\n1,ok\n"); Files.writeString(manifest, "manifest")
    Files.writeString(root.resolve("r.manifest.package"), "package")
    val journal = root.resolve("catalog.log")
    var catalog = RecoveryReportCatalog(journal)
    val registered = catalog.register("report-58", csv, manifest, 100)
    check(registered.lifecycle == RecoveryReportLifecycle.ACTIVE)
    catalog.recordVerification("report-58", RecoveryReportPackageStatus.VALID, 110)
    check(catalog.verificationHistory("report-58").size == 1)
    check(runCatching { catalog.archive("report-58", "operator", "retention", false, 120) }.isFailure)
    val archived = catalog.archive("report-58", "operator", "retention review", true, 130)
    check(archived.lifecycle == RecoveryReportLifecycle.ARCHIVED)
    check(Files.exists(csv) && Files.exists(manifest) && Files.exists(root.resolve("r.manifest.package")))
    catalog = RecoveryReportCatalog(journal)
    check(catalog.verifyJournal())
    check(catalog.get("report-58")?.archiveReason == "retention review")
    check(catalog.list(includeArchived = false).isEmpty())
    val tampered = Files.readString(journal) + "corrupt\n"
    Files.writeString(journal, tampered)
    check(runCatching { RecoveryReportCatalog(journal) }.isFailure)
    println("STEP58_RECOVERY_REPORT_CATALOG_PASS")
}
