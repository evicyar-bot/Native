import aqua.adapters.file.DurableResearchRepositories
import aqua.dataformat.FileDurableBundleStore
import aqua.dataformat.StoreSaveResult
import aqua.research.*
import java.nio.file.Files

fun main(){
 val root=Files.createTempDirectory("aqua-step26"); val store=FileDurableBundleStore(root); val repos=DurableResearchRepositories(store,"research",{1234L}); check(repos.initialize())
 val task=TaskId("taskA"); val source=EvidenceSource(SourceId("src1"),task,"Source","https://example.org",capturedAtEpochMs=10)
 check(repos.evidence.upsert(source)); val claim=Claim(ClaimId("claim1"),task,"Claim",ClaimType.FACT,setOf(source.id),createdAtEpochMs=11);check(repos.claim.upsert(claim)); val dec=ResearchDecision(DecisionId("dec1"),task,"Choice","Selected","Reason",claimId=claim.id,createdAtEpochMs=12,updatedAtEpochMs=12);check(repos.decision.upsert(dec))
 val restarted=DurableResearchRepositories(store,"research");check(restarted.initialize());check(restarted.evidence.list(task).size==1);check(restarted.claim.list(task).single().evidenceSourceIds==setOf(source.id));check(restarted.decision.list(task).single().claimId==claim.id)
 val wrong=Claim(ClaimId("bad"),TaskId("taskB"),"Cross task ref",ClaimType.FACT,setOf(source.id),createdAtEpochMs=13);check(!restarted.claim.upsert(wrong));check(restarted.claim.list().size==1)
 check(restarted.removeTask(task)==3);val after=DurableResearchRepositories(store,"research");check(after.initialize());check(after.evidence.list().isEmpty()&&after.claim.list().isEmpty()&&after.decision.list().isEmpty())
 println("Step26: 6 checks PASS")
}
