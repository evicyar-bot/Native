from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/OrchestrationAudit.kt'
def test_audit_records_are_hash_chained():
    s=SRC.read_text(); assert 'previousHash' in s and 'SHA-256' in s and 'verify()' in s
def test_audit_persistence_is_versioned_and_atomic():
    s=SRC.read_text(); assert 'AQUA_AUDIT_V1' in s and 'ATOMIC_MOVE' in s and 'load(file: File)' in s
def test_audit_is_recording_only():
    s=SRC.read_text(); assert 'Immutable audit record' in s and 'append(sessionId' in s
