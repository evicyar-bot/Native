from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairArchiveHealthAndQueue.kt"


def test_json_export_has_schema_and_false_execution_flag():
    text = SOURCE.read_text()
    assert 'schema":1' in text
    assert 'executable":false' in text
    assert 'health' in text

