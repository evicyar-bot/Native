from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairReviewJournal.kt"
TEST = ROOT / "tests/kotlin/Step61RecoveryReportRepairReviewJournalTest.kt"


def test_review_journal_is_append_only_and_hash_chained():
    source = SOURCE.read_text()
    assert "previousHash" in source and "receiptHash" in source
    assert "ATOMIC_MOVE" in source
    assert "Repair-review hash-chain mismatch" in source


def test_review_never_grants_execution_authority():
    source = SOURCE.read_text()
    assert "!review.executionAllowed" in source
    assert "No method in this class executes or authorizes a repair" in source


def test_restart_and_tamper_regression_are_present():
    test = TEST.read_text()
    assert "RecoveryReportRepairReviewJournal(journalPath)" in test
    assert "dropLast(1)" in test and "isFailure" in test
    assert "STEP61_RECOVERY_REPORT_REPAIR_REVIEW_JOURNAL_PASS" in test
