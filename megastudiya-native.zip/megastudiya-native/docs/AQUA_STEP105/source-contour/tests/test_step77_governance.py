from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryArchiveQueueGovernance.kt"
def test_canonicalization_has_stable_fields_and_escapes_delimiters():
    t = SOURCE.read_text()
    assert "canonicalItem" in t and "canonicalQueue" in t and "\\u001f" in t
