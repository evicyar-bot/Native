from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryArchiveQueueGovernance.kt"
def test_validator_rejects_bad_items_and_executable_flags():
    t = SOURCE.read_text()
    assert '"PRIORITY_RANGE"' in t and '"EXECUTABLE_FORBIDDEN"' in t and '"PATH_EMPTY"' in t
