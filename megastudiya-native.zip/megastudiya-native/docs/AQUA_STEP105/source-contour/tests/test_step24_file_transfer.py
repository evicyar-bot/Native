from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
def test_step24_compiles_and_runs():
    src=[str(p) for p in ROOT.rglob('*.kt')]
    jar=ROOT/'tests'/'step24-tests.jar'
    subprocess.run(['kotlinc',*src,'-include-runtime','-d',str(jar)],check=True,capture_output=True,text=True)
    run=subprocess.run(['java','-cp',str(jar),'Step24FileTransferTestKt'],check=True,capture_output=True,text=True)
    assert 'Step24: 7 checks PASS' in run.stdout
    jar.unlink(missing_ok=True)
def test_codec_and_file_transfer_present_and_host_independent():
    f=ROOT/'modules/aqua-data-format/src/main/kotlin/aqua/dataformat/ResearchBundleJson.kt'
    text=f.read_text()
    for term in ['ResearchBundleJsonCodec','decode(bytes','MAX_BYTES','ATOMIC_MOVE','restoreBackup','Duplicate key']:
        assert term in text
    assert 'android.' not in text and 'app.megastudiya' not in text
