from pathlib import Path
ROOT = Path(__file__).parents[1]
SRC = ROOT / "modules/aqua-history-analytics/src/main/kotlin/aqua/analytics/EventHistoryAnalytics.kt"

def test_analytics_is_read_only_and_uses_journal():
    s = SRC.read_text(); assert "journal.query" in s and "fun analyze" in s and "journal.append" not in s

def test_detects_repeated_failures():
    s = SRC.read_text(); assert "occurrences >= 2" in s and "normalizeReason" in s

def test_success_rates_exclude_nonterminal_events():
    s = SRC.read_text(); assert "it.outcome in TERMINAL" in s and "percent(ok, end.size)" in s

def test_task_recurrence_and_observations():
    s = SRC.read_text(); assert "eventCount >= 3" in s and "observations" in s

def test_scan_limit_is_bounded():
    s = SRC.read_text(); assert "limit in 1..5000" in s

def test_empty_history_handled():
    s = SRC.read_text(); assert "No events available" in s and "denominator == 0" in s
