from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairPlan.kt"
TEST = ROOT / "tests/kotlin/Step60RecoveryReportRepairPlanTest.kt"


def test_plan_is_advisory_and_has_no_filesystem_mutation():
    source = SOURCE.read_text()
    assert "object RecoveryReportRepairPlanner" in source
    assert "executionAllowed: Boolean = false" in source
    assert "no repair was executed" in source
    assert "Files.write" not in source and "Files.delete" not in source


def test_operator_confirmation_and_fingerprint_are_required():
    source = SOURCE.read_text()
    assert "require(confirmed)" in source
    assert "plan fingerprint mismatch" in source
    assert "reviewerLabel.isNotBlank()" in source


def test_executable_regression_covers_safe_review_boundary():
    test = TEST.read_text()
    assert "approvedForFutureExecution && !review.executionAllowed" in test
    assert "planFingerprint" in test
    assert "steps.isEmpty()" in test
