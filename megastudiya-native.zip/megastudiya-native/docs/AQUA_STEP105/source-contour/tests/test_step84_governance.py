from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryArchiveQueueGovernance.kt"
def test_export_manifest_requires_validation_and_has_digest():
    t = SOURCE.read_text()
    assert "Queue fails schema validation" in t and "contentDigest" in t and "executableItems" in t
