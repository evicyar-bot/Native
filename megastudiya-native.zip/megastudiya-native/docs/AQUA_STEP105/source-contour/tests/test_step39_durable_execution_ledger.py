from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
KOTLIN = ROOT / "modules/aqua-execution-ledger/src/main/kotlin/aqua/execution"


def test_durable_store_exists_and_checksums_snapshot():
    src = (KOTLIN / "DurableExecutionLedgerStore.kt").read_text()
    assert "AQUA_EXEC_LEDGER_V1" in src
    assert "SHA-256" in src
    assert "ATOMIC_MOVE" in src


def test_restart_marks_running_as_interrupted_not_replayed():
    src = (KOTLIN / "DurableExecutionLedgerStore.kt").read_text()
    assert "recoverAfterRestart" in src
    assert "StepExecutionStatus.INTERRUPTED" in src
    assert "manual reconciliation required" in src
    assert "resolveInterrupted" in src


def test_resume_requires_explicit_resolution():
    src = (KOTLIN / "DurableExecutionLedgerStore.kt").read_text()
    assert "target == StepExecutionStatus.READY || target == StepExecutionStatus.WAITING" in src


def test_ledger_state_machine_has_interrupted_state():
    src = (KOTLIN / "ExecutionLedger.kt").read_text()
    assert "INTERRUPTED" in src
    assert "StepExecutionStatus.INTERRUPTED -> to in setOf" in src
