from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/ActionJournalExport.kt").read_text()


def test_explicit_export_and_verification_api_exists():
    assert "fun export(journal: ActionResultJournal" in SOURCE
    assert "fun verify(archive: Path)" in SOURCE
    assert "AQUA_ACTION_EXPORT_V1" in SOURCE


def test_export_is_integrity_protected_and_atomic():
    assert "MessageDigest.getInstance(\"SHA-256\")" in SOURCE
    assert "AtomicMoveNotSupportedException" in SOURCE
    assert "Export digest mismatch" in SOURCE


def test_export_does_not_delete_or_mutate_source():
    assert "journal.snapshot()" in SOURCE
    assert "Files.delete(" not in SOURCE
    assert "journal.clear" not in SOURCE
