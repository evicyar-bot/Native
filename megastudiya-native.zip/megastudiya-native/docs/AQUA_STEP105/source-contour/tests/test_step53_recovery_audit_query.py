from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryAuditQuery.kt").read_text()


def test_receipt_filters_cover_requested_dimensions():
    for field in ("fromMillis", "throughMillis", "decision", "archiveId", "outcome"):
        assert f"val {field}:" in SOURCE


def test_report_has_counts_and_integrity_digest():
    for field in ("totalMatched", "approved", "rejected", "completed", "partial", "failed", "sha256"):
        assert field in SOURCE


def test_export_is_read_only_and_atomic():
    assert "fun exportCsv" in SOURCE
    assert "StandardCopyOption.ATOMIC_MOVE" in SOURCE
    assert "receipts.values.toList()" in SOURCE
    assert "receipts.clear" not in SOURCE and "receipts.remove" not in SOURCE
