from pathlib import Path
ROOT = Path(__file__).parents[1]
SRC = ROOT / "modules/aqua-adapters/file/src/main/kotlin/aqua/adapters/file/DurableResearchEventJournal.kt"

def test_durable_journal_replays_on_startup():
    s = SRC.read_text(); assert "replayAndRepair()" in s and "Files.readAllBytes(file)" in s

def test_append_forces_disk_before_publish():
    s = SRC.read_text(); assert "ch.force(true)" in s and s.index("ch.force(true)") < s.index("events += stored")

def test_records_are_checksummed():
    s = SRC.read_text(); assert "sha256(payload)" in s and "Journal checksum mismatch" in s

def test_torn_final_record_repair_only():
    s = SRC.read_text(); assert "validEnd != bytes.size" in s and "truncate(validEnd.toLong())" in s

def test_sequence_and_duplicate_integrity():
    s = SRC.read_text(); assert "Journal sequence gap" in s and "Duplicate event ID in journal" in s

def test_query_filters_and_task_scope_supported():
    s = SRC.read_text(); assert "query.taskId == null || it.taskId == query.taskId" in s and "query.afterSequence" in s
