from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryArchiveQueueImportBoundary.kt"

def test_step86_contract():
    text = SOURCE.read_text()
    assert "MAX_RECORDS" in text
