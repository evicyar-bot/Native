from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryArchiveQueueGovernance.kt"
def test_statistics_include_sorted_buckets_and_empty_safe_values():
    t = SOURCE.read_text()
    assert "bySeverity" in t and "byGroup" in t and "maxOfOrNull" in t
