from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/ExecutionOrchestrator.kt"

def test_orchestrator_is_dry_run_only():
    s = SRC.read_text()
    assert "dryRun: Boolean = true" in s
    assert "live mode is not supported" in s
    assert "no tools or external actions" in s

def test_allowlist_and_dependency_gate_exist():
    s = SRC.read_text()
    assert "allowedActionKeys" in s
    assert "BLOCKED_POLICY" in s and "BLOCKED_DEPENDENCY" in s

def test_owner_approval_for_high_risk():
    s = SRC.read_text()
    assert "REQUIRES_OWNER_APPROVAL" in s
    assert "ownerApprovedActionKeys" in s

def test_stop_and_cycle_validation():
    s = SRC.read_text()
    assert "stopRequested" in s and "STOPPED" in s
    assert "Dependency cycle" in s
