from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RestoreAudit.kt").read_text()

def test_receipts_capture_owner_decision_and_outcome():
    for field in ("ownerApproved", "applied", "imported", "skippedDuplicates", "archiveSha256", "targetBeforeFingerprint"):
        assert field in SOURCE

def test_durable_audit_is_hash_chained_and_versioned():
    assert "AQUA_RESTORE_AUDIT_V1" in SOURCE
    assert "Restore audit integrity failure" in SOURCE
    assert "ATOMIC_MOVE" in SOURCE

def test_restore_attempts_are_audited_even_when_denied():
    assert "ActionJournalRestore.apply(plan, target, ownerApproved)" in SOURCE
    assert "audit.append(RestoreAuditReceipt" in SOURCE
