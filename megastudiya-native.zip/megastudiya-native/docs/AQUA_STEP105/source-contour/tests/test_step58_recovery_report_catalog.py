from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportCatalog.kt"


def test_catalog_has_append_only_hash_chain_and_lifecycle():
    text = SOURCE.read_text()
    assert 'AQUA_RECOVERY_REPORT_CATALOG|1' in text
    assert 'previousHash' in text and 'eventHash' in text
    assert 'enum class RecoveryReportLifecycle' in text
    assert 'fun verificationHistory' in text


def test_archive_requires_confirmation_and_never_deletes_artifacts():
    text = SOURCE.read_text()
    assert 'require(confirmed)' in text
    assert 'Explicit owner confirmation is required' in text
    archive_body = text.split('fun archive(', 1)[1].split('fun get(', 1)[0]
    assert 'Files.delete' not in archive_body


def test_catalog_supports_search_and_fail_closed_validation():
    text = SOURCE.read_text()
    assert 'fun list(' in text and 'query: String' in text
    assert 'Catalogue hash-chain mismatch' in text
    assert 'fun verifyJournal()' in text
