from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryArchiveQueueGovernance.kt"
def test_digest_uses_canonical_content_sha256():
    t = SOURCE.read_text()
    assert "RecoveryArchiveQueueContentDigest" in t and "SHA-256" in t
