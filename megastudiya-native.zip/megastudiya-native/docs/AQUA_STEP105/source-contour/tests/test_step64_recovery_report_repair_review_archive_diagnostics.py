from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairReviewArchiveDiagnostics.kt"


def test_archive_diagnostics_cover_inventory_and_integrity():
    text = SOURCE.read_text()
    for code in (
        "ARCHIVE_DIRECTORY_MISSING", "ARCHIVE_DIRECTORY_UNSAFE", "ARCHIVE_PAYLOAD_MISSING",
        "ARCHIVE_ENTRY_INVALID", "ORPHAN_ARCHIVE_PAYLOAD", "DUPLICATE_SNAPSHOT_CONTENT",
        "INTERRUPTED_ARCHIVE_WRITE", "UNRECOGNIZED_ARCHIVE_ENTRY",
    ):
        assert code in text
    assert "RecoveryReportRepairReviewArchive(root).inspect(id)" in text


def test_diagnostics_are_advisory_and_do_not_mutate_archive():
    text = SOURCE.read_text()
    assert "read-only consistency diagnostics" in text
    assert "proposedAction" in text
    assert "Files.delete" not in text
    assert "Files.move" not in text
    assert "Files.write" not in text
