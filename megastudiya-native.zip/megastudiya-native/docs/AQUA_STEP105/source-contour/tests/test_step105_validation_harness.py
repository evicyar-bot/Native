import importlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]

def test_package_import_does_not_launch_pytest():
    code = "import aqua_validation; import aqua_validation.core; print('SAFE_IMPORT')"
    result = subprocess.run([sys.executable, "-c", code], cwd=ROOT, capture_output=True, text=True, timeout=10)
    assert result.returncode == 0
    assert result.stdout.strip() == "SAFE_IMPORT"

def test_manifest_is_fixed_and_step95_scoped():
    manifest = json.loads((ROOT / "aqua_validation/test_manifest.json").read_text())
    assert len(manifest["step95_test_files"]) == 76
    assert "test_step95_import_boundary_integration.py" in manifest["step95_test_files"]
    assert "test_step105_validation_harness.py" not in manifest["step95_test_files"]

def test_report_seal_and_verify(tmp_path):
    from aqua_validation.core import seal_report, verify_report
    path = tmp_path / "report.json"
    report = seal_report({"schema_version": 1, "integrity": {"algorithm": "SHA-256"}})
    path.write_text(json.dumps(report))
    assert verify_report(path) == (True, "VALID")
    path.write_text(path.read_text().replace("SHA-256", "SHA-1"))
    assert verify_report(path) == (False, "DIGEST_MISMATCH")

def test_inventory_hashes_frozen_inputs():
    from aqua_validation.core import inventory
    manifest = json.loads((ROOT / "aqua_validation/test_manifest.json").read_text())
    result = inventory(ROOT, manifest["step95_test_files"])
    assert result["fixed_test_file_count"] == 76
    assert not result["missing_test_files"]
    assert len(result["test_inventory_sha256"]) == 64

def test_cli_help_is_safe():
    result = subprocess.run([sys.executable, "-m", "aqua_validation", "--help"],
                            cwd=ROOT, capture_output=True, text=True, timeout=10)
    assert result.returncode == 0
    assert "check" in result.stdout and "verify" in result.stdout


def test_subprocess_timeout_is_enforced_and_classified():
    from aqua_validation.core import _run_bounded
    result = _run_bounded([sys.executable, "-c", "import time; time.sleep(3)"],
                          ROOT, timeout=1, log_limit=1024)
    assert result["timed_out"] is True
    assert result["outcome"] == "TIMEOUT"
    assert result["error_code"] == "TEST_TIMEOUT"

def test_log_capture_is_bounded():
    from aqua_validation.core import _run_bounded
    result = _run_bounded([sys.executable, "-c", "print('x' * 10000)"],
                          ROOT, timeout=5, log_limit=1024)
    assert result["captured_log_bytes"] <= 1024
