from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairArchiveHealthAndQueue.kt"


def test_snapshot_digest_is_verifiable():
    text = SOURCE.read_text()
    assert 'snapshot' in text
    assert 'verify' in text
    assert 'queueFingerprint' in text

