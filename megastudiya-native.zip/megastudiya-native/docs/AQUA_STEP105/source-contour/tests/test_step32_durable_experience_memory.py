from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "modules/aqua-adapters/file/src/main/kotlin/aqua/adapters/file/DurableExperienceMemory.kt"
def test_durable_experience_memory_adapter_exists():
    assert SRC.exists()
    text = SRC.read_text()
    assert "ExperienceMemoryRepository" in text
    assert "persist()" in text and "load()" in text
    assert "checksum(payload)" in text
    assert "updateReview" in text

def test_step32_runtime_test_covers_restart_integrity():
    test = (ROOT / "tests/kotlin/Step32DurableExperienceMemoryTest.kt").read_text()
    for marker in ["DurableExperienceMemory(file)", "restored", "CONFIRMED", "rejected"]:
        assert marker in test
