from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairArchiveHealthAndQueue.kt"


def test_grouping_is_stable_and_keeps_items():
    text = SOURCE.read_text()
    assert 'toSortedMap()' in text
    assert 'INTEGRITY' in text
    assert 'HOUSEKEEPING' in text

