from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/ActionJournalRestore.kt").read_text()


def test_restore_is_two_phase_and_requires_owner_approval():
    assert "fun preview(" in SOURCE and "fun apply(" in SOURCE
    assert "ownerApproved: Boolean" in SOURCE
    assert "if (!ownerApproved)" in SOURCE


def test_restore_rechecks_archive_and_target_before_import():
    assert "ActionJournalExport.verify(plan.archive)" in SOURCE
    assert "fingerprint(before) != plan.targetSnapshotFingerprint" in SOURCE
    assert "RestoreDisposition.CONFLICT" in SOURCE


def test_restore_never_overwrites_existing_request_ids():
    assert "IDENTICAL_DUPLICATE" in SOURCE
    assert "target.append(byId.getValue(item.requestId))" in SOURCE
    assert "current == incoming" in SOURCE
    assert "else -> RestoreDisposition.CONFLICT" in SOURCE
