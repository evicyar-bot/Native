from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/ActionApi.kt"


def test_typed_action_contracts_exist():
    source = SOURCE.read_text()
    for token in ("ActionDefinition", "ActionArgument", "ActionRequest", "ActionResult", "ActionRisk", "ActionStatus"):
        assert token in source


def test_dry_run_is_the_only_supported_mode():
    source = SOURCE.read_text()
    assert "LIVE_MODE_UNAVAILABLE" in source
    assert "Only dry-run mode is supported" in source
    assert "ACCEPTED_FOR_SIMULATION" in source


def test_permissions_and_argument_validation_are_enforced():
    source = SOURCE.read_text()
    for token in ("PERMISSION_REQUIRED", "MISSING_ARGUMENT", "UNKNOWN_ARGUMENT", "ARGUMENT_TOO_LONG"):
        assert token in source


def test_idempotency_and_duplicate_request_protection():
    source = SOURCE.read_text()
    assert "REQUEST_ID_CONFLICT" in source
    assert "resultFor" in source
    assert "auditSnapshot" in source
