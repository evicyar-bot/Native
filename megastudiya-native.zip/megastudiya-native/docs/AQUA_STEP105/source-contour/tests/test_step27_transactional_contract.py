from pathlib import Path
ROOT=Path(__file__).parents[1]
SRC=ROOT/'modules/aqua-adapters/file/src/main/kotlin/aqua/adapters/file/DurableResearchRepositories.kt'
STORE=ROOT/'modules/aqua-data-format/src/main/kotlin/aqua/dataformat/DurableBundleStore.kt'
def test_repository_mutations_are_serialized():
 s=SRC.read_text(); assert 'synchronized(lock)' in s and 'private val lock = Any()' in s

def test_persist_before_publish():
 s=SRC.read_text(); assert 'StoreSaveResult.Saved' in s and 'publish()' in s
 assert s.index('publish()') > s.index('store.save(b,storageKey)')

def test_storage_stages_commit_and_pointer():
 s=STORE.read_text(); assert '.stage-' in s and 'generation-' in s and 'current.tmp' in s and 'ATOMIC_MOVE' in s

def test_keeps_two_generations_for_recovery():
 s=STORE.read_text(); assert 'skip(2)' in s and 'override fun recover' in s

def test_validation_before_commit():
 s=STORE.read_text(); assert 'ResearchBundleFormat.validate(sealed)' in s and 'require(validation.valid)' in s

def test_task_isolation_remains_enforced():
 s=SRC.read_text(); assert 'sources[it]?.taskId!=claim.taskId' in s and 'claims[it]?.taskId!=decision.taskId' in s
