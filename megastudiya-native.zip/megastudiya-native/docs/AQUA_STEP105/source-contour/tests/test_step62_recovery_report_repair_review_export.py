from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_step62_export_is_single_file_and_versioned():
    source = (ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairReviewJournalExport.kt").read_text()
    assert 'AQUA_REPAIR_REVIEW_EXPORT|1' in source
    assert 'fun export(sourceJournal: Path, destination: Path)' in source
    assert 'fun verify(exportPath: Path)' in source


def test_step62_export_checks_digest_and_chain_without_source_mutation():
    source = (ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairReviewJournalExport.kt").read_text()
    assert 'Export payload digest mismatch' in source
    assert 'RecoveryReportRepairReviewJournal(temporary)' in source
    assert 'source != target' in source
    assert 'ATOMIC_MOVE' in source


def test_step62_export_is_integrity_not_identity():
    source = (ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairReviewJournalExport.kt").read_text()
    assert 'not a digital signature' in source
    assert 'executionAllowed' not in source
