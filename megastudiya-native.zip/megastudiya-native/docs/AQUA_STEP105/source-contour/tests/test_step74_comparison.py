from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairArchiveHealthAndQueue.kt"


def test_snapshot_comparison_checks_integrity_and_does_not_merge():
    text = SOURCE.read_text()
    assert 'compare' in text
    assert 'Invalid queue snapshot' in text
    assert 'leftOnly' in text

