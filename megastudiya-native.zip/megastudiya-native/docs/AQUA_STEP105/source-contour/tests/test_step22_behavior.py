from pathlib import Path
import subprocess
ROOT = Path(__file__).resolve().parents[1]

def test_step22_kotlin_behavior_executable():
    sources = [str(p) for p in ROOT.rglob('*.kt')]
    out = ROOT / 'tests' / 'step22-behavior.jar'
    subprocess.run(['kotlinc', *sources, '-include-runtime', '-d', str(out)], check=True, capture_output=True, text=True)
    result = subprocess.run(['java', '-cp', str(out), 'Step22BehaviorTestKt'], check=True, capture_output=True, text=True)
    assert 'Step22 behavior: PASS' in result.stdout
    out.unlink(missing_ok=True)


def test_memory_adapter_is_non_durable_and_host_independent():
    p = ROOT / 'modules/aqua-adapters/in-memory/src/main/kotlin/aqua/adapters/memory/InMemoryRepositories.kt'
    text = p.read_text()
    assert 'process-local' in text and 'android.' not in text and 'app.megastudiya' not in text
    assert all(x in text for x in ['EvidenceRepository', 'ClaimRepository', 'DecisionRepository'])
