from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairArchiveHealthAndQueue.kt"


def test_priority_policy_has_severity_and_code_escalation():
    text = SOURCE.read_text()
    assert 'coerceAtMost(100)' in text
    assert 'ARCHIVE_DIRECTORY_UNSAFE' in text
    assert 'ARCHIVE_ENTRY_INVALID' in text

