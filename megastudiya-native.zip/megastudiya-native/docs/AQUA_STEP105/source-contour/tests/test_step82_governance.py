from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryArchiveQueueGovernance.kt"
def test_search_is_bounded_and_empty_query_safe():
    t = SOURCE.read_text()
    assert "limit in 1..200" in t and "needle.isEmpty()" in t
