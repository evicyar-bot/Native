from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-task-planning/src/main/kotlin/aqua/planning/gate/PlanExecutionGate.kt"


def test_gate_is_explicit_approval_only():
    source = SOURCE.read_text()
    assert "StoredPlanStatus.APPROVED" in source
    assert "PlanGateStatus.BLOCKED" in source
    assert "READY_FOR_HANDOFF" in source


def test_gate_checks_review_acknowledgements():
    source = SOURCE.read_text()
    assert "constraintsAcknowledged" in source
    assert "risksAcknowledged" in source
    assert "reviewerId.isBlank()" in source


def test_gate_blocks_unreviewed_plan_states():
    source = SOURCE.read_text()
    assert "PlanStatus.READY" in source
    assert "PlanStatus.INVALID" in source
    assert "PlanStatus.ARCHIVED" in source


def test_gate_has_no_executor_side_effects():
    source = SOURCE.read_text()
    assert "does not execute, approve, or mutate plans" in source
    assert "fun evaluate" in source


def test_review_timestamp_and_criteria_checked():
    source = SOURCE.read_text()
    assert "reviewedAtEpochMs <= 0L" in source
    assert "completionCriteria" in source
    assert "successCriteria" in source


def test_review_rationale_and_context_warnings_retained():
    source = SOURCE.read_text()
    assert "review.note.isBlank()" in source
    assert "contextWarnings" in source
    assert "planningWarnings" in source
