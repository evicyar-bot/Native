from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryReportRepairArchiveHealthAndQueue.kt"


def test_dependencies_are_suggested_not_executable():
    text = SOURCE.read_text()
    assert 'suggested review order only' in text
    assert 'zipWithNext' in text
    assert 'RecoveryArchiveQueueDependency' in text

