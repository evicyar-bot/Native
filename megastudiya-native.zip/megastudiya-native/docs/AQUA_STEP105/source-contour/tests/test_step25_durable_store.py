from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
def test_step25_compiles_and_runs():
    src=[str(p) for p in ROOT.rglob('*.kt')]
    jar=ROOT/'tests'/'step25-tests.jar'
    subprocess.run(['kotlinc',*src,'-include-runtime','-d',str(jar)],check=True,capture_output=True,text=True)
    run=subprocess.run(['java','-cp',str(jar),'Step25DurableStoreTestKt'],check=True,capture_output=True,text=True)
    assert 'Step25: 7 checks PASS' in run.stdout
    jar.unlink(missing_ok=True)
def test_durable_storage_contract():
    f=ROOT/'modules/aqua-data-format/src/main/kotlin/aqua/dataformat/DurableBundleStore.kt'
    text=f.read_text()
    for token in ['interface DurableBundleStore','manifestVersion','generation-','sha256','recover','ATOMIC_MOVE']:
        assert token in text
    assert 'android.' not in text and 'app.megastudiya' not in text
