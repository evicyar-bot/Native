from pathlib import Path
p=Path('modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/ResumeApproval.kt')
s=p.read_text()
def test_queue_fingerprint_and_freeze(): assert 'queueFingerprint' in s and 'fun freeze' in s
def test_review_record_has_explicit_decision(): assert 'ResumeApprovalDecision' in s and 'reviewer' in s
def test_stopped_or_unresolved_queue_not_approvable(): assert 'Stopped queue cannot be approved' in s and 'Queue contains unresolved items' in s
def test_checksum_and_stale_approval_guard(): assert 'checksum mismatch' in s.lower() and 'fun matches' in s
