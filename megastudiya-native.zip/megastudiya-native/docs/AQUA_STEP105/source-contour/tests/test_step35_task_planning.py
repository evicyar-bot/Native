from pathlib import Path
ROOT=Path(__file__).parents[1]
SRC=ROOT/'modules/aqua-task-planning/src/main/kotlin/aqua/planning/TaskPlanning.kt'
def test_step35_plan_models_and_validation():
    s=SRC.read_text()
    for token in ['PlanStepDraft','expectedResult','completionCriteria','dependsOn','riskNotes','overallSuccessCriteria','PlanStatus','topologicalOrder','hasCycle']:
        assert token in s
def test_step35_plan_is_not_execution():
    s=SRC.read_text()
    assert 'does not execute' in s and 'contextMemoryIds' in s and 'contextWarnings' in s
