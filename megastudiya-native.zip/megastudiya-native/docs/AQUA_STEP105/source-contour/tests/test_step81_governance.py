from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "modules/aqua-orchestration/src/main/kotlin/aqua/orchestration/RecoveryArchiveQueueGovernance.kt"
def test_csv_export_quotes_fields_and_exports_non_executable():
    t = SOURCE.read_text()
    assert "replace(\"\\\"\", \"\\\"\\\"\")" in t and "executable" in t and '"false"' in t
