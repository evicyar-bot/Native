from pathlib import Path
ROOT=Path(__file__).parents[1]

def test_insights_are_traceable_and_reviewable():
 s=(ROOT/'modules/aqua-experience-memory/src/main/kotlin/aqua/experience/ExperienceMemory.kt').read_text()
 assert 'evidenceEventIds' in s and 'ExperienceReviewStatus' in s and 'updateReview' in s

def test_confidence_is_explicitly_heuristic_not_probability():
 s=(ROOT/'modules/aqua-experience-memory/src/main/kotlin/aqua/experience/ExperienceMemory.kt').read_text()
 assert 'not a calibrated probability' in s and 'transparent heuristic' in s

def test_learning_service_consumes_report_and_is_idempotent():
 s=(ROOT/'modules/aqua-experience-memory/src/main/kotlin/aqua/experience/ExperienceMemory.kt').read_text()
 assert 'fun learn(report: EventHistoryReport' in s and 'stableId' in s and 'repository::save' in s

def test_in_memory_repository_synchronized():
 s=(ROOT/'modules/aqua-adapters/in-memory/src/main/kotlin/aqua/adapters/memory/InMemoryExperienceMemory.kt').read_text()
 assert 'synchronized(lock)' in s and 'putIfAbsent' in s

def test_analytics_carries_event_provenance():
 s=(ROOT/'modules/aqua-history-analytics/src/main/kotlin/aqua/analytics/EventHistoryAnalytics.kt').read_text()
 assert 'evidenceEventIds' in s and 'group.map { it.id.value }.toSet()' in s

def test_step31_runtime_test_exists():
 assert (ROOT/'tests/kotlin/Step31ExperienceMemoryTest.kt').exists()
