"""Bounded, reproducible validation runner for the standalone AQUA source contour."""
from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from typing import Any

SCHEMA_VERSION = 1
ERROR_CODES = {
    "PASS": "NONE",
    "FAIL": "TESTS_FAILED",
    "TIMEOUT": "TEST_TIMEOUT",
    "ERROR": "HARNESS_ERROR",
    "BLOCKED": "TEST_RUNNER_UNAVAILABLE",
}

def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")

def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def canonical_json(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def seal_report(report: dict[str, Any]) -> dict[str, Any]:
    result = dict(report)
    integrity = dict(result.get("integrity", {}))
    integrity.pop("sha256", None)
    result["integrity"] = integrity
    digest = _sha256(canonical_json(result))
    result["integrity"]["sha256"] = digest
    return result

def verify_report(path: Path) -> tuple[bool, str]:
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
        if report.get("schema_version") != SCHEMA_VERSION:
            return False, "UNSUPPORTED_SCHEMA"
        expected = report.get("integrity", {}).get("sha256")
        if not isinstance(expected, str) or len(expected) != 64:
            return False, "MISSING_DIGEST"
        actual = dict(report)
        actual["integrity"] = dict(actual.get("integrity", {}))
        actual["integrity"].pop("sha256", None)
        if _sha256(canonical_json(actual)) != expected:
            return False, "DIGEST_MISMATCH"
        return True, "VALID"
    except (OSError, UnicodeError, json.JSONDecodeError, TypeError):
        return False, "REPORT_UNREADABLE_OR_INVALID"

def toolchain_diagnostics() -> dict[str, Any]:
    tools = {}
    for name in ("python", "pytest", "java", "kotlinc", "gradle", "adb"):
        executable = shutil.which(name)
        tools[name] = {"available": executable is not None, "path": executable}
    home = os.environ.get("HOME")
    kotlin_candidates = [str(Path(directory) / "kotlinc") for directory in os.get_exec_path()]
    if home:
        kotlin_candidates.append(str(Path(home) / ".sdkman/candidates/kotlin/current/bin/kotlinc"))
    inaccessible_kotlin_candidates = []
    for candidate in dict.fromkeys(kotlin_candidates):
        try:
            if Path(candidate).exists() and not os.access(candidate, os.X_OK):
                inaccessible_kotlin_candidates.append(candidate)
        except PermissionError:
            inaccessible_kotlin_candidates.append(candidate)
    tools["kotlinc"]["inaccessible_candidate_paths"] = inaccessible_kotlin_candidates
    sdk_candidates = [os.environ.get("ANDROID_HOME"), os.environ.get("ANDROID_SDK_ROOT")]
    sdk_path = next((p for p in sdk_candidates if p and Path(p).is_dir()), None)
    tools["android_sdk"] = {
        "available": sdk_path is not None,
        "path": sdk_path,
        "environment_configured": any(sdk_candidates),
    }
    return {
        "python_version": sys.version.split()[0],
        "python_executable": sys.executable,
        "pytest_module_available": __import__("importlib.util", fromlist=["find_spec"]).find_spec("pytest") is not None,
        "tools": tools,
    }

def inventory(root: Path, test_files: list[str]) -> dict[str, Any]:
    records = []
    missing = []
    for rel in test_files:
        path = root / "tests" / rel
        if not path.is_file() or path.is_symlink():
            missing.append(rel)
            continue
        payload = path.read_bytes()
        records.append({"path": f"tests/{rel}", "size_bytes": len(payload), "sha256": _sha256(payload)})
    # A second source inventory makes the baseline auditable without including generated reports.
    source_records = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.is_symlink():
            continue
        if any(part in {".git", "__pycache__", ".pytest_cache"} for part in path.parts):
            continue
        if path.suffix.lower() not in {".py", ".kt"}:
            continue
        rel = path.relative_to(root).as_posix()
        data = path.read_bytes()
        source_records.append({"path": rel, "size_bytes": len(data), "sha256": _sha256(data)})
    return {
        "fixed_test_file_count": len(test_files),
        "test_files": records,
        "missing_test_files": missing,
        "test_inventory_sha256": _sha256(canonical_json(records)),
        "source_file_count": len(source_records),
        "source_files": source_records,
        "source_inventory_sha256": _sha256(canonical_json(source_records)),
    }

def _run_bounded(command: list[str], cwd: Path, timeout: int, log_limit: int) -> dict[str, Any]:
    start = time.monotonic()
    proc = subprocess.Popen(
        command, cwd=str(cwd), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=False, start_new_session=(os.name == "posix")
    )
    cap_out = log_limit // 2
    cap_err = log_limit - cap_out
    captured = {"stdout": bytearray(), "stderr": bytearray()}
    def drain(stream, key, cap):
        while True:
            chunk = stream.read(8192)
            if not chunk:
                break
            remaining = cap - len(captured[key])
            if remaining > 0:
                captured[key].extend(chunk[:remaining])
    threads = [
        threading.Thread(target=drain, args=(proc.stdout, "stdout", cap_out), daemon=True),
        threading.Thread(target=drain, args=(proc.stderr, "stderr", cap_err), daemon=True),
    ]
    for thread in threads: thread.start()
    timed_out = False
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        if os.name == "posix":
            try: os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError: pass
        else:
            proc.kill()
        proc.wait()
    for thread in threads: thread.join(timeout=2)
    stdout = bytes(captured["stdout"]).decode("utf-8", errors="replace")
    stderr = bytes(captured["stderr"]).decode("utf-8", errors="replace")
    combined = (stdout + ("\n" if stdout and stderr else "") + stderr)
    if timed_out:
        outcome, code = "TIMEOUT", "TEST_TIMEOUT"
    elif proc.returncode == 0:
        outcome, code = "PASS", "NONE"
    elif "Permission denied" in combined or "PermissionError" in combined or "not executable" in combined.lower():
        outcome, code = "ERROR", "EXECUTABLE_PERMISSION"
    elif "FileNotFoundError" in combined and "kotlinc" in combined:
        outcome, code = "FAIL", "KOTLIN_COMPILER_UNAVAILABLE"
    else:
        outcome, code = "FAIL", "TESTS_FAILED"
    return {
        "command": command, "return_code": proc.returncode, "duration_seconds": round(time.monotonic()-start, 3),
        "timed_out": timed_out, "outcome": outcome, "error_code": code,
        "stdout": stdout, "stderr": stderr,
        "captured_log_bytes": len(stdout.encode()) + len(stderr.encode()),
        "log_limit_bytes": log_limit,
    }

def run_check(root: Path, timeout: int = 120, log_limit: int = 65536, output: Path | None = None) -> dict[str, Any]:
    if timeout < 1 or timeout > 3600:
        raise ValueError("timeout must be between 1 and 3600 seconds")
    if log_limit < 1024 or log_limit > 10485760:
        raise ValueError("log-limit must be between 1024 and 10485760 bytes")
    manifest_path = root / "aqua_validation" / "test_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    test_files = manifest["step95_test_files"]
    inv = inventory(root, test_files)
    diagnostics = toolchain_diagnostics()
    runner = {"outcome": "BLOCKED", "error_code": "TEST_RUNNER_UNAVAILABLE", "return_code": None,
              "duration_seconds": 0.0, "timed_out": False, "stdout": "", "stderr": "",
              "captured_log_bytes": 0, "log_limit_bytes": log_limit, "command": []}
    if not diagnostics["pytest_module_available"]:
        runner["stderr"] = "pytest is not importable in the active Python environment."
    elif inv["missing_test_files"]:
        runner["outcome"], runner["error_code"] = "ERROR", "FIXED_TEST_FILE_MISSING"
        runner["stderr"] = "One or more frozen Step95 test files are missing."
    else:
        paths = [str(Path("tests") / name) for name in test_files]
        runner = _run_bounded([sys.executable, "-m", "pytest", "-q", "--disable-warnings", "--color=no", "--tb=line", "-rA", *paths],
                              root, timeout, log_limit)
    summary_text = runner.get("stdout", "")
    summary = {
        "passed": int((re.search(r"(\d+) passed", summary_text) or [None, "0"])[1]),
        "failed": int((re.search(r"(\d+) failed", summary_text) or [None, "0"])[1]),
        "skipped": int((re.search(r"(\d+) skipped", summary_text) or [None, "0"])[1]),
        "errors": int((re.search(r"(\d+) errors?", summary_text) or [None, "0"])[1]),
    }
    runner["summary"] = summary
    outcome = runner["outcome"]
    report = {
        "schema_version": SCHEMA_VERSION,
        "report_type": "AQUA_STANDALONE_VALIDATION",
        "generated_at_utc": _utc_now(),
        "project": {"name": "AQUA", "baseline": "Step95", "target": "Step105"},
        "overall_outcome": outcome,
        "error_classification": {"code": runner["error_code"], "category": outcome},
        "environment": diagnostics,
        "inventory": inv,
        "test_run": runner,
        "android_assessment": {
            "android_project_present": any((root / p).exists() for p in ("settings.gradle", "settings.gradle.kts", "build.gradle", "build.gradle.kts", "app")),
            "gradle_configuration_present": any(root.rglob("settings.gradle")) or any(root.rglob("settings.gradle.kts")),
            "apk_built": False,
            "runtime_launched": False,
            "note": "No Android build or device runtime is claimed by this source-contour validation."
        },
        "integrity": {"algorithm": "SHA-256", "scope": "canonical JSON report excluding integrity.sha256",
                      "sha256": ""},
    }
    report = seal_report(report)
    if output is not None:
        output.parent.mkdir(parents=True, exist_ok=True)
        tmp = output.with_name(output.name + ".tmp")
        tmp.write_bytes(json.dumps(report, ensure_ascii=False, indent=2).encode("utf-8") + b"\n")
        os.replace(tmp, output)
        valid, reason = verify_report(output)
        report["integrity"]["written_report_verification"] = {"valid": valid, "result": reason}
        # written_report_verification is itself part of the final digest; reseal and rewrite.
        report = seal_report(report)
        tmp.write_bytes(json.dumps(report, ensure_ascii=False, indent=2).encode("utf-8") + b"\n")
        os.replace(tmp, output)
    return report
