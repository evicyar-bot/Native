"""Command line interface for AQUA validation."""
from __future__ import annotations
import argparse
from pathlib import Path
import json
import sys
from .core import run_check, verify_report

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="python -m aqua_validation")
    sub = parser.add_subparsers(dest="command", required=True)
    check = sub.add_parser("check", help="run the frozen Step95 regression suite")
    check.add_argument("--timeout", type=int, default=120)
    check.add_argument("--log-limit", type=int, default=65536)
    check.add_argument("--output", type=Path, default=Path("validation-report.json"))
    verify = sub.add_parser("verify", help="verify a generated validation report")
    verify.add_argument("report", type=Path, nargs="?", default=Path("validation-report.json"))
    args = parser.parse_args(argv)
    if args.command == "check":
        try:
            report = run_check(Path.cwd(), args.timeout, args.log_limit, args.output)
        except Exception as exc:
            print(f"AQUA validation harness error: {type(exc).__name__}: {exc}", file=sys.stderr)
            return 2
        print(json.dumps({
            "outcome": report["overall_outcome"],
            "error_code": report["error_classification"]["code"],
            "report": str(args.output),
            "report_sha256": report["integrity"]["sha256"],
            "test_return_code": report["test_run"]["return_code"],
        }, ensure_ascii=False, indent=2))
        return 0 if report["overall_outcome"] == "PASS" else 1
    valid, reason = verify_report(args.report)
    print(json.dumps({"valid": valid, "result": reason, "report": str(args.report)}, indent=2))
    return 0 if valid else 1

if __name__ == "__main__":
    raise SystemExit(main())
