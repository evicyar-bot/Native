# AQUA — Standalone development contour

AQUA is now developed as an independent module set. MegaStudio is not the working base; it is only a future host/integration target.

## Current stage
- Step 19: Decision Log (source available; Step 18 merge caveat retained).
- Step 20: Knowledge Graph core model and standalone boundary scaffold.
- No MegaStudio UI/app/assets are carried into this repository.

## Modules
- `modules/aqua-knowledge-graph`: pure Kotlin graph model (nodes, edges, task scoping, safe link validation).
- `modules/aqua-adapters/megastudio`: future host adapter boundary, currently interface contract only.
- `docs/`: architecture and agent handoff.

## Build status
This contour intentionally begins as a lightweight module workspace. Android/Compose integration and host adapters are not compiled here. Python static contracts run with `python3 -m unittest discover -s tests`.


## Step 22
- In-memory repositories for evidence, claims, decisions (prototype/testing only; non-durable).
- Executable Kotlin behavior test covers task scoping, reference integrity, review, revisions, status and cleanup.
- Run: `pytest -q` (compiles Kotlin and executes behavioral assertions).
- Verified in this workspace: 16 tests pass.


## Project purpose
AQUA is the independent research/autonomy core being extracted from MegaStudio: persistent continuity, goals/planning, permitted-source research, evidence/provenance, reproducible experiments, tool execution and eventually controlled self-development. This standalone workspace is for building those modules without carrying the native Android app. Integration back into MegaStudio is intentionally postponed until modules have independent tests.

Current: Step 23 — portable research bundle schema, integrity and v0 migration; JSON byte codec/durable storage still pending.

### Step 24
Portable JSON byte serialization and file export/import now implemented, including size caps, atomic replacement, `.bak` and validated restore. See `AQUA_PROGRESS.md`.

## Step 25 — Durable storage
Portable durable bundle store added: versioned manifest, SHA-256 and byte-size validation, immutable generations, atomic current-pointer commit, path-safe keys, and recovery from previous valid generations. Android/MegaStudio remain outside the core.

### Step 26
File-based persistence now connects research repositories to the durable bundle store. Repository operations validate cross-references and persist before in-memory publication. See `AQUA_PROGRESS.md` and the integration test.

### Step 27
Transaction/concurrency contract checks added for the durable repository and filesystem commit protocol. These are source-level tests; real process-crash injection and filesystem stress remain future verification.

### Step 28 — Event Journal
A portable append-only event domain and journal port are provided. The in-memory adapter is synchronized, assigns monotonic sequence numbers, deduplicates by event ID, and supports scoped/filter queries. Events capture actor, action, subject, outcome, task, reason and details. This is groundwork only; durable journal storage is the next step.

### Step 29 — Durable event journal
The file adapter persists append-only event records with SHA-256 integrity checks and monotonic sequence numbers. It replays on construction and repairs only an incomplete final line. A complete but corrupt record causes a fail-closed error. Appends are forced to storage before the in-memory journal is updated.

### Step 30 — Event-history analytics
The new `aqua-history-analytics` module provides a read-only report over journal history: outcome counts, terminal-event success rate, per-action rates, repeated failure signatures and recurring task patterns. Findings are observations only, with no automatic policy changes or self-modification. Analysis is bounded and task-scoped.

### Experience Memory (Step 31)
AQUA can turn history analytics into reviewable experience insights with source-event provenance, deterministic IDs, heuristic confidence scores, and review statuses. The current adapter is in-memory; durable experience storage is planned separately. Insights are advisory and do not automatically modify agent behavior.

### Step 32: Durable Experience Memory
The file adapter `DurableExperienceMemory` stores reviewable experience records across restarts. Records include evidence event IDs, heuristic confidence, and review state; integrity is checked during loading. The adapter is standalone and does not integrate with Mega Studio.

## Step 33 — Experience Retrieval
AQUA can retrieve relevant historical experience before a task using deterministic term matching and heuristic ranking. Query supports kind filters, reviewed-only mode, confidence floor and bounded result count. Rejected/outdated insights are excluded; returned memories carry matched terms and caution labels. Retrieval is read-only and does not change task behavior.


## Step 34 — Task Context Assembly
- Added bounded, structured context assembly before a task: goal, constraints, retrieved experience, confidence/relevance, matched terms, event provenance, and caution/warnings.
- Explicitly flags unreviewed memories and empty retrieval. Rendering is character-bounded with truncation notice. Assembly is read-only.
- Step 34 Python contracts: 6/6 PASS; Kotlin compilation of all modules and tests: PASS; runtime test: STEP34_TASK_CONTEXT_ASSEMBLER_PASS; combined Steps 27–34 focused contracts: 44/44 PASS.
- Development estimate: 40%; autonomy remains separately unverified. Current source/test count: 1,654 lines Kotlin + Python.
- Next: Step 35 — planning/execution interface consumes task context and produces an auditable action plan (no autonomous execution yet).

## Step 35 — Task Planning
A standalone task-planning module turns task context and a supplied plan draft into an auditable plan. It validates completion criteria, step IDs and dependency graph, rejects cycles, topologically orders steps, and preserves retrieved-memory IDs and context cautions. It only creates plans; it does not execute actions. Invalid plans are marked INVALID; warnings/context cautions mark plans NEEDS_REVIEW.

### Step 36: Durable Task Plan Store
Task plans now have a repository port and both in-memory and file-backed implementations. Durable records retain the plan payload, version, lifecycle state (SAVED/APPROVED/ARCHIVED), save timestamp and status-change history. Records are checksummed and reloaded on startup; identical plan-ID saves are idempotent, while conflicting content under the same ID is rejected. This module stores plans only and does not execute actions.

### Step 37 — Plan Execution Readiness Gate
A read-only review gate requires explicit stored APPROVED state, a READY plan, complete criteria and risk notes, reviewer identity/time, and acknowledgement of constraints and risks. It returns blockers/warnings and `READY_FOR_HANDOFF`; it does not approve or execute plans.

### Step 38 — Execution Ledger
A standalone bookkeeping model for task-step lifecycle, attempts, checkpoint, timestamps, failures and event history. It validates state transitions and duplicate event IDs. It deliberately does not execute tools or external actions. Device runtime/integration remains unverified.

## Step 39 — Durable Execution Ledger & Recovery
A checksummed durable snapshot stores ledger state and event history. On restart, a persisted RUNNING step is marked INTERRUPTED and annotated; AQUA never auto-replays it. Explicit reconciliation is required: place it in WAITING (hold) or READY (reviewed approval to resume). Store corruption is rejected rather than silently accepted. This remains bookkeeping; no executor or external action is implemented.

## Step 40 — Dry-run Execution Orchestrator
AQUA now has a deterministic orchestration layer that orders steps by dependencies and simulates policy decisions. It checks allowlisted action keys, risk thresholds, explicit owner-approved action keys, dependencies, and stop requests. Live execution is deliberately unsupported (`dryRun` must be true); it does not call tools or perform external actions.

### Step 41 — Orchestration audit
Dry-run orchestration decisions can now be recorded in a versioned append snapshot with a SHA-256 hash chain. Loading verifies record sequence, previous-hash links and record hashes. The audit is a record-only feature and does not execute actions.

Step 41 focused verification: Python contracts 3/3, Kotlin compilation PASS, executable audit round-trip and tamper rejection PASS.

### Step 42 — Orchestration Session Recovery
Persist and recover dry-run orchestration session snapshots with plan-fingerprint matching, stop-flag preservation, checksum validation, and explicit review on mismatch. No external actions are invoked.

Validation snapshot: Kotlin compile PASS; Step42 executable PASS; focused contracts Steps 27–42: 76/76 PASS. Android runtime and MegaStudio integration remain unverified.


### Step 43 — Safe Resume Queue Planner
Builds a non-executing resume queue from plan dependencies, execution ledger, and session fingerprint. Completed steps are not requeued; interrupted steps require reconciliation; failed/cancelled/approval-required steps need owner review; stop flag blocks all items. Validated with 4 Python contracts and Kotlin executable test.

## Step 44 — Resume approval
- Freeze a resume queue using a deterministic queue fingerprint.
- Record explicit approve/reject decision, reviewer label, time and rationale; reject stopped or unresolved queues.
- Persist and checksum approval records; detect stale approvals when queue fingerprint changes.
- Review bookkeeping only: no authenticated identity or live execution.
- Focused tests Steps 27–44: 84/84 PASS; Kotlin executable test PASS.

## Step 45 — Preflight safety gate
A final simulation-only gate checks stop flags, matching plan and frozen queue fingerprints, current explicit approval, permission and dependency checks, risk ceiling, budget, and unresolved queue entries. Failure blocks the handoff; a non-simulation request returns owner-confirmation-required. It does not execute tools or external actions.

Step 45 focused verification: contracts Steps 27–45 **88/88 PASS**, focused Kotlin compilation/executable PASS. Full pytest timed out; Android runtime/integration not verified. `.kt`/`.py` line count: **2,681** (+77 from Step 44's 2,604).


## Step 46 — Preflight Receipt
The orchestration layer now emits a durable, reproducible receipt for each preflight evaluation. Receipts capture the relevant request snapshot, all check results and reasons, and are protected by a SHA-256 hash chain. The journal is atomically persisted before an appended receipt is published in memory. This remains simulation/audit bookkeeping: no tools or external actions are executed.

## Step 47 — Typed Action API Foundation
- Defines typed action/argument/request/result contracts and a duplicate-safe action catalogue.
- Validates action registration, enabled state, dry-run-only mode, argument schema and permissions before returning `ACCEPTED_FOR_SIMULATION`.
- Identical request replay is idempotent; request-ID reuse with different content is rejected.
- No live executor or external side effect is present. Focused Python regression Steps 27–47: 96/96 PASS; Kotlin compilation and executable Step 47 test PASS.


### Step 48 — durable action result journal

The dry-run Action API can now use a versioned file-backed result journal. Entries are SHA-256 hash-chained, validated on startup, and atomically persisted before the in-memory result is published. A restarted API restores prior results and preserves request-ID idempotency. Corrupt or tampered journals fail closed. This remains simulation-only: no action execution or automatic replay is implemented.

Step 48 verification: Kotlin compile and Step 47/48 executable checks PASS; focused Python regression Steps 27–48: 100/100 PASS. Inventory: 3,247 lines across 89 Kotlin/Python files (+186 lines, +3 files from Step 47). Engineering-scope estimate 58%; confirmed autonomy evidence score 27% (unchanged; runtime evidence is still absent).


### Step 49 — Action Journal Diagnostics & Bounded Growth
The Action API journal can now be wrapped in a configurable capacity policy. Read-only diagnostics report record count, conservative byte estimate, utilization and health (HEALTHY / NEAR_CAPACITY / CAPACITY_REACHED). At configured limits, new unique records are rejected with an explicit message. Existing history is never automatically pruned; operators must review/archive it deliberately.

Step 49 verification: all-module Kotlin compilation and executable Steps 47–49 PASS; focused Python regression Steps 27–49: 103/103 PASS. Inventory: 3,379 lines (3,051 non-empty) in 92 Kotlin/Python files. Android runtime and MegaStudio integration remain unverified.


### Step 50 — Explicit Action Journal Export & Verification
Call `ActionJournalExport.export(journal, destination)` to create a versioned, SHA-256-protected snapshot, then `ActionJournalExport.verify(path)` to validate it. Export is explicit, atomic where supported, and read-only with respect to the source journal. Verification rejects tampering and malformed records. No source deletion or automatic archival is performed.


**Step 50 verification:** all-module Kotlin compile and executable checks Steps 47–50 passed; focused Python regression Steps 27–50 passed (106/106). Android runtime and MegaStudio integration are not verified.


### Step 53 — Recovery Audit Search & Reports
Recovery audit receipts can be filtered by date range, owner decision, archive ID and outcome. Reports include aggregate counts and a SHA-256 digest, and can be exported to CSV atomically without modifying source history.


### Step 54 — Durable Recovery Audit Store
Recovery receipts now have a versioned, file-backed append-only ledger. Startup verifies the SHA-256 chain and rejects malformed, duplicate, or tampered records. Identical receipt appends are idempotent; conflicting IDs are rejected.

Step 54 verification: 118/118 Python regression tests passed; Kotlin modules plus the Step 54 executable test compiled and passed. Step 50 executable regression passed. Android runtime and MegaStudio integration remain unverified.

### Step 55 — Durable Recovery Audit Reporting
Recovery audit reports can now be generated directly from the verified durable receipt journal, including after restart. Queries support the existing date/decision/archive/outcome filters and stable ordering. CSV export is derived from a fresh integrity-checked snapshot and leaves the source journal unchanged.

### Step 56 — Report provenance
A versioned provenance manifest binds a recovery audit report to its source receipt snapshot, query filters, generation timestamp and report fingerprint. It supports atomic persistence, strict reopen validation and stale/altered source detection. It does not sign reports or establish owner identity.

### Step 57 — Recovery Report Package Integrity
Recovery report CSV output is now cryptographically bound to its Step 56 provenance manifest via a separate versioned package sidecar. Verification returns VALID, STALE, or INVALID and distinguishes changed source/query/report provenance from tampered or missing package files. Verification is read-only; source audit receipts are never modified or automatically pruned. Android runtime and MegaStudio integration remain unverified.

## Step 59 — Recovery report catalogue diagnostics
- Read-only checks for missing registered files and package sidecar/hash mismatches.
- Findings include severity, diagnostic code and suggested operator action; no automatic repair or deletion is performed.
- Clean filesystem diagnostics do not replace full Step 57 provenance verification against the current source snapshot.
- Verification: Kotlin all-module compile and executable Steps 57–59 PASS; Python regression Steps 27–59: 130/130 PASS. Android runtime and MegaStudio integration remain unverified.

## Step 60 — Recovery report repair-plan review
Step 59 diagnostics can now be converted into deterministic, fingerprinted repair proposals. Each proposed step identifies the required trusted input and its risk. Recording operator review requires explicit confirmation and binds the receipt to the exact plan fingerprint. Approval is **not execution authority**: execution remains disabled, and this module performs no file writes, restores, overwrites or deletions. Caller-provided reviewer labels are not authentication.

Verification: all Kotlin modules compile; executable Steps 57–60 PASS; Python regression Steps 27–60: 133/133 PASS. Inventory: 4,995 total lines (4,466 non-empty) across 125 Kotlin/Python files. Engineering-scope estimate 70%; confirmed autonomy evidence 27%. Android runtime and MegaStudio integration remain unverified.

## Step 61 — Durable repair-review receipts
Explicit reviews of Step 60 repair proposals are now stored in a versioned, append-only journal. Each receipt binds the report ID and exact plan fingerprint to a timestamp and caller-supplied reviewer label. A SHA-256 hash chain detects modification, deletion, reordering and malformed entries; startup fails closed if validation fails. Persistence uses atomic replacement where supported, and history survives reopening. Review receipts remain non-executable (`executionAllowed=false`); reviewer labels are not authenticated identity, and the hash chain is not a digital signature against an attacker able to replace the entire journal.

**Step 61 verification:** all Kotlin modules compiled; executable Steps 60–61 passed; Python regression Steps 27–61: 136/136 PASS. Inventory: 5,184 total lines (4,629 non-empty), 128 Kotlin/Python files; +189 lines / +3 files from Step 60. Engineering-scope estimate 71%; confirmed autonomy evidence remains 27%. Android runtime and MegaStudio integration remain unverified.

### Step 62 — Repair-review journal export
The repair-review history can now be explicitly exported as one portable, versioned file. The export contains the exact journal bytes, a SHA-256 payload digest, receipt count and terminal hash. Verification checks the embedded digest and independently revalidates the complete Step 61 hash chain from a temporary copy, so it does not depend on the original journal still being present. Export is atomic where supported and leaves the source journal unchanged. The unkeyed digest is integrity checking, not a digital signature or proof of reviewer identity. No repair is executed or authorized.

**Step 62 verification:** Kotlin all-module compilation and executable Steps 60–62 passed; Python regression Steps 27–62: **139/139 PASS**. Inventory: **5,326 total lines** (**4,754 non-empty**) across **131 Kotlin/Python files**, +142 lines and +3 files from Step 61. Engineering-scope estimate: **72%**; confirmed autonomy evidence remains **27%**. Android runtime and MegaStudio integration remain unverified.

### Step 63 — Repair-review snapshot archive
Multiple Step 62 review-journal exports can now be retained as immutable, explicitly named snapshots. Each archive entry binds its exact export bytes to versioned metadata with SHA-256, receipt count and terminal receipt hash. Inspection verifies both metadata and the complete embedded journal chain. Snapshot comparison detects identical histories, prefix extensions, divergent branches and invalid archives, including the receipt sequence ranges present only on each side. Duplicate IDs are rejected; no automatic pruning, merge, repair or journal mutation occurs. SHA-256 is unkeyed integrity detection, not a digital signature; labels are not authenticated identities, and local archive storage is not WORM/remote backup.

**Step 63 verification:** all Kotlin modules compiled; executable Steps 60–63 passed; Python regression Steps 27–63: **141/141 PASS**. Inventory: **5,515 total lines** (**4,926 non-empty**) across **134 Kotlin/Python files**, +189 lines and +3 files from Step 62. Engineering-scope estimate **73%**; confirmed autonomy evidence remains **27%**. Android runtime and MegaStudio integration remain unverified.

### Step 64 — Repair-review archive diagnostics
The review-snapshot archive now has a read-only consistency scanner. It inventories metadata and payload pairs, validates every archive through the Step 63 inspector and embedded Step 62 journal-chain verifier, and reports missing/unsafe directories, symlinks, missing or invalid payloads, orphan exports, duplicate snapshot content, interrupted temporary writes and unrecognized entries. Each finding includes a severity, stable code, path, explanation and proposed operator action. Diagnostics never repair, rename, overwrite, promote or delete archive entries; the delegated verifier may create and clean a transient scratch file during validation; duplicate content is only a warning.

**Step 64 verification:** all Kotlin modules compiled; executable Steps 60–64 passed; Python regression Steps 27–64: **143/143 PASS**. Inventory: **5,698 total lines** (**5,087 non-empty**) across **137 Kotlin/Python files**, +183 lines and +3 files from Step 63. Engineering-scope estimate **74%**; confirmed autonomy evidence remains **27%**. Android runtime and MegaStudio integration remain unverified.


## Steps 65–74 — Archive health and review queue
- Added archive health aggregation, deterministic remediation queue and priority policy, deduplication, grouping, advisory review ordering, bounded pagination, digest-verified queue snapshots, JSON export, and snapshot comparison.
- The queue remains non-executable. No repairs, deletions, archive changes, MegaStudio integration, or Android work are performed.
- Steps 65–74 contract tests: 10/10 PASS; Step64 regression: 2/2 PASS. Kotlin compiler unavailable; compile/runtime NOT VERIFIED. See `AQUA_PROGRESS.md` for details.

### Steps 75–84: queue governance

The archive-review queue now has strict schema validation, validation summaries, canonical serialization, content digests, queue change detection, filtering, safe CSV export, bounded search, statistics, and a validated export manifest. These remain review-only and non-executable.

### Step 84 checkpoint
Engineering-scope estimate: 90%; autonomy/runtime evidence: 27%. Inventory: 6,192 Kotlin/Python lines (5,512 non-empty) across 159 files. Steps 65–84 targeted contracts: 20 passed; broad suite excluding five compiler-heavy integration tests: 177 passed; direct Kotlin module compilation: passed.


### Step 95 checkpoint

Queue import is restricted to validation preview: no persistence and no execution. Current source/test inventory: 6421 total lines, 5703 non-empty lines, 171 Kotlin/Python files. Focused contract tests: 14 passed; all Kotlin module sources compile. Full test suite timed out and remains pending.


## Step 105 — Reproducible validation harness (Steps 96–105)

A standalone validation command now diagnoses the available toolchain, hashes a frozen
Step 95 regression input set and the Kotlin/Python source inventory, runs that exact
76-file regression set under a hard process timeout, and writes a bounded, versioned
JSON report sealed with SHA-256. The digest is an integrity checksum, not a signature.

From the repository root:

```bash
python -m aqua_validation check
python -m aqua_validation check --timeout 120 --log-limit 65536 --output validation-report.json
python -m aqua_validation verify validation-report.json
```

`check` exits nonzero for FAIL, TIMEOUT, ERROR, or BLOCKED and still writes the report.
The harness package is safe to import: importing it does not launch tests. The fixed
Step 95 test list is recorded in `aqua_validation/test_manifest.json`; Step 105 harness
tests are run separately and are not silently added to the historical regression set.

The report distinguishes available tools from verified build/runtime outcomes. No
Android APK build or device launch is claimed unless a future build workflow explicitly
performs and records those operations. Kotlin compilation is reported as unavailable
when no usable compiler is present.

Latest Step105 run: **195 passed / 5 failed** in the frozen Step95 suite; the five failures are Kotlin test launch permission errors (`kotlinc` inaccessible). The command writes a valid SHA-256-sealed report and exits nonzero as designed. The 7 Step105 harness self-tests passed. Java is present; Kotlin compiler, Gradle, ADB and Android SDK are unavailable to this process. No Android project/APK/runtime was verified.
