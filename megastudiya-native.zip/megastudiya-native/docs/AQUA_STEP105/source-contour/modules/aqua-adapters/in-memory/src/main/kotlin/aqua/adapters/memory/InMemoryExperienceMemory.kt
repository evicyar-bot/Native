package aqua.adapters.memory

import aqua.experience.*

/** Simple synchronized adapter for development and deterministic tests. */
class InMemoryExperienceMemory : ExperienceMemoryRepository {
    private val lock = Any()
    private val records = linkedMapOf<ExperienceId, ExperienceInsight>()
    override fun save(insight: ExperienceInsight): ExperienceInsight = synchronized(lock) {
        records.putIfAbsent(insight.id, insight) ?: insight
    }
    override fun get(id: ExperienceId): ExperienceInsight? = synchronized(lock) { records[id] }
    override fun list(status: ExperienceReviewStatus?): List<ExperienceInsight> = synchronized(lock) {
        records.values.filter { status == null || it.reviewStatus == status }.toList()
    }
    override fun updateReview(id: ExperienceId, status: ExperienceReviewStatus): ExperienceInsight? = synchronized(lock) {
        records[id]?.copy(reviewStatus = status)?.also { records[id] = it }
    }
}
