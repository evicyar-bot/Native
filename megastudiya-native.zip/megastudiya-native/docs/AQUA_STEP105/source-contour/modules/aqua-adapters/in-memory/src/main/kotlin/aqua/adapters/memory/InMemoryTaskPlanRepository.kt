package aqua.adapters.memory
import aqua.planning.*
import aqua.planning.storage.*
class InMemoryTaskPlanRepository:TaskPlanRepository {
 private val lock=Any(); private val items=linkedMapOf<String,StoredTaskPlan>()
 override fun save(planId:String,plan:TaskPlan,nowEpochMs:Long)=synchronized(lock){require(planId.isNotBlank()); val old=items[planId]; if(old!=null){require(old.plan==plan){"Plan ID already exists with different content"};old} else StoredTaskPlan(planId,plan,1,StoredPlanStatus.SAVED,nowEpochMs).also{items[planId]=it}}
 override fun get(planId:String)=synchronized(lock){items[planId]}
 override fun list(taskId:String?)=synchronized(lock){items.values.filter{taskId==null||it.plan.taskId==taskId}.toList()}
 override fun changeStatus(planId:String,status:StoredPlanStatus,nowEpochMs:Long,note:String)=synchronized(lock){val old=items[planId]?:return@synchronized null;if(old.status==status)return@synchronized old;val updated=old.copy(version=old.version+1,status=status,history=old.history+PlanStatusChange(status,nowEpochMs,note));items[planId]=updated;updated}
}
