package aqua.adapters.memory

import aqua.ports.*
import aqua.research.*

/** Deterministic, process-local repositories for tests and prototypes. Not durable storage. */
class InMemoryEvidenceRepository : EvidenceRepository {
    private val items = linkedMapOf<SourceId, EvidenceSource>()
    override fun list(taskId: TaskId?): List<EvidenceSource> = items.values.filter { taskId == null || it.taskId == taskId }
    override fun find(id: SourceId): EvidenceSource? = items[id]
    override fun upsert(source: EvidenceSource): Boolean {
        val existing = items[source.id]
        if (existing != null && existing.taskId != source.taskId) return false
        items[source.id] = source
        return true
    }
    override fun removeTask(taskId: TaskId): Int {
        val ids = items.values.filter { it.taskId == taskId }.map { it.id }
        ids.forEach(items::remove)
        return ids.size
    }
}

class InMemoryClaimRepository : ClaimRepository {
    private val items = linkedMapOf<ClaimId, Claim>()
    override fun list(taskId: TaskId?): List<Claim> = items.values.filter { taskId == null || it.taskId == taskId }
    override fun find(id: ClaimId): Claim? = items[id]
    override fun upsert(claim: Claim): Boolean {
        val existing = items[claim.id]
        if (existing != null && existing.taskId != claim.taskId) return false
        items[claim.id] = claim.copy(evidenceSourceIds = claim.evidenceSourceIds.toSet())
        return true
    }
    override fun removeTask(taskId: TaskId): Int {
        val ids = items.values.filter { it.taskId == taskId }.map { it.id }
        ids.forEach(items::remove)
        return ids.size
    }
}

class InMemoryDecisionRepository : DecisionRepository {
    private val items = linkedMapOf<DecisionId, ResearchDecision>()
    override fun list(taskId: TaskId?): List<ResearchDecision> = items.values.filter { taskId == null || it.taskId == taskId }
    override fun find(id: DecisionId): ResearchDecision? = items[id]
    override fun upsert(decision: ResearchDecision): Boolean {
        val existing = items[decision.id]
        if (existing != null && existing.taskId != decision.taskId) return false
        items[decision.id] = decision.copy(history = decision.history.toList())
        return true
    }
    override fun removeTask(taskId: TaskId): Int {
        val ids = items.values.filter { it.taskId == taskId }.map { it.id }
        ids.forEach(items::remove)
        return ids.size
    }
}
