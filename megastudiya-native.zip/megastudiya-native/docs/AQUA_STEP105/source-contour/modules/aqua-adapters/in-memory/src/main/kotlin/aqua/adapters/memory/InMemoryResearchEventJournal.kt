package aqua.adapters.memory

import aqua.ports.ResearchEventJournal
import aqua.research.EventId
import aqua.research.EventQuery
import aqua.research.ResearchEvent

/** Thread-safe test/runtime adapter. Events are immutable and append-only. */
class InMemoryResearchEventJournal : ResearchEventJournal {
    private val lock = Any()
    private val events = mutableListOf<ResearchEvent>()
    private val byId = mutableMapOf<EventId, ResearchEvent>()
    private var sequence = 0L

    override fun append(event: ResearchEvent): ResearchEvent = synchronized(lock) {
        byId[event.id]?.let { return@synchronized it }
        val stored = event.copy(sequence = ++sequence)
        events += stored
        byId[stored.id] = stored
        stored
    }

    override fun query(query: EventQuery): List<ResearchEvent> = synchronized(lock) {
        events.asSequence()
            .filter { it.sequence > query.afterSequence }
            .filter { query.taskId == null || it.taskId == query.taskId }
            .filter { query.actor == null || it.actor == query.actor }
            .filter { query.action == null || it.action == query.action }
            .filter { query.outcome == null || it.outcome == query.outcome }
            .take(query.limit)
            .toList()
    }

    override fun find(id: EventId): ResearchEvent? = synchronized(lock) { byId[id] }
    override fun latestSequence(): Long = synchronized(lock) { sequence }
}
