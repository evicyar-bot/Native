# MegaStudio host adapter (future)

This directory defines the future integration boundary only. AQUA core must not depend on MegaStudio. Adapter implementation is intentionally deferred until the standalone modules are independently validated.
