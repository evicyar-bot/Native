package aqua.adapters.file

import aqua.ports.ResearchEventJournal
import aqua.research.*
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardOpenOption
import java.security.MessageDigest
import java.util.Base64

/** Append-only, checksummed JSON-independent event journal. A torn final record is discarded on open. */
class DurableResearchEventJournal(private val file: Path) : ResearchEventJournal {
    private val lock = Any()
    private val events = mutableListOf<ResearchEvent>()
    private val byId = mutableMapOf<EventId, ResearchEvent>()
    private var sequence = 0L

    init { synchronized(lock) { replayAndRepair() } }

    override fun append(event: ResearchEvent): ResearchEvent = synchronized(lock) {
        byId[event.id]?.let { return@synchronized it }
        val stored = event.copy(sequence = sequence + 1)
        val record = encode(stored) + "\n"
        Files.createDirectories(file.toAbsolutePath().parent)
        FileChannel.open(file, StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND).use { ch ->
            val bytes = ByteBuffer.wrap(record.toByteArray(StandardCharsets.UTF_8))
            while (bytes.hasRemaining()) ch.write(bytes)
            ch.force(true)
        }
        // Publish only after durable append succeeds.
        sequence = stored.sequence
        events += stored
        byId[stored.id] = stored
        stored
    }

    override fun query(query: EventQuery): List<ResearchEvent> = synchronized(lock) {
        events.asSequence().filter { it.sequence > query.afterSequence }
            .filter { query.taskId == null || it.taskId == query.taskId }
            .filter { query.actor == null || it.actor == query.actor }
            .filter { query.action == null || it.action == query.action }
            .filter { query.outcome == null || it.outcome == query.outcome }
            .take(query.limit).toList()
    }
    override fun find(id: EventId): ResearchEvent? = synchronized(lock) { byId[id] }
    override fun latestSequence(): Long = synchronized(lock) { sequence }

    private fun replayAndRepair() {
        if (!Files.exists(file)) return
        val bytes = Files.readAllBytes(file)
        var validEnd = 0
        var expectedSeq = 1L
        var start = 0
        for (i in bytes.indices) if (bytes[i] == '\n'.code.toByte()) {
            val line = bytes.copyOfRange(start, i).toString(StandardCharsets.UTF_8)
            if (line.isNotEmpty()) {
                val event = decode(line)
                if (event.sequence != expectedSeq) throw IOException("Journal sequence gap at $expectedSeq")
                if (byId.containsKey(event.id)) throw IOException("Duplicate event ID in journal: ${event.id.value}")
                events += event; byId[event.id] = event; sequence = event.sequence; expectedSeq++
            }
            validEnd = i + 1; start = i + 1
        }
        // Only an incomplete trailing line is recoverable; completed malformed records fail closed.
        if (validEnd != bytes.size) FileChannel.open(file, StandardOpenOption.WRITE).use { it.truncate(validEnd.toLong()); it.force(true) }
    }

    private fun encode(e: ResearchEvent): String {
        val fields = listOf(e.sequence.toString(), e.id.value, e.occurredAtEpochMs.toString(), e.actor, e.action,
            e.subjectId, e.outcome.name, e.taskId?.value.orEmpty(), e.reason, e.details)
        val payload = fields.joinToString("\t") { Base64.getUrlEncoder().withoutPadding().encodeToString(it.toByteArray(StandardCharsets.UTF_8)) }
        return "AQUA-EVENT-1\t$payload\t${sha256(payload)}"
    }
    private fun decode(line: String): ResearchEvent {
        val parts = line.split('\t')
        if (parts.size != 12 || parts[0] != "AQUA-EVENT-1") throw IOException("Malformed journal record")
        val payload = parts.subList(1, 11).joinToString("\t")
        if (sha256(payload) != parts[11]) throw IOException("Journal checksum mismatch")
        val f = parts.subList(1, 11).map { String(Base64.getUrlDecoder().decode(it), StandardCharsets.UTF_8) }
        if (f.size != 10) throw IOException("Wrong journal field count")
        try {
            return ResearchEvent(EventId(f[1]), f[2].toLong(), f[3], f[4], f[5], EventOutcome.valueOf(f[6]),
                f[7].takeIf { it.isNotEmpty() }?.let(::TaskId), f[8], f[9], f[0].toLong())
        } catch (e: Exception) { throw IOException("Invalid journal data", e) }
    }
    private fun sha256(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(StandardCharsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
