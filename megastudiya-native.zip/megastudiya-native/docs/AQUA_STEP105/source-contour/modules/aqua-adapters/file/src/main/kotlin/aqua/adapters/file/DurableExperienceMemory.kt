package aqua.adapters.file

import aqua.experience.*
import java.io.File
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Base64

/** Checksummed, atomically rewritten local store for experience insights. */
class DurableExperienceMemory(private val file: File) : ExperienceMemoryRepository {
    private val lock = Any()
    private val records = linkedMapOf<ExperienceId, ExperienceInsight>()
    init { synchronized(lock) { load() } }

    override fun save(insight: ExperienceInsight): ExperienceInsight = synchronized(lock) {
        val existing = records[insight.id]
        if (existing != null) return@synchronized existing
        records[insight.id] = insight
        persist()
        insight
    }
    override fun get(id: ExperienceId): ExperienceInsight? = synchronized(lock) { records[id] }
    override fun list(status: ExperienceReviewStatus?): List<ExperienceInsight> = synchronized(lock) {
        records.values.filter { status == null || it.reviewStatus == status }.toList()
    }
    override fun updateReview(id: ExperienceId, status: ExperienceReviewStatus): ExperienceInsight? = synchronized(lock) {
        val old = records[id] ?: return@synchronized null
        val updated = old.copy(reviewStatus = status)
        records[id] = updated
        persist()
        updated
    }

    private fun load() {
        if (!file.exists()) return
        file.readLines(StandardCharsets.UTF_8).forEachIndexed { index, line ->
            if (line.isBlank()) return@forEachIndexed
            val parts = line.split('|')
            require(parts.size == 2) { "Invalid experience record at line ${index + 1}" }
            val payload = decode(parts[0])
            require(checksum(payload) == parts[1]) { "Experience checksum mismatch at line ${index + 1}" }
            val fields = payload.split('\t')
            require(fields.size == 8) { "Invalid experience payload at line ${index + 1}" }
            val item = ExperienceInsight(ExperienceId(fields[0]), ExperienceKind.valueOf(fields[1]), fields[2],
                fields[3].split(',').filter { it.isNotEmpty() }.toSet(), fields[4].toInt(), fields[5].toInt(),
                ExperienceReviewStatus.valueOf(fields[6]), fields[7].toLong())
            records[item.id] = item
        }
    }
    private fun persist() {
        file.parentFile?.mkdirs()
        val content = records.values.joinToString("\n", postfix = if (records.isEmpty()) "" else "\n") { item ->
            val payload = listOf(item.id.value, item.kind.name, item.statement, item.evidenceEventIds.sorted().joinToString(","),
                item.evidenceCount.toString(), item.confidenceScore.toString(), item.reviewStatus.name, item.createdAtEpochMs.toString()).joinToString("\t")
            "${encode(payload)}|${checksum(payload)}"
        }
        val temp = File(file.parentFile ?: File("."), file.name + ".tmp")
        temp.writeText(content, StandardCharsets.UTF_8)
        if (!temp.renameTo(file)) {
            file.writeText(content, StandardCharsets.UTF_8)
            temp.delete()
        }
    }
    private fun encode(s: String) = Base64.getEncoder().encodeToString(s.toByteArray(StandardCharsets.UTF_8))
    private fun decode(s: String) = String(Base64.getDecoder().decode(s), StandardCharsets.UTF_8)
    private fun checksum(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(StandardCharsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
