package aqua.adapters.file

import aqua.planning.*
import aqua.planning.storage.*
import java.io.File
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Base64

/** Checksummed atomic snapshot store for plans and their lifecycle history. */
class DurableTaskPlanRepository(private val file:File):TaskPlanRepository {
 private val lock=Any();private val items=linkedMapOf<String,StoredTaskPlan>();init{synchronized(lock){load()}}
 override fun save(planId:String,plan:TaskPlan,nowEpochMs:Long)=synchronized(lock){require(planId.isNotBlank());val old=items[planId];if(old!=null){require(old.plan==plan){"Plan ID already exists with different content"};old}else StoredTaskPlan(planId,plan,1,StoredPlanStatus.SAVED,nowEpochMs).also{items[planId]=it;persist()}}
 override fun get(planId:String)=synchronized(lock){items[planId]}
 override fun list(taskId:String?)=synchronized(lock){items.values.filter{taskId==null||it.plan.taskId==taskId}.toList()}
 override fun changeStatus(planId:String,status:StoredPlanStatus,nowEpochMs:Long,note:String)=synchronized(lock){val old=items[planId]?:return@synchronized null;if(old.status==status)return@synchronized old;val updated=old.copy(version=old.version+1,status=status,history=old.history+PlanStatusChange(status,nowEpochMs,note));items[planId]=updated;persist();updated}
 private fun load(){if(!file.exists())return;file.readLines(StandardCharsets.UTF_8).forEachIndexed{i,line->if(line.isBlank())return@forEachIndexed;val p=line.split('|');require(p.size==2){"Invalid task-plan record ${i+1}"};val payload=dec(p[0]);require(hash(payload)==p[1]){"Task-plan checksum mismatch at line ${i+1}"};val f=payload.split('\t');require(f.size==9){"Malformed task-plan record ${i+1}"};val plan=parsePlan(f[1]);val history=f[8].takeIf{it.isNotEmpty()}?.split(';')?.map{val h=it.split(',');PlanStatusChange(StoredPlanStatus.valueOf(h[0]),h[1].toLong(),dec(h[2]))}.orEmpty();val item=StoredTaskPlan(dec(f[0]),plan,f[2].toInt(),StoredPlanStatus.valueOf(f[3]),f[4].toLong(),history);items[item.planId]=item}}
 private fun persist(){file.parentFile?.mkdirs();val content=items.values.joinToString("\n",postfix=if(items.isEmpty())"" else "\n"){s->val payload=listOf(enc(s.planId),encPlan(s.plan),s.version.toString(),s.status.name,s.savedAtEpochMs.toString(),"","","",s.history.joinToString(";"){listOf(it.status.name,it.changedAtEpochMs.toString(),enc(it.note)).joinToString(",")}).joinToString("\t");"${enc(payload)}|${hash(payload)}"};val tmp=File(file.parentFile?:File("."),file.name+".tmp");tmp.writeText(content,StandardCharsets.UTF_8);if(!tmp.renameTo(file)){file.writeText(content,StandardCharsets.UTF_8);tmp.delete()}}
 private fun encPlan(p:TaskPlan):String {val fields=mutableListOf(p.taskId,p.goal,p.constraints.joinToString("\u001e"),p.successCriteria.joinToString("\u001e"),p.contextMemoryIds.joinToString("\u001e"),p.contextWarnings.joinToString("\u001e"),p.planningWarnings.joinToString("\u001e"),p.status.name);fields+=p.steps.joinToString("\u001d"){s->listOf(s.order.toString(),s.draft.id,s.draft.description,s.draft.expectedResult,s.draft.completionCriteria.joinToString("\u001e"),s.draft.dependsOn.joinToString("\u001e"),s.draft.riskNotes.joinToString("\u001e")).joinToString("\u001c", transform=::enc)};return fields.joinToString("\u001b"){enc(it)} }
 private fun parsePlan(encoded:String):TaskPlan {val f=encoded.split('\u001b').map(::dec);require(f.size==9);val steps=f[8].takeIf{it.isNotEmpty()}?.split('\u001d')?.map{z->val a=z.split('\u001c').map(::dec);PlannedStep(a[0].toInt(),PlanStepDraft(a[1],a[2],a[3],splitList(a[4]),splitList(a[5]),splitList(a[6])))}.orEmpty();return TaskPlan(f[0],f[1],splitList(f[2]),steps,splitList(f[3]),splitList(f[4]),splitList(f[5]),splitList(f[6]),PlanStatus.valueOf(f[7]))}
 private fun splitList(s:String)=s.takeIf{it.isNotEmpty()}?.split('\u001e').orEmpty()
 private fun enc(s:String)=Base64.getEncoder().encodeToString(s.toByteArray(StandardCharsets.UTF_8))
 private fun dec(s:String)=if(s.isEmpty()) "" else String(Base64.getDecoder().decode(s),StandardCharsets.UTF_8)
 private fun hash(s:String)=MessageDigest.getInstance("SHA-256").digest(s.toByteArray(StandardCharsets.UTF_8)).joinToString(""){"%02x".format(it)}
}
