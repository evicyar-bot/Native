package aqua.adapters.file

import aqua.dataformat.*
import aqua.ports.*
import aqua.research.*

/** Shared persistence coordinator; separate port adapters avoid JVM signature collisions. */
class DurableResearchRepositories(private val store: DurableBundleStore, private val storageKey: String, private val clock: () -> Long = System::currentTimeMillis) {
    val evidence: EvidenceRepository = EvidencePort()
    val claim: ClaimRepository = ClaimPort()
    val decision: DecisionRepository = DecisionPort()
    private val lock = Any()
    private var sources = linkedMapOf<SourceId,EvidenceSource>()
    private var claims = linkedMapOf<ClaimId,Claim>()
    private var decisions = linkedMapOf<DecisionId,ResearchDecision>()
    private var loaded=false
    private var lastFailure:String?=null
    fun initialize():Boolean=synchronized(lock){ if(loaded) return@synchronized lastFailure==null; when(val r=store.load(storageKey)){ is StoreLoadResult.Missing->{loaded=true;true}; is StoreLoadResult.Loaded->{replace(r.bundle);loaded=true;lastFailure=null;true};is StoreLoadResult.Failed->{lastFailure=r.reason;false} } }
    fun error():String?=synchronized(lock){lastFailure}
    fun recover():Boolean=synchronized(lock){when(val r=store.recover(storageKey)){is StoreLoadResult.Loaded->{replace(r.bundle);loaded=true;lastFailure=null;true};is StoreLoadResult.Missing->false;is StoreLoadResult.Failed->{lastFailure=r.reason;false}}}
    fun removeTask(task:TaskId):Int=synchronized(lock){ensure();val ns=sources.filterValues{it.taskId!=task}.toMutableMap();val nc=claims.filterValues{it.taskId!=task}.toMutableMap();val nd=decisions.filterValues{it.taskId!=task}.toMutableMap();val n=sources.size-ns.size+claims.size-nc.size+decisions.size-nd.size;if(n==0)return@synchronized 0;if(commit(ns,nc,nd){sources=ns.toLinkedMap();claims=nc.toLinkedMap();decisions=nd.toLinkedMap()}) n else -1}
    private inner class EvidencePort:EvidenceRepository {
        override fun list(taskId:TaskId?)=synchronized(lock){ensure();sources.values.filter{taskId==null||it.taskId==taskId}}
        override fun find(id:SourceId)=synchronized(lock){ensure();sources[id]}
        override fun upsert(source:EvidenceSource)=synchronized(lock){ensure();val n=sources.toMutableMap().apply{put(source.id,source)};commit(n,claims,decisions){sources=n.toLinkedMap()}}
        override fun removeTask(taskId:TaskId)=this@DurableResearchRepositories.removeTask(taskId)
    }
    private inner class ClaimPort:ClaimRepository {
        override fun list(taskId:TaskId?)=synchronized(lock){ensure();claims.values.filter{taskId==null||it.taskId==taskId}}
        override fun find(id:ClaimId)=synchronized(lock){ensure();claims[id]}
        override fun upsert(claim:Claim)=synchronized(lock){ensure();if(claim.evidenceSourceIds.any{sources[it]?.taskId!=claim.taskId})return@synchronized false;val n=claims.toMutableMap().apply{put(claim.id,claim)};commit(sources,n,decisions){claims=n.toLinkedMap()}}
        override fun removeTask(taskId:TaskId)=this@DurableResearchRepositories.removeTask(taskId)
    }
    private inner class DecisionPort:DecisionRepository {
        override fun list(taskId:TaskId?)=synchronized(lock){ensure();decisions.values.filter{taskId==null||it.taskId==taskId}}
        override fun find(id:DecisionId)=synchronized(lock){ensure();decisions[id]}
        override fun upsert(decision:ResearchDecision)=synchronized(lock){ensure();if(decision.claimId?.let{claims[it]?.taskId!=decision.taskId}==true)return@synchronized false;val n=decisions.toMutableMap().apply{put(decision.id,decision)};commit(sources,claims,n){decisions=n.toLinkedMap()}}
        override fun removeTask(taskId:TaskId)=this@DurableResearchRepositories.removeTask(taskId)
    }
    private fun commit(s:Map<SourceId,EvidenceSource>,c:Map<ClaimId,Claim>,d:Map<DecisionId,ResearchDecision>,publish:()->Unit):Boolean {
        val b=ResearchBundleFormat.seal(ResearchBundle(ResearchBundleFormat.CURRENT_SCHEMA,clock(),s.values.toList(),c.values.toList(),d.values.toList()));val v=ResearchBundleFormat.validate(b);if(!v.valid){lastFailure=v.errors.joinToString();return false}
        return when(val r=store.save(b,storageKey)){is StoreSaveResult.Saved->{publish();lastFailure=null;true};is StoreSaveResult.Failed->{lastFailure=r.reason;false}}
    }
    private fun ensure(){if(!loaded)check(initialize()){"Repository load failed: $lastFailure"}}
    private fun replace(b:ResearchBundle){sources=b.sources.associateByTo(linkedMapOf()){it.id};claims=b.claims.associateByTo(linkedMapOf()){it.id};decisions=b.decisions.associateByTo(linkedMapOf()){it.id}}
    private fun <K,V> Map<K,V>.toLinkedMap()=LinkedHashMap(this)
}
