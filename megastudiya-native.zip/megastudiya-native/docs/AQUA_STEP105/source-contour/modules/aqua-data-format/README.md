# AQUA Research Bundle format

Schema version 1 is a portable typed bundle for Evidence Sources, Claims, Decisions and decision history.

## Core format
- Stable canonical representation + SHA-256 integrity checksum.
- Validation rejects duplicate IDs, missing evidence/claim references, cross-task references, missing/tampered checksums and unsupported schema versions.
- Schema 0 -> 1 migration preserves records and reseals.
- Checksum detects accidental/tampered content changes but is not authentication or provenance proof.

## Actual transfer (Step 24)
`ResearchBundleJsonCodec` encodes/decodes real UTF-8 JSON bytes without external libraries. `ResearchBundleFileTransfer` validates before export/import, limits files to 5 MiB, writes a temporary file then atomically replaces (fallback supported), retains the previous export as `.bak`, and validates a backup before restore. The parser rejects duplicate keys, malformed JSON, trailing content and invalid data structures.

The module remains platform-independent: it has no Android or MegaStudio dependencies. The file transfer API uses `java.nio.file.Path`; a future host integration should adapt storage access without changing domain DTOs or codec behavior.
