# AQUA / MegaStudio separation

**AQUA is the source of truth for AQUA modules.** Do not develop features inside the full MegaStudio tree unless an explicit integration task is assigned.

## Integration contract
MegaStudio must consume AQUA through a narrow adapter boundary. AQUA must not import MegaStudio packages, UI types, app-wide ViewModels, or app-specific services. Host services are injected through interfaces.

## Module layers
1. `aqua-domain`: domain records and validation (planned)
2. `aqua-storage`: persistence abstractions and implementations (planned)
3. `aqua-research`: tasks, evidence, claims, criteria, coverage, reports, decision journal (existing code is being extracted progressively)
4. `aqua-knowledge-graph`: graph model and relationship queries (Step 20)
5. `aqua-ui`: UI independent from host (planned)
6. `aqua-adapters-*`: optional host integration; MegaStudio is one adapter only

## Rules
- Keep graph links scoped to task ID when known.
- Preserve provenance; no graph edge implies truth or endorsement.
- Mark inferred relationships separately from explicitly entered links.
- Export/import should use versioned JSON and never require MegaStudio.
- Never report Android compile/runtime success without actually building/running.
