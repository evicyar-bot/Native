package app.megastudiya.nativeapp

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.round
import kotlin.math.sqrt

// ЯДРО (эмбрион), шаг 2: замкнутый цикл развития.
//  чувствует (сигналы ленты) → действует (желания → запросы ленты) → оценивает (отклик, ошибка прогноза)
//  → помнит (SQLite) → МЕНЯЕТ СЕБЯ (новые стратегии как данные) → оставляет лучшее или откатывает.
// Стратегия — это строка в таблице rule (источник кандидатов, порог, способ выбора), а не код.
// Код исполняет только Страж, поэтому изменения безопасны и откатываются удалением строки.
// Новая стратегия идёт «на испытание»: ей даётся шанс, и если отклик не лучше среднего, она отвергается.
// Три исходные стратегии (родитель пустой) удалить нельзя.
// Страж: свой поток с низким приоритетом, только пока приложение на экране, лимит 500 циклов в сутки,
// самовыключение при сбоях, ежедневная копия памяти с восстановлением. Раздел «Предназначение» пуст.
internal class CoreDb(ctx: Context) : SQLiteOpenHelper(ctx, "core.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE ev(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, key TEXT, d REAL, err REAL)")
        db.execSQL("CREATE TABLE tagw(t TEXT PRIMARY KEY, w REAL, n INTEGER, ts INTEGER)")
        db.execSQL("CREATE TABLE edge(a TEXT, b TEXT, w REAL, PRIMARY KEY(a, b))")
        db.execSQL("CREATE TABLE arm(name TEXT PRIMARY KEY, n INTEGER, s REAL)")
        db.execSQL("CREATE TABLE prio(name TEXT PRIMARY KEY, w REAL, why TEXT, ts INTEGER)")
        db.execSQL("CREATE TABLE want(t TEXT PRIMARY KEY, arm TEXT, ts INTEGER, state INTEGER)") // 0 открыто, 1 откликнулись, 2 не сбылось
        db.execSQL("CREATE TABLE q(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, text TEXT)")
        db.execSQL("CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT)")
        db.execSQL("CREATE TABLE purpose(id INTEGER PRIMARY KEY, text TEXT)") // пустое: пишет сама система вместе с владельцем
        evoTables(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        if (o < 3) evoTables(db)
    }

    private fun evoTables(db: SQLiteDatabase) {
        // status: 0 испытание, 1 принята, 2 отвергнута или откачена
        db.execSQL("CREATE TABLE IF NOT EXISTS rule(id TEXT PRIMARY KEY, src TEXT, thr REAL, np INTEGER, pick TEXT, prio TEXT, status INTEGER, parent TEXT, born INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS evo(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, text TEXT)")
        // мягкие лимиты: значение v она может поднимать сама, но не выше потолка hi (его меняет только владелец)
        db.execSQL("CREATE TABLE IF NOT EXISTS lim(name TEXT PRIMARY KEY, v REAL, hi REAL, bite INTEGER, ts INTEGER)")
        // реестр потребностей: «что мне мешает» и «чего мне не хватает» со счётчиком, сколько раз упёрлась
        db.execSQL("CREATE TABLE IF NOT EXISTS need(name TEXT PRIMARY KEY, cnt INTEGER, text TEXT, ts INTEGER)")
    }
}

private fun SQLiteDatabase.int(sql: String, vararg a: String): Int =
    rawQuery(sql, arrayOf(*a)).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }

private fun SQLiteDatabase.str(sql: String, vararg a: String): String? =
    rawQuery(sql, arrayOf(*a)).use { c -> if (c.moveToFirst() && !c.isNull(0)) c.getString(0) else null }

private fun SQLiteDatabase.flt(sql: String, vararg a: String): Float? =
    rawQuery(sql, arrayOf(*a)).use { c -> if (c.moveToFirst() && !c.isNull(0)) c.getFloat(0) else null }

private fun SQLiteDatabase.meta(k: String): String? = str("SELECT v FROM meta WHERE k=?", k)

private fun SQLiteDatabase.setMeta(k: String, v: String) {
    execSQL("INSERT OR REPLACE INTO meta(k,v) VALUES(?,?)", arrayOf<Any>(k, v))
}

object Core {
    private const val DAY = 86_400_000L
    private var db: CoreDb? = null
    private var app: Context? = null
    private var started = false
    private var fails = 0
    private var cool = 0
    private val rnd = java.util.Random()

    @Volatile private var active = false

    @Volatile var enabled = true
        private set

    @Volatile var report = "Ядро: просыпается…"
        private set

    private val io = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "ms-core").apply { priority = Thread.MIN_PRIORITY; isDaemon = true }
    }

    private val basePrio = listOf("нехватка данных", "любопытство", "осторожность")
    // какой приоритет питает стратегия с данным источником кандидатов
    private val prioOfSrc = mapOf("pos" to "нехватка данных", "new" to "любопытство", "surp" to "осторожность", "nb" to "любопытство")
    private val srcName = mapOf("pos" to "сильные слова", "new" to "новые слова", "surp" to "неожиданное", "nb" to "соседи сильных слов")

    // мягкие лимиты: начальное значение, потолок, как она это называет
    private val limInfo = mapOf(
        "cycles" to Triple(500f, 1440f, "суточный запас размышлений"),
        "wants" to Triple(3f, 12f, "число желаний одновременно"),
        "rules" to Triple(10f, 40f, "число живых стратегий")
    )

    private fun lim(w: SQLiteDatabase, name: String): Int = (w.flt("SELECT v FROM lim WHERE name=?", name) ?: limInfo[name]!!.first).toInt()

    private fun need(w: SQLiteDatabase, name: String, text: String, now: Long) {
        w.execSQL("INSERT OR IGNORE INTO need(name,cnt,text,ts) VALUES(?,0,?,?)", arrayOf<Any>(name, text, now))
        w.execSQL("UPDATE need SET cnt=cnt+1, ts=? WHERE name=?", arrayOf<Any>(now, name))
    }

    // Лимит «укусил»: она упёрлась в него. Счёт нужен, чтобы расширять только то, что действительно мешает
    private fun bite(w: SQLiteDatabase, name: String, now: Long) {
        w.execSQL("UPDATE lim SET bite=bite+1, ts=? WHERE name=?", arrayOf<Any>(now, name))
        need(w, "lim:$name", "Мне мешает: " + (limInfo[name]?.third ?: name), now)
    }

    // Рост: если лимит мешал много раз и результаты не плохие, она расширяет его сама, но не выше потолка
    private fun grow(w: SQLiteDatabase, now: Long) {
        var n = 0
        var s = 0f
        w.rawQuery("SELECT COALESCE(SUM(n),0),COALESCE(SUM(s),0) FROM arm", null).use { c -> if (c.moveToFirst()) { n = c.getInt(0); s = c.getFloat(1) } }
        val rate = (s + 1f) / (n + 2f)
        for ((name, info) in limInfo) {
            var v = 0f
            var hi = 0f
            var b = 0
            w.rawQuery("SELECT v,hi,bite FROM lim WHERE name=?", arrayOf(name)).use { c ->
                if (c.moveToFirst()) { v = c.getFloat(0); hi = c.getFloat(1); b = c.getInt(2) }
            }
            if (b < 20) continue
            if (v < hi && rate >= 0.15f) {
                val nv = minOf(hi, v * 1.25f + 1f)
                w.execSQL("UPDATE lim SET v=?, bite=0, ts=? WHERE name=?", arrayOf<Any>(nv, now, name))
                note(w, now, "Мне мешало: ${info.third}, упёрлась $b раз. Расширила: ${v.toInt()} → ${nv.toInt()}")
            } else if (v >= hi) {
                need(w, "cap:$name", "Упёрлась в потолок: " + info.third + ". Решать владельцу", now)
            }
        }
    }

    private class Arm(val id: String, val n: Int, val s: Float, val prio: String)
    private class Rule(val id: String, val src: String, val thr: Float, val np: Int, val pick: String, val prio: String, val status: Int, val parent: String, val n: Int, val s: Float)

    // Страж: любой сбой не должен задеть приложение; пять подряд — ядро само выключается до следующего запуска
    private fun guard(b: () -> Unit) {
        try {
            b()
            fails = 0
        } catch (_: Throwable) {
            fails++
            if (fails >= 5) enabled = false
        }
    }

    fun start(ctx: Context) {
        if (started) return
        started = true
        val a = ctx.applicationContext
        app = a
        enabled = a.getSharedPreferences("ms", Context.MODE_PRIVATE).getBoolean("coreOn", true)
        io.execute { guard { open(a) } }
        io.scheduleWithFixedDelay({ tick() }, 45, 60, TimeUnit.SECONDS)
    }

    // Ядро думает, только пока приложение на экране
    fun setActive(v: Boolean) {
        active = v
    }

    private fun tryOpen(a: Context): CoreDb {
        val h = CoreDb(a)
        h.writableDatabase.rawQuery("SELECT COUNT(*) FROM meta", null).use { it.moveToFirst() }
        return h
    }

    private fun open(a: Context) {
        val f = a.getDatabasePath("core.db")
        val bak = File(f.parentFile, "core.db.bak")
        val h = try {
            tryOpen(a)
        } catch (_: Throwable) {
            // память повреждена: возвращаем вчерашнюю копию
            runCatching { db?.close() }
            f.delete()
            if (bak.exists()) bak.copyTo(f, overwrite = true)
            tryOpen(a)
        }
        db = h
        val w = h.writableDatabase
        val now = System.currentTimeMillis()
        for (n in basePrio) w.execSQL("INSERT OR IGNORE INTO prio(name,w,why,ts) VALUES(?,1.0,'старт',?)", arrayOf<Any>(n, now))
        // три исходные стратегии (родитель пустой): это «геном», его не удаляют
        val seeds = listOf(
            arrayOf<Any>("gap", "pos", 0.3, 2, "least_edges"),
            arrayOf<Any>("novelty", "new", 0.0, 2, "random"),
            arrayOf<Any>("surprise", "surp", 0.0, 0, "random")
        )
        for (s in seeds) {
            val src = s[1] as String
            w.execSQL(
                "INSERT OR IGNORE INTO rule(id,src,thr,np,pick,prio,status,parent,born) VALUES(?,?,?,?,?,?,1,'',?)",
                arrayOf<Any>(s[0], src, s[2], s[3], s[4], prioOfSrc[src] ?: basePrio[0], now)
            )
            w.execSQL("INSERT OR IGNORE INTO arm(name,n,s) VALUES(?,0,0)", arrayOf<Any>(s[0]))
        }
        for ((n, i) in limInfo) w.execSQL("INSERT OR IGNORE INTO lim(name,v,hi,bite,ts) VALUES(?,?,?,0,?)", arrayOf<Any>(n, i.first, i.second, now))
        backup(a, w)
        refreshReport(w)
    }

    private fun backup(a: Context, w: SQLiteDatabase) {
        val day = (System.currentTimeMillis() / DAY).toString()
        if (w.meta("bak") == day) return
        val ok = w.rawQuery("PRAGMA integrity_check", null).use { c -> c.moveToFirst() && c.getString(0) == "ok" }
        if (!ok) return
        val f = a.getDatabasePath("core.db")
        f.copyTo(File(f.parentFile, "core.db.bak"), overwrite = true)
        w.setMeta("bak", day)
    }

    // ===== Питание: сигнал из ленты. d > 0 нравится, d < 0 не нравится =====
    fun observe(text: String, src: String, d: Float) {
        if (!enabled || !started) return
        io.execute { guard { learn(text, d) } }
    }

    private fun learn(text: String, d: Float) {
        val w = db?.writableDatabase ?: return
        val tg = Taste.tags(text).take(12)
        if (tg.isEmpty()) return
        val ws = HashMap<String, Float>()
        for (t in tg) ws[t] = w.flt("SELECT w FROM tagw WHERE t=?", t) ?: 0f
        val n = sqrt(tg.size.toFloat())
        val pred = ws.values.sum() / n                 // что она ожидала
        val target = d.coerceIn(-2f, 2f)               // что оказалось
        val err = target - pred                        // удивление
        val now = System.currentTimeMillis()
        w.beginTransaction()
        try {
            for (t in tg) {
                val nw = ((ws[t] ?: 0f) + 0.15f * err / n).coerceIn(-3f, 3f)
                w.execSQL("INSERT OR IGNORE INTO tagw(t,w,n,ts) VALUES(?,0,0,?)", arrayOf<Any>(t, now))
                w.execSQL("UPDATE tagw SET w=?, n=n+1, ts=? WHERE t=?", arrayOf<Any>(nw, now, t))
            }
            if (d > 0f) {
                // связи между словами, которые встретились вместе в понравившемся
                val top = tg.take(6)
                for (i in top.indices) for (j in i + 1 until top.size) {
                    val a = if (top[i] < top[j]) top[i] else top[j]
                    val b = if (top[i] < top[j]) top[j] else top[i]
                    w.execSQL("INSERT OR IGNORE INTO edge(a,b,w) VALUES(?,?,0)", arrayOf<Any>(a, b))
                    w.execSQL("UPDATE edge SET w=w+? WHERE a=? AND b=?", arrayOf<Any>(d.coerceAtMost(2f), a, b))
                }
                // отклик на её желание: стратегия, которая его породила, получает награду
                for (t in tg) {
                    val arm = w.str("SELECT arm FROM want WHERE t=? AND state=0", t) ?: continue
                    w.execSQL("UPDATE want SET state=1 WHERE t=?", arrayOf<Any>(t))
                    w.execSQL("UPDATE arm SET s=s+1 WHERE name=?", arrayOf<Any>(arm))
                }
            }
            w.execSQL("INSERT INTO ev(ts,key,d,err) VALUES(?,?,?,?)", arrayOf<Any>(now, tg[0], d, err))
            // самооценка: скользящая средняя ошибки прогноза и её значение через 30 сигналов (точка отсчёта)
            val ema = (w.meta("ema")?.toFloatOrNull() ?: abs(err)) * 0.95f + abs(err) * 0.05f
            w.setMeta("ema", ema.toString())
            val ne = (w.meta("ne")?.toIntOrNull() ?: 0) + 1
            w.setMeta("ne", ne.toString())
            if (ne == 30) w.setMeta("ema0", ema.toString())
            w.setTransactionSuccessful()
        } finally {
            w.endTransaction()
        }
    }

    // ===== Цикл: проверить бюджет → выбрать стратегию → породить желание → иногда уснуть и измениться =====
    private fun tick() {
        if (!enabled || !active || !started) return
        if (cool > 0) { cool--; return }
        val t0 = System.nanoTime()
        guard { db?.writableDatabase?.let { cycle(it) } }
        // Страж: цикл дороже 80 мс — отдыхаем 10 минут
        if ((System.nanoTime() - t0) / 1_000_000L > 80) cool = 10
    }

    private fun cycle(w: SQLiteDatabase) {
        val now = System.currentTimeMillis()
        val day = (now / DAY).toString()
        if (w.meta("cday") != day) { w.setMeta("cday", day); w.setMeta("cn", "0") }
        val cn = w.meta("cn")?.toIntOrNull() ?: 0
        if (cn >= lim(w, "cycles")) { bite(w, "cycles", now); return } // суточный запас размышлений
        w.setMeta("cn", (cn + 1).toString())
        w.execSQL("UPDATE want SET state=2 WHERE state=0 AND ts<?", arrayOf<Any>(now - 3 * DAY)) // не откликнулись за 3 суток
        val openWants = w.int("SELECT COUNT(*) FROM want WHERE state=0")
        if (openWants >= lim(w, "wants")) bite(w, "wants", now)
        if (openWants < lim(w, "wants")) {
            val arm = pickArm(w)
            if (arm != null) {
                val t = candidate(w, arm, now)
                if (t != null) {
                    w.execSQL("INSERT OR REPLACE INTO want(t,arm,ts,state) VALUES(?,?,?,0)", arrayOf<Any>(t, arm, now))
                    w.execSQL("UPDATE arm SET n=n+1 WHERE name=?", arrayOf<Any>(arm))
                } else {
                    need(w, "nocand:$arm", "Мне не хватает данных: стратегия «$arm» не нашла, что исследовать", now)
                }
            }
        }
        val tot = (w.meta("tot")?.toIntOrNull() ?: 0) + 1
        w.setMeta("tot", tot.toString())
        if (tot % 40 == 0) {
            app?.let { backup(it, w) } // сначала копия, потом перемены
            sleep(w, now)
            grow(w, now)
            evolve(w, now)
        }
        refreshReport(w)
    }

    // Бандит UCB: средняя награда + бонус за малую изученность, с поправкой на вес приоритета.
    // Стратегии на испытании участвуют наравне с принятыми.
    private fun pickArm(w: SQLiteDatabase): String? {
        val total = w.int("SELECT COALESCE(SUM(n),0) FROM arm")
        val arms = ArrayList<Arm>()
        w.rawQuery("SELECT a.name,a.n,a.s,r.prio FROM arm a JOIN rule r ON r.id=a.name WHERE r.status<2", null).use { c ->
            while (c.moveToNext()) arms.add(Arm(c.getString(0), c.getInt(1), c.getFloat(2), c.getString(3)))
        }
        var best: String? = null
        var bs = -1e9f
        for (a in arms) {
            val pw = w.flt("SELECT w FROM prio WHERE name=?", a.prio) ?: 1f
            val sc = ((a.s + 1f) / (a.n + 2f) + 0.3f * sqrt(2f * ln(total + 2f) / (a.n + 1f)) + rnd.nextFloat() * 0.05f) * pw
            if (sc > bs) { bs = sc; best = a.id }
        }
        return best
    }

    // Стратегия исполняется по её описанию (данные), всегда готовыми шаблонами с параметрами
    private fun candidate(w: SQLiteDatabase, id: String, now: Long): String? {
        var src = ""; var thr = 0f; var np = 0; var pick = "random"
        w.rawQuery("SELECT src,thr,np,pick FROM rule WHERE id=?", arrayOf(id)).use { c ->
            if (!c.moveToFirst()) return null
            src = c.getString(0); thr = c.getFloat(1); np = c.getInt(2); pick = c.getString(3)
        }
        val th = thr.toString()
        val pool = ArrayList<String>()
        val sql: String
        val args: Array<String>
        when (src) {
            "pos" -> { sql = "SELECT t FROM tagw WHERE w>? AND n>=? ORDER BY w DESC LIMIT 15"; args = arrayOf(th, np.toString()) }
            "new" -> { sql = "SELECT t FROM tagw WHERE w>? AND n<=? ORDER BY ts DESC LIMIT 15"; args = arrayOf(th, np.toString()) }
            "nb" -> {
                sql = "SELECT CASE WHEN a IN (SELECT t FROM tagw WHERE w>?) THEN b ELSE a END FROM edge " +
                    "WHERE a IN (SELECT t FROM tagw WHERE w>?) OR b IN (SELECT t FROM tagw WHERE w>?) ORDER BY w DESC LIMIT 15"
                args = arrayOf(th, th, th)
            }
            else -> { sql = "SELECT key FROM ev WHERE ts>? ORDER BY ABS(err) DESC LIMIT 15"; args = arrayOf((now - 3 * DAY).toString()) }
        }
        w.rawQuery(sql, args).use { c -> while (c.moveToNext()) pool.add(c.getString(0)) }
        val recent = (now - 7 * DAY).toString()
        val ok = pool.distinct().filter { t ->
            (t.startsWith("#") || t.length >= 5) && w.int("SELECT COUNT(*) FROM want WHERE t=? AND ts>?", t, recent) == 0
        }
        if (ok.isEmpty()) return null
        return when (pick) {
            "least_edges" -> ok.minByOrNull { t -> w.int("SELECT COUNT(*) FROM edge WHERE a=? OR b=?", t, t) } // «пробел»: меньше всего связей
            "top" -> ok[0]
            else -> ok[rnd.nextInt(ok.size)]
        }
    }

    // Сон: забыть мусор, пересмотреть приоритеты по результатам, записать вопрос себе
    private fun sleep(w: SQLiteDatabase, now: Long) {
        w.execSQL("UPDATE tagw SET w=w*0.98")
        w.execSQL("DELETE FROM tagw WHERE ABS(w)<0.03 AND n<3")
        w.execSQL("UPDATE edge SET w=w*0.97")
        w.execSQL("DELETE FROM edge WHERE w<0.2")
        w.execSQL("DELETE FROM ev WHERE id NOT IN (SELECT id FROM ev ORDER BY id DESC LIMIT 3000)")
        w.execSQL("DELETE FROM want WHERE state<>0 AND ts<?", arrayOf<Any>(now - 30 * DAY))
        var best = ""
        var bw = 0f
        for (pn in basePrio) {
            var n = 0
            var s = 0f
            w.rawQuery(
                "SELECT COALESCE(SUM(a.n),0),COALESCE(SUM(a.s),0) FROM arm a JOIN rule r ON r.id=a.name WHERE r.status<2 AND r.prio=?",
                arrayOf(pn)
            ).use { c -> if (c.moveToFirst()) { n = c.getInt(0); s = c.getFloat(1) } }
            if (n < 3) continue
            val rate = (s + 1f) / (n + 2f)
            val old = w.flt("SELECT w FROM prio WHERE name=?", pn) ?: 1f
            val nw = (0.8f * old + 0.2f * rate * 2f).coerceIn(0.2f, 3f)
            if (abs(nw - old) > 0.02f) {
                w.execSQL("UPDATE prio SET w=?, why=?, ts=? WHERE name=?", arrayOf<Any>(nw, "отклик ${s.toInt()} из $n попыток", now, pn))
            }
            if (nw > bw) { bw = nw; best = pn }
        }
        if (best.isNotEmpty()) {
            w.execSQL("INSERT INTO q(ts,text) VALUES(?,?)", arrayOf<Any>(now, "Сейчас мне важнее всего: $best. Это то, что мне нужно?"))
        }
        w.execSQL("DELETE FROM q WHERE id NOT IN (SELECT id FROM q ORDER BY id DESC LIMIT 50)")
    }

    // ===== Развитие: испытать новые стратегии, принять лучшие, откатить худшие, придумать новую =====
    private fun describe(src: String, thr: Float, np: Int, pick: String): String =
        (srcName[src] ?: src) + ", порог " + thr + ", n " + np + ", выбор " + pick

    private fun note(w: SQLiteDatabase, now: Long, text: String) {
        w.execSQL("INSERT INTO evo(ts,text) VALUES(?,?)", arrayOf<Any>(now, text))
        w.execSQL("DELETE FROM evo WHERE id NOT IN (SELECT id FROM evo ORDER BY id DESC LIMIT 50)")
    }

    private fun evolve(w: SQLiteDatabase, now: Long) {
        val rules = ArrayList<Rule>()
        w.rawQuery(
            "SELECT r.id,r.src,r.thr,r.np,r.pick,r.prio,r.status,r.parent,a.n,a.s FROM rule r JOIN arm a ON a.name=r.id WHERE r.status<2",
            null
        ).use { c ->
            while (c.moveToNext()) {
                rules.add(Rule(c.getString(0), c.getString(1), c.getFloat(2), c.getInt(3), c.getString(4), c.getString(5), c.getInt(6), c.getString(7), c.getInt(8), c.getFloat(9)))
            }
        }
        // средний отклик принятых стратегий — планка для новых
        val seasoned = rules.filter { it.status == 1 && it.n >= 3 }
        val base = if (seasoned.isEmpty()) 0.25f else seasoned.map { (it.s + 1f) / (it.n + 2f) }.average().toFloat()
        // 1) суд над испытаниями и откат принятых
        for (r in rules) {
            val rate = (r.s + 1f) / (r.n + 2f)
            val d = describe(r.src, r.thr, r.np, r.pick)
            if (r.status == 0 && r.n >= 8) {
                if (rate > base) {
                    w.execSQL("UPDATE rule SET status=1 WHERE id=?", arrayOf<Any>(r.id))
                    note(w, now, "Принята ${r.id}: $d. Отклик ${"%.2f".format(rate)} выше среднего ${"%.2f".format(base)}")
                } else {
                    w.execSQL("UPDATE rule SET status=2 WHERE id=?", arrayOf<Any>(r.id))
                    note(w, now, "Отвергнута ${r.id}: $d. Отклик ${"%.2f".format(rate)} не выше среднего ${"%.2f".format(base)}")
                }
            } else if (r.status == 1 && r.parent.isNotEmpty() && r.n >= 15 && rate < base * 0.5f) {
                w.execSQL("UPDATE rule SET status=2 WHERE id=?", arrayOf<Any>(r.id))
                note(w, now, "Откат ${r.id}: $d. Отклик упал до ${"%.2f".format(rate)}")
            }
        }
        // 2) вариация: новая стратегия на испытание (не больше двух сразу, не больше десяти живых, нужны данные)
        if (w.int("SELECT COUNT(*) FROM rule WHERE status=0") >= 2) return
        if (w.int("SELECT COUNT(*) FROM rule WHERE status<2") >= lim(w, "rules")) {
            // место закончилось: вытесняем самую слабую из приобретённых, если она хуже среднего
            val weak = rules.filter { it.status == 1 && it.parent.isNotEmpty() && it.n >= 15 }.minByOrNull { (it.s + 1f) / (it.n + 2f) }
            if (weak == null || (weak.s + 1f) / (weak.n + 2f) >= base) {
                bite(w, "rules", now)
                return
            }
            w.execSQL("UPDATE rule SET status=2 WHERE id=?", arrayOf<Any>(weak.id))
            note(w, now, "Вытеснена ${weak.id}: слабее среднего, нужно место для новых")
        }
        if (w.int("SELECT COUNT(*) FROM ev") < 30) {
            need(w, "fewsig", "Мне не хватает ваших сигналов: без них я не могу придумывать новое", now)
            return
        }
        val parents = rules.filter { it.status == 1 }
        if (parents.isEmpty()) return
        val p = parents[rnd.nextInt(parents.size)]
        var src = p.src
        var thr = p.thr
        var np = p.np
        var pick = p.pick
        when (rnd.nextInt(3)) {
            0 -> { // сдвинуть пороги
                thr = if (thr < 0.05f) rnd.nextFloat() * 0.6f else thr * (0.6f + rnd.nextFloat())
                thr = (round(thr.coerceIn(0f, 1.5f) * 100f) / 100f)
                np = (np + rnd.nextInt(3) - 1).coerceIn(0, 6)
            }
            1 -> { // изменить способ выбора
                val o = listOf("least_edges", "random", "top").filter { it != pick }
                pick = o[rnd.nextInt(o.size)]
            }
            else -> { // взять другой источник кандидатов
                val o = listOf("pos", "new", "surp", "nb").filter { it != src }
                src = o[rnd.nextInt(o.size)]
            }
        }
        val dup = w.int(
            "SELECT COUNT(*) FROM rule WHERE src=? AND ABS(thr-?)<0.001 AND np=? AND pick=? AND status<2",
            src, thr.toString(), np.toString(), pick
        )
        if (dup > 0) return
        val id = "r" + (w.int("SELECT COUNT(*) FROM rule") + 1)
        w.execSQL(
            "INSERT INTO rule(id,src,thr,np,pick,prio,status,parent,born) VALUES(?,?,?,?,?,?,0,?,?)",
            arrayOf<Any>(id, src, thr, np, pick, prioOfSrc[src] ?: p.prio, p.id, now)
        )
        w.execSQL("INSERT OR IGNORE INTO arm(name,n,s) VALUES(?,0,0)", arrayOf<Any>(id))
        note(w, now, "Новая стратегия $id (от ${p.id}) на испытании: " + describe(src, thr, np, pick))
    }

    // Действие в среде: её желание превращается в запрос ленты (одно за обновление)
    fun wantQueries(ctx: Context): List<String> {
        if (!enabled) return emptyList()
        return try {
            val w = db?.readableDatabase ?: return emptyList()
            val t = w.str("SELECT t FROM want WHERE state=0 ORDER BY RANDOM() LIMIT 1") ?: return emptyList()
            val q = if (t.startsWith("#")) t.drop(1) else Taste.fullOf(ctx, t)
            if (q.length >= 4) listOf(q) else emptyList()
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun refreshReport(w: SQLiteDatabase) {
        val tot = w.meta("tot") ?: "0"
        val ema = w.meta("ema")?.toFloatOrNull()
        val ema0 = w.meta("ema0")?.toFloatOrNull()
        val pr = ArrayList<String>()
        w.rawQuery("SELECT name,w FROM prio ORDER BY w DESC", null).use { c ->
            while (c.moveToNext()) pr.add(c.getString(0) + " " + "%.1f".format(c.getFloat(1)))
        }
        val q = w.str("SELECT text FROM q ORDER BY id DESC LIMIT 1")
        val e = w.str("SELECT text FROM evo ORDER BY id DESC LIMIT 1")
        val nd = ArrayList<String>()
        w.rawQuery("SELECT text,cnt FROM need ORDER BY cnt DESC LIMIT 2", null).use { c -> while (c.moveToNext()) nd.add(c.getString(0) + " (×" + c.getInt(1) + ")") }
        report = "Ядро · циклов $tot · сигналов ${w.int("SELECT COUNT(*) FROM ev")} · слов ${w.int("SELECT COUNT(*) FROM tagw")} · связей ${w.int("SELECT COUNT(*) FROM edge")}\n" +
            "Желаний: открыто ${w.int("SELECT COUNT(*) FROM want WHERE state=0")}, сбылось ${w.int("SELECT COUNT(*) FROM want WHERE state=1")}, не сбылось ${w.int("SELECT COUNT(*) FROM want WHERE state=2")}\n" +
            "Стратегий: принято ${w.int("SELECT COUNT(*) FROM rule WHERE status=1")}, на испытании ${w.int("SELECT COUNT(*) FROM rule WHERE status=0")}, отвергнуто ${w.int("SELECT COUNT(*) FROM rule WHERE status=2")}\n" +
            "Ошибка прогноза вкуса: " + (if (ema == null) "ещё мало данных" else "%.2f".format(ema) + (if (ema0 != null) " (через 30 сигналов было %.2f)".format(ema0) else "")) + "\n" +
            "Приоритеты: " + pr.joinToString(" · ") +
            "\nЛимиты: циклов ${lim(w, "cycles")}, желаний ${lim(w, "wants")}, стратегий ${lim(w, "rules")}" +
            (if (nd.isNotEmpty()) "\nЧто мне мешает: " + nd.joinToString("; ") else "") +
            (if (e != null) "\nРазвитие: $e" else "") +
            (if (q != null) "\nВопрос себе: $q" else "")
    }
}
