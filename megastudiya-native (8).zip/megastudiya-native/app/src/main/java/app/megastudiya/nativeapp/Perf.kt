package app.megastudiya.nativeapp

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import org.json.JSONArray
import org.json.JSONObject

// Замеры: считаются сами, в фоне, на экран ленты ничего не выводят (смотреть: Я → Тест).
// «Цикл» = один запуск приложения. История запусков хранится на устройстве и НИКОГДА не обнуляется:
// когда запусков становится больше 200, самые старые сворачиваются в общий итог (кадры и лаги не теряются).
object Perf {
    const val BUILD = "n0.62"
    const val LAG_NS = 25_000_000L

    class Run(val t: Long, var frames: Long, var lags: Long, var worstMs: Int)

    val runs = ArrayList<Run>()
    private var oldFrames = 0L
    private var oldLags = 0L
    private var oldRuns = 0
    private var started = false
    private var cur: Run? = null

    // живые показатели (обновляются раз в 60 кадров)
    @Volatile var fps = 0
    @Volatile var hz = 0
    @Volatile var worstMs = 0
    @Volatile var lags10s = 0

    fun start(ctx: Context) {
        if (started) return
        started = true
        runCatching {
            val o = JSONObject(ctx.getSharedPreferences("ms", Context.MODE_PRIVATE).getString("perf", "{}") ?: "{}")
            oldFrames = o.optLong("of"); oldLags = o.optLong("ol"); oldRuns = o.optInt("on")
            val a = o.optJSONArray("r") ?: JSONArray()
            for (i in 0 until a.length()) {
                val r = a.getJSONObject(i)
                runs.add(Run(r.optLong("t"), r.optLong("f"), r.optLong("l"), r.optInt("w")))
            }
        }
        val r = Run(System.currentTimeMillis(), 0, 0, 0)
        runs.add(r)
        cur = r
    }

    fun frame(dNs: Long) {
        val r = cur ?: return
        r.frames++
        if (dNs > LAG_NS) r.lags++
        val ms = (dNs / 1_000_000L).toInt()
        if (ms > r.worstMs) r.worstMs = ms
    }

    fun save(ctx: Context) {
        if (!started) return
        runCatching {
            while (runs.size > 200) { val x = runs.removeAt(0); oldFrames += x.frames; oldLags += x.lags; oldRuns++ }
            val a = JSONArray()
            runs.forEach { a.put(JSONObject().put("t", it.t).put("f", it.frames).put("l", it.lags).put("w", it.worstMs)) }
            val o = JSONObject().put("of", oldFrames).put("ol", oldLags).put("on", oldRuns).put("r", a)
            ctx.getSharedPreferences("ms", Context.MODE_PRIVATE).edit().putString("perf", o.toString()).apply()
        }
    }

    val totalFrames: Long get() = oldFrames + runs.sumOf { it.frames }
    val totalLags: Long get() = oldLags + runs.sumOf { it.lags }
    val totalRuns: Int get() = oldRuns + runs.size

    // лагов на 1000 кадров за последние n запусков (пустые запуски не считаются)
    fun rate(n: Int): Double {
        val l = runs.filter { it.frames > 0 }.takeLast(n)
        val f = l.sumOf { it.frames }
        return if (f == 0L) 0.0 else l.sumOf { it.lags } * 1000.0 / f
    }
    fun lagsLast(n: Int): Long = runs.filter { it.frames > 0 }.takeLast(n).sumOf { it.lags }
}

// Тихий сборщик: ничего не рисует, не меняет состояние на каждом кадре
@Composable
fun PerfCollector() {
    val ctx = LocalContext.current.applicationContext
    val view = LocalView.current
    LaunchedEffect(Unit) {
        Perf.start(ctx)
        var last = 0L
        var n = 0
        var sum = 0L
        var worst = 0L
        var lastSave = 0L
        val lags = ArrayDeque<Long>()
        while (true) {
            val t = withFrameNanos { it }
            if (last != 0L) {
                val d = t - last
                if (d < 500_000_000L) {
                    sum += d
                    n++
                    Perf.frame(d)
                    if (d > Perf.LAG_NS) lags.addLast(t)
                    if (d > worst) worst = d
                }
            }
            last = t
            while (lags.isNotEmpty() && t - lags.first() > 10_000_000_000L) lags.removeFirst()
            if (n >= 60) {
                Perf.fps = (1e9 * n / sum).toInt()
                Perf.hz = view.display?.refreshRate?.toInt() ?: 0
                Perf.worstMs = (worst / 1_000_000L).toInt()
                Perf.lags10s = lags.size
                n = 0; sum = 0L; worst = 0L
            }
            if (lastSave == 0L) lastSave = t
            if (t - lastSave > 30_000_000_000L) { Perf.save(ctx); lastSave = t }
        }
    }
}
