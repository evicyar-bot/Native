package app.megastudiya.nativeapp

import android.content.Context
import org.json.JSONObject
import kotlin.math.pow
import kotlin.math.sqrt

// Вкус: интерес к темам и источникам считается на самом телефоне и никуда не уходит.
// Сигналы копятся (открыл, дочитал, нравится), снижаются (скрыл, не нравится) и раз в сутки чуть забываются.
// Вся логика ленты: оценка = интерес × 0,5^(возраст / 24 ч) + немного случайности.
object Taste {
    private val w = HashMap<String, Float>()
    private val full = HashMap<String, String>() // основа слова (6 букв) -> целое слово, чтобы искать по нему в новостях
    private var loaded = false
    private val stop = setOf(
        "после", "который", "которые", "которая", "также", "только", "этого", "когда", "более", "между", "через", "будет",
        "может", "стали", "своих", "почему", "сообщил", "заявил", "рассказал", "сказал", "новый", "новые", "новая", "около",
        "перед", "этом", "этой", "этот", "были", "было", "была", "очень", "чтобы", "пока", "если", "стало", "после", "время"
    )
    private val tagRe = Regex("#([\\p{L}\\d_]{2,})")
    private val wordRe = Regex("\\p{L}{5,}")

    // Тема материала: по источнику (самое дешёвое и надёжное). Темы копят свой интерес отдельно от слов.
    private val topicOf = mapOf(
        "Forbes" to "Бизнес", "Ведомости" to "Бизнес", "РБК" to "Бизнес", "Коммерсантъ" to "Бизнес", "Bloomberg" to "Бизнес", "The Economist" to "Бизнес",
        "Designboom" to "Дизайн", "ArchDaily" to "Дизайн", "Robb Report" to "Статус",
        "Nature" to "Наука", "Quanta" to "Наука", "N+1" to "Наука", "Naked Science" to "Наука",
        "NASA" to "Космос", "Википедия" to "Знания", "Met Museum" to "Искусство", "Atlas Obscura" to "Мир", "Colossal" to "Искусство", "PetaPixel" to "Фото", "Aeon" to "Идеи"
    )
    fun topic(src: String): String = if (src.startsWith("Новости: ")) src.removePrefix("Новости: ") else topicOf[src] ?: "Другое"

    // Контент ищет вас: любимые темы (интерес выше нуля) превращаются в поисковые запросы к новостям
    private val queries = mapOf(
        "Бизнес" to listOf("бизнес стратегия компании", "инвестиции и рынки", "предпринимательство история успеха"),
        "Дизайн" to listOf("дизайн интерьера", "современная архитектура", "промышленный дизайн"),
        "Наука" to listOf("научное открытие", "исследование учёные", "технологии будущего медицина"),
        "Космос" to listOf("космос астрономия", "телескоп открытие", "исследование планет"),
        "Мир" to listOf("путешествия необычные места", "города мира", "культура и традиции"),
        "Искусство" to listOf("выставка современное искусство", "музей коллекция", "художник новая работа"),
        "Фото" to listOf("фотография выставка", "фотограф проект", "документальная фотография"),
        "Идеи" to listOf("философия идеи", "психология мышление", "как устроено общество наука"),
        "Статус" to listOf("часы люкс коллекция", "яхты и автомобили премиум", "мода дом высокая")
    )
    fun likedTopics(ctx: Context): List<String> {
        load(ctx)
        return w.entries.filter { it.key.startsWith("top:") && it.value > 0.3f }.sortedByDescending { it.value }.take(3).map { it.key.removePrefix("top:") }
    }
    private val fixedTopics: Set<String> by lazy { queries.keys + topicOf.values + setOf("Другое", "Мои") }
    // Для готовых тем берём заготовленные запросы, для тем «из слов» запросом служит само слово
    fun query(topic: String, k: Int): String? = queries[topic]?.let { it[k % it.size] } ?: topic.takeIf { it !in fixedTopics && it.length >= 3 }

    // Темы «из слов»: слова и хэштеги, к которым накопился интерес, сами становятся запросами.
    // Берём по два из шести самых сильных, по кругу (k), чтобы каждое обновление приносило новое.
    fun wordQueries(ctx: Context, k: Int): List<String> {
        load(ctx)
        val top = w.entries
            .filter { !it.key.startsWith("src:") && !it.key.startsWith("top:") && it.value >= 1.5f }
            .sortedByDescending { it.value }.take(6)
            .map { e -> if (e.key.startsWith("#")) e.key.drop(1) else full[e.key] ?: e.key }
            .filter { it.length >= 4 }
        if (top.isEmpty()) return emptyList()
        return (0 until minOf(2, top.size)).map { top[(k * 2 + it) % top.size] }.distinct()
    }

    // Для экспорта: живое состояние вкуса (с учётом забывания) и память о целых словах
    fun snapshot(ctx: Context): Pair<String, String> {
        load(ctx)
        val o = JSONObject(); w.forEach { (k, v) -> o.put(k, v.toDouble()) }
        val f = JSONObject(); full.forEach { (k, v) -> f.put(k, v) }
        return o.toString() to f.toString()
    }

    // Для импорта: сливаем с тем, что есть. По каждому ключу остаётся более сильный интерес.
    fun merge(ctx: Context, taste: String, fullJson: String): Int {
        load(ctx)
        var n = 0
        runCatching {
            val o = JSONObject(taste)
            o.keys().forEach { k ->
                val v = o.getDouble(k).toFloat()
                val c = w[k]
                if (c == null || kotlin.math.abs(v) > kotlin.math.abs(c)) { w[k] = v.coerceIn(-6f, 6f); n++ }
            }
        }
        runCatching {
            val f = JSONObject(fullJson)
            f.keys().forEach { k -> if (k !in full) full[k] = f.getString(k) }
        }
        save(ctx)
        return n
    }

    fun keyOf(x: Any): String = if (x is Post) "p" + x.id else "n" + (x as NewsItem).link

    private fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val p = ctx.getSharedPreferences("ms", Context.MODE_PRIVATE)
        runCatching {
            val o = JSONObject(p.getString("taste", "{}") ?: "{}")
            val t = p.getLong("tasteT", System.currentTimeMillis())
            val days = ((System.currentTimeMillis() - t) / 86_400_000L).toInt().coerceAtLeast(0)
            val k = 0.97f.pow(days)
            o.keys().forEach { key -> w[key] = o.getDouble(key).toFloat() * k }
        }
        runCatching {
            val f = JSONObject(p.getString("tasteFull", "{}") ?: "{}")
            f.keys().forEach { key -> full[key] = f.getString(key) }
        }
    }

    private fun save(ctx: Context) {
        if (w.size > 300) { // оставляем самые сильные
            val keep = w.entries.sortedByDescending { kotlin.math.abs(it.value) }.take(240).map { it.key }.toSet()
            w.keys.retainAll(keep)
        }
        val o = JSONObject()
        w.forEach { (k, v) -> o.put(k, v.toDouble()) }
        if (full.size > 400) full.keys.retainAll(w.keys)
        val f = JSONObject()
        full.forEach { (k, v) -> f.put(k, v) }
        ctx.getSharedPreferences("ms", Context.MODE_PRIVATE).edit().putString("taste", o.toString()).putString("tasteFull", f.toString()).putLong("tasteT", System.currentTimeMillis()).apply()
    }

    fun tags(text: String): List<String> {
        val out = LinkedHashSet<String>()
        tagRe.findAll(text).forEach { out.add("#" + it.groupValues[1].lowercase()) }
        wordRe.findAll(text.lowercase()).forEach { if (it.value !in stop) out.add(it.value.take(6)) }
        return out.take(24)
    }

    // d > 0 нравится, d < 0 не нравится
    fun add(ctx: Context, text: String, src: String, d: Float) {
        load(ctx)
        for (t in tags(text)) w[t] = ((w[t] ?: 0f) + d).coerceIn(-6f, 6f)
        if (d > 0f) wordRe.findAll(text.lowercase()).forEach { if (it.value !in stop) full[it.value.take(6)] = it.value }
        w["src:$src"] = ((w["src:$src"] ?: 0f) + d * 0.5f).coerceIn(-6f, 6f)
        if (src.isNotEmpty()) { val k = "top:" + topic(src); w[k] = ((w[k] ?: 0f) + d * 0.4f).coerceIn(-6f, 6f) }
        save(ctx)
    }

    private fun noise(key: String): Float = (((key.hashCode() * 2654435761L) ushr 8) and 0xFFFF).toFloat() / 65535f * 0.15f

    private class Ent(val x: Any, val src: String, val topic: String, val s: Float, val explore: Boolean)

    fun rank(ctx: Context, all: List<Any>): List<Any> {
        load(ctx)
        val now = System.currentTimeMillis()
        val seen = HashSet<String>()
        val l = ArrayList<Ent>()
        for (x in all) {
            val key = keyOf(x)
            if (!seen.add(key)) continue // дубли отбрасываем
            val text: String; val src: String; val ts: Long; val boost: Float
            if (x is Post) { text = x.text; src = x.author; ts = x.ts; boost = if (x.mine) 0.6f else 0f }
            else { val n = x as NewsItem; text = n.title + " " + n.desc.take(200); src = n.src; ts = n.ts; boost = 0f }
            val tg = tags(text)
            var si = 0f
            for (t in tg) si += w[t] ?: 0f
            if (tg.isNotEmpty()) si /= sqrt(tg.size.toFloat())
            si += w["src:$src"] ?: 0f
            val top = if (x is Post) "Мои" else topic(src)
            val tw = w["top:$top"] ?: 0f
            si += tw * 0.6f
            if (si < -2.5f && x !is Post) continue // то, что ты не любишь, больше не показываем
            // картинка важнее: «сначала глаза» как в Инстаграме
            if (x is NewsItem && x.img.isNotEmpty()) si += 0.25f
            val age = ((now - ts) / 3_600_000f).coerceAtLeast(0f)
            l.add(Ent(x, src, top, (1f + si + boost).coerceAtLeast(0.05f) * 0.5f.pow(age / 24f) + noise(key), x !is Post && kotlin.math.abs(tw) < 0.4f))
        }
        l.sortByDescending { it.s }
        // разбавление: не больше двух подряд из одного источника и трёх из одной темы;
        // каждое пятое место отдано «исследованию»: теме, к которой интерес ещё не сложился (как «Рекомендации» в Инстаграме)
        val out = ArrayList<Any>(l.size)
        val rest = ArrayList(l)
        var last = ""; var run = 0
        var lastT = ""; var runT = 0
        while (rest.isNotEmpty()) {
            var i = 0
            if (out.size % 5 == 4) { val e = rest.indexOfFirst { it.explore && it.src != last && it.topic != lastT }; if (e >= 0) i = e }
            else if (run >= 2 || runT >= 3) { i = rest.indexOfFirst { it.src != last && it.topic != lastT }; if (i < 0) i = rest.indexOfFirst { it.src != last }; if (i < 0) i = 0 }
            val e = rest.removeAt(i)
            run = if (e.src == last) run + 1 else 1
            runT = if (e.topic == lastT) runT + 1 else 1
            last = e.src; lastT = e.topic
            out.add(e.x)
        }
        return out
    }
}
