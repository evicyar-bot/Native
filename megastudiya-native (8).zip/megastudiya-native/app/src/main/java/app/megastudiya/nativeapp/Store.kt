package app.megastudiya.nativeapp

import android.content.Context
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

data class Post(val id: String, val author: String, val text: String, val ts: Long, val mine: Boolean = false, val aid: String = "", val pub: Boolean = true)

// Локальное хранилище: копия лежит в закрытой папке приложения, сети нет.
object Store {
    val posts = mutableStateListOf<Post>()
    var name by mutableStateOf("")
        private set
    var draft by mutableStateOf("")
        private set
    var follows: Set<String> = emptySet()
        private set
    var meId: String = ""
        private set
    private var imported = listOf<Post>()
    private val mine = ArrayList<Post>()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ms", Context.MODE_PRIVATE)

    fun setName(ctx: Context, v: String) {
        name = v.take(40)
        prefs(ctx).edit().putString("name", name).apply()
    }

    fun setDraft(ctx: Context, v: String) {
        draft = v
        prefs(ctx).edit().putString("draft", v).apply()
    }

    // pub = false: «только мне», пост остаётся личным и не уходит в публичное поле.
    fun publish(ctx: Context, pub: Boolean = true) {
        val t = draft.trim()
        if (t.isEmpty()) return
        val ts = System.currentTimeMillis()
        mine.add(Post("m$ts", name.ifBlank { "Я" }, t, ts, true, "", pub))
        saveMine(ctx)
        setDraft(ctx, "")
        rebuild()
    }

    fun delete(ctx: Context, id: String) {
        if (mine.removeAll { it.id == id }) { saveMine(ctx); rebuild() }
    }

    // Отозвать из публичного поля (pub = false) или сделать публичным (pub = true).
    fun setPub(ctx: Context, id: String, pub: Boolean) {
        val i = mine.indexOfFirst { it.id == id }
        if (i < 0) return
        mine[i] = mine[i].copy(pub = pub)
        saveMine(ctx); rebuild()
    }

    // Запись «всё или ничего»: пишем во временный файл, сбрасываем на диск, затем подменяем.
    // Прошлая целая версия остаётся в .bak. Обрыв питания или убийство процесса не портят файл.
    private fun writeAtomic(f: File, text: String) {
        try {
            val tmp = File(f.parentFile, f.name + ".tmp")
            FileOutputStream(tmp).use { it.write(text.toByteArray(Charsets.UTF_8)); it.fd.sync() }
            val bak = File(f.parentFile, f.name + ".bak")
            try {
                if (f.exists()) Files.move(f.toPath(), bak.toPath(), StandardCopyOption.REPLACE_EXISTING)
            } catch (_: Throwable) {
            }
            try {
                Files.move(tmp.toPath(), f.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
            } catch (_: Throwable) {
                if (!tmp.renameTo(f)) f.writeText(text)
            }
        } catch (_: Throwable) {
        }
    }

    // Читаем основной файл; если он битый или пропал, берём прошлую копию.
    private fun <T> readSafe(f: File, parse: (String) -> T): T? {
        for (c in listOf(f, File(f.parentFile, f.name + ".bak"))) {
            try {
                if (c.exists()) return parse(c.readText())
            } catch (_: Throwable) {
            }
        }
        return null
    }

    private fun saveMine(ctx: Context) {
        val a = JSONArray()
        mine.forEach { a.put(JSONObject().put("id", it.id).put("author", it.author).put("text", it.text).put("ts", it.ts).put("pub", it.pub)) }
        writeAtomic(File(ctx.filesDir, "my.json"), a.toString())
    }

    private fun rebuild() {
        val all = ArrayList<Post>(imported.size + mine.size)
        all.addAll(imported)
        all.addAll(mine)
        all.sortByDescending { it.ts }
        val ids = HashSet<String>()
        all.retainAll { ids.add(it.id) }
        posts.clear()
        posts.addAll(all)
    }

    fun load(ctx: Context) {
        name = prefs(ctx).getString("name", "") ?: ""
        draft = prefs(ctx).getString("draft", "") ?: ""
        readSafe(File(ctx.filesDir, "my.json")) { raw ->
            val a = JSONArray(raw)
            val out = ArrayList<Post>(a.length())
            for (i in 0 until a.length()) {
                val p = a.optJSONObject(i) ?: continue
                try {
                    out.add(Post(p.getString("id"), p.getString("author"), p.getString("text"), p.getLong("ts"), true, "", p.optBoolean("pub", true)))
                } catch (_: Throwable) {
                }
            }
            out
        }?.let { mine.clear(); mine.addAll(it.distinctBy { p -> p.id }) } // повторный запуск экрана не должен удваивать посты
        rebuild()
        readSafe(File(ctx.filesDir, "copy.json")) { JSONObject(it) }?.let {
            try {
                apply(it)
            } catch (_: Throwable) {
            }
        }
    }

    // Файл «Копия» из старого приложения: либо зашифрованный (enc=1), либо обычный.
    // Бросает исключение при неверном пароле или чужом файле.
    fun parse(raw: String, pw: String): JSONObject {
        val o = JSONObject(raw)
        if (!o.has("enc")) return o
        val salt = Base64.decode(o.getString("salt"), Base64.DEFAULT)
        val iv = Base64.decode(o.getString("iv"), Base64.DEFAULT)
        val ct = Base64.decode(o.getString("data"), Base64.DEFAULT)
        val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pw.toCharArray(), salt, 250000, 256)).encoded
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return JSONObject(String(c.doFinal(ct), Charsets.UTF_8))
    }


    // ===== Экспорт: всё приложение одним файлом, чтобы оно переехало вместе с нами =====
    // В файле: свои посты, полученная «копия» (чужие посты), вкус ленты (интеллектуальная часть),
    // скрытые источники и материалы, имя, город, звук/осадки. Всё шифруется паролем (AES-GCM, как в старом приложении).
    // Замеры лагов не переносятся: они про конкретное устройство. Ленту и погоду телефон соберёт заново.
    const val COPY_FMT = "ms-native-copy"

    fun isNative(o: JSONObject) = o.optString("fmt") == COPY_FMT

    fun exportAll(ctx: Context, pw: String): String {
        val p = prefs(ctx)
        val o = JSONObject().put("fmt", COPY_FMT).put("v", 2).put("build", Perf.BUILD).put("ts", System.currentTimeMillis())
        val a = JSONArray()
        mine.forEach { a.put(JSONObject().put("id", it.id).put("author", it.author).put("text", it.text).put("ts", it.ts).put("pub", it.pub)) }
        o.put("mine", a)
        readSafe(File(ctx.filesDir, "copy.json")) { JSONObject(it) }?.let { o.put("copy", it) }
        val pr = JSONObject()
        p.getString("name", null)?.let { pr.put("name", it) }
        p.getString("city", null)?.takeIf { it.isNotEmpty() }?.let { pr.put("city", it).put("clat", p.getFloat("clat", 0f).toDouble()).put("clon", p.getFloat("clon", 0f).toDouble()) }
        pr.put("snd", p.getBoolean("snd", true)).put("wx", p.getBoolean("wx", true))
        pr.put("hsrc", JSONArray(p.getStringSet("hsrc", emptySet()) ?: emptySet<String>()))
        pr.put("hlnk", JSONArray(p.getStringSet("hlnk", emptySet()) ?: emptySet<String>()))
        val t = Taste.snapshot(ctx)
        pr.put("taste", t.first).put("tasteFull", t.second)
        o.put("prefs", pr)
        // «Подпись» файла: кто, с какого устройства, когда, что внутри (числа проверяются при импорте)
        val cp = readSafe(File(ctx.filesDir, "copy.json")) { JSONObject(it) }
        o.put("from", JSONObject().put("name", name.ifBlank { "Я" }).put("device", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL)
            .put("build", Perf.BUILD).put("ts", System.currentTimeMillis())
            .put("counts", JSONObject().put("mine", mine.size).put("copy", countPosts(cp))))
        return encrypt(o.toString(), pw)
    }

    private fun encrypt(text: String, pw: String): String {
        val r = java.security.SecureRandom()
        val salt = ByteArray(16).also { r.nextBytes(it) }
        val iv = ByteArray(12).also { r.nextBytes(it) }
        val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pw.toCharArray(), salt, 250000, 256)).encoded
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        val ct = c.doFinal(text.toByteArray(Charsets.UTF_8))
        return JSONObject().put("enc", 1)
            .put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .put("iv", Base64.encodeToString(iv, Base64.NO_WRAP))
            .put("data", Base64.encodeToString(ct, Base64.NO_WRAP)).toString()
    }

    private fun countPosts(o: JSONObject?): Int {
        val a = o?.optJSONArray("posts") ?: return 0
        var n = 0
        for (i in 0 until a.length()) if (!(a.optJSONObject(i)?.optBoolean("del", false) ?: true)) n++
        return n
    }

    // Слияние чужих постов: объединение по id. Удалённое/скрытое/заблокированное в любом из двух остаётся таким.
    // Своя «личность» (me) остаётся ту, что уже была на этом устройстве.
    private fun mergeCopy(a: JSONObject?, b: JSONObject): JSONObject {
        if (a == null) return b
        val out = JSONObject(b.toString())
        fun maps(k: String, bool: Boolean) {
            val x = a.optJSONObject(k); val y = b.optJSONObject(k); val m = JSONObject()
            x?.keys()?.forEach { m.put(it, x.get(it)) }
            y?.keys()?.forEach { key -> if (bool) m.put(key, m.optBoolean(key, false) || y.optBoolean(key, false)) else m.put(key, y.get(key)) }
            out.put(k, m)
        }
        maps("authors", false); maps("follows", true); maps("hidden", true); maps("blocked", true)
        a.optJSONObject("me")?.let { out.put("me", it) }
        val byId = LinkedHashMap<String, JSONObject>()
        fun add(arr: JSONArray?) {
            if (arr == null) return
            for (i in 0 until arr.length()) {
                val p = arr.optJSONObject(i) ?: continue
                var id = p.optString("id")
                if (id.isEmpty()) { id = p.optString("author") + "_" + p.optLong("ts") + "_" + p.optString("text").hashCode(); p.put("id", id) }
                val cur = byId[id]
                if (cur == null) byId[id] = p else if (p.optBoolean("del", false)) cur.put("del", true)
            }
        }
        add(a.optJSONArray("posts")); add(b.optJSONArray("posts"))
        val arr = JSONArray(); byId.values.forEach { arr.put(it) }
        out.put("posts", arr)
        return out
    }

    // Чужие посты из файла (новый или старый формат): сливаются с тем, что уже есть. Возвращает строку для журнала.
    fun commit(ctx: Context, o: JSONObject): String {
        val before = readSafe(File(ctx.filesDir, "copy.json")) { JSONObject(it) }
        val nb = countPosts(before)
        val merged = mergeCopy(before, o)
        writeAtomic(File(ctx.filesDir, "copy.json"), merged.toString())
        apply(merged)
        val na = countPosts(merged)
        return "Чужие посты: было $nb, в файле ${countPosts(o)}, стало $na (новых +${na - nb})"
    }

    // Импорт файла старого приложения («Копия»): тоже сливается и пишется в журнал
    fun importOld(ctx: Context, o: JSONObject): String {
        val line = commit(ctx, o)
        val t = logImport(ctx, "Копия старого приложения", listOf(line))
        return t
    }

    private fun stamp(t: Long) = java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(t))

    // Журнал переезда: кто, откуда, что и как перенесено. Хранится на устройстве, не стирается.
    private fun logImport(ctx: Context, from: String, lines: List<String>): String {
        val now = System.currentTimeMillis()
        runCatching {
            val a = JSONArray(prefs(ctx).getString("implog", "[]") ?: "[]")
            a.put(JSONObject().put("t", now).put("from", from).put("lines", JSONArray(lines)))
            val keep = JSONArray()
            for (i in maxOf(0, a.length() - 100) until a.length()) keep.put(a.get(i))
            prefs(ctx).edit().putString("implog", keep.toString()).apply()
        }
        return (listOf(from) + lines).joinToString("\n")
    }

    fun importLogText(ctx: Context): String {
        val a = runCatching { JSONArray(prefs(ctx).getString("implog", "[]") ?: "[]") }.getOrDefault(JSONArray())
        if (a.length() == 0) return "Пока ничего не переносили. Когда сделаешь импорт, здесь будет видно: когда, от кого, с какого устройства и что именно добавилось."
        val sb = StringBuilder()
        for (i in a.length() - 1 downTo 0) {
            val e = a.getJSONObject(i)
            sb.append(stamp(e.optLong("t"))).append("\n").append(e.optString("from")).append("\n")
            val l = e.optJSONArray("lines")
            if (l != null) for (k in 0 until l.length()) sb.append("• ").append(l.optString(k)).append("\n")
            sb.append("\n")
        }
        return sb.toString().trim()
    }

    // Импорт своей копии (новый формат). Ничего не теряем: свои посты складываются, чужие сливаются по id,
    // вкус сливается (по каждому слову остаётся более сильный интерес), скрытое объединяется.
    // Возвращает отчёт: он же пишется в журнал.
    fun restore(ctx: Context, o: JSONObject): String {
        val L = ArrayList<String>()
        val from = o.optJSONObject("from")
        val cnt = from?.optJSONObject("counts")
        val a = o.optJSONArray("mine")
        var added = 0; var dup = 0
        if (a != null) {
            val have = mine.map { it.id }.toHashSet()
            for (i in 0 until a.length()) {
                val p = a.optJSONObject(i) ?: continue
                try {
                    val id = p.getString("id")
                    if (have.add(id)) { mine.add(Post(id, p.getString("author"), p.getString("text"), p.getLong("ts"), true, "", p.optBoolean("pub", true))); added++ } else dup++
                } catch (_: Throwable) {
                }
            }
            if (added > 0) saveMine(ctx)
        }
        L.add("Свои посты: в файле ${a?.length() ?: 0}, добавлено $added, уже были $dup")
        val cp = o.optJSONObject("copy")
        if (cp != null) L.add(runCatching { commit(ctx, cp) }.getOrDefault("Чужие посты: не удалось прочитать"))
        val pr = o.optJSONObject("prefs")
        if (pr != null) {
            val e = prefs(ctx).edit()
            val nm = pr.optString("name")
            if (name.isBlank() && nm.isNotBlank()) { name = nm.take(40); e.putString("name", name); L.add("Имя: $name") }
            if (pr.has("city") && prefs(ctx).getString("city", "").isNullOrEmpty()) {
                e.putString("city", pr.getString("city")).putFloat("clat", pr.optDouble("clat").toFloat()).putFloat("clon", pr.optDouble("clon").toFloat()).remove("wxt")
                L.add("Город: " + pr.getString("city"))
            }
            e.putBoolean("snd", pr.optBoolean("snd", true)).putBoolean("wx", pr.optBoolean("wx", true))
            e.apply()
            val tn = Taste.merge(ctx, pr.optString("taste", "{}"), pr.optString("tasteFull", "{}"))
            L.add("Вкус ленты: обновлено или добавлено записей $tn")
            val hs = ArrayList<String>(); val hl = ArrayList<String>()
            pr.optJSONArray("hsrc")?.let { for (i in 0 until it.length()) hs.add(it.optString(i)) }
            pr.optJSONArray("hlnk")?.let { for (i in 0 until it.length()) hl.add(it.optString(i)) }
            val hn = News.mergeHidden(ctx, hs, hl)
            L.add("Скрытое: добавлено $hn")
            Snd.init(ctx); WxFx.init(ctx); Place.load(ctx)
        }
        if (cnt != null) {
            val ok = cnt.optInt("mine", -1) == (a?.length() ?: 0) && cnt.optInt("copy", -1) == countPosts(cp)
            L.add(if (ok) "Проверка файла: числа совпали" else "Проверка файла: числа не совпали, файл мог быть повреждён")
        }
        rebuild()
        val src = if (from == null) "Файл без подписи" else
            "От: " + from.optString("name") + " · " + from.optString("device") + " · " + from.optString("build") + " · файл от " + stamp(from.optLong("ts"))
        return logImport(ctx, src, L)
    }

    private fun apply(o: JSONObject) {
        val authors = o.optJSONObject("authors") ?: JSONObject()
        val arr = o.optJSONArray("posts") ?: return
        meId = o.optJSONObject("me")?.optString("id") ?: ""
        val fo = o.optJSONObject("follows") ?: JSONObject()
        follows = fo.keys().asSequence().filter { fo.optBoolean(it, false) }.toSet()
        val hidden = o.optJSONObject("hidden") ?: JSONObject()
        val blocked = o.optJSONObject("blocked") ?: JSONObject()
        val list = ArrayList<Post>(arr.length())
        for (i in 0 until arr.length()) {
            val p = arr.optJSONObject(i) ?: continue
            val a = p.optString("author")
            val id = p.optString("id", i.toString())
            if (p.optBoolean("del", false) || hidden.optBoolean(id, false) || blocked.optBoolean(a, false)) continue
            list.add(Post(id, authors.optString(a, a), p.optString("text"), p.optLong("ts"), false, a))
        }
        imported = list
        rebuild()
    }
}
